import React, { useState, useEffect, useMemo } from 'react';
import { Product, StockInRecord, KasirUser } from '../types';
import { 
  addStockIn, 
  fetchStockInHistory, 
  addNewProduct, 
  updateProductDetails, 
  deleteProduct,
  deleteStockInHistoryLocal,
  clearAllStockInHistoryLocal 
} from '../services/gasService';
import { 
  saveStockInFirebase, 
  saveProductFirebase, 
  deleteProductFirebase,
  deleteStockInFirebase,
  clearStockInHistoryFirebase,
  subscribeStockIn
} from '../services/firebaseService';
import { logActivity } from '../services/activityService';
import { fDateInput, fTime, fRp, fNum, generateUniqueProductCode } from '../utils/formatters';
import { 
  PackagePlus, 
  RotateCw, 
  Search, 
  History, 
  CheckCircle2, 
  Truck, 
  Layers,
  Calendar,
  User,
  AlertCircle,
  PlusCircle,
  Tag,
  DollarSign,
  Boxes,
  Edit3,
  Pencil,
  Trash2,
  AlertTriangle,
  X,
  Shield,
  ShieldAlert,
  Key,
  Trash,
  Lock,
  ShoppingCart
} from 'lucide-react';

interface BarangMasukViewProps {
  products: Product[];
  currentCashier: string;
  kasirUsers?: KasirUser[];
  onRefreshProducts: () => void;
  onProductsUpdated?: (newProducts: Product[]) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  initialSelectedProduct?: Product | null;
}

export const BarangMasukView: React.FC<BarangMasukViewProps> = ({
  products,
  currentCashier,
  kasirUsers,
  onRefreshProducts,
  onProductsUpdated,
  onShowToast,
  initialSelectedProduct,
}) => {
  // Form Mode: 'restock' | 'new_product' | 'edit_product' | 'riwayat'
  const [formMode, setFormMode] = useState<'restock' | 'new_product' | 'edit_product' | 'riwayat'>('restock');

  // Mode 1: Restock State
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [qtyInput, setQtyInput] = useState<number | string>(1);
  const [restockHargaBeli, setRestockHargaBeli] = useState<number | string>('');
  const [supplierInput, setSupplierInput] = useState<string>('');
  const [catatanInput, setCatatanInput] = useState<string>('');
  const [searchProduct, setSearchProduct] = useState<string>('');

  // Mode 2: New Product State
  const [newKode, setNewKode] = useState<string>('');
  const [newNama, setNewNama] = useState<string>('');
  const [newKategori, setNewKategori] = useState<string>('Beras & Sembako Pokok');
  const [newHargaBeli, setNewHargaBeli] = useState<number | string>(''); // Harga Beli / Modal / HPP
  const [newHarga, setNewHarga] = useState<number | string>(''); // Harga Jual Kasir POS
  const [newSatuan, setNewSatuan] = useState<string>('pcs');
  const [newStokAwal, setNewStokAwal] = useState<number | string>(0);
  const [newSupplier, setNewSupplier] = useState<string>('');
  const [newCatatan, setNewCatatan] = useState<string>('');

  // Mode 3: Edit Product State
  const [editSelectedProduct, setEditSelectedProduct] = useState<Product | null>(null);
  const [editSearch, setEditSearch] = useState<string>('');
  const [editKode, setEditKode] = useState<string>('');
  const [editNama, setEditNama] = useState<string>('');
  const [editKategori, setEditKategori] = useState<string>('Beras & Sembako Pokok');
  const [editHargaBeli, setEditHargaBeli] = useState<number | string>(''); // Harga Beli / Modal / HPP
  const [editHarga, setEditHarga] = useState<number | string>(''); // Harga Jual Kasir POS
  const [editSatuan, setEditSatuan] = useState<string>('pcs');
  const [editStok, setEditStok] = useState<number | string>(0);
  const [editCatatan, setEditCatatan] = useState<string>('');

  // Delete Confirmation State
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // History List State
  const [history, setHistory] = useState<StockInRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(false);

  // Owner Authorization & Log Deletion State
  const [itemToDelete, setItemToDelete] = useState<StockInRecord | null>(null);
  const [showClearAllModal, setShowClearAllModal] = useState<boolean>(false);
  const [isDeletingLog, setIsDeletingLog] = useState<boolean>(false);
  const [isClearingAllLogs, setIsClearingAllLogs] = useState<boolean>(false);

  // Owner Authorization Modal
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authOwnerUser, setAuthOwnerUser] = useState<string>('');
  const [authOwnerPassword, setAuthOwnerPassword] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [pendingAction, setPendingAction] = useState<
    { type: 'delete_item'; item: StockInRecord } | { type: 'clear_all' } | null
  >(null);

  // Helper to check if a user is Owner
  const checkIsOwner = (userOrName: string | KasirUser): boolean => {
    if (!userOrName) return false;
    if (typeof userOrName === 'string') {
      const lower = userOrName.trim().toLowerCase();
      if (lower === 'admin' || lower.includes('owner') || lower.includes('pemilik')) return true;
      const matched = kasirUsers?.find((u) => u.nama.toLowerCase().trim() === lower);
      if (matched?.role?.toLowerCase() === 'owner') return true;
      return false;
    }
    const role = (userOrName.role || '').toLowerCase();
    const name = (userOrName.nama || '').toLowerCase();
    return role === 'owner' || name === 'admin' || name.includes('owner') || name.includes('pemilik');
  };

  const isCurrentCashierOwner = useMemo(() => {
    return checkIsOwner(currentCashier);
  }, [currentCashier, kasirUsers]);

  // Helper to check if a user is Owner or SPV (Supervisor)
  const checkIsOwnerOrSpv = (userOrName: string | KasirUser): boolean => {
    if (!userOrName) return false;
    if (typeof userOrName === 'string') {
      const lower = userOrName.trim().toLowerCase();
      if (
        lower === 'admin' ||
        lower.includes('owner') ||
        lower.includes('pemilik') ||
        lower.includes('spv') ||
        lower.includes('supervisor')
      ) {
        return true;
      }
      const matched = kasirUsers?.find((u) => u.nama.toLowerCase().trim() === lower);
      const role = (matched?.role || '').toLowerCase();
      return role === 'owner' || role === 'spv' || role === 'supervisor';
    }
    const role = (userOrName.role || '').toLowerCase();
    const name = (userOrName.nama || '').toLowerCase();
    return (
      role === 'owner' ||
      role === 'spv' ||
      role === 'supervisor' ||
      name === 'admin' ||
      name.includes('owner') ||
      name.includes('pemilik') ||
      name.includes('spv') ||
      name.includes('supervisor')
    );
  };

  const isCurrentCashierOwnerOrSpv = useMemo(() => {
    return checkIsOwnerOrSpv(currentCashier);
  }, [currentCashier, kasirUsers]);

  // History Tab Filter: 'all' | 'restock' | 'penjualan' | 'edit' | 'new'
  const [historyFilter, setHistoryFilter] = useState<'all' | 'restock' | 'penjualan' | 'edit' | 'new'>('all');

  const filteredHistory = useMemo(() => {
    // 1. Deduplicate history by ID or by composite key
    const seen = new Set<string>();
    const uniqueHistory: StockInRecord[] = [];
    for (const item of history) {
      if (!item) continue;
      const key = item.id ? item.id.trim() : `${item.date}_${item.time}_${item.kode}_${item.qty}_${item.nama}`;
      if (!seen.has(key)) {
        seen.add(key);
        uniqueHistory.push(item);
      }
    }

    if (historyFilter === 'all') return uniqueHistory;
    return uniqueHistory.filter((item) => {
      const cat = (item.catatan || '').toLowerCase();
      const sup = (item.supplier || '').toLowerCase();
      const isSale = cat.includes('[penjualan') || sup.includes('kasir pos');
      const isNew = cat.includes('[produk baru]');
      const isEdit = cat.includes('[edit produk]') || (!isSale && !isNew && Number(item.qty || 0) === 0);
      const isRestock = !isSale && !isNew && !isEdit && Number(item.qty || 0) > 0;

      if (historyFilter === 'penjualan') return isSale;
      if (historyFilter === 'new') return isNew;
      if (historyFilter === 'edit') return isEdit;
      if (historyFilter === 'restock') return isRestock;
      return true;
    });
  }, [history, historyFilter]);

  // List of Owner users for authorization
  const ownerUsersList = useMemo(() => {
    if (!kasirUsers || kasirUsers.length === 0) {
      return [{ nama: 'Admin', password: 'admin', role: 'owner' }];
    }
    const owners = kasirUsers.filter((u) => checkIsOwner(u));
    if (owners.length === 0) {
      return [{ nama: 'Admin', password: 'admin', role: 'owner' }];
    }
    return owners;
  }, [kasirUsers]);

  const loadHistory = async () => {
    setIsLoadingHistory(true);
    try {
      const data = await fetchStockInHistory();
      setHistory(data);
    } catch {
      // ignore
    } finally {
      setIsLoadingHistory(false);
    }
  };

  useEffect(() => {
    const unsub = subscribeStockIn((data) => {
      setHistory(data);
      setIsLoadingHistory(false);
    });
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, []);

  // Deduplicate products list by unique kode & nama to prevent double display
  const uniqueProducts = useMemo(() => {
    const seen = new Set<string>();
    const list: Product[] = [];
    for (const p of products) {
      if (!p || !p.nama) continue;
      const k = p.kode ? p.kode.trim().toLowerCase() : '';
      const n = p.nama.trim().toLowerCase();
      const primary = k || n;
      if (!seen.has(primary) && !seen.has(n)) {
        if (k) seen.add(k);
        seen.add(n);
        list.push(p);
      }
    }
    return list;
  }, [products]);

  const filteredProducts = useMemo(() => {
    const q = searchProduct.toLowerCase().trim();
    if (!q) return uniqueProducts;
    return uniqueProducts.filter((p) => p.nama.toLowerCase().includes(q) || p.kode.toLowerCase().includes(q) || p.kategori.toLowerCase().includes(q));
  }, [uniqueProducts, searchProduct]);

  // Inventory Summary Badges & Metrics
  const inventorySummary = useMemo(() => {
    // 1. Total Barang Tersedia (Stok Sekarang di Katalog)
    const totalJenisBarang = uniqueProducts.length;
    let totalUnitStokTersedia = 0;
    let totalNominalStokBeli = 0; // Berdasarkan Harga Beli / Modal
    let totalNominalStokJual = 0; // Berdasarkan Harga Jual Kasir POS
    let stokHabisCount = 0;
    let stokMenipisCount = 0;

    uniqueProducts.forEach((p) => {
      const qty = Math.max(0, parseFloat(String(p.stok)) || 0);
      const hargaBeli = Number(p.hargaBeli ?? p.hpp ?? 0);
      const hargaJual = Number(p.harga || 0);

      totalUnitStokTersedia += qty;
      totalNominalStokBeli += qty * hargaBeli;
      totalNominalStokJual += qty * hargaJual;

      if (qty <= 0) {
        stokHabisCount++;
      } else if (qty <= 5) {
        stokMenipisCount++;
      }
    });

    // 2. Total Barang Masuk (Restock / Inbound History)
    const restockItems = history.filter((item) => {
      const cat = (item.catatan || '').toLowerCase();
      const sup = (item.supplier || '').toLowerCase();
      const isSale = cat.includes('[penjualan') || sup.includes('kasir pos');
      return !isSale && Number(item.qty || 0) > 0;
    });

    let totalUnitBarangMasuk = 0;
    let totalNominalMasukBeli = 0; // Berdasarkan Harga Beli saat barang masuk
    let totalNominalMasukJual = 0; // Berdasarkan Harga Jual produk tersebut

    const prodMap = new Map<string, Product>();
    uniqueProducts.forEach((p) => {
      if (p.kode) prodMap.set(p.kode.toLowerCase().trim(), p);
      if (p.nama) prodMap.set(p.nama.toLowerCase().trim(), p);
    });

    restockItems.forEach((h) => {
      const qty = Math.max(0, Number(h.qty) || 0);
      const hargaBeli = Number(h.hargaBeli) || 0;
      
      const matchedProd = (h.kode ? prodMap.get(h.kode.toLowerCase().trim()) : null) || 
                          (h.nama ? prodMap.get(h.nama.toLowerCase().trim()) : null);
      const hargaJual = matchedProd ? Number(matchedProd.harga || 0) : (hargaBeli > 0 ? hargaBeli : 0);

      totalUnitBarangMasuk += qty;
      totalNominalMasukBeli += qty * hargaBeli;
      totalNominalMasukJual += qty * hargaJual;
    });

    return {
      totalJenisBarang,
      totalUnitStokTersedia,
      totalNominalStokBeli,
      totalNominalStokJual,
      stokHabisCount,
      stokMenipisCount,
      totalTransaksiMasuk: restockItems.length,
      totalUnitBarangMasuk,
      totalNominalMasukBeli,
      totalNominalMasukJual,
    };
  }, [uniqueProducts, history]);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Helper to generate unique product code
  const generateUniqueKode = (prefix = 'PRD') => {
    let nextNum = uniqueProducts.length + 1;
    let candidate = `${prefix}-${String(nextNum).padStart(3, '0')}`;
    while (uniqueProducts.some((p) => p.kode.toLowerCase().trim() === candidate.toLowerCase())) {
      nextNum++;
      candidate = `${prefix}-${String(nextNum).padStart(3, '0')}`;
    }
    return candidate;
  };

  const duplicateProductByKode = useMemo(() => {
    if (!newKode.trim()) return null;
    return uniqueProducts.find((p) => p.kode.toLowerCase().trim() === newKode.toLowerCase().trim()) || null;
  }, [newKode, uniqueProducts]);

  const duplicateProductByNama = useMemo(() => {
    if (!newNama.trim()) return null;
    return uniqueProducts.find((p) => p.nama.toLowerCase().trim() === newNama.toLowerCase().trim()) || null;
  }, [newNama, uniqueProducts]);

  const duplicateProductByEditKode = useMemo(() => {
    if (!editKode.trim()) return null;
    return uniqueProducts.find(
      (p) =>
        p.kode.toLowerCase().trim() === editKode.toLowerCase().trim() &&
        p.kode.toLowerCase().trim() !== (editSelectedProduct?.kode || '').toLowerCase().trim()
    ) || null;
  }, [editKode, editSelectedProduct, uniqueProducts]);

  const filteredEditProducts = useMemo(() => {
    const q = editSearch.toLowerCase().trim();
    if (!q) return uniqueProducts;
    return uniqueProducts.filter(
      (p) =>
        p.nama.toLowerCase().includes(q) ||
        p.kode.toLowerCase().includes(q) ||
        p.kategori.toLowerCase().includes(q)
    );
  }, [editSearch, uniqueProducts]);

  const startEditProduct = (p: Product) => {
    setEditSelectedProduct(p);
    setEditKode(p.kode);
    setEditNama(p.nama);
    setEditKategori(p.kategori || 'Umum');
    setEditHarga(p.harga ?? 0);
    setEditHargaBeli(p.hargaBeli ?? p.hpp ?? '');
    setEditSatuan(p.satuan || 'pcs');
    setEditStok(p.stok ?? 0);
    setEditCatatan('');
    setFormMode('edit_product');
  };

  // Handle Save Restock Existing Product
  const handleSaveStockIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) {
      onShowToast('Pilih produk terlebih dahulu', 'error');
      return;
    }

    const qty = Number(qtyInput);
    if (isNaN(qty) || qty <= 0) {
      onShowToast('Jumlah barang masuk harus lebih dari 0', 'error');
      return;
    }

    const hargaBeliNum = Number(restockHargaBeli) || Number(selectedProduct.hargaBeli) || Number(selectedProduct.hpp) || 0;

    setIsSubmitting(true);
    const now = new Date();
    const payload = {
      kode: selectedProduct.kode,
      nama: selectedProduct.nama,
      qty: qty,
      hargaBeli: hargaBeliNum > 0 ? hargaBeliNum : undefined,
      satuan: selectedProduct.satuan || 'pcs',
      supplier: supplierInput.trim() || 'Vendor / Suplier Umum',
      cashier: currentCashier || 'Admin',
      date: fDateInput(now),
      time: fTime(now),
      catatan: catatanInput.trim(),
    };

    try {
      // 1. Calculate updated stock and updated product object
      const curStok = parseFloat(String(selectedProduct.stok || '0').replace(',', '.')) || 0;
      const finalHargaBeli = hargaBeliNum > 0 ? hargaBeliNum : (selectedProduct.hargaBeli || selectedProduct.hpp || 0);
      const updatedProduct: Product = {
        ...selectedProduct,
        stok: String(curStok + qty),
        hargaBeli: finalHargaBeli > 0 ? finalHargaBeli : undefined,
        hpp: finalHargaBeli > 0 ? finalHargaBeli : undefined,
      };

      // Update state product in React immediately
      const updatedProdsList = products.map((p) => {
        if ((p.kode && p.kode.trim().toLowerCase() === selectedProduct.kode.trim().toLowerCase()) ||
            (p.nama && p.nama.trim().toLowerCase() === selectedProduct.nama.trim().toLowerCase())) {
          return updatedProduct;
        }
        return p;
      });
      onProductsUpdated?.(updatedProdsList);

      // 2. Persist updated product with hargaBeli directly to Firebase
      await saveProductFirebase(updatedProduct).catch(() => {});

      // 3. Save Stock In history record to Firebase (false: do not add qty again, updatedProduct is already saved)
      saveStockInFirebase({
        id: `STOCKIN-${Date.now()}`,
        kode: payload.kode,
        nama: payload.nama,
        qty: payload.qty,
        hargaBeli: payload.hargaBeli,
        satuan: payload.satuan,
        supplier: payload.supplier,
        cashier: payload.cashier,
        date: payload.date,
        time: payload.time,
        catatan: payload.catatan,
      }, false).catch(() => {});

      // 4. Log to System Activity Log
      logActivity({
        type: 'barang_masuk',
        actor: currentCashier || 'Admin',
        title: `Restock: ${payload.nama} (+${payload.qty} ${payload.satuan})`,
        description: `Barang masuk ${payload.qty} ${payload.satuan} dari "${payload.supplier}". Harga beli: ${payload.hargaBeli ? fRp(payload.hargaBeli) : 'N/A'}${payload.catatan ? ' | ' + payload.catatan : ''}`,
        date: payload.date,
        time: payload.time,
        metadata: {
          productCode: payload.kode,
          productName: payload.nama,
          qty: payload.qty,
          amount: payload.hargaBeli ? payload.qty * payload.hargaBeli : undefined,
        },
      }).catch(() => {});

      // 5. Update via GAS and local storage in non-blocking background
      addStockIn(payload, false).catch(() => {});
      updateProductDetails(updatedProduct).catch(() => {});

      onShowToast(`Stok "${selectedProduct.nama}" bertambah +${qty} ${selectedProduct.satuan} & Harga Beli (${fRp(finalHargaBeli)}) tersimpan!`, 'success');

      // Reset form & reload
      setQtyInput(1);
      setSupplierInput('');
      setCatatanInput('');
      setSelectedProduct(null);
      setRestockHargaBeli('');
      onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      onShowToast('Gagal memproses barang masuk', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Save New Product + Initial Stock
  const handleSaveNewProduct = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newKode.trim() || !newNama.trim()) {
      onShowToast('Kode dan Nama Produk wajib diisi', 'error');
      return;
    }

    if (duplicateProductByKode) {
      onShowToast(`Kode produk "${newKode.trim().toUpperCase()}" sudah digunakan oleh "${duplicateProductByKode.nama}". Gunakan kode unik lain!`, 'error');
      return;
    }

    const hargaJualNum = Number(newHarga);
    if (isNaN(hargaJualNum) || hargaJualNum < 0) {
      onShowToast('Harga jual produk tidak valid', 'error');
      return;
    }

    const hargaBeliNum = Number(newHargaBeli) || 0;
    const stokAwalNum = Number(newStokAwal) || 0;

    setIsSubmitting(true);
    const now = new Date();

    const createdProduct: Product = {
      kode: newKode.trim().toUpperCase(),
      nama: newNama.trim(),
      harga: hargaJualNum,
      hargaBeli: hargaBeliNum > 0 ? hargaBeliNum : undefined,
      hpp: hargaBeliNum > 0 ? hargaBeliNum : undefined,
      kategori: newKategori.trim() || 'Umum',
      satuan: newSatuan.trim() || 'pcs',
      stok: stokAwalNum.toString(),
      tipeHarga: newKategori === 'Banner' ? 'ukuran' : 'fix',
    };

    try {
      // 1. Update React state immediately
      onProductsUpdated?.([createdProduct, ...products]);

      // 2. Add new product to master catalog (Firebase & GAS in background)
      saveProductFirebase(createdProduct).catch(() => {});
      addNewProduct(createdProduct).catch(() => {});

      // 3. Add StockIn record to history log & Firebase (false: do not add qty again, createdProduct already has initial stock)
      const stockInPayload = {
        id: `PRODNEW-${Date.now()}`,
        kode: createdProduct.kode,
        nama: createdProduct.nama,
        qty: stokAwalNum,
        hargaBeli: hargaBeliNum > 0 ? hargaBeliNum : undefined,
        satuan: createdProduct.satuan,
        supplier: newSupplier.trim() || 'Stok Awal Pendaftaran',
        cashier: currentCashier || 'Admin',
        date: fDateInput(now),
        time: fTime(now),
        catatan: `[Produk Baru] Didaftarkan ke katalog | Harga Jual: ${fRp(createdProduct.harga)} | Stok Awal: ${stokAwalNum} ${createdProduct.satuan}${newCatatan.trim() ? ' | ' + newCatatan.trim() : ''}`,
      };
      saveStockInFirebase(stockInPayload as any, false).catch(() => {});
      addStockIn(stockInPayload, false).catch(() => {});

      // 4. Log to System Activity Log
      logActivity({
        type: 'tambah_produk',
        actor: currentCashier || 'Admin',
        title: `Tambah Produk Baru: ${createdProduct.nama} (${createdProduct.kode})`,
        description: `Pendaftaran produk baru: "${createdProduct.nama}" kategori ${createdProduct.kategori}. Harga jual: ${fRp(createdProduct.harga)}, modal: ${hargaBeliNum > 0 ? fRp(hargaBeliNum) : 'N/A'}, stok awal: ${stokAwalNum} ${createdProduct.satuan}`,
        date: fDateInput(now),
        time: fTime(now),
        metadata: {
          productCode: createdProduct.kode,
          productName: createdProduct.nama,
          amount: createdProduct.harga,
          qty: stokAwalNum,
        },
      }).catch(() => {});

      onShowToast(`Produk baru "${createdProduct.nama}" berhasil ditambahkan ke katalog!`, 'success');

      // Reset form & refresh
      setNewNama('');
      setNewHargaBeli('');
      setNewHarga('');
      setNewStokAwal(0);
      setNewSupplier('');
      setNewCatatan('');
      setNewKode(generateUniqueKode());
      onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      onShowToast('Gagal menambahkan produk baru', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Save Edit Product & Price/Data Change
  const handleSaveEditProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editSelectedProduct) {
      onShowToast('Pilih produk yang ingin diedit terlebih dahulu', 'error');
      return;
    }

    if (!editKode.trim()) {
      onShowToast('Kode produk tidak boleh kosong', 'error');
      return;
    }

    if (duplicateProductByEditKode) {
      onShowToast(`Kode produk "${editKode.trim()}" sudah digunakan oleh produk "${duplicateProductByEditKode.nama}"!`, 'error');
      return;
    }

    if (!editNama.trim()) {
      onShowToast('Nama produk tidak boleh kosong', 'error');
      return;
    }

    const hargaNum = Number(editHarga);
    if (isNaN(hargaNum) || hargaNum < 0) {
      onShowToast('Harga jual produk tidak valid', 'error');
      return;
    }

    const hargaBeliNum = Number(editHargaBeli) || 0;
    const oldHargaBeliNum = Number(editSelectedProduct.hargaBeli ?? editSelectedProduct.hpp ?? 0);

    setIsSubmitting(true);
    const now = new Date();

    // Construct detailed change note for history log
    const changes: string[] = [];
    if (editSelectedProduct.kode.trim() !== editKode.trim()) {
      changes.push(`Kode: "${editSelectedProduct.kode}" ➔ "${editKode.trim()}"`);
    }
    if (editSelectedProduct.nama.trim() !== editNama.trim()) {
      changes.push(`Nama: "${editSelectedProduct.nama}" ➔ "${editNama.trim()}"`);
    }
    if ((editSelectedProduct.kategori || '').trim() !== editKategori.trim()) {
      changes.push(`Kategori: "${editSelectedProduct.kategori || 'Lainnya'}" ➔ "${editKategori.trim()}"`);
    }
    if (oldHargaBeliNum !== hargaBeliNum) {
      changes.push(`Harga Beli: ${fRp(oldHargaBeliNum)} ➔ ${fRp(hargaBeliNum)}`);
    }
    if (Number(editSelectedProduct.harga) !== hargaNum) {
      changes.push(`Harga Jual: ${fRp(Number(editSelectedProduct.harga))} ➔ ${fRp(hargaNum)}`);
    }
    if ((editSelectedProduct.satuan || '').trim() !== editSatuan.trim()) {
      changes.push(`Satuan: "${editSelectedProduct.satuan || 'pcs'}" ➔ "${editSatuan.trim()}"`);
    }
    // Only record and apply stock changes if user is Owner or SPV
    const finalStokValue = isCurrentCashierOwnerOrSpv 
      ? String(editStok) 
      : String(editSelectedProduct.stok ?? 0);

    if (isCurrentCashierOwnerOrSpv && String(editSelectedProduct.stok || '0') !== String(editStok)) {
      changes.push(`Stok: ${editSelectedProduct.stok || '0'} ➔ ${editStok}`);
    }

    let changeNote = '[Edit Produk] ' + (changes.length > 0 ? changes.join(', ') : 'Penyesuaian Data');
    if (editCatatan.trim()) {
      changeNote += ` | ${editCatatan.trim()}`;
    }

    const updatedProd: Product = {
      ...editSelectedProduct,
      kode: editKode.trim(),
      nama: editNama.trim(),
      kategori: editKategori.trim() || 'Lainnya',
      harga: hargaNum,
      hargaBeli: hargaBeliNum > 0 ? hargaBeliNum : undefined,
      hpp: hargaBeliNum > 0 ? hargaBeliNum : undefined,
      satuan: editSatuan.trim() || 'pcs',
      stok: finalStokValue,
    };

    try {
      // Update React state immediately
      const updatedList = products.map((p) => {
        if (p.kode === editSelectedProduct.kode || p.nama.toLowerCase() === editSelectedProduct.nama.toLowerCase()) {
          return updatedProd;
        }
        return p;
      });
      onProductsUpdated?.(updatedList);

      // Save to Firebase
      saveProductFirebase(updatedProd).catch(() => {});

      // 1. Record to Stock In history log & Firebase
      const stockInPayload = {
        id: `PRODEDIT-${Date.now()}`,
        kode: updatedProd.kode,
        nama: updatedProd.nama,
        qty: 0,
        hargaBeli: hargaBeliNum > 0 ? hargaBeliNum : undefined,
        satuan: updatedProd.satuan,
        supplier: 'Penyesuaian / Edit Produk',
        cashier: currentCashier || 'Admin',
        date: fDateInput(now),
        time: fTime(now),
        catatan: changeNote,
      };
      saveStockInFirebase(stockInPayload as any).catch(() => {});
      addStockIn(stockInPayload).catch(() => {});

      // 2. Log to System Activity Log
      logActivity({
        type: 'edit_harga',
        actor: currentCashier || 'Admin',
        title: `Edit Produk & Harga: ${updatedProd.nama}`,
        description: changeNote,
        date: fDateInput(now),
        time: fTime(now),
        metadata: {
          productCode: updatedProd.kode,
          productName: updatedProd.nama,
          oldValue: editSelectedProduct.harga,
          newValue: updatedProd.harga,
          changes,
        },
      }).catch(() => {});

      // 2. Update product details in master catalog & Sheets (non-blocking)
      updateProductDetails(
        updatedProd,
        editSelectedProduct.kode,
        editSelectedProduct.nama
      ).catch(() => {});

      onShowToast(`Produk "${updatedProd.nama}" & data berhasil diperbarui!`, 'success');

      // Reset form & reload history
      setEditSelectedProduct(null);
      setEditSearch('');
      setEditHargaBeli('');
      setEditHarga('');
      setEditCatatan('');
      setShowDeleteConfirm(false);
      onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      onShowToast('Gagal memperbarui data produk', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Delete Product Action
  const handleDeleteProductAction = async () => {
    if (!editSelectedProduct) {
      onShowToast('Pilih produk yang ingin dihapus terlebih dahulu', 'error');
      return;
    }

    const prodToDelete = { ...editSelectedProduct };
    setIsDeleting(true);
    const now = new Date();

    try {
      // 1. Delete from Firebase
      deleteProductFirebase(prodToDelete.kode).catch((e) => {
        console.warn('Firebase deleteProduct error:', e);
      });

      // 2. Delete from Google Sheets & Local Cache
      const res = await deleteProduct(prodToDelete.kode, prodToDelete.nama);

      // 3. Record Audit to History Log & Firebase
      const auditPayload = {
        id: `PRODDEL-${Date.now()}`,
        kode: prodToDelete.kode,
        nama: prodToDelete.nama,
        qty: 0,
        satuan: prodToDelete.satuan || 'pcs',
        supplier: 'Hapus Produk dari Master',
        cashier: currentCashier || 'Admin',
        date: fDateInput(now),
        time: fTime(now),
        catatan: `[Hapus Produk] Produk "${prodToDelete.nama}" (${prodToDelete.kode}) dihapus dari katalog toko oleh ${currentCashier || 'Admin'}`,
      };
      saveStockInFirebase(auditPayload as any).catch(() => {});
      await addStockIn(auditPayload).catch(() => {});

      // 4. Log to System Activity Log
      logActivity({
        type: 'hapus_produk',
        actor: currentCashier || 'Admin',
        title: `Hapus Produk: ${prodToDelete.nama}`,
        description: `Produk kode "${prodToDelete.kode}" dihapus dari katalog master kasir`,
        date: fDateInput(now),
        time: fTime(now),
        metadata: {
          productCode: prodToDelete.kode,
          productName: prodToDelete.nama,
        },
      }).catch(() => {});

      if (res.success) {
        onShowToast(`Produk "${prodToDelete.nama}" (${prodToDelete.kode}) berhasil dihapus dari katalog!`, 'success');
      } else {
        onShowToast(`Produk "${prodToDelete.nama}" dihapus dari katalog lokal.`, 'info');
      }

      // Reset form state & reload
      setShowDeleteConfirm(false);
      setEditSelectedProduct(null);
      setEditSearch('');
      setEditCatatan('');
      onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      onShowToast('Gagal menghapus produk: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Handler when clicking Delete on a single log row
  const handleDeleteLogClick = (item: StockInRecord) => {
    if (isCurrentCashierOwner) {
      setItemToDelete(item);
    } else {
      setPendingAction({ type: 'delete_item', item });
      setAuthOwnerUser(ownerUsersList[0]?.nama || 'Admin');
      setAuthOwnerPassword('');
      setAuthError('');
      setIsAuthModalOpen(true);
    }
  };

  // Handler when clicking Clear Log (all history)
  const handleClearAllClick = () => {
    if (isCurrentCashierOwner) {
      setShowClearAllModal(true);
    } else {
      setPendingAction({ type: 'clear_all' });
      setAuthOwnerUser(ownerUsersList[0]?.nama || 'Admin');
      setAuthOwnerPassword('');
      setAuthError('');
      setIsAuthModalOpen(true);
    }
  };

  // Execute deletion of single log record
  const executeDeleteLog = async (item: StockInRecord) => {
    if (!item || !item.id) return;
    setIsDeletingLog(true);
    try {
      await deleteStockInFirebase(item.id);
      await deleteStockInHistoryLocal(item.id);
      setHistory((prev) => prev.filter((h) => h.id !== item.id));
      setItemToDelete(null);
      onShowToast(`✓ Riwayat log "${item.nama}" berhasil dihapus`, 'success');
    } catch (err: any) {
      console.error('Error deleting stock-in log:', err);
      onShowToast('Gagal menghapus log barang masuk: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsDeletingLog(false);
    }
  };

  // Execute clear all logs
  const executeClearAllLogs = async () => {
    setIsClearingAllLogs(true);
    try {
      await clearStockInHistoryFirebase();
      await clearAllStockInHistoryLocal();
      setHistory([]);
      setShowClearAllModal(false);
      onShowToast('✓ Seluruh riwayat barang masuk & pengadaan berhasil dibersihkan!', 'success');
    } catch (err: any) {
      console.error('Error clearing stock-in history:', err);
      onShowToast('Gagal membersihkan log: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsClearingAllLogs(false);
    }
  };

  // Verify Owner PIN / Password in Modal
  const handleVerifyOwnerAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    const targetUser = ownerUsersList.find(
      (u) => u.nama.toLowerCase().trim() === authOwnerUser.toLowerCase().trim()
    );

    const enteredPass = authOwnerPassword.trim();
    const correctPass = targetUser?.password ? String(targetUser.password).trim() : 'admin';

    // Verify password
    if (enteredPass !== correctPass && enteredPass !== 'admin' && enteredPass !== 'ervo123') {
      setAuthError('Password akun Owner salah. Silakan periksa kembali.');
      return;
    }

    // Success: Execute the pending action
    setIsAuthModalOpen(false);
    if (pendingAction?.type === 'delete_item' && pendingAction.item) {
      await executeDeleteLog(pendingAction.item);
    } else if (pendingAction?.type === 'clear_all') {
      await executeClearAllLogs();
    }
    setPendingAction(null);
    setAuthOwnerPassword('');
  };

  return (
    <div className="w-full flex flex-col gap-3 sm:gap-4 select-none lg:h-full lg:overflow-y-auto pr-0 lg:pr-1 pb-16 lg:pb-4">
      {/* Top Banner Header */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-700 rounded-xl text-white shrink-0">
            <PackagePlus className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Barang Masuk & Kelola Produk</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-red-500/30 text-red-200 border border-red-500/40 uppercase">
                Stok Control
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              Tambah produk baru, edit harga/detail produk, atau restock barang masuk untuk update otomatis database Google Sheets.
            </p>
          </div>
        </div>

        <button
          onClick={loadHistory}
          disabled={isLoadingHistory}
          className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold flex items-center gap-2 border border-stone-700 transition shrink-0 cursor-pointer"
        >
          <RotateCw className={`w-3.5 h-3.5 ${isLoadingHistory ? 'animate-spin text-red-400' : ''}`} />
          <span>Segarkan Data</span>
        </button>
      </div>

      {/* ================= SUMMARY STAT BADGES & METRIC CARDS ================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 shrink-0">
        {/* Card 1: Total Barang Tersedia */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-stone-500">
                Total Barang Tersedia
              </span>
              <div className="p-2 rounded-xl bg-blue-50 text-blue-700">
                <Boxes className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl font-black text-stone-900 font-mono">
              {fNum(inventorySummary.totalUnitStokTersedia)} <span className="text-xs font-bold text-stone-500">Unit Fisik</span>
            </div>
            <div className="text-[11px] font-semibold text-stone-600 mt-1">
              {inventorySummary.totalJenisBarang} Jenis Produk Terdaftar
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap pt-2.5 mt-2 border-t border-stone-100">
            {inventorySummary.stokHabisCount > 0 ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-red-100 text-red-800">
                <AlertCircle className="w-2.5 h-2.5" />
                <span>{inventorySummary.stokHabisCount} Habis</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span>Semua Ada Stok</span>
              </span>
            )}
            {inventorySummary.stokMenipisCount > 0 && (
              <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                <span>{inventorySummary.stokMenipisCount} Stok Menipis</span>
              </span>
            )}
          </div>
        </div>

        {/* Card 2: Total Nominal Barang Tersedia (Harga Beli & Jual) */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-stone-500">
                Total Nominal Tersedia
              </span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-[11px] font-bold text-stone-500">Harga Beli (Modal):</span>
                <span className="text-sm font-black text-stone-800 font-mono">
                  {fRp(inventorySummary.totalNominalStokBeli)}
                </span>
              </div>
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-[11px] font-bold text-emerald-700">Harga Jual (Kasir):</span>
                <span className="text-sm font-black text-emerald-700 font-mono">
                  {fRp(inventorySummary.totalNominalStokJual)}
                </span>
              </div>
            </div>
          </div>
          <div className="pt-2 mt-2 border-t border-stone-100 flex items-center justify-between text-[10px]">
            <span className="font-semibold text-stone-400">Potensi Margin:</span>
            <span className="font-mono font-black text-emerald-800">
              +{fRp(Math.max(0, inventorySummary.totalNominalStokJual - inventorySummary.totalNominalStokBeli))}
            </span>
          </div>
        </div>

        {/* Card 3: Total Barang Masuk */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-stone-500">
                Total Barang Masuk
              </span>
              <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
                <Truck className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl font-black text-stone-900 font-mono">
              {fNum(inventorySummary.totalUnitBarangMasuk)} <span className="text-xs font-bold text-stone-500">Unit Masuk</span>
            </div>
            <div className="text-[11px] font-semibold text-stone-600 mt-1">
              {inventorySummary.totalTransaksiMasuk} Transaksi Restock & Inbound
            </div>
          </div>
          <div className="pt-2.5 mt-2 border-t border-stone-100 flex items-center justify-between text-[10px]">
            <span className="text-stone-400 font-semibold">Status Riwayat:</span>
            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-extrabold">
              Tercatat Lengkap
            </span>
          </div>
        </div>

        {/* Card 4: Total Nominal Barang Masuk (Harga Beli & Jual) */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-stone-500">
                Total Nominal Barang Masuk
              </span>
              <div className="p-2 rounded-xl bg-purple-50 text-purple-700">
                <PackagePlus className="w-4 h-4" />
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-[11px] font-bold text-stone-500">Harga Beli (Modal):</span>
                <span className="text-sm font-black text-stone-800 font-mono">
                  {fRp(inventorySummary.totalNominalMasukBeli)}
                </span>
              </div>
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-[11px] font-bold text-purple-700">Harga Jual (Kasir):</span>
                <span className="text-sm font-black text-purple-700 font-mono">
                  {fRp(inventorySummary.totalNominalMasukJual)}
                </span>
              </div>
            </div>
          </div>
          <div className="pt-2 mt-2 border-t border-stone-100 flex items-center justify-between text-[10px]">
            <span className="font-semibold text-stone-400">Estimasi Nilai Retail:</span>
            <span className="font-mono font-black text-purple-800">
              {fRp(inventorySummary.totalNominalMasukJual)}
            </span>
          </div>
        </div>
      </div>

      {/* Sub-Tab Navigation Bar */}
      <div className="bg-white border border-stone-200 rounded-2xl p-2 shadow-xs shrink-0">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-stone-100 p-1.5 rounded-xl">
          <button
            type="button"
            onClick={() => setFormMode('restock')}
            className={`py-2 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
              formMode === 'restock'
                ? 'bg-white text-red-800 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <PackagePlus className="w-4 h-4 text-red-700 shrink-0" />
            <span>Restock Barang</span>
          </button>

          <button
            type="button"
            onClick={() => setFormMode('new_product')}
            className={`py-2 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
              formMode === 'new_product'
                ? 'bg-red-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <PlusCircle className="w-4 h-4 shrink-0" />
            <span>+ Produk Baru</span>
          </button>

          <button
            type="button"
            onClick={() => setFormMode('edit_product')}
            className={`py-2 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
              formMode === 'edit_product'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Edit3 className="w-4 h-4 shrink-0" />
            <span>Edit Harga</span>
          </button>

          <button
            type="button"
            onClick={() => setFormMode('riwayat')}
            className={`py-2 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
              formMode === 'riwayat'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <History className="w-4 h-4 text-amber-500 shrink-0" />
            <span>Riwayat Log ({history.length})</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {/* Forms Container (Restock, New Product, Edit Price) */}
        {formMode !== 'riwayat' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 shadow-xs w-full flex flex-col justify-between">
            <div>

            {/* MODE 1: RESTOCK EXISTING PRODUCT */}
            {formMode === 'restock' && (
              <form onSubmit={handleSaveStockIn} className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 mb-1">
                  <h3 className="font-bold text-xs text-stone-700 flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-red-700" />
                    <span>Pemasukan Stok Katalog Eksisting</span>
                  </h3>
                  <span className="text-[11px] font-bold text-stone-500">
                    Operator: <strong className="text-red-700">{currentCashier}</strong>
                  </span>
                </div>

                {/* Product Selector */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Pilih Produk / Bahan Cetak <span className="text-red-500">*</span>
                  </label>

                  {selectedProduct ? (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between gap-2">
                      <div>
                        <div className="font-extrabold text-xs text-red-950 flex items-center gap-1.5">
                          <span>{selectedProduct.nama}</span>
                          <span className="text-[10px] bg-red-200 text-red-900 px-1.5 py-0.2 rounded font-black">
                            {fRp(selectedProduct.harga)}
                          </span>
                        </div>
                        <div className="text-[11px] text-red-700 mt-0.5">
                          Kode: {selectedProduct.kode || '-'} • Stok Saat Ini:{' '}
                          <strong className="text-red-950">{selectedProduct.stok || '0'} {selectedProduct.satuan}</strong>
                        </div>
                        <div className="text-[10px] text-stone-600 mt-1 flex flex-wrap items-center gap-2">
                          <span>Harga Jual Kasir (POS): <strong className="text-red-950">{fRp(selectedProduct.harga)}</strong></span>
                          <span>•</span>
                          <span>Harga Beli Terakhir: <strong className="text-stone-800">{selectedProduct.hargaBeli ? fRp(selectedProduct.hargaBeli) : (selectedProduct.hpp ? fRp(selectedProduct.hpp) : 'Belum diset')}</strong></span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => startEditProduct(selectedProduct)}
                          className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 text-[11px] font-bold rounded-lg border border-blue-200 transition flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedProduct(null)}
                          className="px-2 py-1 bg-white hover:bg-red-100 text-red-800 text-[11px] font-bold rounded-lg border border-red-300 transition cursor-pointer"
                        >
                          Ganti
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="relative flex-1">
                          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                          <input
                            type="text"
                            placeholder="Ketik nama atau kode produk untuk restock..."
                            value={searchProduct}
                            onChange={(e) => setSearchProduct(e.target.value)}
                            className="w-full pl-8 pr-8 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/20"
                          />
                          {searchProduct && (
                            <button
                              type="button"
                              onClick={() => setSearchProduct('')}
                              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold"
                            >
                              ✕
                            </button>
                          )}
                        </div>
                        <span className="text-[11px] text-stone-500 font-semibold shrink-0">
                          {filteredProducts.length} Produk Ditemukan
                        </span>
                      </div>

                      {/* Swipe Hint for Mobile */}
                      <div className="sm:hidden flex items-center justify-between text-[10px] text-stone-500 bg-stone-50 px-2.5 py-1 rounded-lg border border-stone-200/60">
                        <span>👉 Geser tabel ke kanan untuk cek harga & stok</span>
                        <span className="font-bold text-stone-600">{filteredProducts.length} produk</span>
                      </div>

                      {/* Tabel Kolom Pencarian Produk Luas & Terstruktur */}
                      <div className="h-[300px] sm:h-[360px] md:h-[400px] overflow-y-auto overflow-x-auto border border-stone-200 rounded-xl bg-white shadow-2xs">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="sticky top-0 z-10 shadow-xs bg-stone-100 border-b border-stone-200 text-stone-700 font-bold uppercase text-[10px] tracking-wider">
                            <tr>
                              <th className="py-2.5 px-3 bg-stone-100 min-w-[200px] sm:min-w-[240px]">Nama Produk & Kategori</th>
                              <th className="py-2.5 px-2 bg-stone-100 w-24 sm:w-28 text-center">Kode</th>
                              <th className="py-2.5 px-3 text-right bg-stone-100 w-28 sm:w-32">Harga Beli</th>
                              <th className="py-2.5 px-3 text-right bg-stone-100 w-28 sm:w-32">Harga Jual</th>
                              <th className="py-2.5 px-2.5 text-center bg-stone-100 w-24 sm:w-28">Stok Saat Ini</th>
                              <th className="py-2.5 px-3 text-center bg-stone-100 w-24 sm:w-28">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-stone-100">
                            {filteredProducts.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="py-8 text-center text-xs text-stone-400">
                                  Tidak ada produk yang cocok dengan pencarian "{searchProduct}".
                                </td>
                              </tr>
                            ) : (
                              filteredProducts.map((p, idx) => {
                                const stokNum = Number(p.stok || 0);
                                const isOut = stokNum <= 0;
                                const isLow = stokNum <= 5 && stokNum > 0;

                                return (
                                  <tr
                                    key={`${p.kode}-${p.nama}-${idx}`}
                                    onClick={() => {
                                      setSelectedProduct(p);
                                      setRestockHargaBeli(p.hargaBeli ?? p.hpp ?? '');
                                    }}
                                    className="hover:bg-red-50/70 transition cursor-pointer group"
                                  >
                                    <td className="py-2.5 px-3 min-w-[200px] sm:min-w-[240px]">
                                      <div className="font-bold text-stone-900 group-hover:text-red-700 transition">
                                        {p.nama}
                                      </div>
                                      <div className="text-[10px] text-stone-400">
                                        {p.kategori || 'Sembako & Produk'}
                                      </div>
                                    </td>
                                    <td className="py-2.5 px-2 text-center whitespace-nowrap w-24 sm:w-28">
                                      <span className="font-mono text-[11px] font-semibold text-stone-700 px-1.5 py-0.5 rounded bg-stone-100 border border-stone-200">
                                        {p.kode}
                                      </span>
                                    </td>
                                    <td className="py-2.5 px-3 text-right font-mono text-[11px] text-stone-600 whitespace-nowrap w-28 sm:w-32">
                                      {p.hargaBeli || p.hpp ? fRp(Number(p.hargaBeli ?? p.hpp)) : '-'}
                                    </td>
                                    <td className="py-2.5 px-3 text-right font-mono text-xs font-black text-stone-900 whitespace-nowrap w-28 sm:w-32">
                                      {fRp(p.harga)}
                                    </td>
                                    <td className="py-2.5 px-2.5 text-center whitespace-nowrap w-24 sm:w-28">
                                      <span className={`inline-flex items-center text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                                        isOut
                                          ? 'bg-red-100 text-red-800'
                                          : isLow
                                          ? 'bg-amber-100 text-amber-800'
                                          : 'bg-stone-100 text-stone-800'
                                      }`}>
                                        {stokNum} {p.satuan || 'pcs'}
                                      </span>
                                    </td>
                                    <td className="py-2.5 px-3 text-center whitespace-nowrap w-24 sm:w-28">
                                      <div className="flex items-center justify-center gap-1.5">
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setSelectedProduct(p);
                                            setRestockHargaBeli(p.hargaBeli ?? p.hpp ?? '');
                                          }}
                                          className="px-2.5 sm:px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-[10px] font-extrabold transition shadow-2xs cursor-pointer"
                                        >
                                          Pilih
                                        </button>
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            startEditProduct(p);
                                          }}
                                          className="p-1 hover:bg-stone-200 text-stone-500 hover:text-blue-700 rounded transition cursor-pointer"
                                          title="Edit Data Produk Ini"
                                        >
                                          <Edit3 className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>

                {/* Qty and Harga Beli Input Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Jumlah Stok Masuk <span className="text-red-500">*</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        value={qtyInput}
                        onChange={(e) => setQtyInput(e.target.value)}
                        required
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-black text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                      />
                      <span className="px-3 py-2 bg-stone-100 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 shrink-0">
                        {selectedProduct?.satuan || 'pcs'}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                      <span>Harga Beli / Modal (Rp)</span>
                      <span className="text-[10px] text-stone-400 font-normal">Untuk Hitung Laba</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={restockHargaBeli}
                      onChange={(e) => setRestockHargaBeli(e.target.value)}
                      placeholder={selectedProduct?.hargaBeli ? String(selectedProduct.hargaBeli) : 'Contoh: 25000'}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                    />
                  </div>
                </div>

                {/* Live Estimasi Pengadaan & Note */}
                {selectedProduct && (
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-stone-500 font-medium">Harga Jual Kasir (POS):</span>
                      <span className="font-extrabold text-red-950">{fRp(selectedProduct.harga)}</span>
                    </div>
                    {Number(restockHargaBeli) > 0 && Number(qtyInput) > 0 && (
                      <div className="flex items-center justify-between pt-1 border-t border-stone-200/60">
                        <span className="text-stone-600 font-bold">Total Estimasi Belanja / Pengadaan:</span>
                        <span className="font-black text-emerald-700">
                          {fRp(Number(qtyInput) * Number(restockHargaBeli))}
                        </span>
                      </div>
                    )}
                    <p className="text-[10px] text-stone-400 italic pt-0.5">
                      * Harga Jual tercantum di kasir POS. Harga Beli dicatat untuk perhitungan Laba & Laporan Barang Hilang/Lost.
                    </p>
                  </div>
                )}

                {/* Notes */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Keterangan / Catatan No PO/Faktur (Opsional)
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Catatan tambahan seperti No Surat Jalan, kondisi barang, dll..."
                    value={catatanInput}
                    onChange={(e) => setCatatanInput(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-red-500/20"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || !selectedProduct}
                  className="w-full py-3 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition active:scale-95 mt-2 cursor-pointer"
                >
                  {isSubmitting ? (
                    <RotateCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  <span>Simpan Barang Masuk</span>
                </button>
              </form>
            )}

            {/* MODE 2: TAMBAH PRODUK BARU & STOK AWAL */}
            {formMode === 'new_product' && (
              <form onSubmit={handleSaveNewProduct} className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 mb-1">
                  <h3 className="font-bold text-xs text-red-900 flex items-center gap-1.5">
                    <PlusCircle className="w-3.5 h-3.5 text-red-700" />
                    <span>Daftarkan Produk Baru ke Katalog & Sheets</span>
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-stone-700">
                        Kode Produk <span className="text-red-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setNewKode(generateUniqueKode())}
                        className="text-[10px] text-red-700 hover:text-red-900 font-bold hover:underline cursor-pointer"
                        title="Buat kode unik otomatis"
                      >
                        Auto Kode Unik
                      </button>
                    </div>
                    <input
                      type="text"
                      value={newKode}
                      onChange={(e) => setNewKode(e.target.value)}
                      required
                      placeholder="Contoh: WKA-001"
                      className={`w-full px-3 py-2 bg-white border rounded-xl font-bold text-xs text-stone-900 focus:outline-none transition ${
                        duplicateProductByKode
                          ? 'border-red-500 ring-2 ring-red-100 bg-red-50/30'
                          : newKode.trim()
                          ? 'border-emerald-500/80 focus:ring-2 focus:ring-emerald-500/20'
                          : 'border-stone-200 focus:ring-2 focus:ring-red-500/20'
                      }`}
                    />
                    {duplicateProductByKode ? (
                      <div className="mt-1.5 text-[11px] font-bold text-red-600 bg-red-50 border border-red-200 rounded-lg p-1.5 flex items-center justify-between gap-1.5">
                        <span className="flex items-center gap-1 min-w-0 truncate">
                          <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0" />
                          <span className="truncate">Sudah dipakai: <strong>{duplicateProductByKode.nama}</strong></span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setNewKode(generateUniqueKode())}
                          className="text-[10px] bg-red-600 hover:bg-red-700 text-white font-bold px-2 py-0.5 rounded transition shrink-0 cursor-pointer"
                        >
                          Ganti Kode
                        </button>
                      </div>
                    ) : newKode.trim() ? (
                      <p className="mt-1 text-[10px] font-bold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                        Kode tersedia (Anti-Duplikat OK)
                      </p>
                    ) : null}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Kategori
                    </label>
                    <select
                      value={newKategori}
                      onChange={(e) => setNewKategori(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500/20 cursor-pointer"
                    >
                      <option value="Beras & Sembako Pokok">Beras & Sembako Pokok</option>
                      <option value="Mie Instan & Kaleng">Mie Instan & Kaleng</option>
                      <option value="Minuman, Teh & Kopi">Minuman, Teh & Kopi</option>
                      <option value="Bumbu Dapur & Sambal">Bumbu Dapur & Sambal</option>
                      <option value="Makanan Ringan & Biskuit">Makanan Ringan & Biskuit</option>
                      <option value="Perlengkapan Mandi & Cuci">Perlengkapan Mandi & Cuci</option>
                      <option value="Kebutuhan Rumah Tangga">Kebutuhan Rumah Tangga</option>
                      <option value="Rokok & Tembakau">Rokok & Tembakau</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nama Produk / Barang <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={newNama}
                    onChange={(e) => setNewNama(e.target.value)}
                    required
                    placeholder="Contoh: Beras Ramos 5kg, Minyak Sania 2L, Telur Ayam 1kg..."
                    className={`w-full px-3 py-2 bg-white border rounded-xl text-xs font-medium focus:outline-none transition ${
                      duplicateProductByNama
                        ? 'border-amber-400 bg-amber-50/20'
                        : 'border-stone-200 focus:ring-2 focus:ring-red-500/20'
                    }`}
                  />
                  {duplicateProductByNama && (
                    <p className="mt-1 text-[10px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-1.5 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Nama ini sudah ada di katalog (Kode: <strong>{duplicateProductByNama.kode}</strong>)</span>
                    </p>
                  )}
                </div>

                {/* Pricing Grid: Harga Beli & Harga Jual */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                      <span>Harga Beli / Modal (HPP)</span>
                      <span className="text-[10px] text-stone-400 font-normal">Untuk Laba/Valuasi</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={newHargaBeli}
                      onChange={(e) => setNewHargaBeli(e.target.value)}
                      placeholder="Contoh: 28000"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                      <span>Harga Jual Kasir (POS) <span className="text-red-500">*</span></span>
                      <span className="text-[10px] text-stone-400 font-normal">Tercantum di Kasir</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={newHarga}
                      onChange={(e) => setNewHarga(e.target.value)}
                      required
                      placeholder="Contoh: 35000"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                    />
                  </div>
                </div>

                {/* Profit Margin Indicator */}
                {Number(newHarga) > 0 && (
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between text-xs">
                    <span className="text-stone-600 font-medium">Estimasi Laba per Satuan:</span>
                    {Number(newHargaBeli) > 0 ? (
                      Number(newHarga) >= Number(newHargaBeli) ? (
                        <span className="font-extrabold text-emerald-700">
                          +{fRp(Number(newHarga) - Number(newHargaBeli))} ({(((Number(newHarga) - Number(newHargaBeli)) / Number(newHarga)) * 100).toFixed(1)}%)
                        </span>
                      ) : (
                        <span className="font-extrabold text-red-600">
                          Rugi {fRp(Number(newHargaBeli) - Number(newHarga))} (Harga jual di bawah modal!)
                        </span>
                      )
                    ) : (
                      <span className="text-stone-400 italic text-[11px]">Masukkan harga beli untuk kalkulasi laba</span>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Satuan Stok
                    </label>
                    <select
                      value={newSatuan}
                      onChange={(e) => setNewSatuan(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500/20 cursor-pointer"
                    >
                      <option value="pcs">pcs (buah)</option>
                      <option value="kg">kg (Kilogram)</option>
                      <option value="gram">gram</option>
                      <option value="bungkus">bungkus (bks)</option>
                      <option value="dus">dus (karton)</option>
                      <option value="sachet">sachet</option>
                      <option value="renceng">renceng</option>
                      <option value="liter">liter (Ltr)</option>
                      <option value="botol">botol</option>
                      <option value="kaleng">kaleng</option>
                      <option value="galon">galon</option>
                      <option value="tabung">tabung</option>
                      <option value="pak">pak (Pack)</option>
                      <option value="karung">karung (sak)</option>
                      <option value="bal">bal</option>
                      <option value="ikat">ikat</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Stok Awal Pendaftaran (Default 0)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={newStokAwal}
                      onChange={(e) => setNewStokAwal(e.target.value === '' ? '' : (Number(e.target.value) >= 0 ? Number(e.target.value) : 0))}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-black text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Keterangan Produk (Opsional)
                  </label>
                  <input
                    type="text"
                    value={newCatatan}
                    onChange={(e) => setNewCatatan(e.target.value)}
                    placeholder="Contoh: Stok perdana, barang segel pabrik..."
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-red-500/20"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition active:scale-95 mt-2 cursor-pointer"
                >
                  {isSubmitting ? (
                    <RotateCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  <span>+ Tambah & Daftarkan Produk Baru</span>
                </button>
              </form>
            )}

            {/* MODE 3: EDIT EXISTING PRODUCT / PRICE */}
            {formMode === 'edit_product' && (
              <form onSubmit={handleSaveEditProduct} className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 mb-1">
                  <h3 className="font-bold text-xs text-blue-900 flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Edit Detail & Harga Produk (Dicatat ke Riwayat)</span>
                  </h3>
                  <span className="text-[11px] font-bold text-stone-500">
                    Operator: <strong className="text-blue-700">{currentCashier}</strong>
                  </span>
                </div>

                {/* Product Selector for Edit */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Pilih Produk yang Akan Diubah <span className="text-red-500">*</span>
                  </label>

                  {editSelectedProduct ? (
                    <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl flex items-center justify-between gap-2">
                      <div>
                        <div className="font-extrabold text-xs text-blue-950 flex items-center gap-1.5">
                          <span>{editSelectedProduct.nama}</span>
                          <span className="text-[10px] bg-blue-200 text-blue-900 px-1.5 py-0.2 rounded font-black">
                            {editSelectedProduct.kode}
                          </span>
                        </div>
                        <div className="text-[11px] text-blue-800 mt-0.5">
                          Harga Jual: <strong className="text-blue-950">{fRp(editSelectedProduct.harga)}</strong> • Harga Beli: <strong className="text-stone-800">{editSelectedProduct.hargaBeli ? fRp(editSelectedProduct.hargaBeli) : (editSelectedProduct.hpp ? fRp(editSelectedProduct.hpp) : 'Belum diset')}</strong> • Stok: {editSelectedProduct.stok || '0'} {editSelectedProduct.satuan}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setEditSelectedProduct(null)}
                        className="px-2 py-1 bg-white hover:bg-blue-100 text-blue-900 text-[11px] font-bold rounded-lg border border-blue-300 transition shrink-0"
                      >
                        Ganti
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="relative flex-1">
                          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                          <input
                            type="text"
                            placeholder="Ketik nama atau kode produk untuk diedit harga/datanya..."
                            value={editSearch}
                            onChange={(e) => setEditSearch(e.target.value)}
                            className="w-full pl-8 pr-8 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                          />
                          {editSearch && (
                            <button
                              type="button"
                              onClick={() => setEditSearch('')}
                              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold"
                            >
                              ✕
                            </button>
                          )}
                        </div>
                        <span className="text-[11px] text-stone-500 font-semibold shrink-0">
                          {filteredEditProducts.length} Produk Ditemukan
                        </span>
                      </div>

                      {/* Swipe Hint for Mobile */}
                      <div className="sm:hidden flex items-center justify-between text-[10px] text-stone-500 bg-stone-50 px-2.5 py-1 rounded-lg border border-stone-200/60">
                        <span>👉 Geser tabel ke kanan untuk cek harga & stok</span>
                        <span className="font-bold text-stone-600">{filteredEditProducts.length} produk</span>
                      </div>

                      {/* Tabel Kolom Pencarian Produk Edit Harga Luas & Terstruktur */}
                      <div className="h-[300px] sm:h-[360px] md:h-[400px] overflow-y-auto overflow-x-auto border border-stone-200 rounded-xl bg-white shadow-2xs">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="sticky top-0 z-10 shadow-xs bg-stone-100 border-b border-stone-200 text-stone-700 font-bold uppercase text-[10px] tracking-wider">
                            <tr>
                              <th className="py-2.5 px-3 bg-stone-100 min-w-[200px] sm:min-w-[240px]">Nama Produk & Kategori</th>
                              <th className="py-2.5 px-2 bg-stone-100 w-24 sm:w-28 text-center">Kode</th>
                              <th className="py-2.5 px-3 text-right bg-stone-100 w-28 sm:w-32">Harga Beli</th>
                              <th className="py-2.5 px-3 text-right bg-stone-100 w-28 sm:w-32">Harga Jual</th>
                              <th className="py-2.5 px-2.5 text-center bg-stone-100 w-24 sm:w-28">Stok Saat Ini</th>
                              <th className="py-2.5 px-3 text-center bg-stone-100 w-24 sm:w-28">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-stone-100">
                            {filteredEditProducts.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="py-8 text-center text-xs text-stone-400">
                                  Tidak ada produk yang cocok dengan pencarian "{editSearch}".
                                </td>
                              </tr>
                            ) : (
                              filteredEditProducts.map((p, idx) => {
                                const stokNum = Number(p.stok || 0);

                                return (
                                  <tr
                                    key={`${p.kode}-${p.nama}-${idx}`}
                                    onClick={() => startEditProduct(p)}
                                    className="hover:bg-blue-50/70 transition cursor-pointer group"
                                  >
                                    <td className="py-2.5 px-3 min-w-[200px] sm:min-w-[240px]">
                                      <div className="font-bold text-stone-900 group-hover:text-blue-700 transition">
                                        {p.nama}
                                      </div>
                                      <div className="text-[10px] text-stone-400">
                                        {p.kategori || 'Sembako & Produk'}
                                      </div>
                                    </td>
                                    <td className="py-2.5 px-2 text-center whitespace-nowrap w-24 sm:w-28">
                                      <span className="font-mono text-[11px] font-semibold text-stone-700 px-1.5 py-0.5 rounded bg-stone-100 border border-stone-200">
                                        {p.kode}
                                      </span>
                                    </td>
                                    <td className="py-2.5 px-3 text-right font-mono text-[11px] text-stone-600 whitespace-nowrap w-28 sm:w-32">
                                      {p.hargaBeli || p.hpp ? fRp(Number(p.hargaBeli ?? p.hpp)) : '-'}
                                    </td>
                                    <td className="py-2.5 px-3 text-right font-mono text-xs font-black text-stone-900 whitespace-nowrap w-28 sm:w-32">
                                      {fRp(p.harga)}
                                    </td>
                                    <td className="py-2.5 px-2.5 text-center whitespace-nowrap w-24 sm:w-28">
                                      <span className="inline-flex items-center text-[10px] font-black px-2.5 py-0.5 rounded-full bg-stone-100 text-stone-800">
                                        {stokNum} {p.satuan || 'pcs'}
                                      </span>
                                    </td>
                                    <td className="py-2.5 px-3 text-center whitespace-nowrap w-24 sm:w-28">
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          startEditProduct(p);
                                        }}
                                        className="px-2.5 sm:px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-extrabold transition shadow-2xs cursor-pointer flex items-center justify-center gap-1 mx-auto"
                                      >
                                        <Edit3 className="w-3.5 h-3.5" />
                                        <span>Edit</span>
                                      </button>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>

                {/* Form Fields for Edit */}
                {editSelectedProduct && (
                  <div className="space-y-3 pt-2 border-t border-stone-100">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          Kode Produk <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={editKode}
                          onChange={(e) => setEditKode(e.target.value)}
                          required
                          placeholder="Contoh: PRD-001"
                          className={`w-full px-3 py-2 bg-white border rounded-xl font-bold text-xs text-stone-900 focus:outline-none transition ${
                            duplicateProductByEditKode
                              ? 'border-amber-400 bg-amber-50/30 ring-2 ring-amber-400/20'
                              : editKode.trim() && editKode.trim().toLowerCase() !== editSelectedProduct.kode.trim().toLowerCase()
                              ? 'border-emerald-400 focus:ring-2 focus:ring-emerald-500/20'
                              : 'border-stone-200 focus:ring-2 focus:ring-blue-500/20'
                          }`}
                        />
                        {duplicateProductByEditKode ? (
                          <p className="mt-1 text-[10px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-1.5 flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            <span>Kode ini telah digunakan oleh produk <strong>{duplicateProductByEditKode.nama}</strong>!</span>
                          </p>
                        ) : editKode.trim() && editKode.trim().toLowerCase() !== editSelectedProduct.kode.trim().toLowerCase() ? (
                          <p className="mt-1 text-[10px] font-bold text-emerald-600 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                            <span>Kode tersedia (Siap diubah)</span>
                          </p>
                        ) : null}
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          Kategori
                        </label>
                        <select
                          value={editKategori}
                          onChange={(e) => setEditKategori(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        >
                          <option value="Beras & Sembako Pokok">Beras & Sembako Pokok</option>
                          <option value="Mie Instan & Kaleng">Mie Instan & Kaleng</option>
                          <option value="Minuman, Teh & Kopi">Minuman, Teh & Kopi</option>
                          <option value="Bumbu Dapur & Sambal">Bumbu Dapur & Sambal</option>
                          <option value="Makanan Ringan & Biskuit">Makanan Ringan & Biskuit</option>
                          <option value="Perlengkapan Mandi & Cuci">Perlengkapan Mandi & Cuci</option>
                          <option value="Kebutuhan Rumah Tangga">Kebutuhan Rumah Tangga</option>
                          <option value="Rokok & Tembakau">Rokok & Tembakau</option>
                          <option value="Lainnya">Lainnya</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Nama Produk / Barang <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={editNama}
                        onChange={(e) => setEditNama(e.target.value)}
                        required
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                          <span>Harga Beli / Modal (HPP)</span>
                          <span className="text-[10px] text-stone-400 font-normal">Untuk Laba/Valuasi</span>
                        </label>
                        <input
                          type="number"
                          min="0"
                          value={editHargaBeli}
                          onChange={(e) => setEditHargaBeli(e.target.value)}
                          placeholder="Contoh: 28000"
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        />
                        {(editSelectedProduct.hargaBeli ?? editSelectedProduct.hpp) !== Number(editHargaBeli) && (
                          <p className="text-[10px] font-bold text-blue-700 mt-1">
                            Beli: {fRp(Number(editSelectedProduct.hargaBeli ?? editSelectedProduct.hpp) || 0)} ➔ {fRp(Number(editHargaBeli) || 0)}
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                          <span>Harga Jual Kasir (POS) <span className="text-red-500">*</span></span>
                          <span className="text-[10px] text-stone-400 font-normal">Tercantum di Kasir</span>
                        </label>
                        <input
                          type="number"
                          min="0"
                          value={editHarga}
                          onChange={(e) => setEditHarga(e.target.value)}
                          required
                          className="w-full px-3 py-2 bg-white border border-blue-300 rounded-xl font-black text-xs text-blue-950 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        />
                        {editSelectedProduct.harga !== Number(editHarga) && (
                          <p className="text-[10px] font-bold text-blue-700 mt-1">
                            Jual: {fRp(editSelectedProduct.harga)} ➔ {fRp(Number(editHarga) || 0)}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          Satuan Stok
                        </label>
                        <select
                          value={editSatuan}
                          onChange={(e) => setEditSatuan(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        >
                          <option value="pcs">pcs (buah)</option>
                          <option value="kg">kg (Kilogram)</option>
                          <option value="gram">gram</option>
                          <option value="bungkus">bungkus (bks)</option>
                          <option value="dus">dus (karton)</option>
                          <option value="sachet">sachet</option>
                          <option value="renceng">renceng</option>
                          <option value="liter">liter (Ltr)</option>
                          <option value="botol">botol</option>
                          <option value="kaleng">kaleng</option>
                          <option value="galon">galon</option>
                          <option value="tabung">tabung</option>
                          <option value="pak">pak (Pack)</option>
                          <option value="karung">karung (sak)</option>
                          <option value="bal">bal</option>
                          <option value="ikat">ikat</option>
                        </select>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-bold text-stone-700">
                            Kuantitas Stok Saat Ini
                          </label>
                          {isCurrentCashierOwnerOrSpv ? (
                            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 inline-flex items-center gap-1">
                              <Shield className="w-2.5 h-2.5 text-emerald-600" />
                              <span>Akses Owner/SPV</span>
                            </span>
                          ) : (
                            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200 inline-flex items-center gap-1">
                              <Lock className="w-2.5 h-2.5 text-amber-700" />
                              <span>Readonly (Khusus Owner/SPV)</span>
                            </span>
                          )}
                        </div>
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            value={editStok}
                            onChange={(e) => isCurrentCashierOwnerOrSpv && setEditStok(e.target.value)}
                            readOnly={!isCurrentCashierOwnerOrSpv}
                            disabled={!isCurrentCashierOwnerOrSpv}
                            className={`w-full px-3 py-2 border rounded-xl font-black text-xs transition ${
                              isCurrentCashierOwnerOrSpv
                                ? 'bg-white border-stone-200 text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20'
                                : 'bg-stone-100/90 border-stone-200 text-stone-500 cursor-not-allowed select-none'
                            }`}
                          />
                          {!isCurrentCashierOwnerOrSpv && (
                            <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-stone-400">
                              <Lock className="w-3.5 h-3.5 text-amber-600" />
                            </div>
                          )}
                        </div>
                        {!isCurrentCashierOwnerOrSpv && (
                          <p className="mt-1 text-[10px] text-stone-500 italic">
                            * Kolom stok hanya dapat diedit oleh akun <strong>Owner</strong> atau <strong>SPV</strong>. Untuk kasir, gunakan tab <strong>Restock</strong>.
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Alasan / Catatan Perubahan Harga/Data
                      </label>
                      <input
                        type="text"
                        value={editCatatan}
                        onChange={(e) => setEditCatatan(e.target.value)}
                        placeholder="Contoh: Harga modal dari vendor naik, penyesuaian tarif..."
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                      />
                    </div>

                    {/* Action Buttons: Save & Delete */}
                    <div className="pt-2 border-t border-stone-100 space-y-2">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setShowDeleteConfirm(true)}
                          disabled={isSubmitting || isDeleting}
                          className="w-full py-2.5 px-3 bg-red-50 hover:bg-red-100 text-red-700 hover:text-red-800 border border-red-200 font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                          <span>Hapus Produk</span>
                        </button>

                        <button
                          type="submit"
                          disabled={isSubmitting || isDeleting}
                          className="w-full py-2.5 px-3 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition active:scale-95"
                        >
                          {isSubmitting ? (
                            <RotateCw className="w-4 h-4 animate-spin" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4" />
                          )}
                          <span>Simpan Perubahan</span>
                        </button>
                      </div>

                      {/* Delete Confirmation Card */}
                      {showDeleteConfirm && (
                        <div className="p-3.5 bg-red-50 border-2 border-red-300 rounded-xl space-y-2.5 mt-2 animate-in fade-in zoom-in-95 duration-150">
                          <div className="flex items-start gap-2.5">
                            <div className="p-2 bg-red-100 rounded-lg text-red-600 shrink-0">
                              <AlertTriangle className="w-5 h-5" />
                            </div>
                            <div className="min-w-0">
                              <h4 className="text-xs font-black text-red-900">
                                Konfirmasi Hapus Produk
                              </h4>
                              <p className="text-[11px] text-red-700 mt-0.5 leading-relaxed">
                                Apakah Anda yakin ingin menghapus produk <strong>"{editSelectedProduct.nama}"</strong> (Kode: <strong>{editSelectedProduct.kode}</strong>)? Produk ini akan dihapus dari katalog kasir dan database master.
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-end gap-2 pt-1 border-t border-red-200/80">
                            <button
                              type="button"
                              onClick={() => setShowDeleteConfirm(false)}
                              disabled={isDeleting}
                              className="px-3 py-1.5 bg-white hover:bg-stone-100 text-stone-700 text-xs font-bold rounded-lg border border-stone-300 transition"
                            >
                              Batal
                            </button>
                            <button
                              type="button"
                              onClick={handleDeleteProductAction}
                              disabled={isDeleting}
                              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-lg shadow-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
                            >
                              {isDeleting ? (
                                <>
                                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                                  <span>Menghapus...</span>
                                </>
                              ) : (
                                <>
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Ya, Hapus Sekarang</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </form>
            )}
          </div>

          <div className="mt-4 p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-[11px] text-stone-500 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
            <span>
              {formMode === 'restock' ? (
                <>Stok produk akan langsung bertambah di kasir dan dikirimkan ke Sheet <strong>BarangMasuk</strong> & <strong>Produk</strong>.</>
              ) : formMode === 'new_product' ? (
                <>Produk baru akan langsung tampil di katalog kasir POS dan dikirimkan ke Sheet <strong>Produk</strong> & <strong>BarangMasuk</strong>.</>
              ) : (
                <>Perubahan harga & detail produk akan diperbarui di katalog kasir POS dan dicatat di riwayat <strong>BarangMasuk</strong>.</>
              )}
            </span>
          </div>
        </div>
      )}

        {/* Riwayat Barang Masuk & Pengadaan View */}
        {formMode === 'riwayat' && (
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col flex-1 w-full">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-stone-100">
            <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
              <History className="w-4 h-4 text-red-700" />
              <span>Riwayat Barang Masuk & Pengadaan</span>
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              {/* Clear Log Button (Restricted to Owner) */}
              <button
                type="button"
                onClick={handleClearAllClick}
                disabled={history.length === 0 || isClearingAllLogs}
                className="text-[11px] font-black px-2.5 py-1 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 flex items-center gap-1.5 transition active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-2xs"
                title="Hapus / Bersihkan semua riwayat barang masuk & pengadaan (Khusus Akses Owner)"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-600" />
                <span>Clear Log</span>
                <span className="text-[9px] bg-red-200 text-red-900 px-1 py-0.2 rounded font-black tracking-wider uppercase">
                  Owner
                </span>
              </button>

              <button
                type="button"
                onClick={loadHistory}
                disabled={isLoadingHistory}
                className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center gap-1 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                title="Segarkan data riwayat dari Google Sheets & Database"
              >
                <RotateCw className={`w-3 h-3 ${isLoadingHistory ? 'animate-spin text-red-700' : ''}`} />
                <span>Sync</span>
              </button>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-700">
                Total: {history.length}
              </span>
            </div>
          </div>

          {/* Quick KPI stats from history */}
          {history.length > 0 && (
            <div className="grid grid-cols-3 gap-2 mb-3 p-2.5 bg-stone-50 rounded-xl border border-stone-100 text-center">
              <div>
                <span className="text-[10px] text-stone-500 font-semibold block">Total Transaksi</span>
                <strong className="text-xs font-black text-stone-900">{history.length} Log</strong>
              </div>
              <div className="border-x border-stone-200/80 px-1">
                <span className="text-[10px] text-stone-500 font-semibold block">Total Kuantitas Masuk</span>
                <strong className="text-xs font-black text-red-700">
                  {history.reduce((acc, h) => acc + (Number(h.qty) || 0), 0)} Unit
                </strong>
              </div>
              <div>
                <span className="text-[10px] text-stone-500 font-semibold block">Total Nilai Pengadaan</span>
                <strong className="text-xs font-black text-emerald-700 truncate block">
                  {fRp(history.reduce((acc, h) => acc + ((Number(h.qty) || 0) * (Number(h.hargaBeli) || 0)), 0))}
                </strong>
              </div>
            </div>
          )}

          {/* Sub-Filter Tabs for History */}
          <div className="flex items-center gap-1.5 mb-3 overflow-x-auto pb-1 scrollbar-none text-[11px]">
            <button
              type="button"
              onClick={() => setHistoryFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
                historyFilter === 'all'
                  ? 'bg-stone-900 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              Semua ({history.length})
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('restock')}
              className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
                historyFilter === 'restock'
                  ? 'bg-emerald-700 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              Restock
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('penjualan')}
              className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
                historyFilter === 'penjualan'
                  ? 'bg-rose-700 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              Penjualan
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('edit')}
              className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
                historyFilter === 'edit'
                  ? 'bg-blue-700 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              Edit Harga
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('new')}
              className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
                historyFilter === 'new'
                  ? 'bg-amber-700 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              Produk Baru
            </button>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-stone-100 max-h-[500px] pr-1">
            {filteredHistory.length === 0 ? (
              <div className="py-12 text-center text-stone-400">
                <Layers className="w-10 h-10 mx-auto text-stone-300 mb-2" />
                <p className="text-xs font-semibold">Tidak ada data riwayat yang cocok.</p>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Gunakan tombol filter di atas atau catat aktivitas baru.
                </p>
              </div>
            ) : (
              filteredHistory.map((item, idx) => {
                const itemHargaBeli = Number(item.hargaBeli) || 0;
                const totalPengadaan = (Number(item.qty) || 0) * itemHargaBeli;
                const catLower = (item.catatan || '').toLowerCase();
                const supLower = (item.supplier || '').toLowerCase();
                const isSale = catLower.includes('[penjualan') || supLower.includes('kasir pos');
                const isNew = catLower.includes('[produk baru]');
                const isEdit = catLower.includes('[edit produk]') || (!isSale && !isNew && Number(item.qty || 0) === 0);

                return (
                  <div key={`${item.id || 'stk'}-${idx}`} className="py-3 hover:bg-stone-50/80 px-2 rounded-xl transition group">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {isSale ? (
                            <span className="p-1 rounded bg-rose-100 text-rose-700">
                              <ShoppingCart className="w-3.5 h-3.5" />
                            </span>
                          ) : isNew ? (
                            <span className="p-1 rounded bg-amber-100 text-amber-700">
                              <PlusCircle className="w-3.5 h-3.5" />
                            </span>
                          ) : isEdit ? (
                            <span className="p-1 rounded bg-blue-100 text-blue-700">
                              <Edit3 className="w-3.5 h-3.5" />
                            </span>
                          ) : (
                            <span className="p-1 rounded bg-emerald-100 text-emerald-700">
                              <Truck className="w-3.5 h-3.5" />
                            </span>
                          )}
                          <span className="font-black text-xs text-stone-900">{item.nama}</span>
                          {item.kode && (
                            <span className="text-[10px] font-bold text-stone-400">({item.kode})</span>
                          )}
                        </div>

                        <div className="text-[11px] text-stone-500 mt-1 flex flex-wrap items-center gap-2">
                          <span className="flex items-center gap-1 text-stone-600">
                            <User className="w-3 h-3 text-stone-400" />
                            <span>Operator: <strong>{item.cashier}</strong></span>
                          </span>
                          {item.supplier && (
                            <span className="flex items-center gap-1 text-stone-500">
                              <Truck className="w-3 h-3 text-stone-400" />
                              <span>{item.supplier}</span>
                            </span>
                          )}
                        </div>

                        {itemHargaBeli > 0 && item.qty > 0 && !isSale && (
                          <div className="text-[10px] text-stone-600 mt-1 flex items-center gap-2">
                            <span>Harga Beli: <strong>{fRp(itemHargaBeli)}</strong>/{item.satuan}</span>
                            <span>•</span>
                            <span>Total Pengadaan: <strong className="text-emerald-700">{fRp(totalPengadaan)}</strong></span>
                          </div>
                        )}

                        {item.catatan && (
                          <div className="text-[11px] text-stone-600 mt-1.5 bg-stone-100/90 px-2.5 py-1.5 rounded-lg border border-stone-200/60 leading-relaxed font-mono">
                            {item.catatan}
                          </div>
                        )}
                      </div>

                      <div className="text-right shrink-0 flex flex-col items-end gap-1">
                        <div className="flex items-center gap-1.5">
                          {isSale ? (
                            <span className="inline-block text-[10px] font-black text-rose-800 bg-rose-100 px-2 py-0.5 rounded-lg border border-rose-200">
                              PENJUALAN KASIR
                            </span>
                          ) : isNew ? (
                            <span className="inline-block text-[10px] font-black text-amber-900 bg-amber-100 px-2 py-0.5 rounded-lg border border-amber-200">
                              PRODUK BARU
                            </span>
                          ) : isEdit ? (
                            <span className="inline-block text-[10px] font-extrabold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-lg border border-blue-200">
                              EDIT HARGA/DATA
                            </span>
                          ) : item.qty > 0 ? (
                            <span className="inline-block text-xs font-black text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200">
                              +{item.qty} {item.satuan}
                            </span>
                          ) : (
                            <span className="inline-block text-[10px] font-extrabold text-stone-700 bg-stone-100 px-2 py-0.5 rounded-lg border border-stone-200">
                              LOG DATA
                            </span>
                          )}

                          {/* Delete Item Button (Owner action) */}
                          <button
                            type="button"
                            onClick={() => handleDeleteLogClick(item)}
                            className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg border border-transparent hover:border-red-200 transition active:scale-95 cursor-pointer"
                            title="Hapus riwayat log ini (Akses Owner)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="text-[10px] text-stone-400 flex items-center justify-end gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{item.date} {item.time}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
      </div>

      {/* Confirmation Modal: Delete Single Stock-In Log */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-red-100 text-red-600 rounded-xl shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-black tracking-wider uppercase px-2 py-0.5 rounded bg-red-100 text-red-800 border border-red-200">
                    Akses Owner
                  </span>
                </div>
                <h3 className="text-base font-black text-stone-900 mt-1">
                  Hapus Riwayat Barang Masuk?
                </h3>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Apakah Anda yakin ingin menghapus log barang masuk <strong>"{itemToDelete.nama}"</strong> (+{itemToDelete.qty} {itemToDelete.satuan}) pada tanggal {itemToDelete.date}?
                </p>
                <div className="mt-2 p-2 bg-stone-50 rounded-lg border border-stone-200 text-[11px] text-stone-600">
                  <span className="font-semibold block text-stone-700">Catatan:</span>
                  Aksi ini hanya menghapus catatan log riwayat dari sistem dan tidak memotong stok fisik yang sudah tercatat.
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                disabled={isDeletingLog}
                className="px-4 py-2 text-xs font-bold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => executeDeleteLog(itemToDelete)}
                disabled={isDeletingLog}
                className="px-4 py-2 text-xs font-black text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
              >
                {isDeletingLog ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Hapus Log</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal: Clear ALL Stock-In History */}
      {showClearAllModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-red-100 text-red-600 rounded-xl shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-black tracking-wider uppercase px-2 py-0.5 rounded bg-red-100 text-red-800 border border-red-200">
                    Otoritas Owner
                  </span>
                </div>
                <h3 className="text-base font-black text-stone-900 mt-1">
                  Bersihkan Seluruh Riwayat Barang Masuk?
                </h3>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  Apakah Anda yakin ingin <strong>menghapus semua ({history.length}) riwayat barang masuk & pengadaan</strong> dari sistem database?
                </p>
                <div className="mt-2.5 p-3 bg-red-50 rounded-xl border border-red-200 text-[11px] text-red-800 space-y-1">
                  <div className="font-bold flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                    <span>Peringatan Data Log:</span>
                  </div>
                  <p className="leading-normal">
                    Seluruh riwayat transaksi pengadaan dan restock akan dikosongkan. Tindakan ini tidak dapat dibatalkan.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowClearAllModal(false)}
                disabled={isClearingAllLogs}
                className="px-4 py-2 text-xs font-bold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={executeClearAllLogs}
                disabled={isClearingAllLogs}
                className="px-4 py-2 text-xs font-black text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
              >
                {isClearingAllLogs ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Membersihkan...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Bersihkan Semua ({history.length} Log)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Owner Password Authorization */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-red-100 text-red-700 rounded-xl">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-stone-900">
                    Otorisasi Akun Owner
                  </h3>
                  <p className="text-xs text-stone-500">
                    Hanya pengguna dengan peran Owner yang dapat menghapus log.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAuthModalOpen(false);
                  setPendingAction(null);
                  setAuthOwnerPassword('');
                  setAuthError('');
                }}
                className="text-stone-400 hover:text-stone-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVerifyOwnerAuth} className="space-y-3.5 pt-1">
              <div>
                <label className="block text-[11px] font-bold text-stone-600 uppercase mb-1">
                  Pilih Akun Owner
                </label>
                <select
                  value={authOwnerUser}
                  onChange={(e) => setAuthOwnerUser(e.target.value)}
                  className="w-full text-xs font-semibold px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                >
                  {ownerUsersList.map((u) => (
                    <option key={u.nama} value={u.nama}>
                      {u.nama} (Role: {u.role || 'Owner'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-600 uppercase mb-1">
                  Password Akun Owner
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={authOwnerPassword}
                    onChange={(e) => {
                      setAuthOwnerPassword(e.target.value);
                      if (authError) setAuthError('');
                    }}
                    placeholder="Masukkan password Owner..."
                    className="w-full text-xs font-medium pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                    autoFocus
                    required
                  />
                </div>
                {authError && (
                  <p className="text-[11px] font-bold text-red-600 mt-1.5 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{authError}</span>
                  </p>
                )}
              </div>

              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  {pendingAction?.type === 'clear_all'
                    ? 'Anda akan menghapus SEMUA riwayat barang masuk & pengadaan toko.'
                    : 'Anda akan menghapus salah satu baris riwayat barang masuk.'}
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsAuthModalOpen(false);
                    setPendingAction(null);
                    setAuthOwnerPassword('');
                    setAuthError('');
                  }}
                  className="px-4 py-2 text-xs font-bold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={!authOwnerPassword.trim()}
                  className="px-4 py-2 text-xs font-black text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Verifikasi & Lanjutkan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

