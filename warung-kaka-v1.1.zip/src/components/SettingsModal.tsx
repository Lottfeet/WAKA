import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Settings, 
  Store, 
  Link, 
  CheckCircle2, 
  AlertCircle, 
  RotateCw, 
  Save, 
  PlugZap, 
  ChevronDown,
  Users,
  UserPlus,
  ShieldCheck,
  Lock,
  KeyRound,
  Clock,
  CreditCard,
  Trash2,
  Database,
  Flame,
  Zap,
  ArrowRight,
  SlidersHorizontal,
  Package,
  Palette,
  MapPin,
  Phone,
  Sparkles,
  Tag,
  FileText,
  Hash,
  FileSpreadsheet,
  ExternalLink,
  UploadCloud,
  DownloadCloud,
  CheckCircle,
  PlusCircle,
  Download,
  Upload,
  FileUp,
  FileJson,
  HardDrive
} from 'lucide-react';
import { StoreSettings, KasirUser, Customer, Product, ExpenseRecord, Invoice, StockInRecord } from '../types';
import { getSheetUrl, setSheetUrl, gasGet, updateKasirPassword, deleteKasirUser, initSheetsRemote, saveSettingsRemote, clearLocalCache, getLocalProducts, getLocalStockInHistory } from '../services/gasService';
import { getStoredExpenses } from '../services/expenseService';
import { migrateAllDataToFirebase, deleteKasirUserFirebase, saveKasirUserFirebase, deleteAllDummyDataFirebase, saveStoreSettingsFirebase } from '../services/firebaseService';
import { 
  createWarungSpreadsheet, 
  syncAllToGoogleSheets, 
  pullProductsFromGoogleSheet, 
  getStoredSpreadsheetInfo, 
  setStoredSpreadsheetId, 
  requestGoogleAccessToken, 
  extractSpreadsheetId, 
  getStoredToken
} from '../services/googleSheetsService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StoreSettings;
  kasirList: string[];
  kasirUsers?: KasirUser[];
  customers?: Customer[];
  products?: Product[];
  invoices?: Invoice[];
  onUpdateKasirUsers?: (users: KasirUser[]) => void;
  onUpdateProducts?: (products: Product[]) => void;
  onUpdateCustomers?: (customers: Customer[]) => void;
  onUpdateInvoices?: (invoices: Invoice[]) => void;
  onSaveSettings: (newSettings: StoreSettings) => void;
  onSync: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onOpenAddCustomer?: () => void;
  onOpenGasGuide?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  kasirList = [],
  kasirUsers = [],
  customers = [],
  products = [],
  invoices = [],
  onUpdateKasirUsers,
  onUpdateProducts,
  onUpdateCustomers,
  onUpdateInvoices,
  onSaveSettings,
  onSync,
  onShowToast,
  onOpenAddCustomer,
  onOpenGasGuide,
}) => {
  const [url, setUrl] = useState(getSheetUrl());
  const [testing, setTesting] = useState(false);
  const [initializing, setInitializing] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [autoLogoutMin, setAutoLogoutMin] = useState<number>(settings.autoLogoutMinutes ?? 15);
  const [minStockThreshold, setMinStockThreshold] = useState<number>(settings.minStockThreshold ?? 10);
  const [rekeningText, setRekeningText] = useState<string>(settings.rekening || '');

  // Google Sheets Direct OAuth Integration State
  const [sheetInfo, setSheetInfo] = useState(getStoredSpreadsheetInfo());
  const [customSheetInput, setCustomSheetInput] = useState('');
  const [isCreatingSheet, setIsCreatingSheet] = useState(false);
  const [isPushingSheets, setIsPushingSheets] = useState(false);
  const [isPullingSheets, setIsPullingSheets] = useState(false);
  const [isAuthorizingGoogle, setIsAuthorizingGoogle] = useState(false);
  const [googleAuthStatus, setGoogleAuthStatus] = useState<boolean>(!!getStoredToken());

  useEffect(() => {
    if (isOpen) {
      setSheetInfo(getStoredSpreadsheetInfo());
      setGoogleAuthStatus(!!getStoredToken());
    }
  }, [isOpen]);

  // Store Branding & Identity State
  const [storeName, setStoreName] = useState<string>(settings.name || 'WARUNGKU');
  const [storeTagline, setStoreTagline] = useState<string>(settings.tagline || 'Cepat / Tepat / Berkualitas');
  const [storeAddress, setStoreAddress] = useState<string>(settings.address || '');
  const [storePhone, setStorePhone] = useState<string>(settings.phone || '');
  const [storeFooter, setStoreFooter] = useState<string>(settings.footer || 'Terima Kasih Atas Kunjungan Anda');
  const [prefixInvoice, setPrefixInvoice] = useState<string>(settings.prefixInvoice || 'INV');

  // Add & Delete Kasir State & Permission Controls
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<{ type: 'add' | 'delete'; targetKasir?: string } | null>(null);
  const [isAddKasirOpen, setIsAddKasirOpen] = useState(false);
  const [authSpvUser, setAuthSpvUser] = useState('');
  const [authPassword, setAuthPassword] = useState('');

  const [newKasirName, setNewKasirName] = useState('');
  const [newKasirRole, setNewKasirRole] = useState<'Kasir' | 'SPV' | 'Owner'>('Kasir');
  const [newKasirPass, setNewKasirPass] = useState('');
  const [isSavingNewKasir, setIsSavingNewKasir] = useState(false);
  const [deletingKasirName, setDeletingKasirName] = useState<string | null>(null);
  const [kasirToDelete, setKasirToDelete] = useState<string | null>(null);

  // Local Backup State & Handler (JSON)
  const [isExportingBackup, setIsExportingBackup] = useState(false);

  const handleDownloadLocalBackupJSON = () => {
    setIsExportingBackup(true);
    try {
      // 1. Gather all current products
      const localProds = products && products.length > 0 ? products : getLocalProducts();

      // 2. Gather stock-in history
      const localStockIn = getLocalStockInHistory();

      // 3. Gather expenses
      const localExpenses = getStoredExpenses();

      // 4. Gather invoices
      let allInvoices: Invoice[] = invoices && invoices.length > 0 ? invoices : [];
      if (allInvoices.length === 0) {
        try {
          const rawInv = localStorage.getItem('strukku_recent_invoices');
          if (rawInv) allInvoices = JSON.parse(rawInv);
        } catch {}
      }

      // 5. Gather customers
      let allCustomers: Customer[] = customers && customers.length > 0 ? customers : [];
      if (allCustomers.length === 0) {
        try {
          const rawCust = localStorage.getItem('strukku_customers');
          if (rawCust) allCustomers = JSON.parse(rawCust);
        } catch {}
      }

      const now = new Date();
      const pad = (n: number) => String(n).padStart(2, '0');
      const timestampFormatted = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
      const fileTimestamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;

      const backupData = {
        aplikasi: 'WARUNG KAKA POS & SISTEM KASIR',
        tipe: 'BACKUP_DATA_LOKAL',
        versiFormat: '1.0',
        tanggalBackup: timestampFormatted,
        isoTimestamp: now.toISOString(),
        toko: {
          nama: storeName.trim() || settings.name || 'WARUNGKU',
          tagline: storeTagline.trim() || settings.tagline || '',
          alamat: storeAddress.trim() || settings.address || '',
          telepon: storePhone.trim() || settings.phone || '',
          footerNota: storeFooter.trim() || settings.footer || '',
          prefixNota: prefixInvoice.trim() || settings.prefixInvoice || 'INV',
          rekening: rekeningText.trim() || settings.rekening || '',
        },
        ringkasan: {
          totalPelanggan: allCustomers.length,
          totalProduk: localProds.length,
          totalInvoice: allInvoices.length,
          totalPengeluaran: localExpenses.length,
          totalStokMasuk: localStockIn.length,
          totalKasirUsers: kasirUsers.length,
        },
        data: {
          pelanggan: allCustomers,
          produk: localProds,
          invoices: allInvoices,
          pengeluaran: localExpenses,
          stokMasuk: localStockIn,
          kasirUsers: kasirUsers,
          pengaturan: {
            ...settings,
            name: storeName,
            tagline: storeTagline,
            address: storeAddress,
            phone: storePhone,
            footer: storeFooter,
            prefixInvoice: prefixInvoice,
            rekening: rekeningText,
            autoLogoutMinutes: autoLogoutMin,
            minStockThreshold: minStockThreshold,
          },
        },
      };

      const jsonStr = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
      const safeStoreName = (storeName.trim() || 'WARUNGKAKA').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `Backup_${safeStoreName}_${fileTimestamp}.json`;

      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);

      onShowToast(`✓ Berhasil mengunduh Backup Lokal: ${filename} (${allCustomers.length} pelanggan, ${localProds.length} produk, ${allInvoices.length} invoice)`, 'success');
    } catch (err: any) {
      onShowToast(`Gagal mengunduh backup: ${err?.message || 'Terjadi kesalahan'}`, 'error');
    } finally {
      setIsExportingBackup(false);
    }
  };

  // Local Backup Upload & Restore State
  const backupFileInputRef = useRef<HTMLInputElement>(null);
  const [backupFilePreview, setBackupFilePreview] = useState<{
    fileName: string;
    customers: Customer[];
    products: Product[];
    invoices: Invoice[];
    expenses: ExpenseRecord[];
    stockIn: StockInRecord[];
    kasirUsers: KasirUser[];
    settings?: Partial<StoreSettings>;
    dateStr?: string;
    version?: string;
  } | null>(null);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [isRestoringBackup, setIsRestoringBackup] = useState(false);

  const handleBackupFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    e.target.value = '';

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        if (!text) {
          onShowToast('File backup kosong atau tidak dapat dibaca', 'error');
          return;
        }

        const parsed = JSON.parse(text);
        const rootData = parsed.data || parsed;

        // Extract products
        const rawProds = rootData.produk || rootData.products || (Array.isArray(parsed) ? parsed : []);
        const parsedProducts: Product[] = Array.isArray(rawProds) ? rawProds.map((p: any) => ({
          kode: String(p.kode || p.id || '').trim(),
          nama: String(p.nama || p.name || '').trim(),
          harga: Number(p.harga || p.price || 0),
          hargaBeli: p.hargaBeli !== undefined && p.hargaBeli !== null ? Number(p.hargaBeli) : (p.hpp !== undefined && p.hpp !== null ? Number(p.hpp) : undefined),
          hpp: p.hpp !== undefined && p.hpp !== null ? Number(p.hpp) : (p.hargaBeli !== undefined && p.hargaBeli !== null ? Number(p.hargaBeli) : undefined),
          kategori: String(p.kategori || p.category || 'Umum'),
          stok: p.stok !== undefined && p.stok !== null ? String(p.stok) : (p.stock !== undefined && p.stock !== null ? String(p.stock) : '0'),
          satuan: String(p.satuan || p.unit || 'pcs'),
          tipeHarga: p.tipeHarga || 'fix',
        })).filter((p) => p.kode || p.nama) : [];

        // Extract customers
        const rawCust = rootData.pelanggan || rootData.customers || [];
        const parsedCustomers: Customer[] = Array.isArray(rawCust) ? rawCust.map((c: any) => {
          const div = String(c.divisi || c.division || '').trim();
          return {
            nama: String(c.nama || c.name || '').trim(),
            kelas: String(c.kelas || c.class || 'Umum'),
            divisi: div,
            division: div,
            diskon: Number(c.diskon || c.discount || 0),
            telepon: String(c.telepon || c.phone || ''),
            alamat: String(c.alamat || c.address || ''),
            catatan: String(c.catatan || c.notes || ''),
          };
        }).filter((c) => c.nama) : [];

        // Extract invoices
        const rawInv = rootData.invoices || rootData.transaksi || rootData.penjualan || [];
        const parsedInvoices: Invoice[] = Array.isArray(rawInv) ? rawInv.map((inv: any) => {
          const tot = Number(inv.total || 0);
          const dpVal = Number(inv.dp || 0);
          const sisaVal = Number(inv.sisa || 0);
          return {
            invoiceNo: String(inv.invoiceNo || inv.noInvoice || '').trim(),
            noInvoice: String(inv.noInvoice || inv.invoiceNo || '').trim(),
            date: String(inv.date || inv.tanggal || ''),
            time: String(inv.time || inv.jam || ''),
            customer: String(inv.customer || inv.pelanggan || 'Umum'),
            pelanggan: String(inv.pelanggan || inv.customer || 'Umum'),
            cashier: String(inv.cashier || inv.kasir || 'Admin'),
            subtotal: Number(inv.subtotal || tot),
            discPct: Number(inv.discPct || 0),
            discAmt: Number(inv.discAmt || 0),
            taxPct: Number(inv.taxPct || 0),
            taxAmt: Number(inv.taxAmt || 0),
            negoAmt: Number(inv.negoAmt || 0),
            total: tot,
            payMethod: String(inv.payMethod || inv.metodePembayaran || 'Tunai'),
            metodePembayaran: String(inv.metodePembayaran || inv.payMethod || 'Tunai'),
            dp: dpVal,
            sisa: sisaVal,
            kembalian: Number(inv.kembalian || 0),
            deadline: String(inv.deadline || ''),
            status: inv.status || (sisaVal <= 0 ? 'LUNAS' : 'DP'),
            customerPhone: inv.customerPhone,
            customerAddress: inv.customerAddress,
            items: Array.isArray(inv.items) ? inv.items : [],
            pelunasanHistory: Array.isArray(inv.pelunasanHistory) ? inv.pelunasanHistory : (Array.isArray(inv.historiPelunasan) ? inv.historiPelunasan : []),
            historiPelunasan: Array.isArray(inv.historiPelunasan) ? inv.historiPelunasan : (Array.isArray(inv.pelunasanHistory) ? inv.pelunasanHistory : []),
            lastEditedBy: inv.lastEditedBy,
            lastEditedAt: inv.lastEditedAt,
            editReason: inv.editReason,
            auditLogs: Array.isArray(inv.auditLogs) ? inv.auditLogs : [],
            slipNo: inv.slipNo,
            slipPrinted: inv.slipPrinted,
            slipPrintedAt: inv.slipPrintedAt,
          };
        }).filter((inv) => inv.invoiceNo) : [];

        // Extract expenses
        const rawExp = rootData.pengeluaran || rootData.expenses || [];
        const parsedExpenses: ExpenseRecord[] = Array.isArray(rawExp) ? rawExp.map((e: any) => ({
          id: String(e.id || `EXP-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`),
          tanggal: String(e.tanggal || e.date || ''),
          kategori: String(e.kategori || e.category || 'Operasional'),
          keterangan: String(e.keterangan || e.description || ''),
          nominal: Number(e.nominal || e.amount || 0),
          pj: String(e.pj || e.operator || 'Admin'),
        })).filter((e) => e.keterangan || e.nominal > 0) : [];

        // Extract stock in history
        const rawStock = rootData.stokMasuk || rootData.stockIn || rootData.barangMasuk || [];
        const parsedStockIn: StockInRecord[] = Array.isArray(rawStock) ? rawStock.map((s: any) => ({
          id: s.id ? String(s.id) : undefined,
          kode: String(s.kode || s.code || ''),
          nama: String(s.nama || s.name || ''),
          qty: Number(s.qty || s.jumlah || 0),
          satuan: String(s.satuan || s.unit || 'pcs'),
          hargaBeli: s.hargaBeli !== undefined ? Number(s.hargaBeli) : undefined,
          supplier: String(s.supplier || ''),
          cashier: String(s.cashier || s.kasir || 'Admin'),
          date: String(s.date || s.tanggal || ''),
          time: String(s.time || s.jam || ''),
          catatan: String(s.catatan || s.notes || ''),
        })).filter((s) => s.nama || s.kode) : [];

        // Extract kasir users
        const rawUsers = rootData.kasirUsers || rootData.users || [];
        const parsedUsers: KasirUser[] = Array.isArray(rawUsers) ? rawUsers.map((u: any) => ({
          nama: String(u.nama || u.name || '').trim(),
          password: String(u.password || '123456'),
          role: u.role || 'kasir',
        })).filter((u) => u.nama) : [];

        // Extract settings
        const parsedSettings = rootData.pengaturan || parsed.toko || rootData.settings;

        const totalItems = parsedProducts.length + parsedCustomers.length + parsedInvoices.length + parsedExpenses.length + parsedStockIn.length + parsedUsers.length;

        if (totalItems === 0 && !parsedSettings) {
          onShowToast('Format data di dalam file JSON tidak dikenali atau kosong.', 'error');
          return;
        }

        setBackupFilePreview({
          fileName: file.name,
          customers: parsedCustomers,
          products: parsedProducts,
          invoices: parsedInvoices,
          expenses: parsedExpenses,
          stockIn: parsedStockIn,
          kasirUsers: parsedUsers,
          settings: parsedSettings,
          dateStr: parsed.tanggalBackup || parsed.isoTimestamp,
          version: parsed.versiFormat || '1.0',
        });
      } catch (err: any) {
        console.error('Error parsing JSON backup file:', err);
        onShowToast('Gagal membaca file JSON: ' + (err?.message || 'Format tidak valid'), 'error');
      }
    };
    reader.readAsText(file);
  };

  const handleExecuteRestoreBackup = async () => {
    if (!backupFilePreview) return;
    setIsRestoringBackup(true);

    try {
      const { products: bProds, customers: bCusts, invoices: bInvs, expenses: bExps, stockIn: bStock, kasirUsers: bUsers, settings: bSet } = backupFilePreview;

      // 1. Prepare Final Products
      let finalProducts: Product[] = [];
      if (importMode === 'replace') {
        finalProducts = bProds;
      } else {
        const prodMap = new Map<string, Product>();
        (products || []).forEach((p) => prodMap.set(p.kode.toLowerCase().trim(), p));
        bProds.forEach((p) => prodMap.set(p.kode.toLowerCase().trim(), p));
        finalProducts = Array.from(prodMap.values());
      }
      if (finalProducts.length > 0) {
        localStorage.setItem('strukku_products', JSON.stringify(finalProducts));
        onUpdateProducts?.(finalProducts);
      }

      // 2. Prepare Final Customers
      let finalCustomers: Customer[] = [];
      if (importMode === 'replace') {
        finalCustomers = bCusts;
      } else {
        const custMap = new Map<string, Customer>();
        (customers || []).forEach((c) => custMap.set(c.nama.toLowerCase().trim(), c));
        bCusts.forEach((c) => custMap.set(c.nama.toLowerCase().trim(), c));
        finalCustomers = Array.from(custMap.values());
      }
      if (finalCustomers.length > 0) {
        localStorage.setItem('strukku_customers', JSON.stringify(finalCustomers));
        onUpdateCustomers?.(finalCustomers);
      }

      // 3. Prepare Final Invoices
      let finalInvoices: Invoice[] = [];
      if (importMode === 'replace') {
        finalInvoices = bInvs;
      } else {
        const invMap = new Map<string, Invoice>();
        (invoices || []).forEach((inv) => invMap.set((inv.invoiceNo || (inv as any).noInvoice || '').trim(), inv));
        bInvs.forEach((inv) => invMap.set((inv.invoiceNo || (inv as any).noInvoice || '').trim(), inv));
        finalInvoices = Array.from(invMap.values());
      }
      if (finalInvoices.length > 0) {
        localStorage.setItem('strukku_recent_invoices', JSON.stringify(finalInvoices));
        onUpdateInvoices?.(finalInvoices);
      }

      // 4. Prepare Final Expenses
      let finalExpenses: ExpenseRecord[] = [];
      if (importMode === 'replace') {
        finalExpenses = bExps;
      } else {
        const expMap = new Map<string, ExpenseRecord>();
        getStoredExpenses().forEach((e) => expMap.set(e.id || `${e.tanggal}-${e.keterangan}`, e));
        bExps.forEach((e) => expMap.set(e.id || `${e.tanggal}-${e.keterangan}`, e));
        finalExpenses = Array.from(expMap.values());
      }
      if (finalExpenses.length > 0) {
        localStorage.setItem('strukku_company_expenses', JSON.stringify(finalExpenses));
      }

      // 5. Prepare Final Stock In History
      let finalStockIn: StockInRecord[] = [];
      if (importMode === 'replace') {
        finalStockIn = bStock;
      } else {
        const stMap = new Map<string, StockInRecord>();
        getLocalStockInHistory().forEach((s) => stMap.set(s.id || `${s.kode}-${s.date}-${s.time}`, s));
        bStock.forEach((s) => stMap.set(s.id || `${s.kode}-${s.date}-${s.time}`, s));
        finalStockIn = Array.from(stMap.values());
      }
      if (finalStockIn.length > 0) {
        localStorage.setItem('strukku_stock_in_history', JSON.stringify(finalStockIn));
      }

      // 6. Prepare Final Kasir Users
      let finalKasirUsers: KasirUser[] = [];
      if (importMode === 'replace') {
        const hasAdmin = bUsers.some((u) => u.nama.toLowerCase().trim() === 'admin');
        finalKasirUsers = hasAdmin ? bUsers : [{ nama: 'Admin', password: 'admin', role: 'owner' }, ...bUsers];
      } else {
        const userMap = new Map<string, KasirUser>();
        (kasirUsers || []).forEach((u) => userMap.set(u.nama.toLowerCase().trim(), u));
        bUsers.forEach((u) => userMap.set(u.nama.toLowerCase().trim(), u));
        finalKasirUsers = Array.from(userMap.values());
      }
      if (finalKasirUsers.length > 0) {
        localStorage.setItem('strukku_kasir_users', JSON.stringify(finalKasirUsers));
        localStorage.setItem('strukku_kasir_list', JSON.stringify(finalKasirUsers.map((u) => u.nama)));
        onUpdateKasirUsers?.(finalKasirUsers);
      }

      // 7. Store Settings
      if (bSet && Object.keys(bSet).length > 0) {
        const updatedSettings: StoreSettings = {
          ...settings,
          ...bSet,
          name: bSet.name || (bSet as any).nama || settings.name,
          tagline: bSet.tagline || settings.tagline,
          address: bSet.address || (bSet as any).alamat || settings.address,
          phone: bSet.phone || (bSet as any).telepon || settings.phone,
          footer: bSet.footer || (bSet as any).footerNota || settings.footer,
          prefixInvoice: bSet.prefixInvoice || (bSet as any).prefixNota || settings.prefixInvoice,
          rekening: bSet.rekening || settings.rekening,
        };
        localStorage.setItem('strukku_settings', JSON.stringify(updatedSettings));
        localStorage.setItem('strukku_sheet_settings', JSON.stringify(updatedSettings));
        onSaveSettings(updatedSettings);
        if (updatedSettings.name) setStoreName(updatedSettings.name);
        if (updatedSettings.tagline) setStoreTagline(updatedSettings.tagline);
        if (updatedSettings.address) setStoreAddress(updatedSettings.address);
        if (updatedSettings.phone) setStorePhone(updatedSettings.phone);
        if (updatedSettings.footer) setStoreFooter(updatedSettings.footer);
        if (updatedSettings.prefixInvoice) setPrefixInvoice(updatedSettings.prefixInvoice);
        if (updatedSettings.rekening) setRekeningText(updatedSettings.rekening);
      }

      // 8. Auto-Sync all restored data to Firebase Firestore
      await migrateAllDataToFirebase({
        products: finalProducts,
        customers: finalCustomers,
        kasirUsers: finalKasirUsers,
        settings: bSet || settings,
        expenses: finalExpenses,
        stockIn: finalStockIn,
        invoices: finalInvoices,
      }).catch((err) => {
        console.warn('Firebase sync on backup restore:', err);
      });

      setBackupFilePreview(null);
      onSync();
      onShowToast(
        `✓ Berhasil mengupload & memulihkan backup! (${bProds.length} produk, ${bCusts.length} pelanggan, ${bInvs.length} invoice)`,
        'success'
      );
    } catch (err: any) {
      console.error('Error executing backup restore:', err);
      onShowToast('Gagal memulihkan file backup: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsRestoringBackup(false);
    }
  };

  // Firebase Migration State
  const [isMigratingFirebase, setIsMigratingFirebase] = useState(false);
  const [migrationStats, setMigrationStats] = useState<Record<string, number> | null>(null);
  const [isClearingDummy, setIsClearingDummy] = useState(false);
  const [showConfirmClearDummy, setShowConfirmClearDummy] = useState(false);

  const handleDeleteAllDummyData = async () => {
    setIsClearingDummy(true);
    try {
      const res = await deleteAllDummyDataFirebase();
      if (res.success) {
        onShowToast('✓ Semua data dummy berhasil dibersihkan!', 'success');
        setShowConfirmClearDummy(false);
        onSync();
      } else {
        onShowToast('Gagal menghapus data dummy: ' + res.message, 'error');
      }
    } catch (err: any) {
      onShowToast('Error: ' + (err?.message || 'Gagal menghapus data dummy'), 'error');
    } finally {
      setIsClearingDummy(false);
    }
  };

  const handleMigrateToFirebase = async () => {
    setIsMigratingFirebase(true);
    setMigrationStats(null);

    try {
      // Gather current local & sync data
      const localProds = getLocalProducts();
      const localStockIn = getLocalStockInHistory();
      const localExpenses = getStoredExpenses();

      // Gather recent invoices from local storage
      let recentInvoices: any[] = [];
      try {
        const rawInv = localStorage.getItem('strukku_recent_invoices');
        if (rawInv) recentInvoices = JSON.parse(rawInv);
      } catch {}

      const res = await migrateAllDataToFirebase({
        products: localProds,
        customers: customers,
        kasirUsers: kasirUsers,
        settings: settings,
        expenses: localExpenses,
        stockIn: localStockIn,
        invoices: recentInvoices,
      });

      if (res.success) {
        setMigrationStats(res.migratedCounts);
        const totalItems = Object.values(res.migratedCounts).reduce((a, b) => a + b, 0);
        onShowToast(`✓ Berhasil migrasi ${totalItems} data ke Firestore!`, 'success');
        // Run onSync in background without blocking UI
        setTimeout(() => {
          try { onSync(); } catch {}
        }, 100);
      } else {
        onShowToast('Gagal migrasi: ' + res.message, 'error');
      }
    } catch (err: any) {
      onShowToast('Error migrasi ke Firebase: ' + (err?.message || 'Gagal'), 'error');
    } finally {
      setIsMigratingFirebase(false);
    }
  };

  // Google Workspace Direct Sheets Actions
  const handleAuthorizeGoogle = async () => {
    setIsAuthorizingGoogle(true);
    try {
      const token = await requestGoogleAccessToken();
      if (token) {
        setGoogleAuthStatus(true);
        onShowToast('✓ Akun Google & Izin Sheets berhasil diotorisasi!', 'success');
      }
    } catch (err: any) {
      onShowToast('Gagal otorisasi Google: ' + (err?.message || 'Akses ditolak'), 'error');
    } finally {
      setIsAuthorizingGoogle(false);
    }
  };

  const handleCreateGoogleSpreadsheet = async () => {
    setIsCreatingSheet(true);
    try {
      const storeTitle = `WARUNG KAKA - Database POS & Keuangan (${new Date().toLocaleDateString('id-ID')})`;
      const res = await createWarungSpreadsheet(storeTitle);
      if (res.success && res.spreadsheetId) {
        setSheetInfo({
          id: res.spreadsheetId,
          url: res.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${res.spreadsheetId}/edit`,
          title: storeTitle,
        });
        onShowToast('✓ Spreadsheet baru berhasil dibuat di Google Drive Anda!', 'success');

        // Automatically push current data
        const localProds = products.length > 0 ? products : getLocalProducts();
        const localStockIn = getLocalStockInHistory();
        const localExpenses = getStoredExpenses();
        await syncAllToGoogleSheets(res.spreadsheetId, {
          products: localProds,
          customers,
          kasirUsers,
          invoices,
          settings,
          expenses: localExpenses,
          stockIn: localStockIn,
        });
        onShowToast('✓ Seluruh data awal berhasil disinkronkan ke Spreadsheet baru!', 'success');
      } else {
        onShowToast('Gagal membuat Spreadsheet: ' + res.message, 'error');
      }
    } catch (err: any) {
      onShowToast('Error membuat Spreadsheet: ' + (err?.message || 'Gagal'), 'error');
    } finally {
      setIsCreatingSheet(false);
    }
  };

  const handleConnectCustomSpreadsheet = () => {
    const cleanId = extractSpreadsheetId(customSheetInput);
    if (!cleanId) {
      onShowToast('Masukkan URL atau ID Google Spreadsheet yang valid', 'error');
      return;
    }
    const cleanUrl = `https://docs.google.com/spreadsheets/d/${cleanId}/edit`;
    const title = 'Spreadsheet Terhubung';
    setStoredSpreadsheetId(cleanId, cleanUrl, title);
    setSheetInfo({ id: cleanId, url: cleanUrl, title });
    setCustomSheetInput('');
    onShowToast('✓ Spreadsheet berhasil dihubungkan!', 'success');
  };

  const handleDisconnectSpreadsheet = () => {
    setStoredSpreadsheetId('');
    setSheetInfo({ id: null, url: null, title: 'WARUNG KAKA - Database POS & Keuangan' });
    onShowToast('Spreadsheet Google diputuskan dari sistem.', 'info');
  };

  const handlePushAllToGoogleSheets = async () => {
    if (!sheetInfo.id) {
      onShowToast('Hubungkan atau buat Spreadsheet Google terlebih dahulu.', 'error');
      return;
    }
    setIsPushingSheets(true);
    try {
      const localProds = products.length > 0 ? products : getLocalProducts();
      const localStockIn = getLocalStockInHistory();
      const localExpenses = getStoredExpenses();
      const res = await syncAllToGoogleSheets(sheetInfo.id, {
        products: localProds,
        customers,
        kasirUsers,
        invoices,
        settings,
        expenses: localExpenses,
        stockIn: localStockIn,
      });

      if (res.success) {
        onShowToast(res.message, 'success');
      } else {
        onShowToast(res.message, 'error');
      }
    } catch (err: any) {
      onShowToast('Error sinkronisasi ke Google Sheets: ' + (err?.message || 'Gagal'), 'error');
    } finally {
      setIsPushingSheets(false);
    }
  };

  const handlePullProductsFromGoogleSheets = async () => {
    if (!sheetInfo.id) {
      onShowToast('Hubungkan atau buat Spreadsheet Google terlebih dahulu.', 'error');
      return;
    }
    setIsPullingSheets(true);
    try {
      const res = await pullProductsFromGoogleSheet(sheetInfo.id);
      if (res.success && res.products && res.products.length > 0) {
        if (onUpdateProducts) {
          onUpdateProducts(res.products);
        }
        localStorage.setItem('strukku_products', JSON.stringify(res.products));
        onShowToast(`✓ Berhasil memuat ${res.products.length} produk dari Google Sheets!`, 'success');
      } else {
        onShowToast(res.message || 'Tidak ada produk ditemukan di sheet "Produk".', 'info');
      }
    } catch (err: any) {
      onShowToast('Error membaca produk dari Google Sheets: ' + (err?.message || 'Gagal'), 'error');
    } finally {
      setIsPullingSheets(false);
    }
  };

  if (!isOpen) return null;

  // Helper to check if name represents an SPV or Owner role
  const checkIsSpvOrOwner = (userOrName: string | KasirUser): boolean => {
    if (!userOrName) return false;
    let name = '';
    let role = '';
    if (typeof userOrName === 'string') {
      name = userOrName.trim().toLowerCase();
      const matched = kasirUsers.find((u) => u.nama.toLowerCase().trim() === name);
      if (matched && matched.role) role = matched.role.toLowerCase();
    } else {
      name = (userOrName.nama || '').trim().toLowerCase();
      role = (userOrName.role || '').trim().toLowerCase();
    }

    if (role === 'spv' || role === 'owner' || role === 'supervisor' || role === 'admin') {
      return true;
    }

    return (
      name.includes('spv') ||
      name.includes('supervisor') ||
      name.includes('owner') ||
      name.includes('pemilik') ||
      name.includes('pimpinan') ||
      name.includes('admin') ||
      name.includes('master')
    );
  };

  const handleOpenAddKasirFlow = () => {
    const currentCashier = settings.cashier || localStorage.getItem('strukku_logged_kasir') || '';
    if (checkIsSpvOrOwner(currentCashier)) {
      // Logged in as SPV/Owner -> Direct access
      setIsAddKasirOpen(true);
    } else {
      // Regular Kasir -> Require SPV/Owner Authorization
      setPendingAction({ type: 'add' });
      const spvCandidates = kasirUsers.filter((u) => checkIsSpvOrOwner(u));
      if (spvCandidates.length > 0) {
        setAuthSpvUser(spvCandidates[0].nama);
      } else if (kasirUsers.length > 0) {
        setAuthSpvUser(kasirUsers[0].nama);
      }
      setAuthPassword('');
      setIsAuthModalOpen(true);
    }
  };

  const handleDeleteKasirClick = (kasirName: string) => {
    const currentCashier = settings.cashier || localStorage.getItem('strukku_logged_kasir') || '';
    if (checkIsSpvOrOwner(currentCashier)) {
      // Direct open in-app confirmation modal
      setKasirToDelete(kasirName);
    } else {
      // Require SPV/Owner Authorization first
      setPendingAction({ type: 'delete', targetKasir: kasirName });
      const spvCandidates = kasirUsers.filter((u) => checkIsSpvOrOwner(u));
      if (spvCandidates.length > 0) {
        setAuthSpvUser(spvCandidates[0].nama);
      } else if (kasirUsers.length > 0) {
        setAuthSpvUser(kasirUsers[0].nama);
      }
      setAuthPassword('');
      setIsAuthModalOpen(true);
    }
  };

  const executeDeleteKasir = async (kasirName: string) => {
    if (!kasirName) return;
    setDeletingKasirName(kasirName);
    try {
      // 1. Delete from Firebase
      await deleteKasirUserFirebase(kasirName).catch((e) => console.warn('Firebase deleteKasirUser warning:', e));

      // 2. Delete from GAS & LocalStorage
      await deleteKasirUser(kasirName);

      // 3. Update React state in App
      const cleanTarget = kasirName.toLowerCase().trim();
      const updatedUsers = kasirUsers.filter((u) => u.nama.toLowerCase().trim() !== cleanTarget);

      if (onUpdateKasirUsers) {
        onUpdateKasirUsers(updatedUsers);
      }

      onShowToast(`Akun kasir "${kasirName}" berhasil dihapus!`, 'success');
      setKasirToDelete(null);
    } catch (err: any) {
      console.error('Delete cashier error:', err);
      onShowToast(`Gagal menghapus kasir "${kasirName}"`, 'error');
    } finally {
      setDeletingKasirName(null);
    }
  };

  const handleVerifyAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authSpvUser) {
      onShowToast('Pilih akun SPV / Owner terlebih dahulu', 'error');
      return;
    }

    const targetUser = kasirUsers.find((u) => u.nama.toLowerCase().trim() === authSpvUser.toLowerCase().trim());
    const validPassword = targetUser?.password || 'ervo123';

    if (authPassword.trim() === validPassword) {
      onShowToast(`Otorisasi SPV/Owner (${authSpvUser}) berhasil diverifikasi!`, 'success');
      setIsAuthModalOpen(false);
      setAuthPassword('');

      if (pendingAction?.type === 'add') {
        setIsAddKasirOpen(true);
      } else if (pendingAction?.type === 'delete' && pendingAction.targetKasir) {
        setKasirToDelete(pendingAction.targetKasir);
      }
      setPendingAction(null);
    } else {
      onShowToast(`Password otorisasi untuk ${authSpvUser} salah!`, 'error');
    }
  };

  const handleAddKasirSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newKasirName.trim();
    if (!cleanName) {
      onShowToast('Nama kasir/operator baru tidak boleh kosong!', 'error');
      return;
    }

    const pass = newKasirPass.trim() || 'ervo123';

    // Duplicate check
    if (kasirUsers.some((k) => k.nama.toLowerCase().trim() === cleanName.toLowerCase())) {
      onShowToast(`Kasir dengan nama "${cleanName}" sudah terdaftar!`, 'error');
      return;
    }

    setIsSavingNewKasir(true);
    try {
      const roleVal = newKasirRole.toLowerCase();
      await updateKasirPassword(cleanName, pass, roleVal);
      await saveKasirUserFirebase({
        nama: cleanName,
        password: pass,
        role: roleVal,
      }).catch((e) => console.warn('Firebase saveKasirUser warning:', e));

      const updatedUsers = [
        ...kasirUsers.filter((u) => u.nama.toLowerCase().trim() !== cleanName.toLowerCase()),
        { nama: cleanName, password: pass, role: roleVal },
      ];

      if (onUpdateKasirUsers) {
        onUpdateKasirUsers(updatedUsers);
      }

      onShowToast(`Kasir/Operator "${cleanName}" (${newKasirRole}) berhasil ditambahkan!`, 'success');
      setIsAddKasirOpen(false);
      setNewKasirName('');
      setNewKasirPass('');
      setNewKasirRole('Kasir');
    } catch {
      onShowToast('Gagal menambahkan kasir baru', 'error');
    } finally {
      setIsSavingNewKasir(false);
    }
  };

  const handleTestConnection = async () => {
    if (!url.trim()) {
      setTestResult({ ok: false, msg: 'Masukkan URL Google Apps Script terlebih dahulu' });
      return;
    }

    setTesting(true);
    setTestResult(null);

    setSheetUrl(url.trim());
    const res = await gasGet('ping');
    setTesting(false);

    if (res.success) {
      setTestResult({ ok: true, msg: 'Terhubung! Google Apps Script Backend aktif.' });
      onShowToast('Koneksi Google Sheets Berhasil!', 'success');
    } else {
      setTestResult({ ok: false, msg: res.message || 'Gagal terhubung ke Google Apps Script' });
      onShowToast('Koneksi Gagal: Cek Akses Deployment Apps Script (Anyone)', 'error');
    }
  };

  const handleInitSheets = async () => {
    if (!url.trim()) {
      setTestResult({ ok: false, msg: 'Masukkan URL Google Apps Script terlebih dahulu' });
      return;
    }

    setInitializing(true);
    setTestResult(null);
    setSheetUrl(url.trim());

    try {
      const res = await initSheetsRemote();
      if (res.success) {
        setTestResult({ ok: true, msg: '✓ Inisialisasi sheet & header v5 berhasil!' });
        onShowToast('✓ Inisialisasi Google Sheets v5 Berhasil! Sheet & Header telah disesuaikan.', 'success');
        onSync();
      } else {
        setTestResult({ ok: false, msg: res.message || 'Gagal melakukan inisialisasi sheet.' });
        onShowToast('Gagal inisialisasi: ' + res.message, 'error');
      }
    } catch (err: any) {
      setTestResult({ ok: false, msg: 'Error: ' + err.message });
      onShowToast('Gagal menghubungi Google Sheets: ' + err.message, 'error');
    } finally {
      setInitializing(false);
    }
  };

  const handleSave = () => {
    setSheetUrl(url.trim());
    const updatedSettings: StoreSettings = {
      ...settings,
      name: storeName.trim() || 'WARUNGKU',
      storeName: storeName.trim() || 'WARUNGKU',
      tagline: storeTagline.trim(),
      address: storeAddress.trim(),
      phone: storePhone.trim(),
      footer: storeFooter.trim(),
      prefixInvoice: prefixInvoice.trim() || 'INV',
      rekening: rekeningText.trim(),
      autoLogoutMinutes: autoLogoutMin,
      minStockThreshold: Number(minStockThreshold) || 10,
    };
    onSaveSettings(updatedSettings);

    // Save locally to localStorage so settings persist across reloads
    try {
      localStorage.setItem('strukku_settings', JSON.stringify(updatedSettings));
      localStorage.setItem('strukku_sheet_settings', JSON.stringify(updatedSettings));
    } catch {}

    // Save to Firebase Firestore
    saveStoreSettingsFirebase(updatedSettings).catch(() => {});

    // Sync settings to Google Sheets in background
    saveSettingsRemote(updatedSettings).catch(() => {});

    onShowToast('Pengaturan & Branding Toko berhasil disimpan!', 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-700 text-white flex items-center justify-center font-bold shadow-xs">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base">Pengaturan Sistem & Toko</h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Atur branding aplikasi, otorisasi kasir, rekening & database
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 space-y-4">
          {/* Identitas & Branding Toko / Aplikasi (Login Screen, Header, Portal Publik, Nota) */}
          <div className="p-3.5 rounded-xl border-2 border-red-200 bg-gradient-to-br from-red-50/80 via-amber-50/40 to-stone-50/70 space-y-3 text-xs shadow-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5 text-red-900 font-black">
                <Palette className="w-4 h-4 text-red-700" /> Branding & Identitas Toko
              </span>
              <span className="text-[10px] bg-red-700 text-white px-2 py-0.5 rounded-full font-bold shadow-2xs">
                Login, Header & Struk
              </span>
            </div>

            {/* Live Branding Preview Box */}
            <div className="p-2.5 rounded-lg bg-white/90 border border-red-200/80 shadow-2xs space-y-1">
              <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-500" /> Preview Tampilan Branding:
              </div>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-red-700 text-white font-black text-xs flex items-center justify-center shadow-xs">
                  {storeName.trim() ? storeName.trim().charAt(0).toUpperCase() : 'W'}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-extrabold text-stone-900 text-sm truncate uppercase tracking-wide">
                    {storeName.trim() || 'WARUNGKU'}
                  </div>
                  <div className="text-[10px] text-red-700 font-semibold truncate">
                    {storeTagline.trim() || 'Cepat / Tepat / Berkualitas'}
                  </div>
                </div>
              </div>
              {(storeAddress || storePhone) && (
                <div className="text-[10px] text-stone-500 pt-0.5 border-t border-stone-100 flex flex-wrap gap-x-2">
                  {storeAddress && <span>📍 {storeAddress}</span>}
                  {storePhone && <span>📞 {storePhone}</span>}
                </div>
              )}
            </div>

            <div className="space-y-2.5 pt-1">
              {/* Nama Toko / Branding */}
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                  <Store className="w-3.5 h-3.5 text-red-700" /> Nama Usaha / Toko (Branding Utama)
                </label>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="contoh: WARUNGKU atau ERVO PRINT"
                  className="w-full px-3 py-2 bg-white rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-bold text-stone-800 shadow-2xs"
                />
                <p className="text-[10px] text-stone-500 mt-0.5">
                  Tampil di Layar Login, Header Kasir, Portal Publik Pelanggan, dan Cetak Struk/Nota.
                </p>
              </div>

              {/* Slogan / Tagline */}
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-amber-600" /> Slogan / Tagline Usaha
                </label>
                <input
                  type="text"
                  value={storeTagline}
                  onChange={(e) => setStoreTagline(e.target.value)}
                  placeholder="contoh: Cepat / Tepat / Berkualitas atau Belanja Murah & Lengkap"
                  className="w-full px-3 py-2 bg-white rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-medium text-stone-800 shadow-2xs"
                />
                <p className="text-[10px] text-stone-500 mt-0.5">
                  Tampil di bawah nama toko pada Layar Login dan Header.
                </p>
              </div>

              {/* Alamat & Telepon Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-red-600" /> Alamat Toko / Workshop
                  </label>
                  <input
                    type="text"
                    value={storeAddress}
                    onChange={(e) => setStoreAddress(e.target.value)}
                    placeholder="contoh: Jl. HOS Cokroaminoto No.17"
                    className="w-full px-3 py-2 bg-white rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs text-stone-800 shadow-2xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" /> No. Telp / WhatsApp
                  </label>
                  <input
                    type="text"
                    value={storePhone}
                    onChange={(e) => setStorePhone(e.target.value)}
                    placeholder="contoh: 0812-2247-2007"
                    className="w-full px-3 py-2 bg-white rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs text-stone-800 shadow-2xs"
                  />
                </div>
              </div>

              {/* Prefix Invoice & Footer Struk */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                    <Hash className="w-3.5 h-3.5 text-purple-600" /> Prefix No. Nota
                  </label>
                  <input
                    type="text"
                    value={prefixInvoice}
                    onChange={(e) => setPrefixInvoice(e.target.value.toUpperCase())}
                    placeholder="INV"
                    maxLength={6}
                    className="w-full px-3 py-2 bg-white rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-bold text-stone-800 uppercase shadow-2xs"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-blue-600" /> Catatan / Footer Struk
                  </label>
                  <input
                    type="text"
                    value={storeFooter}
                    onChange={(e) => setStoreFooter(e.target.value)}
                    placeholder="Terima Kasih Atas Kunjungan Anda"
                    className="w-full px-3 py-2 bg-white rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs text-stone-800 shadow-2xs"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Daftar Kasir / Operator Section with Delete Permission for SPV & Owner */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2.5 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-red-700" /> Daftar Operator / Kasir
              </span>

              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-red-100 text-red-900 border border-red-200 px-2 py-0.5 rounded-full font-extrabold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-red-700" /> SPV & Owner
                </span>
                <button
                  type="button"
                  onClick={handleOpenAddKasirFlow}
                  className="px-2.5 py-1 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs transition active:scale-95 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Tambah Kasir</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 pt-1">
              {kasirUsers.length > 0 ? (
                kasirUsers.map((u, idx) => {
                  const isSpvOrOwner = checkIsSpvOrOwner(u);
                  const isDeleting = deletingKasirName === u.nama;
                  const isMainAdmin = u.nama.toLowerCase().trim() === 'admin';
                  const roleUpper = (u.role || (isSpvOrOwner ? 'spv' : 'kasir')).toUpperCase();

                  return (
                    <div
                      key={`${u.nama}-${idx}`}
                      className="px-3 py-2 bg-white border border-stone-200 text-stone-800 font-extrabold rounded-xl text-[11px] shadow-2xs flex items-center justify-between gap-2 hover:border-stone-300 transition"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-stone-400 shrink-0">👤</span>
                        <span className="truncate">{u.nama}</span>
                        <span className={`text-[9px] px-1.5 py-0.5 border rounded font-black shrink-0 ${
                          roleUpper === 'OWNER' 
                            ? 'bg-amber-50 text-amber-900 border-amber-300'
                            : roleUpper === 'SPV'
                            ? 'bg-purple-50 text-purple-900 border-purple-300'
                            : 'bg-stone-50 text-stone-700 border-stone-200'
                        }`}>
                          {roleUpper}
                        </span>
                      </div>

                      {!isMainAdmin && (
                        <button
                          type="button"
                          onClick={() => handleDeleteKasirClick(u.nama)}
                          disabled={isDeleting}
                          className="px-2 py-1 bg-stone-50 hover:bg-red-50 text-stone-400 hover:text-red-700 border border-stone-200 hover:border-red-200 rounded-lg text-[10px] font-bold flex items-center gap-1 transition cursor-pointer shrink-0 active:scale-95"
                          title={`Hapus akun operator/kasir ${u.nama} (Khusus SPV/Owner)`}
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-600" />
                          <span className="hidden sm:inline">{isDeleting ? 'Menghapus...' : 'Hapus'}</span>
                        </button>
                      )}
                    </div>
                  );
                })
              ) : (
                <span className="text-stone-400 italic text-[11px]">Belum ada kasir tersimpan</span>
              )}
            </div>

            <p className="text-[10px] text-stone-500 pt-1 leading-normal border-t border-stone-200/60 mt-1">
              💡 <strong>Otorisasi Terbatas:</strong> Hanya akun berwenang <strong>SPV / Owner</strong> yang dapat <strong>menambah</strong> atau <strong>menghapus</strong> akun kasir dari sistem.
            </p>
          </div>

          {/* Batas Peringatan Stok Menipis (Threshold Katalog POS) */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <SlidersHorizontal className="w-4 h-4 text-red-700" /> Batas Peringatan Stok Menipis (Katalog POS)
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={minStockThreshold}
                  onChange={(e) => setMinStockThreshold(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-16 px-2 py-1 bg-white border border-stone-300 rounded-lg text-xs font-black text-center text-red-700 focus:ring-1 focus:ring-red-600 outline-none"
                />
                <span className="text-[11px] font-bold text-stone-600">item</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[5, 10, 15, 20, 50].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setMinStockThreshold(val)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition border cursor-pointer ${
                    minStockThreshold === val
                      ? 'bg-red-700 text-white border-red-700 shadow-2xs'
                      : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  ≤ {val} item
                </button>
              ))}
            </div>
            <p className="text-[10px] text-stone-500 leading-relaxed">
              Produk dengan sisa stok di bawah atau sama dengan angka ini akan otomatis ditandai dengan badge <strong>⚠️ Stok Menipis</strong> pada Katalog Kasir POS.
            </p>
          </div>

          {/* Master Pelanggan Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2.5 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-red-700" /> Data Pelanggan ({customers.length})
              </span>

              {onOpenAddCustomer && (
                <button
                  type="button"
                  onClick={onOpenAddCustomer}
                  className="px-2.5 py-1 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs transition active:scale-95 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Tambah Pelanggan</span>
                </button>
              )}
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1 max-h-32 overflow-y-auto">
              {customers.length > 0 ? (
                customers.map((c, idx) => (
                  <span
                    key={`${c.nama}-${idx}`}
                    className="px-2.5 py-1 bg-white border border-stone-200 text-stone-800 font-bold rounded-lg text-[11px] shadow-2xs flex items-center gap-1"
                  >
                    <span>{c.nama}</span>
                    {c.kelas && (
                      <span className="text-[9px] px-1 py-0.2 bg-red-50 text-red-800 rounded font-semibold border border-red-200">
                        {c.kelas} ({c.diskon}%)
                      </span>
                    )}
                  </span>
                ))
              ) : (
                <span className="text-stone-400 italic text-[11px]">Belum ada data pelanggan tersimpan</span>
              )}
            </div>
          </div>

          {/* Rekening Pembayaran Bank Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-red-700" /> No. Rekening Pembayaran (Invoice)
              </span>
            </div>
            <textarea
              rows={3}
              value={rekeningText}
              onChange={(e) => setRekeningText(e.target.value)}
              placeholder={`Dapat diisi lebih dari 1 nomor rekening (1 per baris):\nBCA: 123456789 a/n ERVO PRINT\nMandiri: 987654321 a/n ERVO PRINT`}
              className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold bg-white focus:ring-1 focus:ring-red-600 outline-none resize-y"
            />
            <p className="text-[10px] text-stone-500 leading-relaxed">
              Bisa memasukkan lebih dari 1 nomor rekening (pisahkan dengan baris baru). Otomatis tersimpan ke Google Sheets (kolom <code>Rekening</code>) dan akan tercetak rapi di Invoice A5 & Struk Thermal.
            </p>
          </div>

          {/* Auto Logout Inaktivitas Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-red-700" /> Auto Logout Inaktivitas
              </span>
              <select
                value={autoLogoutMin}
                onChange={(e) => setAutoLogoutMin(Number(e.target.value))}
                className="px-2.5 py-1 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-800 focus:ring-1 focus:ring-red-600 outline-none cursor-pointer"
              >
                <option value={5}>5 Menit</option>
                <option value={10}>10 Menit</option>
                <option value={15}>15 Menit (Default)</option>
                <option value={30}>30 Menit</option>
                <option value={60}>60 Menit (1 Jam)</option>
                <option value={0}>Nonaktif (Matikan Auto Logout)</option>
              </select>
            </div>
            <p className="text-[10px] text-stone-500 leading-relaxed">
              Kasir/operator akan otomatis di-logout jika tidak ada reaksi/transaksi selama durasi ini. <strong>Sinkronisasi data Google Sheets tetap berjalan otomatis di latar belakang setiap 10 menit sekali.</strong>
            </p>
          </div>

          {/* Backup Lokal / Data Loss Prevention Section */}
          <div className="p-4 rounded-xl border border-sky-300 bg-sky-50/60 space-y-3 text-xs shadow-2xs">
            <div className="flex items-center justify-between font-bold text-sky-950 flex-wrap gap-2">
              <span className="flex items-center gap-2 text-sm font-extrabold">
                <FileJson className="w-5 h-5 text-sky-700" /> Backup Data Lokal (Format JSON)
              </span>
              <span className="px-2.5 py-0.5 bg-sky-100 text-sky-900 rounded-full text-[10px] font-extrabold border border-sky-200 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-sky-700" /> Pencegahan Kehilangan Data
              </span>
            </div>

            <p className="text-[11px] text-stone-700 leading-relaxed font-medium">
              Simpan dan unduh seluruh data toko saat ini (<strong>pelanggan, produk, invoice/transaksi, kasir, pengeluaran & stok</strong>) ke file cadangan <strong>.json</strong> di perangkat Anda.
            </p>

            {/* Quick Live Stats Pills */}
            <div className="grid grid-cols-3 gap-2 text-[10px] font-bold text-stone-700">
              <div className="p-2 bg-white rounded-lg border border-sky-200 text-center">
                <div className="text-stone-400 font-medium">👥 Pelanggan</div>
                <div className="text-xs font-black text-sky-950 mt-0.5">
                  {customers.length > 0 ? customers.length : (JSON.parse(localStorage.getItem('strukku_customers') || '[]').length)} Data
                </div>
              </div>
              <div className="p-2 bg-white rounded-lg border border-sky-200 text-center">
                <div className="text-stone-400 font-medium">📦 Produk</div>
                <div className="text-xs font-black text-sky-950 mt-0.5">
                  {products.length > 0 ? products.length : getLocalProducts().length} Data
                </div>
              </div>
              <div className="p-2 bg-white rounded-lg border border-sky-200 text-center">
                <div className="text-stone-400 font-medium">📄 Invoice</div>
                <div className="text-xs font-black text-sky-950 mt-0.5">
                  {invoices.length > 0 ? invoices.length : (JSON.parse(localStorage.getItem('strukku_recent_invoices') || '[]').length)} Data
                </div>
              </div>
            </div>

            {/* Hidden File Input for Uploading Backup */}
            <input
              type="file"
              ref={backupFileInputRef}
              onChange={handleBackupFileSelect}
              accept=".json,application/json"
              className="hidden"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={handleDownloadLocalBackupJSON}
                disabled={isExportingBackup}
                className="w-full py-2.5 px-3 bg-sky-700 hover:bg-sky-800 active:scale-98 disabled:bg-sky-400 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <Download className={`w-4 h-4 ${isExportingBackup ? 'animate-bounce' : ''}`} />
                <span>
                  {isExportingBackup ? 'Menyiapkan Backup...' : 'Download Backup (.json)'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => backupFileInputRef.current?.click()}
                className="w-full py-2.5 px-3 bg-white hover:bg-sky-100/70 border border-sky-300 text-sky-900 active:scale-98 font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <Upload className="w-4 h-4 text-sky-700" />
                <span>Upload Backup (.json)</span>
              </button>
            </div>
          </div>

          {/* Firebase Firestore Cloud Database Section */}
          <div className="p-4 rounded-xl border border-red-200 bg-red-50/50 space-y-3 text-xs">
            <div className="flex items-center justify-between font-bold text-red-950">
              <span className="flex items-center gap-2 text-sm font-extrabold">
                <Flame className="w-5 h-5 text-red-600 fill-red-500" /> Firebase Firestore Backend
              </span>
              <span className="px-2.5 py-0.5 bg-red-100 text-red-900 rounded-full text-[10px] font-extrabold border border-red-200 flex items-center gap-1">
                <Zap className="w-3 h-3 text-red-700 fill-red-600" /> Ultra Fast Realtime
              </span>
            </div>

            <p className="text-[11px] text-stone-700 leading-relaxed font-medium">
              Firebase Firestore telah aktif dan siap memberikan performa database super cepat (&lt;50ms), dukungan offline, serta pembaruan otomatis antar-kasir tanpa perlu reload page!
            </p>

            <div className="pt-1 flex flex-col gap-2">
              <button
                type="button"
                onClick={handleMigrateToFirebase}
                disabled={isMigratingFirebase || isClearingDummy}
                className="w-full py-2.5 bg-red-700 hover:bg-red-800 disabled:bg-red-400 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition active:scale-98 cursor-pointer"
              >
                <Database className="w-4 h-4" />
                <span>
                  {isMigratingFirebase ? 'Proses Migrasi Ke Firestore...' : 'Migrasi 1-Klik Data Ke Firebase Firestore'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {!showConfirmClearDummy ? (
                <button
                  type="button"
                  onClick={() => setShowConfirmClearDummy(true)}
                  disabled={isMigratingFirebase || isClearingDummy}
                  className="w-full py-2 bg-stone-100 hover:bg-red-50 text-stone-700 hover:text-red-700 border border-stone-200 hover:border-red-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                  <span>Hapus Semua Data Dummy / Bersihkan Database</span>
                </button>
              ) : (
                <div className="p-3 bg-red-50 border border-red-300 rounded-xl space-y-2 text-xs animate-fade-in">
                  <p className="font-extrabold text-red-950 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-red-700 shrink-0" />
                    Konfirmasi Hapus Semua Data Dummy?
                  </p>
                  <p className="text-[11px] text-stone-600 leading-relaxed font-medium">
                    Aksi ini akan menghapus produk dummy/sample, pelanggan dummy, kasir dummy (menyisakan Admin), riwayat transaksi, dan membersihkan seluruh cache lokal.
                  </p>
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowConfirmClearDummy(false)}
                      disabled={isClearingDummy}
                      className="px-3 py-1.5 bg-white border border-stone-300 text-stone-700 rounded-lg text-xs font-bold hover:bg-stone-50 cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="button"
                      onClick={handleDeleteAllDummyData}
                      disabled={isClearingDummy}
                      className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isClearingDummy ? 'Menghapus...' : 'Ya, Hapus Semua Dummy'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {migrationStats && (
              <div className="p-2.5 bg-white border border-red-200 rounded-lg space-y-1 text-[11px]">
                <p className="font-extrabold text-red-900 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Hasil Migrasi Firebase Firestore:
                </p>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-stone-700 font-semibold pt-1 text-[10px]">
                  <div>📦 Produk: <strong>{migrationStats.products || 0}</strong></div>
                  <div>👥 Pelanggan: <strong>{migrationStats.customers || 0}</strong></div>
                  <div>🔑 Kasir/User: <strong>{migrationStats.kasirUsers || 0}</strong></div>
                  <div>💸 Pengeluaran: <strong>{migrationStats.expenses || 0}</strong></div>
                  <div>📄 Transaksi/Invoice: <strong>{migrationStats.invoices || 0}</strong></div>
                  <div>⚙️ Pengaturan Toko: <strong>{migrationStats.settings || 0}</strong></div>
                </div>
              </div>
            )}
          </div>

          {/* Google Sheets Workspace Integration (Direct REST API & OAuth) */}
          <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/60 space-y-3 text-xs">
            <div className="flex items-center justify-between font-bold text-emerald-950 flex-wrap gap-2">
              <span className="flex items-center gap-2 text-sm font-extrabold">
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" /> Google Sheets Cloud Integration
              </span>
              <div className="flex items-center gap-2">
                {sheetInfo.id ? (
                  <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-900 rounded-full text-[10px] font-extrabold border border-emerald-300 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3 text-emerald-700" /> Terhubung
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 bg-stone-100 text-stone-700 rounded-full text-[10px] font-bold border border-stone-200">
                    Belum Terhubung
                  </span>
                )}
              </div>
            </div>

            <p className="text-[11px] text-stone-700 leading-relaxed font-medium">
              Simpan dan sinkronkan data produk, pelanggan, riwayat transaksi, barang masuk, pengeluaran, dan kasir langsung ke Google Spreadsheet di Google Drive Anda.
            </p>

            {/* Connected Spreadsheet Card */}
            {sheetInfo.id ? (
              <div className="p-3 bg-white border border-emerald-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="min-w-0">
                    <p className="font-extrabold text-stone-900 text-xs truncate flex items-center gap-1.5">
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{sheetInfo.title || 'WARUNG KAKA - Database POS & Keuangan'}</span>
                    </p>
                    <p className="text-[10px] text-stone-500 font-mono truncate mt-0.5">
                      ID: {sheetInfo.id}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {sheetInfo.url && (
                      <a
                        href={sheetInfo.url}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs transition active:scale-95"
                      >
                        <span>Buka di Google Sheets</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}

                    <button
                      type="button"
                      onClick={handleDisconnectSpreadsheet}
                      className="px-2 py-1.5 text-stone-400 hover:text-red-700 hover:bg-red-50 rounded-lg text-xs font-bold transition"
                      title="Putuskan sambungan Spreadsheet ini"
                    >
                      Putuskan
                    </button>
                  </div>
                </div>

                {/* 2-Way Sync Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={handlePushAllToGoogleSheets}
                    disabled={isPushingSheets || isPullingSheets}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white font-extrabold rounded-lg text-xs flex items-center justify-center gap-1.5 transition active:scale-98 cursor-pointer shadow-2xs"
                  >
                    <UploadCloud className={`w-4 h-4 ${isPushingSheets ? 'animate-bounce' : ''}`} />
                    <span>{isPushingSheets ? 'Mengirim Data...' : 'Kirim Semua Data ke Sheets'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handlePullProductsFromGoogleSheets}
                    disabled={isPushingSheets || isPullingSheets}
                    className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold border border-stone-200 rounded-lg text-xs flex items-center justify-center gap-1.5 transition active:scale-98 cursor-pointer"
                  >
                    <DownloadCloud className={`w-4 h-4 ${isPullingSheets ? 'animate-bounce' : ''}`} />
                    <span>{isPullingSheets ? 'Memuat Produk...' : 'Tarik Produk dari Sheets'}</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Connect / Create Spreadsheet Options */
              <div className="space-y-2.5 bg-white p-3.5 rounded-xl border border-emerald-200">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCreateGoogleSpreadsheet}
                    disabled={isCreatingSheet}
                    className="flex-1 py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 disabled:bg-emerald-400 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition active:scale-98 cursor-pointer"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>
                      {isCreatingSheet ? 'Membuat Spreadsheet...' : 'Buat Spreadsheet Baru (1-Klik)'}
                    </span>
                  </button>

                  {!googleAuthStatus && (
                    <button
                      type="button"
                      onClick={handleAuthorizeGoogle}
                      disabled={isAuthorizingGoogle}
                      className="py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold border border-stone-200 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      <Link className="w-3.5 h-3.5 text-stone-600" />
                      <span>{isAuthorizingGoogle ? 'Otorisasi...' : 'Otorisasi Google'}</span>
                    </button>
                  )}
                </div>

                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-stone-200"></div>
                  <span className="flex-shrink mx-2 text-[10px] text-stone-400 font-bold uppercase">Atau Hubungkan yang Sudah Ada</span>
                  <div className="flex-grow border-t border-stone-200"></div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customSheetInput}
                    onChange={(e) => setCustomSheetInput(e.target.value)}
                    placeholder="Paste link Google Spreadsheet atau Spreadsheet ID..."
                    className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs text-stone-800 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-600 font-medium"
                  />
                  <button
                    type="button"
                    onClick={handleConnectCustomSpreadsheet}
                    className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow-2xs transition active:scale-95 cursor-pointer"
                  >
                    Hubungkan
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Connection URL Google Sheets Configuration (Apps Script) */}
          <details className="p-3.5 rounded-xl border border-stone-200 bg-white group">
            <summary className="text-xs font-bold text-stone-800 cursor-pointer flex items-center justify-between select-none">
              <span className="flex items-center gap-1.5">
                <Link className="w-4 h-4 text-stone-500" /> Google Apps Script (Web App v6 Alternative)
              </span>
              <ChevronDown className="w-4 h-4 text-stone-400 group-open:rotate-180 transition" />
            </summary>
            <div className="mt-3 pt-3 border-t border-stone-100 space-y-3">
              {/* Panduan Integrasi Banner */}
              <div className="p-3 bg-red-50/60 border border-red-200 rounded-xl flex items-center justify-between gap-3 flex-wrap">
                <div className="text-xs">
                  <p className="font-extrabold text-red-900">
                    Panduan Script & Download Code.gs (v5)
                  </p>
                  <p className="text-[11px] text-stone-600 font-medium">
                    Salin kode Apps Script v5, unduh file Code.gs, atau baca petunjuk integrasi real-time.
                  </p>
                </div>
                {onOpenGasGuide && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenGasGuide();
                    }}
                    className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition shrink-0 active:scale-95 shadow-xs cursor-pointer"
                  >
                    <span>Panduan & Download Code.gs</span>
                  </button>
                )}
              </div>

              <div>
                <label className="text-[11px] text-stone-500 block font-medium mb-1">
                  URL Web App Google Apps Script (Deployment 'Anyone'):
                </label>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://script.google.com/macros/s/.../exec"
                  className="w-full p-2 border border-stone-200 rounded-lg font-mono text-[11px] bg-stone-50 focus:bg-white focus:border-red-600 focus:ring-1 focus:ring-red-200 transition"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={testing || initializing}
                  className="px-2.5 py-1.5 rounded-lg border border-stone-200 bg-stone-100 hover:bg-stone-200 text-stone-800 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                >
                  <PlugZap className="w-3.5 h-3.5 text-stone-600" />
                  <span>{testing ? 'Menghubungi...' : 'Tes Koneksi'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleInitSheets}
                  disabled={testing || initializing}
                  className="px-2.5 py-1.5 rounded-lg border border-stone-300 bg-stone-50 hover:bg-stone-100 text-stone-900 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                >
                  <RotateCw className={`w-3.5 h-3.5 text-stone-700 ${initializing ? 'animate-spin' : ''}`} />
                  <span>{initializing ? 'Menginisialisasi...' : 'Init Sheet v5'}</span>
                </button>

                <button
                  type="button"
                  onClick={onSync}
                  disabled={testing || initializing}
                  className="px-2.5 py-1.5 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-800 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                >
                  <RotateCw className="w-3.5 h-3.5 text-red-700" />
                  <span>Sinkron Data</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    clearLocalCache();
                    onSync();
                    onShowToast('Cache transaksi lokal dibersihkan & disinkron ulang', 'info');
                  }}
                  className="px-2.5 py-1.5 rounded-lg border border-stone-200 bg-stone-100 hover:bg-stone-200 text-stone-700 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                  title="Hapus cache transaksi/pelunasan lokal jika spreadsheet kosong"
                >
                  <Trash2 className="w-3.5 h-3.5 text-stone-600" />
                  <span>Clear Cache</span>
                </button>
              </div>

              {testResult && (
                <div
                  className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                    testResult.ok ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-red-50 text-red-800'
                  }`}
                >
                  {testResult.ok ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0" />
                  )}
                  <span>{testResult.msg}</span>
                </div>
              )}
            </div>
          </details>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-200">
            <button
              onClick={onClose}
              className="px-4 py-2 text-stone-600 hover:bg-stone-100 text-xs font-semibold rounded-lg transition cursor-pointer"
            >
              Batal
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-bold rounded-lg shadow-xs transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Pengaturan</span>
            </button>
          </div>
        </div>
      </div>

      {/* SPV / Owner Authorization Verification Modal */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <Lock className="w-4 h-4 text-red-700" />
                <span>Otorisasi SPV / Owner Diperlukan</span>
              </h3>
              <button
                onClick={() => {
                  setIsAuthModalOpen(false);
                  setPendingAction(null);
                }}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Tindakan ini merupakan hak akses terbatas ({pendingAction?.type === 'delete' ? `Hapus Kasir "${pendingAction.targetKasir}"` : 'Tambah Kasir'}). Silakan pilih akun <strong>SPV / Owner</strong> dan masukkan password otorisasi.
            </p>

            <form onSubmit={handleVerifyAuth} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Akun SPV / Owner Penanggung Jawab
                </label>
                <select
                  value={authSpvUser}
                  onChange={(e) => setAuthSpvUser(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-bold bg-stone-50"
                  required
                >
                  {kasirUsers.map((u, i) => (
                    <option key={i} value={u.nama}>
                      👤 {u.nama}
                    </option>
                  ))}
                  {kasirUsers.length === 0 && <option value="SPV">SPV / Admin</option>}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Password Otorisasi
                </label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="Masukkan password SPV / Owner"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAuthModalOpen(false);
                    setPendingAction(null);
                  }}
                  className="px-3 py-1.5 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verifikasi & Lanjutkan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Kasir Modal */}
      {isAddKasirOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-red-700" />
                <span>Tambah Kasir / Operator Baru</span>
              </h3>
              <button
                onClick={() => setIsAddKasirOpen(false)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddKasirSubmit} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Nama Kasir / Operator Baru
                </label>
                <input
                  type="text"
                  value={newKasirName}
                  onChange={(e) => setNewKasirName(e.target.value)}
                  placeholder="Contoh: Ani, Budi, Maya"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Role / Jabatan
                </label>
                <select
                  value={newKasirRole}
                  onChange={(e) => setNewKasirRole(e.target.value as any)}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold bg-stone-50"
                >
                  <option value="Kasir">Kasir / Operator Standard</option>
                  <option value="SPV">SPV (Supervisor)</option>
                  <option value="Owner">Owner / Pimpinan</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Password Akses (Opsional)
                </label>
                <input
                  type="password"
                  value={newKasirPass}
                  onChange={(e) => setNewKasirPass(e.target.value)}
                  placeholder="Default: ervo123 (jika dikosongkan)"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs"
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Password awal default jika kosong adalah <strong>ervo123</strong>
                </p>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddKasirOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSavingNewKasir}
                  className="px-4 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  {isSavingNewKasir ? 'Menyimpan...' : 'Tambah Kasir'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Kasir Confirmation Modal */}
      {kasirToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-rose-700 text-sm flex items-center gap-2">
                <Trash2 className="w-4 h-4" />
                <span>Hapus Akun Operator / Kasir</span>
              </h3>
              <button
                onClick={() => setKasirToDelete(null)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-stone-600 space-y-2">
              <p>
                Apakah Anda yakin ingin menghapus akun operator/kasir <strong className="text-stone-900">"{kasirToDelete}"</strong> dari sistem?
              </p>
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 text-[11px] text-stone-500">
                Akun ini tidak akan dapat login lagi ke sistem kasir. Riwayat transaksi sebelumnya tetap tersimpan rapi.
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
              <button
                type="button"
                disabled={deletingKasirName !== null}
                onClick={() => setKasirToDelete(null)}
                className="px-3.5 py-1.5 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={deletingKasirName !== null}
                onClick={() => executeDeleteKasir(kasirToDelete)}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition active:scale-95 disabled:opacity-50"
              >
                {deletingKasirName ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Hapus Akun</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BACKUP RESTORE / UPLOAD CONFIRMATION MODAL */}
      {backupFilePreview && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-sky-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2 text-sky-950 font-black text-sm">
                <FileUp className="w-5 h-5 text-sky-600" />
                <span>Konfirmasi Pemulihan File Backup</span>
              </div>
              <button
                type="button"
                disabled={isRestoringBackup}
                onClick={() => setBackupFilePreview(null)}
                className="text-stone-400 hover:text-stone-700 text-base font-bold p-1 rounded-lg hover:bg-stone-100 cursor-pointer disabled:opacity-50"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-sky-50/80 border border-sky-200 rounded-xl p-3.5 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sky-950 text-xs truncate max-w-[280px]">
                    📄 {backupFilePreview.fileName}
                  </span>
                  <span className="px-2 py-0.5 bg-sky-100 text-sky-800 text-[10px] font-extrabold rounded-full">
                    JSON Valid
                  </span>
                </div>
                {backupFilePreview.dateStr && (
                  <p className="text-[11px] text-stone-500">
                    Tanggal Backup: <strong>{backupFilePreview.dateStr}</strong>
                  </p>
                )}
              </div>

              {/* Data Summary Grid */}
              <div>
                <p className="text-[11px] font-bold text-stone-700 mb-1.5">Data Ditemukan di Dalam File:</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-center">
                    <div className="text-[10px] text-stone-400 font-medium">📦 Produk</div>
                    <div className="text-sm font-black text-stone-900 mt-0.5">
                      {backupFilePreview.products.length}
                    </div>
                  </div>
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-center">
                    <div className="text-[10px] text-stone-400 font-medium">👥 Pelanggan</div>
                    <div className="text-sm font-black text-stone-900 mt-0.5">
                      {backupFilePreview.customers.length}
                    </div>
                  </div>
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-center">
                    <div className="text-[10px] text-stone-400 font-medium">📄 Invoice</div>
                    <div className="text-sm font-black text-stone-900 mt-0.5">
                      {backupFilePreview.invoices.length}
                    </div>
                  </div>
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-center">
                    <div className="text-[10px] text-stone-400 font-medium">💸 Pengeluaran</div>
                    <div className="text-sm font-black text-stone-900 mt-0.5">
                      {backupFilePreview.expenses.length}
                    </div>
                  </div>
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-center">
                    <div className="text-[10px] text-stone-400 font-medium">📥 Stok Masuk</div>
                    <div className="text-sm font-black text-stone-900 mt-0.5">
                      {backupFilePreview.stockIn.length}
                    </div>
                  </div>
                  <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-center">
                    <div className="text-[10px] text-stone-400 font-medium">👤 Kasir/User</div>
                    <div className="text-sm font-black text-stone-900 mt-0.5">
                      {backupFilePreview.kasirUsers.length}
                    </div>
                  </div>
                </div>
              </div>

              {/* Mode Selection */}
              <div className="space-y-1.5 pt-1">
                <p className="text-[11px] font-bold text-stone-700">Metode Pemulihan:</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label className={`p-2.5 rounded-xl border flex items-start gap-2.5 cursor-pointer transition ${importMode === 'merge' ? 'bg-sky-50/80 border-sky-400 ring-1 ring-sky-300' : 'bg-white border-stone-200 hover:bg-stone-50'}`}>
                    <input
                      type="radio"
                      name="importMode"
                      value="merge"
                      checked={importMode === 'merge'}
                      onChange={() => setImportMode('merge')}
                      className="mt-0.5 accent-sky-700"
                    />
                    <div>
                      <div className="text-xs font-bold text-stone-900">Gabungkan (Merge)</div>
                      <div className="text-[10px] text-stone-500 leading-tight mt-0.5">
                        Menambahkan data baru tanpa menghapus data lokal yang sudah ada sebelumnya.
                      </div>
                    </div>
                  </label>

                  <label className={`p-2.5 rounded-xl border flex items-start gap-2.5 cursor-pointer transition ${importMode === 'replace' ? 'bg-amber-50/80 border-amber-400 ring-1 ring-amber-300' : 'bg-white border-stone-200 hover:bg-stone-50'}`}>
                    <input
                      type="radio"
                      name="importMode"
                      value="replace"
                      checked={importMode === 'replace'}
                      onChange={() => setImportMode('replace')}
                      className="mt-0.5 accent-amber-600"
                    />
                    <div>
                      <div className="text-xs font-bold text-stone-900">Gantikan (Replace)</div>
                      <div className="text-[10px] text-stone-500 leading-tight mt-0.5">
                        Menimpa dan menggantikan penuh seluruh data lokal dengan data dari file backup.
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-3 text-[11px] text-emerald-900 leading-relaxed">
                ✨ <strong>Otomatis Sinkronisasi:</strong> Seluruh data yang dipulihkan akan langsung disimpan di memori lokal dan disinkronkan ke <strong>Firebase Firestore Cloud Database</strong>.
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
              <button
                type="button"
                disabled={isRestoringBackup}
                onClick={() => setBackupFilePreview(null)}
                className="px-3.5 py-2 rounded-xl border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 cursor-pointer disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isRestoringBackup}
                onClick={handleExecuteRestoreBackup}
                className="px-4 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs transition active:scale-95 disabled:opacity-50"
              >
                {isRestoringBackup ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin" />
                    <span>Memulihkan Data...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Pulihkan & Terapkan Data</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
