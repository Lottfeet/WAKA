import { ExpenseRecord } from '../types';
import { addExpenseRemote, deleteExpenseRemote } from './gasService';
import { saveExpenseFirebase, deleteExpenseFirebase } from './firebaseService';

const STORAGE_KEY = 'strukku_company_expenses';

export function deduplicateExpenses(list: ExpenseRecord[]): ExpenseRecord[] {
  if (!Array.isArray(list)) return [];
  const seen = new Set<string>();
  const result: ExpenseRecord[] = [];
  for (const item of list) {
    if (!item) continue;
    const key = item.id && item.id.trim() ? item.id.trim() : `${item.tanggal}-${item.keterangan}-${item.nominal}`;
    if (!seen.has(key)) {
      seen.add(key);
      result.push(item);
    }
  }
  return result;
}

// Sample initial expense data for immediate reporting demo
const INITIAL_EXPENSES: ExpenseRecord[] = [
  {
    id: 'EXP-101',
    tanggal: new Date().toISOString().split('T')[0],
    kategori: 'Bahan Baku',
    keterangan: 'Pembelian Kertas Art Paper 230g A3+ (5 Pack)',
    nominal: 450000,
    pj: 'Admin / Kasir',
  },
  {
    id: 'EXP-102',
    tanggal: new Date().toISOString().split('T')[0],
    kategori: 'Sewa & Utilitas',
    keterangan: 'Pembayaran Token Listrik Operasional Workshop',
    nominal: 250000,
    pj: 'Admin / Kasir',
  },
  {
    id: 'EXP-103',
    tanggal: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    kategori: 'Maintenance & Service',
    keterangan: 'Servis Head & Isi Ulang Tinta Plotter Roland',
    nominal: 350000,
    pj: 'Teknisi Studio',
  },
  {
    id: 'EXP-104',
    tanggal: new Date(Date.now() - 86400000 * 4).toISOString().split('T')[0],
    kategori: 'Operasional & Makanan',
    keterangan: 'Snack & Galon Air Minum Karyawan Cetak',
    nominal: 85000,
    pj: 'Kasir',
  },
];

export function getStoredExpenses(): ExpenseRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_EXPENSES));
      return INITIAL_EXPENSES;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      const unique = deduplicateExpenses(parsed);
      if (unique.length !== parsed.length) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(unique));
      }
      return unique;
    }
    return INITIAL_EXPENSES;
  } catch (e) {
    console.error('Failed to parse expenses from localStorage:', e);
    return INITIAL_EXPENSES;
  }
}

export function saveExpenses(expenses: ExpenseRecord[]): void {
  try {
    const unique = deduplicateExpenses(expenses);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(unique));
  } catch (e) {
    console.error('Failed to save expenses to localStorage:', e);
  }
}

export function addExpenseRecord(expense: Omit<ExpenseRecord, 'id'>): ExpenseRecord {
  const current = getStoredExpenses();
  const newRecord: ExpenseRecord = {
    ...expense,
    id: 'EXP-' + Date.now().toString().slice(-6),
  };
  const updated = deduplicateExpenses([newRecord, ...current]);
  saveExpenses(updated);

  // Sync to Google Sheets in background
  addExpenseRemote(newRecord).catch((err) =>
    console.error('Failed to sync new expense to Google Sheets:', err)
  );

  // Sync to Firebase in background
  saveExpenseFirebase(newRecord).catch((err) =>
    console.error('Failed to sync new expense to Firebase:', err)
  );

  return newRecord;
}

export function updateExpenseRecord(id: string, expense: Partial<ExpenseRecord>): boolean {
  const current = getStoredExpenses();
  const idx = current.findIndex((e) => e.id === id);
  if (idx === -1) return false;
  current[idx] = { ...current[idx], ...expense };
  const updated = deduplicateExpenses(current);
  saveExpenses(updated);

  // Sync updated record to Google Sheets
  addExpenseRemote(updated[idx]).catch((err) =>
    console.error('Failed to sync updated expense to Google Sheets:', err)
  );

  // Sync updated record to Firebase
  saveExpenseFirebase(updated[idx]).catch((err) =>
    console.error('Failed to sync updated expense to Firebase:', err)
  );

  return true;
}

export function deleteExpenseRecord(id: string): boolean {
  const current = getStoredExpenses();
  const filtered = current.filter((e) => e.id !== id);
  if (filtered.length === current.length) return false;
  saveExpenses(filtered);

  // Sync deletion to Google Sheets in background
  deleteExpenseRemote(id).catch((err) =>
    console.error('Failed to delete expense from Google Sheets:', err)
  );

  // Sync deletion to Firebase
  deleteExpenseFirebase(id).catch((err) =>
    console.error('Failed to delete expense from Firebase:', err)
  );

  return true;
}
