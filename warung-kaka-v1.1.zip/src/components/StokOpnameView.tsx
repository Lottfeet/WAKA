import React, { useState, useEffect, useMemo } from 'react';
import { Product, StockOpnameRecord, StockOpnameItem, StoreSettings } from '../types';
import { saveStockOpnameFirebase, deleteStockOpnameFirebase, subscribeStockOpname, saveProductFirebase } from '../services/firebaseService';
import { submitStockOpname, getStockOpnameHistoryFromLocal, deleteStockOpnameFromLocal, updateProductDetails } from '../services/gasService';
import { fDateInput, fTime, fRp } from '../utils/formatters';
import { 
  generateStockOpnameA4HTML, 
  generateBlankStockOpnameSheetHTML, 
  openPrintWindow 
} from '../utils/printUtils';
import { 
  ClipboardCheck, 
  Search, 
  RotateCw, 
  Printer, 
  FileText, 
  History, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingDown, 
  TrendingUp, 
  Calendar, 
  User, 
  Filter, 
  HelpCircle, 
  Sparkles, 
  ChevronRight, 
  ChevronDown,
  ChevronUp,
  ArrowUpDown,
  ArrowUp,
  SlidersHorizontal,
  Layers,
  Trash2, 
  Eye, 
  ArrowRight,
  Boxes,
  Plus,
  Minus,
  Check,
  FileSpreadsheet,
  X,
  Clock,
  Save,
  Info,
  CheckCheck,
  FileCheck,
  FileEdit,
  PenLine,
  RotateCcw
} from 'lucide-react';

interface AuditItemDetail {
  stokFisik: number | string;
  isFilled: boolean;
  countedBy?: string;
  countedAt?: string;
  catatan: string;
}

interface DraftOpnameState {
  bulanPeriode: string;
  tanggalOpname: string;
  jamOpname: string;
  petugas: string;
  penanggungJawab: string;
  catatanUmum: string;
  auditItems: Record<string, AuditItemDetail>;
  lastSavedAt?: string;
  lastSavedBy?: string;
}

interface StokOpnameViewProps {
  products: Product[];
  currentCashier: string;
  settings: StoreSettings;
  onRefreshProducts: () => void;
  onProductsUpdated?: (newProducts: Product[]) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const StokOpnameView: React.FC<StokOpnameViewProps> = ({
  products,
  currentCashier,
  settings,
  onRefreshProducts,
  onProductsUpdated,
  onShowToast,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'audit_form' | 'history'>('audit_form');

  // Audit Form Header State
  const today = new Date();
  const currentMonthYearName = today.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
  const [bulanPeriode, setBulanPeriode] = useState<string>(currentMonthYearName);
  const [tanggalOpname, setTanggalOpname] = useState<string>(fDateInput(today));
  const [jamOpname, setJamOpname] = useState<string>(fTime(today));
  const [petugas, setPetugas] = useState<string>(currentCashier || 'Admin');
  const [penanggungJawab, setPenanggungJawab] = useState<string>('Kepala Toko / SPV');
  const [catatanUmum, setCatatanUmum] = useState<string>('Stock opname rutin bulanan');

  // Interactive Product Audit State: mapping product code/name -> StockOpnameItem
  const [auditItems, setAuditItems] = useState<Record<string, AuditItemDetail>>({});
  const [lastSavedDraftInfo, setLastSavedDraftInfo] = useState<{ at: string; by: string } | null>(null);
  const [draftLoaded, setDraftLoaded] = useState<boolean>(false);

  // Filter & Search Controls
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('Semua');
  const [statusFilter, setStatusFilter] = useState<'semua' | 'belum_diisi' | 'sudah_diisi' | 'sedang_diinput' | 'selisih' | 'kurang' | 'lebih' | 'sesuai'>('semua');
  const [sortBy, setSortBy] = useState<'default' | 'uncounted_first' | 'selisih_first' | 'name_asc' | 'name_desc' | 'stock_desc'>('default');
  const [isMetadataOpen, setIsMetadataOpen] = useState<boolean>(false);
  const [pinnedFilterKeys, setPinnedFilterKeys] = useState<Set<string> | null>(null);

  // Confirmation Modal State
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [deletingRecord, setDeletingRecord] = useState<StockOpnameRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // History & Detail Modal State
  const [opnameHistory, setOpnameHistory] = useState<StockOpnameRecord[]>(() => getStockOpnameHistoryFromLocal());
  const [selectedRecordDetail, setSelectedRecordDetail] = useState<StockOpnameRecord | null>(null);
  const [historySearch, setHistorySearch] = useState<string>('');

  // Subscribe to real-time opname history
  useEffect(() => {
    const unsub = subscribeStockOpname((list) => {
      setOpnameHistory(list);
    });
    return () => {
      unsub();
    };
  }, []);

  // Restore Draft on component mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('strukku_stock_opname_draft');
      if (saved) {
        const parsed: DraftOpnameState = JSON.parse(saved);
        if (parsed && parsed.auditItems && Object.keys(parsed.auditItems).length > 0) {
          setAuditItems(parsed.auditItems);
          if (parsed.bulanPeriode) setBulanPeriode(parsed.bulanPeriode);
          if (parsed.tanggalOpname) setTanggalOpname(parsed.tanggalOpname);
          if (parsed.jamOpname) setJamOpname(parsed.jamOpname);
          if (parsed.petugas) setPetugas(parsed.petugas);
          if (parsed.penanggungJawab) setPenanggungJawab(parsed.penanggungJawab);
          if (parsed.catatanUmum) setCatatanUmum(parsed.catatanUmum);
          if (parsed.lastSavedAt) {
            setLastSavedDraftInfo({ at: parsed.lastSavedAt, by: parsed.lastSavedBy || 'Petugas' });
          }
        }
      }
    } catch (e) {
      console.warn('Error restoring stock opname draft:', e);
    }
    setDraftLoaded(true);
  }, []);

  // Auto-Save Draft with Debounce
  useEffect(() => {
    if (!draftLoaded) return;
    const timer = setTimeout(() => {
      const filledCount = (Object.values(auditItems) as AuditItemDetail[]).filter((i) => i.isFilled).length;
      if (filledCount > 0) {
        const nowStr = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) + ' ' + fTime(new Date());
        const draft: DraftOpnameState = {
          bulanPeriode,
          tanggalOpname,
          jamOpname,
          petugas,
          penanggungJawab,
          catatanUmum,
          auditItems,
          lastSavedAt: nowStr,
          lastSavedBy: petugas || currentCashier || 'Admin',
        };
        try {
          localStorage.setItem('strukku_stock_opname_draft', JSON.stringify(draft));
          setLastSavedDraftInfo({ at: nowStr, by: draft.lastSavedBy || 'Petugas' });
        } catch (e) {
          console.warn('Failed auto-saving draft opname:', e);
        }
      }
    }, 600);
    return () => clearTimeout(timer);
  }, [auditItems, bulanPeriode, tanggalOpname, jamOpname, petugas, penanggungJawab, catatanUmum, draftLoaded, currentCashier]);

  // Get distinct categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.kategori && p.kategori.trim()) {
        set.add(p.kategori.trim());
      }
    });
    return ['Semua', ...Array.from(set).sort()];
  }, [products]);

  // Handle Physical Stock Change for a product
  const handlePhysicalStockChange = (prodCode: string, val: number | string) => {
    const isNowFilled = val !== '' && val !== null && !isNaN(Number(val));
    const nowStr = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) + ' ' + fTime(new Date());
    setAuditItems((prev) => {
      const existing = prev[prodCode] || { stokFisik: '', isFilled: false, catatan: '' };
      return {
        ...prev,
        [prodCode]: {
          ...existing,
          stokFisik: val,
          isFilled: isNowFilled,
          countedBy: isNowFilled ? (existing.countedBy || currentCashier || 'Petugas') : undefined,
          countedAt: isNowFilled ? (existing.countedAt || nowStr) : undefined,
        },
      };
    });
  };

  // Quick action: Set physical stock equal to system stock for one item (1-Klik Tandai Pas/Selesai)
  const handleSetSameAsSystem = (prodCode: string, sysStok: number) => {
    const nowStr = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) + ' ' + fTime(new Date());
    setAuditItems((prev) => {
      const existing = prev[prodCode] || { stokFisik: '', isFilled: false, catatan: '' };
      return {
        ...prev,
        [prodCode]: {
          ...existing,
          stokFisik: sysStok,
          isFilled: true,
          countedBy: currentCashier || petugas || 'Petugas',
          countedAt: nowStr,
          catatan: existing.catatan || 'Sesuai',
        },
      };
    });
  };

  // Reset single item back to uncounted (default 0)
  const handleResetItem = (prodCode: string) => {
    setAuditItems((prev) => {
      const next = { ...prev };
      delete next[prodCode];
      return next;
    });
  };

  // Quick action: Set catatan for one item
  const handleCatatanChange = (prodCode: string, catatan: string) => {
    setAuditItems((prev) => {
      const existing = prev[prodCode] || { stokFisik: '', isFilled: false, catatan: '' };
      return {
        ...prev,
        [prodCode]: {
          ...existing,
          catatan,
        },
      };
    });
  };

  // Pre-fill all items with system stock
  const handlePreFillAllWithSystem = () => {
    const nowStr = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) + ' ' + fTime(new Date());
    const newItems: Record<string, AuditItemDetail> = {};
    products.forEach((p) => {
      const sysStok = parseFloat(String(p.stok || '0').replace(',', '.')) || 0;
      const key = p.kode || p.nama;
      newItems[key] = {
        stokFisik: sysStok,
        isFilled: true,
        countedBy: currentCashier || petugas || 'Petugas',
        countedAt: nowStr,
        catatan: auditItems[key]?.catatan || '',
      };
    });
    setAuditItems(newItems);
    onShowToast('Semua stok fisik diisi sesuai stok sistem. Silakan sesuaikan barang yang memiliki selisih.', 'info');
  };

  // Reset all audit inputs
  const handleResetAuditForm = () => {
    setShowResetConfirmModal(true);
  };

  const handleExecuteResetAudit = () => {
    setAuditItems({});
    try {
      localStorage.removeItem('strukku_stock_opname_draft');
    } catch (e) {}
    setLastSavedDraftInfo(null);
    setStatusFilter('semua');
    setPinnedFilterKeys(null);
    setSortBy('default');
    setSearchQuery('');
    setCategoryFilter('Semua');
    setShowResetConfirmModal(false);
    onShowToast('Lembar hitung fisik dan draf sesi opname berhasil di-reset menjadi kosong.', 'info');
  };

  // Map of products that have been officially saved in latest Stock Opnames
  const latestAuditedMap = useMemo(() => {
    const map: Record<string, { tanggal: string; jam: string; id: string; stokFisik: number; selisih: number; status: string; petugas: string; bulanPeriode: string }> = {};
    const sorted = [...opnameHistory].sort((a, b) => new Date(b.createdAt || b.tanggal).getTime() - new Date(a.createdAt || a.tanggal).getTime());
    for (const rec of sorted) {
      if (rec.items && Array.isArray(rec.items)) {
        for (const item of rec.items) {
          const key = item.kode || item.nama;
          if (!map[key]) {
            map[key] = {
              tanggal: rec.tanggal,
              jam: rec.jam || '',
              id: rec.id,
              stokFisik: item.stokFisik,
              selisih: item.selisih,
              status: item.status,
              petugas: rec.petugas || 'Petugas',
              bulanPeriode: rec.bulanPeriode || '',
            };
          }
        }
      }
    }
    return map;
  }, [opnameHistory]);

  // Safe Status Filter Selection (Pins rows so typing does not cause items to jump or vanish)
  const handleSelectStatusFilter = (status: 'semua' | 'belum_diisi' | 'sudah_diisi' | 'sedang_diinput' | 'selisih' | 'kurang' | 'lebih' | 'sesuai') => {
    setStatusFilter(status);
    if (status === 'semua') {
      setPinnedFilterKeys(null);
    } else {
      const keys = new Set<string>();
      processedProducts.forEach((item) => {
        let match = false;
        if (status === 'belum_diisi') match = item.countState === 'uncounted';
        else if (status === 'sedang_diinput') match = item.countState === 'draft';
        else if (status === 'sudah_diisi') match = item.countState === 'saved';
        else if (status === 'selisih') match = (item.isFilled || item.countState === 'saved') && item.selisih !== 0;
        else if (status === 'kurang') match = (item.isFilled || item.countState === 'saved') && item.selisih < 0;
        else if (status === 'lebih') match = (item.isFilled || item.countState === 'saved') && item.selisih > 0;
        else if (status === 'sesuai') match = (item.isFilled || item.countState === 'saved') && item.selisih === 0;
        if (match) keys.add(item.key);
      });
      setPinnedFilterKeys(keys);
    }
  };

  // Manual Draft Save Trigger
  const handleManualSaveDraft = () => {
    const filledCount = (Object.values(auditItems) as AuditItemDetail[]).filter((i) => i.isFilled).length;
    if (filledCount === 0) {
      onShowToast('Belum ada item yang dihitung untuk disimpan sebagai draf', 'info');
      return;
    }
    const nowStr = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) + ' ' + fTime(new Date());
    const draft: DraftOpnameState = {
      bulanPeriode,
      tanggalOpname,
      jamOpname,
      petugas,
      penanggungJawab,
      catatanUmum,
      auditItems,
      lastSavedAt: nowStr,
      lastSavedBy: petugas || currentCashier || 'Admin',
    };
    try {
      localStorage.setItem('strukku_stock_opname_draft', JSON.stringify(draft));
      setLastSavedDraftInfo({ at: nowStr, by: draft.lastSavedBy || 'Petugas' });
      onShowToast(`Draf sesi opname berhasil disimpan (${filledCount} produk terhitung)`, 'success');
    } catch (e) {
      onShowToast('Gagal menyimpan draf sesi', 'error');
    }
  };

  // Calculated List of Audited Items
  const processedProducts = useMemo(() => {
    return products.map((p) => {
      const key = p.kode || p.nama;
      const sysStok = parseFloat(String(p.stok || '0').replace(',', '.')) || 0;
      
      // Ambil Harga Beli / Modal Produk
      let hargaBeli = 0;
      if (p.hargaBeli !== undefined && p.hargaBeli !== null && p.hargaBeli !== '') {
        hargaBeli = typeof p.hargaBeli === 'number' ? p.hargaBeli : (parseFloat(String(p.hargaBeli).replace(/[^0-9.-]/g, '')) || 0);
      } else if (p.hpp !== undefined && p.hpp !== null && p.hpp !== '') {
        hargaBeli = typeof p.hpp === 'number' ? p.hpp : (parseFloat(String(p.hpp).replace(/[^0-9.-]/g, '')) || 0);
      } else if (p.harga) {
        hargaBeli = Number(p.harga);
      }

      const entry = auditItems[key];
      const isFilled = entry?.isFilled || false;
      const lastAudit = latestAuditedMap[key];

      // Tentukan status penghitungan:
      // 'draft': Sedang diinput pada form/lembar aktif (Belum dikonfirmasi simpan)
      // 'saved': Telah resmi disimpan dan diverifikasi pada Stock Opname terakhir (✓ SUDAH DIHITUNG)
      // 'uncounted': Belum pernah dihitung / belum ada di draf maupun riwayat opname
      let countState: 'saved' | 'draft' | 'uncounted' = 'uncounted';
      if (isFilled) {
        countState = 'draft';
      } else if (lastAudit) {
        countState = 'saved';
      } else {
        countState = 'uncounted';
      }

      const rawFisik = entry !== undefined && entry.stokFisik !== undefined && entry.stokFisik !== '' 
        ? String(entry.stokFisik) 
        : (isFilled ? '0' : (lastAudit ? String(lastAudit.stokFisik) : '0'));
      
      const fisikNum = isFilled ? Number(rawFisik) : (lastAudit ? lastAudit.stokFisik : sysStok);
      const selisih = isFilled ? (Number(rawFisik) - sysStok) : (lastAudit ? lastAudit.selisih : 0);
      
      // Nilai Selisih = Qty Selisih x Harga Beli
      const nilaiSelisih = selisih * hargaBeli;

      let status: 'sesuai' | 'kurang' | 'lebih' = 'sesuai';
      if (selisih < 0) status = 'kurang';
      else if (selisih > 0) status = 'lebih';

      return {
        product: p,
        key,
        sysStok,
        fisikNum,
        rawFisik,
        isFilled,
        countState,
        lastAudit,
        countedBy: entry?.countedBy || lastAudit?.petugas,
        countedAt: entry?.countedAt || (lastAudit ? `${lastAudit.tanggal} ${lastAudit.jam}` : undefined),
        selisih,
        nilaiSelisih,
        status,
        hpp: hargaBeli,
        hargaBeli,
        catatan: entry?.catatan || '',
      };
    });
  }, [products, auditItems, latestAuditedMap]);

  // Filtered Products for Display
  const filteredProducts = useMemo(() => {
    return processedProducts.filter((item) => {
      const p = item.product;
      const matchQuery = !searchQuery.trim() || 
        p.nama.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (p.kode && p.kode.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (p.kategori && p.kategori.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchCategory = categoryFilter === 'Semua' || (p.kategori || '').toLowerCase() === categoryFilter.toLowerCase();

      let matchStatus = true;
      if (statusFilter !== 'semua') {
        if (pinnedFilterKeys !== null) {
          matchStatus = pinnedFilterKeys.has(item.key);
        } else {
          if (statusFilter === 'belum_diisi') matchStatus = item.countState === 'uncounted';
          else if (statusFilter === 'sedang_diinput') matchStatus = item.countState === 'draft';
          else if (statusFilter === 'sudah_diisi') matchStatus = item.countState === 'saved';
          else if (statusFilter === 'selisih') matchStatus = (item.isFilled || item.countState === 'saved') && item.selisih !== 0;
          else if (statusFilter === 'kurang') matchStatus = (item.isFilled || item.countState === 'saved') && item.selisih < 0;
          else if (statusFilter === 'lebih') matchStatus = (item.isFilled || item.countState === 'saved') && item.selisih > 0;
          else if (statusFilter === 'sesuai') matchStatus = (item.isFilled || item.countState === 'saved') && item.selisih === 0;
        }
      }

      return matchQuery && matchCategory && matchStatus;
    });
  }, [processedProducts, searchQuery, categoryFilter, statusFilter, pinnedFilterKeys]);

  // Sorted and Filtered Products for Display
  const sortedAndFilteredProducts = useMemo(() => {
    const list = [...filteredProducts];
    if (sortBy === 'uncounted_first') {
      list.sort((a, b) => {
        if (!a.isFilled && b.isFilled) return -1;
        if (a.isFilled && !b.isFilled) return 1;
        return 0;
      });
    } else if (sortBy === 'selisih_first') {
      list.sort((a, b) => {
        const aHasDiff = a.isFilled && a.selisih !== 0 ? 1 : 0;
        const bHasDiff = b.isFilled && b.selisih !== 0 ? 1 : 0;
        return bHasDiff - aHasDiff;
      });
    } else if (sortBy === 'name_asc') {
      list.sort((a, b) => (a.product.nama || '').localeCompare(b.product.nama || ''));
    } else if (sortBy === 'name_desc') {
      list.sort((a, b) => (b.product.nama || '').localeCompare(a.product.nama || ''));
    } else if (sortBy === 'stock_desc') {
      list.sort((a, b) => b.sysStok - a.sysStok);
    }
    return list;
  }, [filteredProducts, sortBy]);

  // Statistics Summary for Current Audit
  const stats = useMemo(() => {
    const filledItems = processedProducts.filter((i) => i.isFilled);
    const sesuai = filledItems.filter((i) => i.selisih === 0);
    const kurang = filledItems.filter((i) => i.selisih < 0);
    const lebih = filledItems.filter((i) => i.selisih > 0);

    const totalNilaiKurang = kurang.reduce((acc, i) => acc + Math.abs(i.nilaiSelisih), 0);
    const totalNilaiLebih = lebih.reduce((acc, i) => acc + i.nilaiSelisih, 0);
    const netNilaiSelisih = filledItems.reduce((acc, i) => acc + i.nilaiSelisih, 0);

    return {
      totalProducts: products.length,
      totalFilled: filledItems.length,
      totalSesuai: sesuai.length,
      totalKurang: kurang.length,
      totalLebih: lebih.length,
      totalNilaiKurang,
      totalNilaiLebih,
      netNilaiSelisih,
      selisihItems: filledItems.filter((i) => i.selisih !== 0),
    };
  }, [processedProducts, products.length]);

  // Execute and Save Stock Opname
  const handleSaveStockOpname = async () => {
    if (stats.totalFilled === 0) {
      onShowToast('Belum ada stok fisik yang diisi. Mohon hitung atau isi stok fisik terlebih dahulu.', 'error');
      return;
    }

    setIsSaving(true);
    try {
      const now = new Date();
      const opnameId = `OPN-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

      // Build Items Array for Record
      const opnameItems: StockOpnameItem[] = processedProducts
        .filter((item) => item.isFilled)
        .map((item) => ({
          kode: item.product.kode,
          nama: item.product.nama,
          satuan: item.product.satuan || 'pcs',
          kategori: item.product.kategori || 'Umum',
          stokSistem: item.sysStok,
          stokFisik: item.fisikNum,
          selisih: item.selisih,
          status: item.status,
          hargaBeli: item.hargaBeli,
          nilaiSelisih: item.nilaiSelisih,
          catatan: item.catatan,
          countedBy: item.countedBy || petugas || 'Petugas',
          countedAt: item.countedAt,
        }));

      const record: StockOpnameRecord = {
        id: opnameId,
        tanggal: tanggalOpname,
        jam: jamOpname,
        bulanPeriode,
        petugas,
        penanggungJawab,
        catatanUmum,
        totalItemDihitung: opnameItems.length,
        totalItemSesuai: stats.totalSesuai,
        totalItemSelisihKurang: stats.totalKurang,
        totalItemSelisihLebih: stats.totalLebih,
        totalNilaiSelisihKurang: stats.totalNilaiKurang,
        totalNilaiSelisihLebih: stats.totalNilaiLebih,
        totalNilaiSelisih: stats.netNilaiSelisih,
        items: opnameItems,
        createdAt: new Date().toISOString(),
      };

      // 1. Update Master Stock in products list state (Real Physical Stock becomes active for POS immediately!)
      const updatedProductsList = products.map((p) => {
        const opItem = opnameItems.find((item) => (item.kode && item.kode === p.kode) || item.nama === p.nama);
        if (opItem) {
          return {
            ...p,
            stok: opItem.stokFisik,
          };
        }
        return p;
      });

      // Save to local storage for immediate persistence
      try {
        localStorage.setItem('strukku_products', JSON.stringify(updatedProductsList));
      } catch (e) {
        console.warn('Failed saving updated products to localStorage', e);
      }

      // Propagate new products state to parent App immediately (POS kasir immediately gets real physical stock!)
      if (onProductsUpdated) {
        onProductsUpdated(updatedProductsList);
      }

      // 2. Save to Firestore (instant in background / non-blocking)
      saveStockOpnameFirebase(record, true).catch((e) => console.warn('Firebase opname save warning:', e));

      // Also ensure Firebase master products collection doc is saved for each adjusted item
      for (const opItem of opnameItems) {
        const prod = updatedProductsList.find((p) => (p.kode && p.kode === opItem.kode) || p.nama === opItem.nama);
        if (prod) {
          saveProductFirebase(prod).catch(() => {});
        }
      }

      // 3. Save to Local Storage & Google Sheets (background non-blocking sync)
      submitStockOpname(record).catch(() => {});

      // 4. Update Google Sheets master spreadsheet stock asynchronously in background
      for (const opItem of opnameItems) {
        const prod = updatedProductsList.find((p) => (p.kode && p.kode === opItem.kode) || p.nama === opItem.nama);
        if (prod) {
          updateProductDetails(prod).catch(() => {});
        }
      }

      // Clear active draft after successful completion & reset physical count to default 0
      try {
        localStorage.removeItem('strukku_stock_opname_draft');
      } catch (e) {}
      setLastSavedDraftInfo(null);
      setAuditItems({});
      setStatusFilter('semua');
      setPinnedFilterKeys(null);
      setSortBy('default');
      setSearchQuery('');
      setCategoryFilter('Semua');

      setShowConfirmModal(false);
      onShowToast(`Stock Opname ${bulanPeriode} berhasil disimpan dan stok master telah disesuaikan!`, 'success');

      // Switch to History Tab to view the newly saved record
      setActiveSubTab('history');
      setSelectedRecordDetail(record);
    } catch (err: any) {
      console.error('Error saving stock opname:', err);
      onShowToast('Gagal menyimpan stock opname: ' + (err.message || 'Terjadi kesalahan'), 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete an Opname Record Confirmation Handler
  const handleConfirmDelete = async () => {
    if (!deletingRecord) return;
    setIsDeleting(true);
    const recId = deletingRecord.id;

    try {
      await deleteStockOpnameFirebase(recId);
      deleteStockOpnameFromLocal(recId);
      setOpnameHistory((prev) => prev.filter((r) => r.id !== recId));
      if (selectedRecordDetail?.id === recId) {
        setSelectedRecordDetail(null);
      }
      onShowToast(`Berita acara "${recId}" berhasil dihapus`, 'info');
      setDeletingRecord(null);
    } catch (err: any) {
      console.error('Error deleting opname record:', err);
      // Fallback local deletion
      deleteStockOpnameFromLocal(recId);
      setOpnameHistory((prev) => prev.filter((r) => r.id !== recId));
      if (selectedRecordDetail?.id === recId) {
        setSelectedRecordDetail(null);
      }
      onShowToast(`Berita acara "${recId}" dihapus dari arsip lokal`, 'info');
      setDeletingRecord(null);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1 sm:pr-2 pb-24 scroll-smooth">
      {/* Top Banner Navigation */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-700 text-white flex items-center justify-center shadow-xs">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-stone-900 tracking-tight flex items-center gap-2">
                Stock Opname & Audit Fisik
                <span className="text-[11px] font-bold px-2 py-0.5 bg-red-100 text-red-800 rounded-full">
                  Bulanan
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                Pencocokan stok fisik real toko dengan stok sistem, analisis selisih, dan penyesuaian otomatis.
              </p>
            </div>
          </div>
        </div>

        {/* Tab Toggle Buttons */}
        <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-xl w-full md:w-auto">
          <button
            onClick={() => setActiveSubTab('audit_form')}
            className={`flex-1 md:flex-initial flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
              activeSubTab === 'audit_form'
                ? 'bg-white text-red-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Boxes className="w-4 h-4 text-red-700" />
            <span>Lembar Hitung Aktif</span>
            {stats.totalFilled > 0 && (
              <span className="text-[10px] font-black bg-red-700 text-white px-1.5 py-0.2 rounded-full">
                {stats.totalFilled}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('history')}
            className={`flex-1 md:flex-initial flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
              activeSubTab === 'history'
                ? 'bg-white text-red-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <History className="w-4 h-4 text-stone-700" />
            <span>Riwayat & Berita Acara</span>
            <span className="text-[10px] font-bold bg-stone-200 text-stone-700 px-1.5 py-0.2 rounded-full">
              {opnameHistory.length}
            </span>
          </button>
        </div>
      </div>

      {/* ================= MODE 1: ACTIVE AUDIT FORM ================= */}
      {activeSubTab === 'audit_form' && (
        <div className="space-y-4">
          {/* Header Metadata Information Form (Collapsible to save vertical screen space) */}
          <div className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden transition">
            <div className="p-3.5 sm:p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-red-100 text-red-800 flex items-center justify-center font-bold text-xs">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-black text-stone-900 flex items-center gap-2">
                    <span>Informasi Periode & Petugas Audit</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-stone-200 text-stone-700 rounded-full">
                      {products.length} Master Produk
                    </span>
                  </div>
                  {!isMetadataOpen && (
                    <div className="text-[11px] text-stone-500 font-medium mt-0.5 flex items-center gap-2 flex-wrap">
                      <span>📅 <strong>{bulanPeriode}</strong> ({tanggalOpname})</span>
                      <span>•</span>
                      <span>👤 Petugas: <strong>{petugas}</strong></span>
                      <span>•</span>
                      <span>🛡️ SPV: <strong>{penanggungJawab}</strong></span>
                    </div>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsMetadataOpen(!isMetadataOpen)}
                className="px-3 py-1.5 bg-white hover:bg-stone-100 text-stone-700 border border-stone-300 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                {isMetadataOpen ? (
                  <>
                    <ChevronUp className="w-3.5 h-3.5" />
                    <span>Sembunyikan Form</span>
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-3.5 h-3.5 text-red-600" />
                    <span>Ubah Info Periode</span>
                  </>
                )}
              </button>
            </div>

            {isMetadataOpen && (
              <div className="p-4 sm:p-5 bg-white border-t border-stone-100 animate-in fade-in duration-150">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1">
                      Bulan / Periode Opname
                    </label>
                    <input
                      type="text"
                      value={bulanPeriode}
                      onChange={(e) => setBulanPeriode(e.target.value)}
                      placeholder="e.g. Agustus 2026"
                      className="w-full text-xs font-bold px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1">
                      Tanggal Pelaksanaan
                    </label>
                    <input
                      type="date"
                      value={tanggalOpname}
                      onChange={(e) => setTanggalOpname(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1">
                      Petugas Auditor / Kasir
                    </label>
                    <input
                      type="text"
                      value={petugas}
                      onChange={(e) => setPetugas(e.target.value)}
                      placeholder="Nama petugas"
                      className="w-full text-xs px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1">
                      Saksi / Penanggung Jawab
                    </label>
                    <input
                      type="text"
                      value={penanggungJawab}
                      onChange={(e) => setPenanggungJawab(e.target.value)}
                      placeholder="Kepala Toko / SPV"
                      className="w-full text-xs px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1">
                      Catatan / Keterangan
                    </label>
                    <input
                      type="text"
                      value={catatanUmum}
                      onChange={(e) => setCatatanUmum(e.target.value)}
                      placeholder="e.g. Audit Rutin Akhir Bulan"
                      className="w-full text-xs px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sesi & Shift Handover Banner */}
          <div className="bg-linear-to-r from-red-50 via-rose-50 to-stone-50 border border-red-200/80 rounded-2xl p-4 shadow-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-red-700 text-white shadow-2xs">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Sesi Stock Opname Berjalan</span>
                </span>
                {lastSavedDraftInfo ? (
                  <span className="text-[11px] text-stone-600 flex items-center gap-1">
                    <Save className="w-3.5 h-3.5 text-emerald-600 inline" />
                    Draf otomatis disimpan • Terakhir: <strong>{lastSavedDraftInfo.at}</strong> ({lastSavedDraftInfo.by})
                  </span>
                ) : (
                  <span className="text-[11px] text-stone-500">
                    Draf otomatis tersimpan di perangkat ini & Cloud
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-600 leading-relaxed">
                💡 <strong>Fitur Multi-Shift:</strong> Jika proses hitung berlanjut ke hari atau shift berikutnya, petugas pengganti dapat langsung membuka tab <span className="font-bold text-red-900 bg-red-100 px-1.5 py-0.2 rounded">⏳ Belum Dihitung</span> untuk menyelesaikan sisa barang tanpa risiko menghitung ulang.
              </p>
            </div>

            {/* Visual Progress Bar */}
            <div className="mt-3 pt-3 border-t border-red-200/60">
              <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                <span className="text-stone-700 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Progress Penghitungan Fisik: {stats.totalFilled} dari {stats.totalProducts} Produk ({Math.round((stats.totalFilled / (stats.totalProducts || 1)) * 100)}%)
                </span>
                <span className="text-red-900 font-bold">
                  Tersisa {stats.totalProducts - stats.totalFilled} Produk Belum Dihitung
                </span>
              </div>
              <div className="w-full bg-stone-200/80 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-emerald-600 h-2.5 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${Math.min(100, Math.round((stats.totalFilled / (stats.totalProducts || 1)) * 100))}%` }}
                />
              </div>
            </div>
          </div>

          {/* Real-time Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div 
              onClick={() => handleSelectStatusFilter(statusFilter === 'belum_diisi' ? 'semua' : 'belum_diisi')}
              className={`border rounded-xl p-3.5 flex flex-col justify-between cursor-pointer transition ${
                statusFilter === 'belum_diisi' 
                  ? 'bg-red-100/80 border-red-400 ring-2 ring-red-500 shadow-xs' 
                  : 'bg-red-50/70 border-red-200 hover:bg-red-100/50'
              }`}
            >
              <span className="text-[11px] font-bold text-red-800 uppercase tracking-tight flex items-center justify-between">
                <span>Belum Dihitung</span>
                <Clock className="w-3.5 h-3.5 text-red-600" />
              </span>
              <div className="mt-1">
                <div className="text-xl font-black text-red-950">
                  {processedProducts.filter((i) => i.countState === 'uncounted').length} <span className="text-xs font-semibold text-red-700">Produk</span>
                </div>
                <div className="text-[10px] text-red-700 font-medium mt-0.5">
                  Klik untuk fokus sisa hitung
                </div>
              </div>
            </div>

            <div 
              onClick={() => handleSelectStatusFilter(statusFilter === 'sudah_diisi' ? 'semua' : 'sudah_diisi')}
              className={`border rounded-xl p-3.5 flex flex-col justify-between cursor-pointer transition ${
                statusFilter === 'sudah_diisi' 
                  ? 'bg-emerald-100/80 border-emerald-400 ring-2 ring-emerald-500 shadow-xs' 
                  : 'bg-emerald-50/70 border-emerald-200 hover:bg-emerald-100/50'
              }`}
            >
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-tight flex items-center justify-between">
                <span>Sudah Dihitung</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              </span>
              <div className="mt-1">
                <div className="text-xl font-black text-emerald-800">
                  {processedProducts.filter((i) => i.countState === 'saved').length} <span className="text-xs font-semibold text-emerald-700">Tersimpan</span>
                </div>
                <div className="text-[10px] text-emerald-700 mt-0.5">
                  {stats.totalFilled > 0 ? `(${stats.totalFilled} sedang diisi draf)` : 'Tersimpan resmi di database'}
                </div>
              </div>
            </div>

            <div 
              onClick={() => handleSelectStatusFilter(statusFilter === 'kurang' ? 'semua' : 'kurang')}
              className={`border rounded-xl p-3.5 flex flex-col justify-between cursor-pointer transition ${
                statusFilter === 'kurang' 
                  ? 'bg-rose-100/80 border-rose-400 ring-2 ring-rose-500 shadow-xs' 
                  : 'bg-rose-50/70 border-rose-200 hover:bg-rose-100/50'
              }`}
            >
              <span className="text-[11px] font-bold text-rose-800 uppercase tracking-tight flex items-center justify-between">
                <span>Selisih Kurang</span>
                <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
              </span>
              <div className="mt-1">
                <div className="text-xl font-black text-rose-700">
                  {stats.totalKurang} <span className="text-xs font-semibold text-rose-600">Item</span>
                </div>
                <div className="text-[10px] font-semibold text-rose-600 mt-0.5">
                  - {fRp(stats.totalNilaiKurang)}
                </div>
              </div>
            </div>

            <div 
              onClick={() => handleSelectStatusFilter(statusFilter === 'lebih' ? 'semua' : 'lebih')}
              className={`border rounded-xl p-3.5 flex flex-col justify-between cursor-pointer transition ${
                statusFilter === 'lebih' 
                  ? 'bg-blue-100/80 border-blue-400 ring-2 ring-blue-500 shadow-xs' 
                  : 'bg-blue-50/70 border-blue-200 hover:bg-blue-100/50'
              }`}
            >
              <span className="text-[11px] font-bold text-blue-800 uppercase tracking-tight flex items-center justify-between">
                <span>Selisih Lebih</span>
                <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              </span>
              <div className="mt-1">
                <div className="text-xl font-black text-blue-700">
                  {stats.totalLebih} <span className="text-xs font-semibold text-blue-600">Item</span>
                </div>
                <div className="text-[10px] font-semibold text-blue-600 mt-0.5">
                  + {fRp(stats.totalNilaiLebih)}
                </div>
              </div>
            </div>
          </div>

          {/* Table Controls & Action Bar */}
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              {/* Search & Category */}
              <div className="flex flex-1 flex-col sm:flex-row items-center gap-2">
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari kode atau nama barang..."
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="w-full sm:w-48">
                  <select
                    value={categoryFilter}
                    onChange={(e) => {
                      setCategoryFilter(e.target.value);
                      if (statusFilter !== 'semua') {
                        handleSelectStatusFilter(statusFilter);
                      }
                    }}
                    className="w-full py-2 px-3 text-xs border border-stone-300 rounded-xl bg-white focus:ring-2 focus:ring-red-600 focus:outline-hidden cursor-pointer"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c === 'Semua' ? '📂 Semua Kategori' : c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handlePreFillAllWithSystem}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  title="Isi otomatis semua fisik sama dengan sistem, lalu cukup ubah yang ada selisih"
                >
                  <Sparkles className="w-3.5 h-3.5 text-red-600" />
                  <span>Isi Sesuai Sistem</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const html = generateBlankStockOpnameSheetHTML(products, settings, categoryFilter);
                    openPrintWindow(html, `Lembar Blanko Opname - ${categoryFilter}`);
                  }}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  title="Cetak lembar kerja kosong bergaris untuk dibawa staf keliling gudang/rak"
                >
                  <Printer className="w-3.5 h-3.5 text-stone-600" />
                  <span>Cetak Blanko Semua (A4)</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetAuditForm}
                  className="px-3 py-2 bg-stone-100 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl transition cursor-pointer"
                  title="Kosongkan semua isian dan reset draf"
                >
                  Reset Sesi
                </button>
              </div>
            </div>

            {/* Filter Pills with Dedicated Handover View Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-stone-100">
              <span className="text-[11px] font-bold text-stone-400 mr-1 flex items-center gap-1">
                <Filter className="w-3 h-3" /> Filter Tampilan:
              </span>

              {[
                { id: 'semua', label: 'Semua Produk', count: processedProducts.length, icon: null },
                { 
                  id: 'belum_diisi', 
                  label: '⏳ Belum Dihitung', 
                  count: processedProducts.filter((i) => i.countState === 'uncounted').length,
                  highlight: 'bg-red-50 text-red-950 border-red-300 font-extrabold',
                  tag: 'Fokus Petugas Pengganti'
                },
                ...(stats.totalFilled > 0 ? [{
                  id: 'sedang_diinput',
                  label: '📝 Sedang Diinput',
                  count: processedProducts.filter((i) => i.countState === 'draft').length,
                  highlight: 'bg-amber-50 text-amber-900 border-amber-300 font-bold',
                }] : []),
                { 
                  id: 'sudah_diisi', 
                  label: '✓ Sudah Dihitung', 
                  count: processedProducts.filter((i) => i.countState === 'saved').length,
                  highlight: 'bg-emerald-50 text-emerald-900 border-emerald-300 font-bold'
                },
                { id: 'selisih', label: '⚠️ Ada Selisih', count: stats.totalKurang + stats.totalLebih },
                { id: 'kurang', label: 'Selisih Kurang', count: stats.totalKurang },
                { id: 'lebih', label: 'Selisih Lebih', count: stats.totalLebih },
                { id: 'sesuai', label: 'Stok Sesuai', count: stats.totalSesuai },
              ].map((pill: any) => {
                const isActive = statusFilter === pill.id;
                return (
                  <button
                    key={pill.id}
                    onClick={() => handleSelectStatusFilter(pill.id)}
                    className={`text-[11px] font-bold px-3 py-1.5 rounded-xl border transition flex items-center gap-1.5 cursor-pointer ${
                      isActive
                        ? 'bg-red-700 text-white border-red-800 shadow-xs'
                        : pill.highlight 
                        ? `${pill.highlight} hover:opacity-90`
                        : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
                    }`}
                  >
                    <span>{pill.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                      isActive ? 'bg-red-950 text-white' : 'bg-black/10 text-stone-800'
                    }`}>
                      {pill.count}
                    </span>
                    {pill.tag && !isActive && (
                      <span className="text-[9px] font-bold uppercase bg-red-200/80 text-red-950 px-1.5 py-0.2 rounded-md hidden sm:inline">
                        {pill.tag}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Interactive Products Opname Table */}
          <div className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden flex flex-col">
            {/* Table Sub-Header Bar with Count, Print & Sort Controls */}
            <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-stone-800">Tabel Audit Fisik Produk</span>
                <span className="text-[11px] text-stone-500 font-medium">
                  (Menampilkan <strong>{sortedAndFilteredProducts.length}</strong> dari {products.length} produk)
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    const uncounted = products.filter((p) => {
                      const key = p.kode || p.nama;
                      return !auditItems[key]?.isFilled;
                    });
                    if (uncounted.length === 0) {
                      onShowToast('Semua produk sudah dihitung!', 'info');
                      return;
                    }
                    const html = generateBlankStockOpnameSheetHTML(
                      uncounted, 
                      settings, 
                      categoryFilter, 
                      'LEMBAR KERJA SISA BELUM DIHITUNG (STOCK OPNAME)'
                    );
                    openPrintWindow(html, `Lembar Kerja Belum Dihitung - ${categoryFilter}`);
                  }}
                  className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white text-[11px] font-bold rounded-xl transition flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  title="Cetak lembar A4 khusus untuk barang-barang yang belum dihitung"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak Sisa Belum Dihitung (A4)</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-stone-500 flex items-center gap-1">
                    <ArrowUpDown className="w-3.5 h-3.5 text-stone-400" /> Urutkan:
                  </span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="text-[11px] py-1 px-2.5 border border-stone-300 rounded-xl bg-white font-bold text-stone-700 focus:ring-2 focus:ring-red-600 focus:outline-hidden cursor-pointer"
                  >
                    <option value="default">Urutan Standar Master</option>
                    <option value="uncounted_first">⏳ Belum Dihitung Teratas</option>
                    <option value="selisih_first">⚠️ Ada Selisih Teratas</option>
                    <option value="name_asc">Nama Produk (A-Z)</option>
                    <option value="name_desc">Nama Produk (Z-A)</option>
                    <option value="stock_desc">Stok Sistem Terbanyak</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Table Body Container with Horizontal Scrolling and Crisp Layout */}
            <div className="overflow-x-auto relative focus:outline-none">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-stone-100 shadow-2xs border-b border-stone-300">
                  <tr className="text-stone-700 font-bold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-3 text-center w-12 bg-stone-100">No</th>
                    <th className="py-3 px-3 w-28 bg-stone-100">Kode</th>
                    <th className="py-3 px-3 min-w-[200px] bg-stone-100">Nama Produk / Kategori</th>
                    <th className="py-3 px-3 text-center w-16 bg-stone-100">Satuan</th>
                    <th className="py-3 px-3 text-center w-36 bg-stone-200/80">Status Hitung</th>
                    <th className="py-3 px-3 text-right w-24 bg-stone-100">Stok Sistem</th>
                    <th className="py-3 px-3 text-center w-56 bg-red-50/80 text-red-950">Stok Fisik (Real)</th>
                    <th className="py-3 px-3 text-center w-28 bg-stone-100">Qty Selisih</th>
                    <th className="py-3 px-3 text-right w-32 bg-stone-100" title="Dihitung dari: Qty Selisih × Harga Beli">
                      <div>Nilai Selisih</div>
                      <div className="text-[9px] font-normal lowercase text-stone-500">qty × harga beli</div>
                    </th>
                    <th className="py-3 px-3 min-w-[180px] bg-stone-100">Alasan / Keterangan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 bg-white">
                  {sortedAndFilteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-stone-400">
                        <Boxes className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        <p className="font-semibold">Tidak ada produk yang cocok dengan filter atau pencarian.</p>
                        {statusFilter === 'belum_diisi' && stats.totalFilled > 0 && (
                          <p className="text-xs text-emerald-600 font-bold mt-1">
                            🎉 Hebat! Semua produk pada filter ini sudah selesai dihitung.
                          </p>
                        )}
                      </td>
                    </tr>
                  ) : (
                    sortedAndFilteredProducts.map((item, idx) => {
                      const p = item.product;
                      const isHighlighted = item.isFilled && item.selisih !== 0;

                      return (
                        <tr 
                          key={item.key} 
                          className={`hover:bg-stone-50/80 transition ${
                            isHighlighted ? (item.selisih < 0 ? 'bg-rose-50/30' : 'bg-blue-50/30') : ''
                          }`}
                        >
                          <td className="py-3 px-3 text-center text-stone-400 font-mono text-[11px]">
                            {idx + 1}
                          </td>

                          <td className="py-3 px-3 font-mono font-bold text-stone-700 text-[11px]">
                            {p.kode || '-'}
                          </td>

                          <td className="py-3 px-3">
                            <div className="font-bold text-stone-900 leading-tight">{p.nama}</div>
                            <div className="text-[10px] text-stone-500 mt-0.5">
                              {p.kategori || 'Umum'} • <span className="font-semibold text-stone-700">Harga Beli: {fRp(item.hargaBeli)}</span>
                            </div>
                          </td>

                          <td className="py-3 px-3 text-center text-stone-600 font-medium">
                            {p.satuan || 'pcs'}
                          </td>

                          {/* Badge Status Hitung (Sudah Dihitung / Sedang Diinput / Belum Dihitung) */}
                          <td className="py-3 px-3 text-center bg-stone-50/50">
                            {item.countState === 'saved' ? (
                              <div className="flex flex-col items-center">
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                  <span>✓ SUDAH DIHITUNG</span>
                                </span>
                                <span className="text-[9px] text-stone-500 mt-0.5 font-medium whitespace-nowrap">
                                  Tersimpan • {item.lastAudit?.petugas || item.countedBy || 'Petugas'} ({item.lastAudit?.tanggal || 'Terverifikasi'})
                                </span>
                              </div>
                            ) : item.countState === 'draft' ? (
                              <div className="flex flex-col items-center">
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs">
                                  <PenLine className="w-3 h-3 text-amber-700" />
                                  <span>SEDANG DIINPUT</span>
                                </span>
                                <span className="text-[9px] text-amber-700 mt-0.5 font-medium whitespace-nowrap">
                                  Draf • Belum Disimpan
                                </span>
                              </div>
                            ) : (
                              <div className="flex flex-col items-center">
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-red-50 text-red-800 border border-red-200">
                                  <Clock className="w-3 h-3 text-red-600" />
                                  <span>BELUM DIHITUNG</span>
                                </span>
                                <span className="text-[9px] text-stone-400 mt-0.5 italic">
                                  Default: 0
                                </span>
                              </div>
                            )}
                          </td>

                          <td className="py-3 px-3 text-right font-black text-stone-700 text-sm">
                            {item.sysStok}
                          </td>

                          {/* Interactive Input for Physical Stock */}
                          <td className="py-2.5 px-3 bg-red-50/20">
                            <div className="flex items-center justify-center gap-1.5 max-w-[230px] mx-auto">
                              <button
                                type="button"
                                onClick={() => {
                                  const cur = item.isFilled ? item.fisikNum : 0;
                                  handlePhysicalStockChange(item.key, Math.max(0, cur - 1));
                                }}
                                className="w-7 h-7 flex items-center justify-center rounded-lg bg-white border border-stone-300 text-stone-700 hover:bg-stone-100 active:scale-95 transition cursor-pointer"
                                title="Kurangi 1"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>

                              <input
                                type="number"
                                min="0"
                                step="any"
                                value={item.rawFisik}
                                onChange={(e) => handlePhysicalStockChange(item.key, e.target.value)}
                                onFocus={(e) => {
                                  if (e.target.value === '0') {
                                    e.target.select();
                                  }
                                }}
                                placeholder="0"
                                className={`w-16 py-1 px-1.5 text-center font-black text-sm rounded-lg border focus:ring-2 focus:ring-red-600 focus:outline-hidden ${
                                  item.isFilled 
                                    ? 'bg-white border-amber-500 text-amber-950 shadow-xs' 
                                    : item.countState === 'saved'
                                    ? 'bg-emerald-50/50 border-emerald-300 text-emerald-950'
                                    : 'bg-stone-50 border-stone-300 text-stone-600'
                                }`}
                              />

                              <button
                                type="button"
                                onClick={() => {
                                  const cur = item.isFilled ? item.fisikNum : 0;
                                  handlePhysicalStockChange(item.key, cur + 1);
                                }}
                                className="w-7 h-7 flex items-center justify-center rounded-lg bg-white border border-stone-300 text-stone-700 hover:bg-stone-100 active:scale-95 transition cursor-pointer"
                                title="Tambah 1"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>

                              <button
                                type="button"
                                onClick={() => handleSetSameAsSystem(item.key, item.sysStok)}
                                className={`px-2 py-1 rounded-lg border text-[10px] font-black transition flex items-center gap-1 cursor-pointer ${
                                  item.isFilled && item.selisih === 0
                                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                                    : 'bg-white text-stone-600 border-stone-300 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300'
                                }`}
                                title="1-Klik: Tandai Selesai dan Stok Fisik Pas (Sesuai Sistem)"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">Pas</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handlePhysicalStockChange(item.key, 0)}
                                className="px-1.5 py-1 rounded-lg border border-stone-200 bg-white hover:bg-stone-100 text-stone-600 text-[10px] font-bold transition cursor-pointer"
                                title="Set Stok Fisik = 0"
                              >
                                0
                              </button>

                              {item.isFilled && (
                                <button
                                  type="button"
                                  onClick={() => handleResetItem(item.key)}
                                  className="w-6 h-6 flex items-center justify-center rounded-lg text-stone-400 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 transition cursor-pointer"
                                  title="Reset / Kosongkan status hitung barang ini (Kembali ke default 0)"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </td>

                          {/* Selisih Badge */}
                          <td className="py-3 px-3 text-center">
                            {item.countState === 'uncounted' ? (
                              <span className="text-[10px] font-semibold text-stone-400 italic">
                                Belum dihitung
                              </span>
                            ) : item.selisih === 0 ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                                <Check className="w-3 h-3" /> Pas (0)
                              </span>
                            ) : item.selisih < 0 ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-extrabold bg-rose-100 text-rose-800">
                                <TrendingDown className="w-3 h-3" /> {item.selisih}
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-extrabold bg-blue-100 text-blue-800">
                                <TrendingUp className="w-3 h-3" /> +{item.selisih}
                              </span>
                            )}
                          </td>

                          {/* Nilai Selisih */}
                          <td className="py-3 px-3 text-right font-mono font-bold">
                            {item.countState === 'uncounted' || item.selisih === 0 ? (
                              <span className="text-stone-400 text-[11px]">Rp 0</span>
                            ) : item.selisih < 0 ? (
                              <div>
                                <div className="text-rose-700 text-xs">- {fRp(Math.abs(item.nilaiSelisih))}</div>
                                <div className="text-[9px] text-stone-400 font-sans font-normal">
                                  {Math.abs(item.selisih)} × {fRp(item.hargaBeli)}
                                </div>
                              </div>
                            ) : (
                              <div>
                                <div className="text-blue-700 text-xs">+ {fRp(item.nilaiSelisih)}</div>
                                <div className="text-[9px] text-stone-400 font-sans font-normal">
                                  {item.selisih} × {fRp(item.hargaBeli)}
                                </div>
                              </div>
                            )}
                          </td>

                          {/* Catatan / Alasan Input */}
                          <td className="py-2 px-3">
                            <div className="flex items-center gap-1">
                              <select
                                value={item.catatan}
                                onChange={(e) => handleCatatanChange(item.key, e.target.value)}
                                className="w-full text-[11px] py-1 px-2 border border-stone-200 rounded-lg bg-white focus:outline-hidden focus:ring-1 focus:ring-red-600"
                              >
                                <option value="">Pilih Alasan / Catatan...</option>
                                <option value="Sesuai">Sesuai (Kondisi Baik)</option>
                                <option value="Barang Rusak / Cacat">⚠️ Barang Rusak / Cacat</option>
                                <option value="Kadaluarsa / Expired">⌛ Kadaluarsa / Expired</option>
                                <option value="Hilang / Tidak Ditemukan">❓ Hilang / Tidak Ditemukan</option>
                                <option value="Salah Catat / Salah Hitung">📝 Salah Catat / Hitung Masuk</option>
                                <option value="Bonus / Sampel Tambahan">🎁 Bonus / Sampel Tambahan</option>
                              </select>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Sticky Bottom Footer Submit Bar (Always visible for easy access) */}
            <div className="sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-stone-300 px-4 py-3 sm:py-3.5 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-stone-700 text-center sm:text-left">
                <div className="font-bold flex items-center gap-2">
                  <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>
                    Progres: <strong>{stats.totalFilled}</strong> dari <strong>{products.length}</strong> produk ({Math.round((stats.totalFilled / (products.length || 1)) * 100)}%)
                  </span>
                </div>
                {stats.totalKurang + stats.totalLebih > 0 && (
                  <div className="text-[11px] font-medium text-rose-700 mt-0.5">
                    ⚠️ {stats.totalKurang + stats.totalLebih} produk memiliki selisih fisik (Net: {stats.netNilaiSelisih < 0 ? '-' + fRp(Math.abs(stats.netNilaiSelisih)) : '+' + fRp(stats.netNilaiSelisih)})
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={handleManualSaveDraft}
                  className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 border border-stone-300 cursor-pointer shadow-2xs"
                  title="Simpan progress draf sementara"
                >
                  <Save className="w-4 h-4 text-red-600" />
                  <span className="hidden sm:inline">Simpan Draf</span>
                </button>

                <button
                  type="button"
                  disabled={stats.totalFilled === 0 || isSaving}
                  onClick={() => setShowConfirmModal(true)}
                  className="w-full sm:w-auto px-5 sm:px-6 py-2.5 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ClipboardCheck className="w-4 h-4" />
                  <span>Simpan & Terapkan Penyesuaian Stok</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODE 2: HISTORY & BERITA ACARA ARCHIVE ================= */}
      {activeSubTab === 'history' && (
        <div className="space-y-4">
          {/* History Header & Search */}
          <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-extrabold text-stone-900 text-base flex items-center gap-2">
                <History className="w-5 h-5 text-red-700" />
                <span>Riwayat Berita Acara Stock Opname</span>
              </h3>
              <p className="text-xs text-stone-500">
                Daftar rekapan audit fisik bulanan yang pernah dilakukan beserta dokumen berita acara resmi.
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Cari nomor dokumen / periode / petugas..."
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-600 focus:outline-hidden"
              />
            </div>
          </div>

          {/* History List Cards */}
          {opnameHistory.length === 0 ? (
            <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400">
              <ClipboardCheck className="w-12 h-12 mx-auto mb-3 opacity-30 text-stone-500" />
              <h4 className="font-bold text-stone-700 text-sm">Belum Ada Riwayat Stock Opname</h4>
              <p className="text-xs text-stone-500 mt-1 max-w-md mx-auto">
                Silakan lakukan penghitungan fisik pada tab "Lembar Hitung Aktif" dan simpan hasilnya untuk membuat Berita Acara pertama Anda.
              </p>
              <button
                onClick={() => setActiveSubTab('audit_form')}
                className="mt-4 px-4 py-2 bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs hover:bg-red-800 transition cursor-pointer"
              >
                Mulai Hitung Stock Opname
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {opnameHistory
                .filter((rec) => {
                  if (!historySearch.trim()) return true;
                  const q = historySearch.toLowerCase();
                  return (
                    rec.id.toLowerCase().includes(q) ||
                    rec.bulanPeriode.toLowerCase().includes(q) ||
                    rec.petugas.toLowerCase().includes(q) ||
                    (rec.penanggungJawab && rec.penanggungJawab.toLowerCase().includes(q))
                  );
                })
                .map((rec) => (
                  <div
                    key={rec.id}
                    className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs hover:shadow-md transition flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <span className="text-[10px] font-black tracking-wide uppercase px-2 py-0.5 bg-red-100 text-red-800 rounded-md">
                            {rec.bulanPeriode || 'Bulanan'}
                          </span>
                          <h4 className="font-black text-stone-900 text-base mt-1 leading-tight">
                            {rec.id}
                          </h4>
                          <div className="text-[11px] text-stone-500 flex items-center gap-1.5 mt-0.5">
                            <Calendar className="w-3 h-3" />
                            <span>{rec.tanggal} • {rec.jam || '-'}</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className={`text-xs font-black px-2 py-1 rounded-lg ${
                            rec.totalNilaiSelisih < 0 
                              ? 'bg-rose-100 text-rose-800' 
                              : (rec.totalNilaiSelisih > 0 ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800')
                          }`}>
                            {rec.totalNilaiSelisih === 0 ? 'Pas' : (rec.totalNilaiSelisih < 0 ? '-' + fRp(Math.abs(rec.totalNilaiSelisih)) : '+' + fRp(rec.totalNilaiSelisih))}
                          </span>
                        </div>
                      </div>

                      {/* Auditor info */}
                      <div className="text-[11px] text-stone-600 bg-stone-50 rounded-xl p-2.5 my-2.5 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-stone-400">Petugas:</span>
                          <span className="font-bold text-stone-800">{rec.petugas}</span>
                        </div>
                        {rec.penanggungJawab && (
                          <div className="flex items-center justify-between">
                            <span className="text-stone-400">Penanggung Jawab:</span>
                            <span className="font-semibold text-stone-700">{rec.penanggungJawab}</span>
                          </div>
                        )}
                      </div>

                      {/* Stats badge grid */}
                      <div className="grid grid-cols-3 gap-1.5 text-center my-2">
                        <div className="bg-emerald-50 rounded-lg p-1.5">
                          <div className="text-[10px] text-emerald-700 font-semibold">Sesuai</div>
                          <div className="text-xs font-black text-emerald-800">{rec.totalItemSesuai}</div>
                        </div>
                        <div className="bg-rose-50 rounded-lg p-1.5">
                          <div className="text-[10px] text-rose-700 font-semibold">Kurang</div>
                          <div className="text-xs font-black text-rose-800">{rec.totalItemSelisihKurang}</div>
                        </div>
                        <div className="bg-blue-50 rounded-lg p-1.5">
                          <div className="text-[10px] text-blue-700 font-semibold">Lebih</div>
                          <div className="text-xs font-black text-blue-800">{rec.totalItemSelisihLebih}</div>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-1 mt-2">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            const html = generateStockOpnameA4HTML(rec, settings);
                            openPrintWindow(html, `Berita Acara - ${rec.id}`);
                          }}
                          className="p-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
                          title="Cetak Berita Acara Resmi Format A4"
                        >
                          <Printer className="w-3.5 h-3.5 text-stone-700" />
                          <span className="hidden sm:inline">Cetak A4</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeletingRecord(rec)}
                          className="p-2 bg-stone-100 hover:bg-rose-100 text-stone-400 hover:text-rose-700 rounded-xl transition cursor-pointer"
                          title="Hapus Dokumen Berita Acara"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => setSelectedRecordDetail(rec)}
                        className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Rincian</span>
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* ================= CONFIRMATION MODAL BEFORE APPLYING STOCK ================= */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-stone-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2 text-stone-900 font-extrabold text-base">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <span>Konfirmasi Stock Opname</span>
              </div>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="text-stone-400 hover:text-stone-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-stone-600 space-y-2">
              <p>
                Anda akan menyimpan hasil audit fisik untuk periode <strong>{bulanPeriode}</strong> dan 
                <strong> memperbarui stok master produk secara otomatis</strong> sesuai hitungan fisik real:
              </p>

              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 space-y-1.5">
                <div className="flex justify-between">
                  <span>Total Produk Dihitung:</span>
                  <strong className="text-stone-900">{stats.totalFilled} Item</strong>
                </div>
                <div className="flex justify-between text-emerald-700">
                  <span>Stok Sesuai (Pas):</span>
                  <strong>{stats.totalSesuai} Item</strong>
                </div>
                <div className="flex justify-between text-rose-700">
                  <span>Selisih Kurang (Hilang/Rusak):</span>
                  <strong>{stats.totalKurang} Item (-{fRp(stats.totalNilaiKurang)})</strong>
                </div>
                <div className="flex justify-between text-blue-700">
                  <span>Selisih Lebih (Kelebihan):</span>
                  <strong>{stats.totalLebih} Item (+{fRp(stats.totalNilaiLebih)})</strong>
                </div>
                <div className="pt-1.5 border-t border-stone-200 flex justify-between font-black">
                  <span>Total Net Nilai Selisih:</span>
                  <span className={stats.netNilaiSelisih < 0 ? 'text-rose-700' : 'text-emerald-700'}>
                    {stats.netNilaiSelisih === 0 ? 'Rp 0' : (stats.netNilaiSelisih < 0 ? '-' + fRp(Math.abs(stats.netNilaiSelisih)) : '+' + fRp(stats.netNilaiSelisih))}
                  </span>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-[11px] text-emerald-900 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Hasil Tindakan:</strong> Setelah tombol simpan ini diklik, status {stats.totalFilled} produk ini akan resmi ditetapkan sebagai <span className="font-extrabold text-emerald-800 bg-emerald-100 px-1 py-0.5 rounded">✓ SUDAH DIHITUNG</span>, data audit disimpan di Riwayat Berita Acara, dan stok POS kasir disinkronkan.
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 text-xs font-bold text-stone-600 hover:bg-stone-100 rounded-xl transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleSaveStockOpname}
                className="px-5 py-2 text-xs font-extrabold bg-red-700 hover:bg-red-800 text-white rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                {isSaving ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menyimpan & Menyesuaikan Stok...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Ya, Simpan & Terapkan Sekarang</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL KONFIRMASI RESET SESI OPNAME ================= */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2 text-rose-700 font-extrabold text-base">
                <RotateCcw className="w-5 h-5" />
                <span>Reset Sesi Audit Fisik</span>
              </div>
              <button
                onClick={() => setShowResetConfirmModal(false)}
                className="text-stone-400 hover:text-stone-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-stone-600 space-y-2">
              <p>
                <strong>Kegunaan Fitur Reset Sesi:</strong>
              </p>
              <p>
                Tombol ini digunakan untuk <strong>mengosongkan seluruh angka stok fisik</strong> yang telah Anda ketik dan <strong>menghapus draf sesi hitung berjalan</strong> dari memori lokal jika Anda ingin membatalkan hitungan atau memulai lembar hitung baru dari nol.
              </p>
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-[11px] text-rose-900 space-y-1 font-semibold">
                <p>⚠️ <strong>Perhatian:</strong></p>
                <p>Isian fisik yang belum disimpan akan dikosongkan. Data master stok produk di kasir POS tidak akan berubah.</p>
              </div>
              <p className="text-stone-800 font-bold pt-1">
                Apakah Anda yakin ingin mengosongkan lembar audit dan mereset sesi ini?
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2 text-xs font-bold text-stone-600 hover:bg-stone-100 rounded-xl transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleExecuteResetAudit}
                className="px-5 py-2 text-xs font-extrabold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Reset Sesi Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL KONFIRMASI HAPUS BERITA ACARA ================= */}
      {deletingRecord && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2 text-rose-700 font-extrabold text-base">
                <Trash2 className="w-5 h-5" />
                <span>Hapus Berita Acara</span>
              </div>
              <button
                onClick={() => setDeletingRecord(null)}
                className="text-stone-400 hover:text-stone-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-stone-600 space-y-2">
              <p>
                Apakah Anda yakin ingin menghapus arsip Berita Acara Stock Opname <strong>"{deletingRecord.id}"</strong> ({deletingRecord.bulanPeriode})?
              </p>
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 text-[11px] text-stone-500">
                <p><strong>Catatan:</strong> Dokumen berita acara ini akan dihapus dari arsip riwayat. Master stok produk yang sudah disesuaikan tidak akan berubah.</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeletingRecord(null)}
                className="px-4 py-2 text-xs font-bold text-stone-600 hover:bg-stone-100 rounded-xl transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="px-5 py-2 text-xs font-extrabold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                {isDeleting ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Hapus Dokumen</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= DETAIL MODAL FOR RECORD ================= */}
      {selectedRecordDetail && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div>
                <span className="text-[10px] font-black px-2 py-0.5 bg-red-100 text-red-800 rounded-md uppercase">
                  {selectedRecordDetail.bulanPeriode}
                </span>
                <h3 className="font-extrabold text-stone-900 text-base mt-1">
                  Berita Acara #{selectedRecordDetail.id}
                </h3>
                <div className="text-xs text-stone-500 mt-0.5">
                  Tanggal: {selectedRecordDetail.tanggal} {selectedRecordDetail.jam} • Petugas: {selectedRecordDetail.petugas} • SPV: {selectedRecordDetail.penanggungJawab || '-'}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const html = generateStockOpnameA4HTML(selectedRecordDetail, settings);
                    openPrintWindow(html, `Berita Acara - ${selectedRecordDetail.id}`);
                  }}
                  className="px-3 py-1.5 bg-white border border-stone-300 text-stone-700 text-xs font-bold rounded-xl hover:bg-stone-100 transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-stone-700" />
                  <span>Cetak A4</span>
                </button>

                <button
                  onClick={() => {
                    setDeletingRecord(selectedRecordDetail);
                  }}
                  className="px-3 py-1.5 bg-white border border-rose-200 text-rose-700 text-xs font-bold rounded-xl hover:bg-rose-50 transition flex items-center gap-1.5 cursor-pointer"
                  title="Hapus Berita Acara"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Hapus</span>
                </button>

                <button
                  onClick={() => setSelectedRecordDetail(null)}
                  className="text-stone-400 hover:text-stone-600 p-1.5 rounded-lg hover:bg-stone-200 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body - Items Table */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
              {/* Summary mini cards */}
              <div className="grid grid-cols-4 gap-2">
                <div className="bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-center">
                  <div className="text-[10px] text-stone-500">Total Dihitung</div>
                  <div className="font-black text-stone-900 text-sm">{selectedRecordDetail.totalItemDihitung} Item</div>
                </div>
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-center">
                  <div className="text-[10px] text-emerald-700">Sesuai</div>
                  <div className="font-black text-emerald-800 text-sm">{selectedRecordDetail.totalItemSesuai} Item</div>
                </div>
                <div className="bg-rose-50 border border-rose-200 rounded-xl p-2.5 text-center">
                  <div className="text-[10px] text-rose-700">Selisih Kurang</div>
                  <div className="font-black text-rose-800 text-sm">{selectedRecordDetail.totalItemSelisihKurang} Item</div>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-center">
                  <div className="text-[10px] text-blue-700">Selisih Lebih</div>
                  <div className="font-black text-blue-800 text-sm">{selectedRecordDetail.totalItemSelisihLebih} Item</div>
                </div>
              </div>

              {/* Items List */}
              <div className="border border-stone-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100 text-stone-600 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3 text-center w-10">No</th>
                      <th className="py-2.5 px-3">Kode</th>
                      <th className="py-2.5 px-3">Nama Produk</th>
                      <th className="py-2.5 px-3 text-right">Stok Sistem</th>
                      <th className="py-2.5 px-3 text-right">Stok Fisik</th>
                      <th className="py-2.5 px-3 text-center">Selisih</th>
                      <th className="py-2.5 px-3 text-right">Harga Beli</th>
                      <th className="py-2.5 px-3 text-right">Nilai Selisih</th>
                      <th className="py-2.5 px-3">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {selectedRecordDetail.items.map((item, idx) => (
                      <tr key={idx} className={item.selisih !== 0 ? (item.selisih < 0 ? 'bg-rose-50/40' : 'bg-blue-50/40') : ''}>
                        <td className="py-2.5 px-3 text-center text-stone-400 font-mono">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-stone-700">{item.kode || '-'}</td>
                        <td className="py-2.5 px-3 font-bold text-stone-900">{item.nama}</td>
                        <td className="py-2.5 px-3 text-right font-medium text-stone-600">{item.stokSistem} {item.satuan}</td>
                        <td className="py-2.5 px-3 text-right font-black text-stone-900">{item.stokFisik} {item.satuan}</td>
                        <td className="py-2.5 px-3 text-center">
                          {item.selisih === 0 ? (
                            <span className="text-emerald-700 font-bold">Pas (0)</span>
                          ) : item.selisih < 0 ? (
                            <span className="text-rose-700 font-extrabold">{item.selisih}</span>
                          ) : (
                            <span className="text-blue-700 font-extrabold">+{item.selisih}</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-stone-600">
                          {fRp(item.hargaBeli || 0)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold">
                          {item.selisih === 0 ? 'Rp 0' : (item.selisih < 0 ? '-' + fRp(Math.abs(item.nilaiSelisih)) : '+' + fRp(item.nilaiSelisih))}
                        </td>
                        <td className="py-2.5 px-3 text-stone-500 text-[11px]">{item.catatan || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-stone-200 flex items-center justify-between bg-stone-50">
              <div className="text-xs font-bold text-stone-700">
                Net Nilai Selisih: <span className={selectedRecordDetail.totalNilaiSelisih < 0 ? 'text-rose-700' : 'text-emerald-700'}>
                  {selectedRecordDetail.totalNilaiSelisih === 0 ? 'Rp 0' : (selectedRecordDetail.totalNilaiSelisih < 0 ? '-' + fRp(Math.abs(selectedRecordDetail.totalNilaiSelisih)) : '+' + fRp(selectedRecordDetail.totalNilaiSelisih))}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedRecordDetail(null)}
                  className="px-4 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
