import { Invoice, Customer } from '../types';

export interface CustomerSlipGroup {
  slipNo: number;
  isPrinted: boolean;
  printedAt?: string;
  invoices: Invoice[];
  total: number;
  totalUnpaid: number;
  totalSettled: number;
  isLunas: boolean;
  itemCount: number;
}

export interface CustomerSlipSummary {
  customer: string;
  activeSlip: CustomerSlipGroup | null;
  historySlips: CustomerSlipGroup[];
  allSlips: CustomerSlipGroup[];
  highestSlipNo: number;
  activeSlipNo: number;
  totalUnpaidAllSlips: number;
}

/**
 * Check if two customer names belong to the same customer entity
 * Handles cases where customer name or division was edited, or parentheses differ
 */
export function isSameCustomer(name1: string, name2: string, customerDirectory?: Customer[]): boolean {
  if (!name1 || !name2) return false;
  const n1 = name1.trim().toLowerCase();
  const n2 = name2.trim().toLowerCase();
  if (n1 === n2) return true;

  // Base name comparison stripping parentheses: e.g. "Budi (Gudang)" vs "Budi"
  const b1 = n1.replace(/\(.*?\)/g, '').trim();
  const b2 = n2.replace(/\(.*?\)/g, '').trim();
  if (b1.length > 2 && b1 === b2) return true;

  if (customerDirectory && customerDirectory.length > 0) {
    const match1 = customerDirectory.find((c) => {
      const cLow = c.nama.trim().toLowerCase();
      const cBase = cLow.replace(/\(.*?\)/g, '').trim();
      return cLow === n1 || (cBase.length > 2 && cBase === b1);
    });
    const match2 = customerDirectory.find((c) => {
      const cLow = c.nama.trim().toLowerCase();
      const cBase = cLow.replace(/\(.*?\)/g, '').trim();
      return cLow === n2 || (cBase.length > 2 && cBase === b2);
    });
    if (match1 && match2 && match1.nama.trim().toLowerCase() === match2.nama.trim().toLowerCase()) {
      return true;
    }
  }

  return false;
}

/**
 * Memeriksa apakah sebuah transaksi invoice sudah dikunci oleh petugas kasir.
 * Mendukung berbagai representasi (slipPrinted, isLocked, terkunci, locked, slipPrintedAt).
 */
export function isInvoiceLocked(inv: any): boolean {
  if (!inv) return false;
  return Boolean(
    inv.slipPrinted === true ||
    inv.slipPrinted === 'true' ||
    inv.slipPrinted === 1 ||
    inv.slipPrinted === '1' ||
    inv.isLocked === true ||
    inv.isLocked === 'true' ||
    inv.terkunci === true ||
    inv.terkunci === 'true' ||
    inv.locked === true ||
    inv.locked === 'true' ||
    (inv.slipPrintedAt && String(inv.slipPrintedAt).trim() !== '')
  );
}

/**
 * Mendapatkan nomor slip tagihan berikutnya untuk seorang pelanggan / karyawan.
 * - Aturan Kerja WAKA: Penagihan tidak tentu (misal mingguan dengan 4-5 slip per bulan).
 * - Ketika slip tagihan dibuat/dicetak, semua transaksi tercatat sampai waktu pencetakan.
 * - Transaksi belanja berikutnya (meskipun di hari/jam yang sama) otomatis masuk ke slip berikutnya (Slip #{N+1}).
 */
export function getNextSlipNumberForCustomer(
  customerName: string, 
  allInvoices: Invoice[],
  customerDirectory?: Customer[]
): number {
  if (!customerName || !customerName.trim()) return 1;

  const custInvoices = allInvoices.filter((i) => {
    const invCust = (i.customer || (i as any).pelanggan || '').trim();
    return isSameCustomer(customerName, invCust, customerDirectory);
  });

  if (custInvoices.length === 0) return 1;

  let maxLockedSlipNo = 0;
  for (const inv of custInvoices) {
    if (isInvoiceLocked(inv)) {
      const sNo = Number(inv.slipNo) || 1;
      if (sNo > maxLockedSlipNo) {
        maxLockedSlipNo = sNo;
      }
    }
  }

  if (maxLockedSlipNo === 0) return 1;
  return maxLockedSlipNo + 1;
}

/**
 * Mengelompokkan semua invoice milik pelanggan berdasarkan nomor Slip Tagihan.
 * Memisahkan secara ketat transaksi yang sudah DIKUNCI petugas (historySlips)
 * dan transaksi yang BELUM DIKUNCI (activeSlip).
 */
export function getCustomerSlipSummary(
  customerName: string,
  customerInvoices: Invoice[],
  customerDirectory?: Customer[]
): CustomerSlipSummary {
  // Deduplikasi awal seluruh invoice berdasarkan invoiceNo unik
  const uniqueInvsMap = new Map<string, Invoice>();
  customerInvoices.forEach((inv) => {
    const key = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
    if (key) {
      if (!uniqueInvsMap.has(key)) {
        uniqueInvsMap.set(key, inv);
      }
    } else {
      uniqueInvsMap.set(Math.random().toString(), inv);
    }
  });

  const list = Array.from(uniqueInvsMap.values()).filter((i) => {
    const invCust = (i.customer || (i as any).pelanggan || '').trim();
    return isSameCustomer(customerName, invCust, customerDirectory);
  });

  // Pisahkan nota yang sudah dikunci oleh kasir vs nota baru yang belum dikunci
  const lockedInvoices: Invoice[] = [];
  const unlockedInvoices: Invoice[] = [];

  list.forEach((inv) => {
    if (isInvoiceLocked(inv)) {
      lockedInvoices.push(inv);
    } else {
      unlockedInvoices.push(inv);
    }
  });

  // Hitung nomor slip tertinggi yang sudah dikunci
  let maxLockedSlipNo = 0;
  lockedInvoices.forEach((inv) => {
    const sNo = Number(inv.slipNo) || 1;
    if (sNo > maxLockedSlipNo) {
      maxLockedSlipNo = sNo;
    }
  });

  // Kelompokkan nota TERKUNCI berdasarkan nomor slip mereka (Slip #1, Slip #2, dst)
  const lockedSlipMap = new Map<number, Invoice[]>();
  lockedInvoices.forEach((inv) => {
    const sNo = Number(inv.slipNo) || 1;
    if (!lockedSlipMap.has(sNo)) {
      lockedSlipMap.set(sNo, []);
    }
    const targetArr = lockedSlipMap.get(sNo)!;
    const invKey = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
    if (!targetArr.some((ex) => (ex.invoiceNo || (ex as any).noInvoice || '').trim().toLowerCase() === invKey)) {
      targetArr.push(inv);
    }
  });

  const historySlips: CustomerSlipGroup[] = [];
  lockedSlipMap.forEach((invs, sNo) => {
    if (invs.length === 0) return;

    let total = 0;
    let totalUnpaid = 0;
    let totalSettled = 0;
    let itemCount = 0;
    let printedAt: string | undefined = undefined;

    invs.forEach((inv) => {
      const invTotal = Number(inv.total || 0);
      const invSisa = (inv as any).calculatedSisa !== undefined 
        ? Number((inv as any).calculatedSisa) 
        : Number(inv.sisa !== undefined ? inv.sisa : invTotal);

      total += invTotal;
      totalUnpaid += Math.max(0, invSisa);
      totalSettled += Math.max(0, invTotal - invSisa);
      itemCount += (inv.items?.length || 0);

      if (inv.slipPrintedAt && !printedAt) {
        printedAt = inv.slipPrintedAt;
      }
    });

    historySlips.push({
      slipNo: sNo,
      isPrinted: true,
      printedAt,
      invoices: invs,
      total,
      totalUnpaid,
      totalSettled,
      isLunas: totalUnpaid <= 0,
      itemCount,
    });
  });

  // Urutkan historySlips menurun (Slip #2, Slip #1)
  historySlips.sort((a, b) => b.slipNo - a.slipNo);

  // Kelompokkan nota BELUM DIKUNCI (Active Slip)
  // Nota belum dikunci TIDAK BOLEH masuk ke slip yang sudah dikunci!
  const activeSlipNo = maxLockedSlipNo > 0 ? maxLockedSlipNo + 1 : 1;
  let activeSlip: CustomerSlipGroup | null = null;

  if (unlockedInvoices.length > 0) {
    let total = 0;
    let totalUnpaid = 0;
    let totalSettled = 0;
    let itemCount = 0;

    unlockedInvoices.forEach((inv) => {
      const invTotal = Number(inv.total || 0);
      const invSisa = (inv as any).calculatedSisa !== undefined 
        ? Number((inv as any).calculatedSisa) 
        : Number(inv.sisa !== undefined ? inv.sisa : invTotal);

      total += invTotal;
      totalUnpaid += Math.max(0, invSisa);
      totalSettled += Math.max(0, invTotal - invSisa);
      itemCount += (inv.items?.length || 0);
    });

    activeSlip = {
      slipNo: activeSlipNo,
      isPrinted: false,
      invoices: unlockedInvoices,
      total,
      totalUnpaid,
      totalSettled,
      isLunas: totalUnpaid <= 0,
      itemCount,
    };
  }

  const allSlips: CustomerSlipGroup[] = [];
  if (activeSlip) {
    allSlips.push(activeSlip);
  }
  historySlips.forEach((s) => allSlips.push(s));

  allSlips.sort((a, b) => b.slipNo - a.slipNo);

  const highestSlipNo = Math.max(activeSlipNo, maxLockedSlipNo);
  const totalUnpaidAllSlips = allSlips.reduce((acc, s) => acc + s.totalUnpaid, 0);

  return {
    customer: customerName,
    activeSlip,
    historySlips,
    allSlips,
    highestSlipNo,
    activeSlipNo,
    totalUnpaidAllSlips,
  };
}
