import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

const DEFAULT_GAS_URL = "";

function isValidHttpUrl(string: string): boolean {
  if (!string || typeof string !== "string") return false;
  const trimmed = string.trim();
  if (trimmed.includes("paste link") || !trimmed.startsWith("http")) return false;
  try {
    const url = new URL(trimmed);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "100mb" }));
  app.use(express.text({ limit: "100mb" }));

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

// Proxy endpoint for Google Apps Script (bypasses browser CORS restrictions with fast in-memory caching)
  interface ProxyCacheEntry {
    timestamp: number;
    json: any;
  }
  const proxyCache = new Map<string, ProxyCacheEntry>();
  const CACHE_TTL_MS = 15000; // 15 seconds TTL for GET queries

  app.all("/api/sheets/proxy", async (req, res) => {
    try {
      const targetUrl = ((req.query.gasUrl as string) || (req.headers["x-gas-url"] as string) || DEFAULT_GAS_URL).trim();
      
      if (!isValidHttpUrl(targetUrl)) {
        return res.status(200).json({
          success: false,
          message: "URL Google Apps Script belum dikonfigurasi. Silakan masukkan URL Web App di Pengaturan > Google Sheets.",
        });
      }

      const action = (req.query.action as string) || "";
      const isGet = req.method === "GET";

      // Check cache for GET requests
      const cacheKey = `${targetUrl}::${action}::${JSON.stringify(req.query)}`;
      if (isGet) {
        const cached = proxyCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
          return res.json(cached.json);
        }
      } else {
        // Clear GET cache on write/POST operations to ensure fresh data after mutation
        proxyCache.clear();
      }

      let fetchUrl = targetUrl;
      if (action) {
        try {
          const urlObj = new URL(targetUrl);
          urlObj.searchParams.set("action", action);
          // Copy any additional query params except gasUrl and action
          Object.keys(req.query).forEach((key) => {
            if (key !== "gasUrl" && key !== "action") {
              urlObj.searchParams.set(key, req.query[key] as string);
            }
          });
          fetchUrl = urlObj.toString();
        } catch {
          fetchUrl = targetUrl;
        }
      }

      const doFetch = async (url: string, timeoutMs: number) => {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

        const options: RequestInit = {
          method: req.method,
          redirect: "follow",
          signal: controller.signal,
          headers: {
            "User-Agent": "Strukku-App/1.0",
          },
        };

        if (req.method === "POST" || req.method === "PUT") {
          options.headers = {
            ...options.headers,
            "Content-Type": "text/plain;charset=utf-8",
          };
          let bodyPayload: any = req.body;
          if (typeof bodyPayload === "string") {
            try {
              bodyPayload = JSON.parse(bodyPayload);
            } catch {}
          }
          if (typeof bodyPayload === "object" && bodyPayload !== null && action && !bodyPayload.action) {
            bodyPayload = { action, ...bodyPayload };
          }
          options.body = typeof bodyPayload === "string" ? bodyPayload : JSON.stringify(bodyPayload);
        }

        try {
          return await fetch(url, options);
        } finally {
          clearTimeout(timeoutId);
        }
      };

      let response;
      try {
        // Extended 40-second timeout for Google Apps Script execution
        response = await doFetch(fetchUrl, 40000);
      } catch (firstErr: any) {
        const isAbort = firstErr.name === "AbortError" || firstErr.message?.includes("aborted");
        if (isAbort) {
          return res.status(200).json({
            success: false,
            message: "Koneksi ke Google Sheets waktu habis (Timeout). Menggunakan data lokal/cache.",
          });
        } else {
          throw firstErr;
        }
      }

      const text = await response.text();

      try {
        const json = JSON.parse(text);
        if (isGet && json && json.success) {
          proxyCache.set(cacheKey, { timestamp: Date.now(), json });
        }
        res.json(json);
      } catch {
        res.type("text/plain").send(text);
      }
    } catch (err: any) {
      const isAbort = err.name === "AbortError" || err.message?.includes("aborted");
      if (isAbort) {
        console.warn("[GAS Proxy] Google Apps Script request timed out.");
        res.status(200).json({
          success: false,
          message: "Koneksi ke Google Sheets waktu habis (Timeout). Menggunakan data lokal/cache.",
        });
      } else {
        console.warn("[GAS Proxy] Error:", err.message || err);
        res.status(200).json({
          success: false,
          message: "Proxy error: " + (err.message || "Gagal terhubung"),
        });
      }
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Strukku Server] Listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
