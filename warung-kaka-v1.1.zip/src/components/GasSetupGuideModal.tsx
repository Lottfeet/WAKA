import React, { useState } from 'react';
import { X, Code2, Copy, Check, FileSpreadsheet, Download } from 'lucide-react';
import { GAS_SCRIPT_V5 } from '../data/gasCodeTemplate';

interface GasSetupGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const GasSetupGuideModal: React.FC<GasSetupGuideModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GAS_SCRIPT_V5);
    setCopied(true);
    onShowToast('Kode Apps Script v5 tersalin ke clipboard!', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadFile = () => {
    const element = document.createElement('a');
    const file = new Blob([GAS_SCRIPT_V5], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = 'Code.gs';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    onShowToast('File Code.gs (v5) berhasil diunduh!', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-700 text-white flex items-center justify-center font-bold">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base">
                Panduan Integrasi Google Sheets Real-Time (v5)
              </h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Backend Apps Script v5 — Otomatisasi Stok & Sheet BarangMasuk
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-5 text-xs text-stone-800">
          {/* Quick Step Checklist */}
          <div className="p-4 rounded-xl bg-red-50/70 border border-red-200 space-y-2">
            <h4 className="font-extrabold text-stone-900 text-sm flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4 text-red-700" /> Langkah Pasang / Update Backend di Google Sheets:
            </h4>
            <ol className="list-decimal list-inside space-y-1.5 font-medium text-stone-700">
              <li>
                Buka Spreadsheet Google Sheets Anda.
              </li>
              <li>
                Pilih menu <strong className="text-stone-900">Extensions (Ekstensi)</strong> →{' '}
                <strong className="text-stone-900">Apps Script</strong>.
              </li>
              <li>
                Hapus semua isi kode lama, lalu <strong className="text-stone-900">Paste</strong> kode v5 di bawah (atau gunakan tombol Download <code className="bg-stone-200 px-1 py-0.5 rounded font-mono font-bold text-stone-900">Code.gs</code>).
              </li>
              <li>
                <strong className="text-stone-900">Inisialisasi Sheet:</strong> Pilih fungsi <code className="bg-red-200 px-1 py-0.5 rounded font-mono font-bold text-stone-900">init</code> di dropdown atas Apps Script lalu klik <strong className="text-stone-900">▶ Run (Jalankan)</strong> (atau muat ulang Spreadsheet & pilih menu <strong className="text-stone-900">🚀 Strukku POS → 🔄 Inisialisasi</strong>).
              </li>
              <li>
                Klik tombol <strong className="text-stone-900">Deploy (Terapkan)</strong> →{' '}
                <strong className="text-stone-900">Manage deployments (Kelola penerapan)</strong>.
              </li>
              <li>
                Klik tombol ✏️ <strong>Edit</strong> → Versi: <strong className="text-red-800 font-bold">New version (Versi baru)</strong> → Klik <strong>Deploy</strong>.
              </li>
              <li>
                Pastikan akses <strong className="text-red-800 font-bold">Who has access</strong> adalah <strong className="text-red-800 font-bold">Anyone (Siapa saja)</strong>. (URL Script tetap sama & tidak berubah).
              </li>
            </ol>
          </div>

          {/* Copy Code Box */}
          <div className="space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <label className="font-extrabold text-stone-900 text-xs">
                Kode Google Apps Script v5 (Lengkap):
              </label>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadFile}
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition active:scale-95 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5 text-stone-300" />
                  <span>Unduh Code.gs</span>
                </button>

                <button
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition active:scale-95 shadow-xs"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Tersalin!' : 'Salin Kode GAS v5'}</span>
                </button>
              </div>
            </div>

            <textarea
              readOnly
              value={GAS_SCRIPT_V5}
              rows={12}
              className="w-full p-3 font-mono text-[11px] bg-stone-900 text-stone-100 rounded-xl border border-stone-800 leading-relaxed overflow-x-auto focus:outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

