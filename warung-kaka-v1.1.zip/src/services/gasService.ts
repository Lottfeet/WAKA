import { Product, Customer, StoreSettings, Invoice, InvoiceItem, GasResponse, PiutangItem, PelunasanRecord, KasirUser, StockInRecord, ExpenseRecord, StockOpnameRecord } from '../types';
import { INITIAL_PRODUCTS, INITIAL_CUSTOMERS, INITIAL_KASIR } from '../utils/formatters';

export const DEFAULT_GAS_URL = "";

export function isValidGasUrl(url?: string): boolean {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (trimmed.includes('paste link') || !trimmed.startsWith('http')) return false;
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

export function getSheetUrl(): string {
  const saved = localStorage.getItem('strukku_sheet_url');
  const active = (saved !== null && saved !== undefined ? saved : DEFAULT_GAS_URL).trim();
  return active;
}

export function setSheetUrl(url: string) {
  localStorage.setItem('strukku_sheet_url', url.trim());
}

export async function gasGet<T = any>(action: string, extraQuery = ''): Promise<GasResponse<T>> {
  const gasUrl = getSheetUrl();
  if (!isValidGasUrl(gasUrl)) {
    return { success: false, message: 'URL Google Apps Script belum dikonfigurasi.' };
  }
  const timestamp = Date.now();
  
  // Primary attempt via express server proxy
  try {
    const proxyUrl = `/api/sheets/proxy?action=${action}&gasUrl=${encodeURIComponent(gasUrl)}&_=${timestamp}${extraQuery ? '&' + extraQuery : ''}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35000); // 35s timeout
    const res = await fetch(proxyUrl, { 
      headers: { 'Cache-Control': 'no-cache' },
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    if (res.ok) {
      const json = await res.json();
      if (json) return json;
    }
  } catch (err: any) {
    if (err?.name !== 'AbortError') {
      console.warn(`[gasGet] Proxy GET (${action}) failed, trying direct fetch...`, err?.message || err);
    }
  }

  // Fallback to direct fetch
  try {
    const directUrl = `${gasUrl}?action=${action}&_=${timestamp}${extraQuery ? '&' + extraQuery : ''}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s fallback timeout
    const res = await fetch(directUrl, { 
      cache: 'no-store',
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, message: 'Gagal terhubung ke Google Sheets: ' + (err?.message || 'Waktu koneksi habis') };
  }
}

export async function gasPost<T = any>(action: string, body: any = {}): Promise<GasResponse<T>> {
  const gasUrl = getSheetUrl();
  if (!isValidGasUrl(gasUrl)) {
    return { success: false, message: 'URL Google Apps Script belum dikonfigurasi.' };
  }

  // Ensure body always contains action explicitly so GAS doPost receives data.action even if URL query parameters are stripped during 302 redirects
  const payloadWithAction = (typeof body === 'object' && body !== null)
    ? { action, ...body }
    : body;

  // Primary attempt via express server proxy
  try {
    const proxyUrl = `/api/sheets/proxy?action=${action}&gasUrl=${encodeURIComponent(gasUrl)}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45000); // 45s timeout for writes
    const res = await fetch(proxyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payloadWithAction),
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    if (res.ok) {
      const json = await res.json();
      if (json) return json;
    }
  } catch (err: any) {
    if (err?.name !== 'AbortError') {
      console.warn(`[gasPost] Proxy POST (${action}) failed, trying direct fetch...`, err?.message || err);
    }
  }

  // Fallback to direct fetch
  try {
    const directUrl = `${gasUrl}?action=${action}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 40000); // 40s fallback timeout
    const res = await fetch(directUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payloadWithAction),
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, message: 'Gagal mengirim data ke Google Sheets: ' + (err?.message || 'Waktu koneksi habis') };
  }
}

export function getDeletedProducts(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_products');
    if (raw) {
      const list: string[] = JSON.parse(raw);
      return new Set(list.map((s) => s.trim().toLowerCase()));
    }
  } catch {}
  return new Set();
}

export function addDeletedProduct(kodeOrNama: string) {
  try {
    const clean = kodeOrNama.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedProducts();
    set.add(clean);
    localStorage.setItem('strukku_deleted_products', JSON.stringify(Array.from(set)));
  } catch {}
}

export function removeDeletedProduct(kodeOrNama: string) {
  try {
    const clean = kodeOrNama.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedProducts();
    set.delete(clean);
    localStorage.setItem('strukku_deleted_products', JSON.stringify(Array.from(set)));
  } catch {}
}

// Instant Local Getters (0ms delay for Stale-While-Revalidate UI rendering)
export function getLocalProducts(): Product[] {
  const deletedCodes = getDeletedProducts();
  const cached = localStorage.getItem('strukku_products');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed
          .filter((p) => {
            const k = String(p.kode || '').trim().toLowerCase();
            const n = String(p.nama || '').trim().toLowerCase();
            // Filter dummy products from initial seed
            const isDummy = k.startsWith('wka-0') && (n.includes('beras ramos') || n.includes('minyak goreng') || n.includes('indomie') || n.includes('aqua'));
            return !deletedCodes.has(k) && !deletedCodes.has(n) && !isDummy;
          })
          .map((p) => ({
            kode: String(p.kode || '').trim(),
            nama: String(p.nama || '').trim(),
            harga: Number(p.harga || 0),
            hargaBeli: p.hargaBeli !== undefined && p.hargaBeli !== null ? Number(p.hargaBeli) : (p.hpp !== undefined && p.hpp !== null ? Number(p.hpp) : undefined),
            hpp: p.hargaBeli !== undefined && p.hargaBeli !== null ? Number(p.hargaBeli) : (p.hpp !== undefined && p.hpp !== null ? Number(p.hpp) : undefined),
            kategori: String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '') || 'Lainnya',
            stok: (p.stok !== null && p.stok !== undefined && String(p.stok).trim() !== '') ? String(p.stok).trim() : '',
            satuan: String(p.satuan || 'pcs').trim(),
            tipeHarga: String(p.tipeHarga || 'fix').trim(),
          }));
      }
    } catch {}
  }
  return INITIAL_PRODUCTS.filter((p) => {
    const k = p.kode.trim().toLowerCase();
    const n = p.nama.trim().toLowerCase();
    return !deletedCodes.has(k) && !deletedCodes.has(n);
  });
}

export function getDeletedCustomers(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_customers');
    if (raw) {
      const list: string[] = JSON.parse(raw);
      return new Set(list.map((s) => s.trim().toLowerCase()));
    }
  } catch {}
  return new Set();
}

export function addDeletedCustomer(nama: string) {
  try {
    const clean = nama.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedCustomers();
    set.add(clean);
    localStorage.setItem('strukku_deleted_customers', JSON.stringify(Array.from(set)));
  } catch {}
}

export function removeDeletedCustomer(nama: string) {
  try {
    const clean = nama.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedCustomers();
    set.delete(clean);
    localStorage.setItem('strukku_deleted_customers', JSON.stringify(Array.from(set)));
  } catch {}
}

export function getLocalCustomers(): Customer[] {
  const deletedNames = getDeletedCustomers();
  const cached = localStorage.getItem('strukku_customers') || localStorage.getItem('warung_kaka_customers');
  if (cached !== null) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) {
        const custMap = new Map<string, Customer>();
        parsed.forEach((c) => {
          const n = (c.nama || '').trim();
          const isDummy = n.toLowerCase().includes('ahmad (karyawan)') || n.toLowerCase().includes('siti rahma (karyawan)');
          if (n && !deletedNames.has(n.toLowerCase()) && !isDummy) {
            const divClean = (c.divisi || c.division || '').trim();
            const obj: Customer = {
              ...c,
              nama: n,
              divisi: divClean,
              division: divClean,
              telepon: formatPhone(c.telepon),
            };
            const key = n.toLowerCase();
            if (!custMap.has(key)) {
              custMap.set(key, obj);
            }
          }
        });
        return Array.from(custMap.values());
      }
    } catch {}
  }
  return INITIAL_CUSTOMERS.filter((c) => !deletedNames.has(c.nama.trim().toLowerCase()));
}

export function getLocalKasirUsers(): KasirUser[] {
  const cached = localStorage.getItem('strukku_kasir_users');
  const customPasses = getLocalCustomPasswords();
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const filtered = parsed.filter((u: KasirUser) => {
          const n = (u.nama || '').trim().toLowerCase();
          return !['budi', 'siti', 'operator 1'].includes(n);
        });
        if (filtered.length > 0) {
          return filtered.map((u: KasirUser) => ({
            ...u,
            password: customPasses[u.nama.toLowerCase()] || u.password || 'ervo123',
          }));
        }
      }
    } catch {}
  }
  return INITIAL_KASIR.map((k) => ({
    nama: k,
    password: customPasses[k.toLowerCase()] || 'admin',
    role: 'owner',
  }));
}

export function getLocalSettings(): Partial<StoreSettings> {
  const cached = localStorage.getItem('strukku_sheet_settings');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }
  return {};
}

export function getLocalStockInHistory(): StockInRecord[] {
  const cached = localStorage.getItem('strukku_stock_in_history');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }
  return [];
}

export interface BatchSyncResult {
  products?: Product[];
  customers?: Customer[];
  kasirUsers?: KasirUser[];
  kasirList?: string[];
  settings?: Partial<StoreSettings>;
  stockIn?: StockInRecord[];
  nextInvoiceNo?: string;
  isBatchSupported: boolean;
}

/**
 * Ultra-fast single-request batch data sync from Google Sheets (v6)
 * Reduces 5+ HTTP roundtrips down to 1 request (~1.5s total time)
 */
export async function fetchAllDataBatch(): Promise<BatchSyncResult> {
  try {
    const res = await gasGet<any>('getAllData');
    if (res.success && res.data) {
      const d = res.data;
      let products: Product[] | undefined;
      let customers: Customer[] | undefined;
      let kasirUsers: KasirUser[] | undefined;
      let settings: Partial<StoreSettings> | undefined;
      let stockIn: StockInRecord[] | undefined;
      let nextInvoiceNo: string | undefined;

      if (Array.isArray(d.products) && d.products.length > 0) {
        const deletedProducts = getDeletedProducts();
        
        // Get existing cached products for preserving hargaBeli and recent stock adjustments
        let existingMap = new Map<string, Product>();
        try {
          const cachedRaw = localStorage.getItem('strukku_products');
          if (cachedRaw) {
            const parsedList: Product[] = JSON.parse(cachedRaw);
            if (Array.isArray(parsedList)) {
              parsedList.forEach((p) => {
                if (p.kode) existingMap.set(p.kode.trim().toLowerCase(), p);
                if (p.nama) existingMap.set(p.nama.trim().toLowerCase(), p);
              });
            }
          }
        } catch {}

        products = d.products
          .filter((p: any) => {
            const k = String(p.kode || '').trim().toLowerCase();
            const n = String(p.nama || '').trim().toLowerCase();
            return !deletedProducts.has(k) && !deletedProducts.has(n);
          })
          .map((p: any) => {
            const k = String(p.kode || '').trim().toLowerCase();
            const n = String(p.nama || '').trim().toLowerCase();
            const existing = existingMap.get(k) || existingMap.get(n);

            const rawBeli = p.hargaBeli ?? p.harga_beli ?? p.HargaBeli ?? p.hpp ?? p.HPP ?? p.modal ?? p.HargaModal ?? p['Harga Beli'] ?? p['Harga Modal'];
            const parsedBeli = (rawBeli !== undefined && rawBeli !== null && rawBeli !== '') ? Number(rawBeli) : undefined;
            const finalHargaBeli = (parsedBeli !== undefined && !isNaN(parsedBeli) && parsedBeli > 0) 
              ? parsedBeli 
              : (existing?.hargaBeli || existing?.hpp);

            return {
              kode: String(p.kode || '').trim(),
              nama: String(p.nama || '').trim(),
              harga: Number(p.harga || 0),
              hargaBeli: finalHargaBeli,
              hpp: finalHargaBeli,
              kategori: String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '') || 'Lainnya',
              stok: (p.stok !== null && p.stok !== undefined && String(p.stok).trim() !== '') ? String(p.stok).trim() : (existing?.stok || ''),
              satuan: String(p.satuan || 'pcs').trim(),
              tipeHarga: String(p.tipeHarga || 'fix').trim(),
            };
          });

        // Deduplicate products by code and name
        const seenProd = new Set<string>();
        const uniqueProducts: Product[] = [];
        for (const p of products) {
          if (!p || !p.nama) continue;
          const kKey = p.kode ? p.kode.trim().toLowerCase() : '';
          const nKey = p.nama.trim().toLowerCase();
          const primaryKey = kKey || nKey;
          if (!seenProd.has(primaryKey) && !seenProd.has(nKey)) {
            if (kKey) seenProd.add(kKey);
            seenProd.add(nKey);
            uniqueProducts.push(p);
          }
        }
        products = uniqueProducts;

        localStorage.setItem('strukku_products', JSON.stringify(products));
      }

      if (Array.isArray(d.customers)) {
        const deletedNames = getDeletedCustomers();
        customers = d.customers
          .filter((c: any) => c.nama && !deletedNames.has(c.nama.trim().toLowerCase()))
          .map((c: any) => {
            const divClean = (c.divisi || c.division || c.Divisi || c.Division || '').trim();
            return {
              ...c,
              divisi: divClean,
              division: divClean,
              telepon: formatPhone(c.telepon),
            };
          });
        localStorage.setItem('strukku_customers', JSON.stringify(customers));
        localStorage.setItem('warung_kaka_customers', JSON.stringify(customers));
      }

      if (Array.isArray(d.kasir) && d.kasir.length > 0) {
        const customPasses = getLocalCustomPasswords();
        kasirUsers = d.kasir.map((item: any) => {
          let nama = typeof item === 'string' ? item.trim() : String(item.nama || item.name || '').trim();
          let passFromGas = typeof item === 'object' ? String(item.password || '').trim() : '';
          let roleFromGas = typeof item === 'object' && item.role ? String(item.role).trim().toLowerCase() : undefined;
          
          let role = roleFromGas;
          if (!role) {
            const lower = nama.toLowerCase();
            if (lower === 'admin' || lower.includes('owner')) role = 'owner';
            else if (lower.includes('spv') || lower.includes('supervisor')) role = 'spv';
            else role = 'kasir';
          }
          const finalPass = customPasses[nama.toLowerCase()] || passFromGas || 'ervo123';
          return { nama, password: finalPass, role };
        }).filter((u: any) => u.nama.length > 0);

        if (kasirUsers.length > 0) {
          localStorage.setItem('strukku_kasir_users', JSON.stringify(kasirUsers));
          localStorage.setItem('strukku_kasir_list', JSON.stringify(kasirUsers.map((u) => u.nama)));
        }
      }

      if (d.settings && typeof d.settings === 'object') {
        const data = d.settings;
        const getVal = (possibleKeys: string[]): string | undefined => {
          const keys = Object.keys(data);
          for (const pKey of possibleKeys) {
            const cleanP = pKey.toLowerCase().replace(/[^a-z0-9]/g, '');
            const foundKey = keys.find((k) => k.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanP);
            if (foundKey && data[foundKey] !== undefined && data[foundKey] !== null) {
              const val = String(data[foundKey]).trim();
              if (val) return val;
            }
          }
          return undefined;
        };

        const cfg: Partial<StoreSettings> = {};
        const name = getVal(['NamaToko', 'Nama Toko', 'StoreName', 'Toko']);
        if (name) cfg.name = name;
        const address = getVal(['Alamat', 'AlamatToko', 'Address']);
        if (address) cfg.address = address;
        const phone = getVal(['Telepon', 'NoTelepon', 'Phone', 'HP', 'NoHP', 'WA', 'WhatsApp']);
        if (phone) cfg.phone = phone;
        const footer = getVal(['Footer', 'CatatanFooter', 'Catatan', 'Note']);
        if (footer) cfg.footer = footer;
        const prefix = getVal(['PrefixInvoice', 'Prefix', 'KodeInvoice']);
        if (prefix) cfg.prefixInvoice = prefix;
        const rekening = getVal(['Rekening', 'NoRekening', 'No. Rekening', 'RekeningPembayaran', 'Bank', 'NoRek', 'Account']);
        if (rekening !== undefined) cfg.rekening = rekening;

        settings = cfg;
        localStorage.setItem('strukku_sheet_settings', JSON.stringify(cfg));
      }

      if (Array.isArray(d.stockIn)) {
        stockIn = d.stockIn;
        localStorage.setItem('strukku_stock_in_history', JSON.stringify(stockIn));
      }

      if (d.nextInvoiceNo) {
        nextInvoiceNo = String(d.nextInvoiceNo).trim();
      }

      return {
        products,
        customers,
        kasirUsers,
        kasirList: kasirUsers ? kasirUsers.map((u) => u.nama) : undefined,
        settings,
        stockIn,
        nextInvoiceNo,
        isBatchSupported: true,
      };
    }
  } catch (err) {
    console.warn('Batch getAllData failed, falling back to parallel fetch:', err);
  }

  // Fallback to individual fetches if getAllData is not supported on older script
  const [pData, cData, kUsers, sData, stData] = await Promise.all([
    fetchProducts(),
    fetchCustomers(),
    fetchKasirUsers(),
    fetchSheetSettings(),
    fetchStockInHistory(),
  ]);

  return {
    products: pData,
    customers: cData,
    kasirUsers: kUsers,
    kasirList: kUsers.map((u) => u.nama),
    settings: sData,
    stockIn: stData,
    isBatchSupported: false,
  };
}

export async function getNextInvoiceNumber(): Promise<string> {
  try {
    const res = await gasGet<{ invoiceNo: string }>('getNextInvoiceNo');
    if (res.success && res.invoiceNo) {
      return res.invoiceNo;
    }
  } catch {
    // offline fallback
  }

  const d = new Date();
  const yearMonth = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0');
  const key = 'strukku_inv_' + yearMonth;
  let count = parseInt(localStorage.getItem(key) || '0', 10) + 1;
  localStorage.setItem(key, count.toString());
  return 'ERV-' + yearMonth + '-' + String(count).padStart(3, '0');
}

export async function fetchProducts(): Promise<Product[]> {
  const deletedCodes = getDeletedProducts();
  const sanitize = (list: any[]): Product[] => {
    let existingMap = new Map<string, Product>();
    try {
      const cachedRaw = localStorage.getItem('strukku_products');
      if (cachedRaw) {
        const parsedList: Product[] = JSON.parse(cachedRaw);
        if (Array.isArray(parsedList)) {
          parsedList.forEach((p) => {
            if (p.kode) existingMap.set(p.kode.trim().toLowerCase(), p);
            if (p.nama) existingMap.set(p.nama.trim().toLowerCase(), p);
          });
        }
      }
    } catch {}

    return list
      .filter((p) => {
        const k = String(p.kode || '').trim().toLowerCase();
        const n = String(p.nama || '').trim().toLowerCase();
        return !deletedCodes.has(k) && !deletedCodes.has(n);
      })
      .map((p) => {
        const k = String(p.kode || '').trim().toLowerCase();
        const n = String(p.nama || '').trim().toLowerCase();
        const existing = existingMap.get(k) || existingMap.get(n);

        const rawBeli = p.hargaBeli ?? p.harga_beli ?? p.HargaBeli ?? p.hpp ?? p.HPP ?? p.modal ?? p.HargaModal ?? p['Harga Beli'] ?? p['Harga Modal'];
        const parsedBeli = (rawBeli !== undefined && rawBeli !== null && rawBeli !== '') ? Number(rawBeli) : undefined;
        const finalHargaBeli = (parsedBeli !== undefined && !isNaN(parsedBeli) && parsedBeli > 0) 
          ? parsedBeli 
          : (existing?.hargaBeli || existing?.hpp);

        return {
          kode: String(p.kode || '').trim(),
          nama: String(p.nama || '').trim(),
          harga: Number(p.harga || 0),
          hargaBeli: finalHargaBeli,
          hpp: finalHargaBeli,
          kategori: String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '') || 'Lainnya',
          stok: (p.stok !== null && p.stok !== undefined && String(p.stok).trim() !== '') ? String(p.stok).trim() : (existing?.stok || ''),
          satuan: String(p.satuan || 'pcs').trim(),
          tipeHarga: String(p.tipeHarga || 'fix').trim(),
        };
      });
  };

  try {
    const res = await gasGet<Product[]>('getProducts');
    if (res.success && Array.isArray(res.data) && res.data.length > 0) {
      const sanitized = sanitize(res.data);
      localStorage.setItem('strukku_products', JSON.stringify(sanitized));
      return sanitized;
    }
  } catch {
    // fallback to cache
  }

  const cached = localStorage.getItem('strukku_products');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return sanitize(parsed);
      }
    } catch {}
  }
  return sanitize(INITIAL_PRODUCTS);
}

export function formatPhone(val: string | number | undefined | null): string {
  if (val === undefined || val === null) return '';
  let str = String(val).trim();
  if (str.startsWith("'")) {
    str = str.substring(1);
  }
  if (/^8\d{8,12}$/.test(str)) {
    str = '0' + str;
  }
  return str;
}

export async function fetchCustomers(): Promise<Customer[]> {
  const deletedNames = getDeletedCustomers();
  try {
    const res = await gasGet<Customer[]>('getCustomers');
    if (res.success && Array.isArray(res.data)) {
      const custMap = new Map<string, Customer>();
      res.data.forEach((c) => {
        const name = (c.nama || '').trim();
        if (name && !deletedNames.has(name.toLowerCase())) {
          const divClean = (c.divisi || c.division || (c as any).Divisi || (c as any).Division || '').trim();
          const obj: Customer = {
            ...c,
            nama: name,
            divisi: divClean,
            division: divClean,
            telepon: formatPhone(c.telepon),
          };
          const key = name.toLowerCase();
          if (!custMap.has(key)) {
            custMap.set(key, obj);
          }
        }
      });
      const sanitized = Array.from(custMap.values());
      localStorage.setItem('strukku_customers', JSON.stringify(sanitized));
      localStorage.setItem('warung_kaka_customers', JSON.stringify(sanitized));
      return sanitized;
    }
  } catch {
    // fallback
  }

  return getLocalCustomers();
}

export async function addCustomer(customerData: Customer, oldName?: string): Promise<{ success: boolean; isSheetSynced: boolean; message: string; customer: Customer; needsScriptUpdate?: boolean }> {
  const cleanName = customerData.nama.trim();
  const cleanPhone = formatPhone(customerData.telepon);
  const cleanDivisi = (customerData.divisi || customerData.division || '').trim();

  removeDeletedCustomer(cleanName);
  if (oldName && oldName.trim() && oldName.trim().toLowerCase() !== cleanName.toLowerCase()) {
    addDeletedCustomer(oldName.trim());
  }

  const formattedData: Customer = {
    ...customerData,
    nama: cleanName,
    kelas: customerData.kelas || 'Reguler',
    divisi: cleanDivisi,
    division: cleanDivisi,
    diskon: Number(customerData.diskon || 0),
    telepon: cleanPhone,
    catatan: customerData.catatan || '',
    alamat: customerData.alamat || '',
  };

  // Update local storage cache immediately
  const cached = localStorage.getItem('strukku_customers') || localStorage.getItem('warung_kaka_customers');
  let customers: Customer[] = [];
  if (cached) {
    try { customers = JSON.parse(cached); } catch {}
  } else {
    customers = getLocalCustomers();
  }

  // Remove old name entry if name changed
  if (oldName && oldName.trim()) {
    customers = customers.filter((c) => c.nama.trim().toLowerCase() !== oldName.trim().toLowerCase());
  }
  // Remove existing with same name (case-insensitive)
  customers = customers.filter((c) => c.nama.trim().toLowerCase() !== cleanName.toLowerCase());
  customers.push(formattedData);

  localStorage.setItem('strukku_customers', JSON.stringify(customers));
  localStorage.setItem('warung_kaka_customers', JSON.stringify(customers));

  const telPayload = cleanPhone ? (cleanPhone.startsWith('0') ? ("'" + cleanPhone) : cleanPhone) : '';

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('addCustomer', {
      action: 'addCustomer',
      nama: cleanName,
      kelas: formattedData.kelas,
      divisi: cleanDivisi,
      division: cleanDivisi,
      diskon: formattedData.diskon,
      telepon: telPayload,
      catatan: formattedData.catatan,
      alamat: formattedData.alamat,
      pelanggan: cleanName,
      customer: formattedData,
    });

    if (res.success) {
      return {
        success: true,
        isSheetSynced: true,
        message: res.message || `Pelanggan "${cleanName}" berhasil disimpan ke Google Sheets!`,
        customer: formattedData,
      };
    } else {
      const isScriptOld = res.message?.includes('tidak dikenal') || res.message?.includes('Action');
      return {
        success: true,
        isSheetSynced: false,
        needsScriptUpdate: isScriptOld,
        message: isScriptOld
          ? `Pelanggan "${cleanName}" tersimpan di lokal HP/Aplikasi. PERHATIAN: Kode Apps Script di Google Sheets Anda perlu diperbarui ke versi v4 agar tercatat langsung di spreadsheet.`
          : `Pelanggan "${cleanName}" tersimpan di lokal. (${res.message || 'Gagal ke Google Sheets'})`,
        customer: formattedData,
      };
    }
  } catch (err: any) {
    return {
      success: true,
      isSheetSynced: false,
      message: `Pelanggan "${cleanName}" tersimpan secara lokal (offline mode).`,
      customer: formattedData,
    };
  }
}

export async function deleteCustomer(customerName: string): Promise<{ success: boolean; message: string }> {
  const cleanName = customerName.trim();

  addDeletedCustomer(cleanName);

  // Remove from localStorage cache
  const cached = localStorage.getItem('strukku_customers') || localStorage.getItem('warung_kaka_customers');
  if (cached) {
    try {
      let customers: Customer[] = JSON.parse(cached);
      customers = customers.filter((c) => c.nama.trim().toLowerCase() !== cleanName.toLowerCase());
      localStorage.setItem('strukku_customers', JSON.stringify(customers));
      localStorage.setItem('warung_kaka_customers', JSON.stringify(customers));
    } catch {}
  }

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('deleteCustomer', {
      action: 'deleteCustomer',
      nama: cleanName,
      pelanggan: cleanName,
    });

    if (res.success) {
      return {
        success: true,
        message: res.message || `Pelanggan "${cleanName}" berhasil dihapus.`,
      };
    } else {
      return {
        success: true,
        message: `Pelanggan "${cleanName}" dihapus dari data lokal.`,
      };
    }
  } catch (err: any) {
    return {
      success: true,
      message: `Pelanggan "${cleanName}" dihapus secara lokal (offline mode).`,
    };
  }
}

export function getLocalCustomPasswords(): Record<string, string> {
  try {
    const cached = localStorage.getItem('strukku_custom_passwords');
    return cached ? JSON.parse(cached) : {};
  } catch {
    return {};
  }
}

export function setLocalCustomPassword(kasirName: string, pass: string) {
  const current = getLocalCustomPasswords();
  current[kasirName.trim().toLowerCase()] = pass;
  localStorage.setItem('strukku_custom_passwords', JSON.stringify(current));
}

export async function fetchKasirUsers(): Promise<KasirUser[]> {
  const customPasses = getLocalCustomPasswords();

  try {
    const res = await gasGet<any[]>('getKasir');
    if (res.success && Array.isArray(res.data) && res.data.length > 0) {
      const users: KasirUser[] = res.data.map((item) => {
        let nama = '';
        let passFromGas = '';
        let roleFromGas = '';
        if (typeof item === 'string') {
          nama = item.trim();
        } else {
          nama = String(item.nama || item.name || '').trim();
          passFromGas = String(item.password || '').trim();
          roleFromGas = String(item.role || '').trim().toLowerCase();
        }
        const lowerName = nama.toLowerCase();
        let role = roleFromGas;
        if (!role) {
          if (lowerName === 'admin' || lowerName.includes('owner')) role = 'owner';
          else if (lowerName.includes('spv') || lowerName.includes('supervisor')) role = 'spv';
          else role = 'kasir';
        }
        const finalPass = customPasses[lowerName] || passFromGas || 'ervo123';
        return { nama, password: finalPass, role };
      }).filter((u) => u.nama.length > 0);

      if (users.length > 0) {
        localStorage.setItem('strukku_kasir_users', JSON.stringify(users));
        const names = users.map((u) => u.nama);
        localStorage.setItem('strukku_kasir_list', JSON.stringify(names));
        return users;
      }
    }
  } catch {}

  const cached = localStorage.getItem('strukku_kasir_users');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((u: KasirUser) => ({
          ...u,
          password: customPasses[u.nama.toLowerCase()] || u.password || 'ervo123',
          role: u.role || (u.nama.toLowerCase() === 'admin' ? 'owner' : (u.nama.toLowerCase().includes('spv') ? 'spv' : 'kasir')),
        }));
      }
    } catch {}
  }

  return INITIAL_KASIR.map((k) => ({
    nama: k,
    password: customPasses[k.toLowerCase()] || 'ervo123',
    role: k.toLowerCase() === 'admin' ? 'owner' : 'kasir',
  }));
}

export async function fetchKasirList(): Promise<string[]> {
  const users = await fetchKasirUsers();
  return users.map((u) => u.nama);
}

export async function updateKasirPassword(kasirName: string, newPassword: string, role?: string): Promise<{ success: boolean; message: string }> {
  // Save custom local password immediately
  setLocalCustomPassword(kasirName, newPassword);

  // Update local storage cache immediately
  const cached = localStorage.getItem('strukku_kasir_users');
  let users: KasirUser[] = [];
  if (cached) {
    try { users = JSON.parse(cached); } catch {}
  }
  let found = false;
  const lowerTarget = kasirName.trim().toLowerCase();
  users = users.map((u) => {
    if (u.nama.toLowerCase() === lowerTarget) {
      found = true;
      return { 
        ...u, 
        password: newPassword, 
        role: role || u.role || (lowerTarget === 'admin' ? 'owner' : (lowerTarget.includes('spv') ? 'spv' : 'kasir')) 
      };
    }
    return u;
  });
  if (!found) {
    const finalRole = role || (lowerTarget === 'admin' ? 'owner' : (lowerTarget.includes('spv') ? 'spv' : 'kasir'));
    users.push({ nama: kasirName.trim(), password: newPassword, role: finalRole });
  }
  localStorage.setItem('strukku_kasir_users', JSON.stringify(users));

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('updatePassword', {
      action: 'updatePassword',
      kasir: kasirName.trim(),
      nama: kasirName.trim(),
      newPassword: newPassword,
      password: newPassword,
      role: role || (lowerTarget === 'admin' ? 'owner' : (lowerTarget.includes('spv') ? 'spv' : 'kasir')),
    });
    if (res.success) {
      return {
        success: true,
        message: res.message || 'User & Password berhasil diperbarui & disimpan!',
      };
    } else {
      return {
        success: true,
        message: 'User berhasil diperbarui di aplikasi!',
      };
    }
  } catch (err: any) {
    return {
      success: true,
      message: 'User berhasil diperbarui di aplikasi!',
    };
  }
}

export async function deleteKasirUser(kasirName: string): Promise<{ success: boolean; message: string }> {
  const cleanName = kasirName.trim();
  
  // Remove from localStorage custom passwords
  const customPasses = getLocalCustomPasswords();
  delete customPasses[cleanName.toLowerCase()];
  localStorage.setItem('strukku_custom_passwords', JSON.stringify(customPasses));

  // Remove from local storage users & list
  const cached = localStorage.getItem('strukku_kasir_users');
  if (cached) {
    try {
      let users: KasirUser[] = JSON.parse(cached);
      users = users.filter((u) => u.nama.toLowerCase() !== cleanName.toLowerCase());
      localStorage.setItem('strukku_kasir_users', JSON.stringify(users));
      const names = users.map((u) => u.nama);
      localStorage.setItem('strukku_kasir_list', JSON.stringify(names));
    } catch {}
  }

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('deleteKasir', {
      action: 'deleteKasir',
      kasir: cleanName,
      nama: cleanName,
    });
    if (res.success) {
      return { success: true, message: res.message || `Kasir "${cleanName}" berhasil dihapus!` };
    }
  } catch {}

  return { success: true, message: `Kasir "${cleanName}" berhasil dihapus.` };
}

export async function fetchSheetSettings(): Promise<Partial<StoreSettings>> {
  try {
    const res = await gasGet<Record<string, string>>('getSettings');
    if (res.success && res.data) {
      const data = res.data;
      const getVal = (possibleKeys: string[]): string | undefined => {
        const keys = Object.keys(data);
        for (const pKey of possibleKeys) {
          const cleanP = pKey.toLowerCase().replace(/[^a-z0-9]/g, '');
          const foundKey = keys.find((k) => k.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanP);
          if (foundKey && data[foundKey] !== undefined && data[foundKey] !== null) {
            const val = String(data[foundKey]).trim();
            if (val) return val;
          }
        }
        return undefined;
      };

      const cfg: Partial<StoreSettings> = {};
      const name = getVal(['NamaToko', 'Nama Toko', 'StoreName', 'Toko']);
      if (name) cfg.name = name;

      const tagline = getVal(['Tagline', 'Slogan', 'Motto', 'SubJudul', 'SubTitle']);
      if (tagline) cfg.tagline = tagline;

      const address = getVal(['Alamat', 'AlamatToko', 'Address']);
      if (address) cfg.address = address;

      const phone = getVal(['Telepon', 'NoTelepon', 'Phone', 'HP', 'NoHP', 'WA', 'WhatsApp']);
      if (phone) cfg.phone = phone;

      const footer = getVal(['Footer', 'CatatanFooter', 'Catatan', 'Note']);
      if (footer) cfg.footer = footer;

      const prefix = getVal(['PrefixInvoice', 'Prefix', 'KodeInvoice']);
      if (prefix) cfg.prefixInvoice = prefix;

      const rekening = getVal(['Rekening', 'NoRekening', 'No. Rekening', 'RekeningPembayaran', 'Bank', 'NoRek', 'Account', 'RekeningBank', 'NomorRekening', 'No.Rekening']);
      if (rekening !== undefined) cfg.rekening = rekening;

      const sheetUrl = getVal(['Url', 'AlamatUrl', 'GasUrl', 'WebUrl']);
      if (sheetUrl && sheetUrl.startsWith('http')) {
        setSheetUrl(sheetUrl);
      }

      localStorage.setItem('strukku_sheet_settings', JSON.stringify(cfg));
      return cfg;
    }
  } catch {}

  const cached = localStorage.getItem('strukku_sheet_settings');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }
  return {};
}

export async function saveSettingsRemote(settings: Partial<StoreSettings>): Promise<GasResponse> {
  return gasPost('saveSettings', {
    NamaToko: settings.name,
    Tagline: settings.tagline,
    Alamat: settings.address,
    Telepon: settings.phone,
    Footer: settings.footer,
    PrefixInvoice: settings.prefixInvoice,
    Rekening: settings.rekening,
  });
}

export interface RecentInvoiceItem {
  invoiceNo: string;
  date?: string;
  time?: string;
  customer?: string;
  cashier?: string;
  total?: number;
  dp?: number;
  sisa?: number;
  status?: string;
  items?: InvoiceItem[];
  historiPelunasan?: PelunasanRecord[];
  payMethod?: string;
  metodePembayaran?: string;
  slipNo?: number;
  slipPrinted?: boolean;
  slipPrintedAt?: string;
}

export function addRecentInvoiceToLocal(inv: Partial<Invoice>) {
  if (!inv.invoiceNo) return;
  try {
    const cached = localStorage.getItem('strukku_recent_invoices');
    let list: RecentInvoiceItem[] = cached ? JSON.parse(cached) : [];
    const invKey = inv.invoiceNo.trim().toLowerCase();
    list = list.filter((x) => (x.invoiceNo ? x.invoiceNo.trim().toLowerCase() : '') !== invKey);
    const method = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
    list.unshift({
      invoiceNo: inv.invoiceNo,
      date: inv.date,
      time: inv.time,
      customer: inv.customer,
      cashier: inv.cashier,
      total: inv.total,
      dp: inv.dp !== undefined ? inv.dp : 0,
      sisa: inv.sisa,
      status: inv.status || ((inv.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
      items: inv.items,
      payMethod: method,
      metodePembayaran: method,
      slipNo: inv.slipNo,
      slipPrinted: inv.slipPrinted,
      slipPrintedAt: inv.slipPrintedAt,
    });
    if (list.length > 200) list = list.slice(0, 200);
    localStorage.setItem('strukku_recent_invoices', JSON.stringify(list));
  } catch {}
}

export async function fetchRecentInvoices(forceRefresh = false): Promise<{ list: RecentInvoiceItem[]; needsScriptUpdate: boolean }> {
  const localHistoryRaw = localStorage.getItem('strukku_recent_invoices');
  let localList: RecentInvoiceItem[] = [];
  if (localHistoryRaw) {
    try { localList = JSON.parse(localHistoryRaw); } catch {}
  }

  let needsScriptUpdate = false;

  const syncGas = async () => {
    try {
      const res = await gasGet<RecentInvoiceItem[]>('getRecentInvoices');
      if (res.success && Array.isArray(res.data)) {
        const localItemsMap = new Map<string, InvoiceItem[]>();
        const localDpMap = new Map<string, number>();
        const localPayMethodMap = new Map<string, string>();
        localList.forEach((item) => {
          if (item.invoiceNo) {
            const invKey = item.invoiceNo.trim();
            if (item.items && item.items.length > 0) {
              localItemsMap.set(invKey, item.items);
            }
            if (item.dp !== undefined) {
              localDpMap.set(invKey, Number(item.dp));
            }
            const pm = item.payMethod || (item as any).metodePembayaran;
            if (pm) {
              localPayMethodMap.set(invKey, pm);
              localPayMethodMap.set(invKey.toLowerCase(), pm);
            }
          }
        });

        const seenInvMap = new Map<string, RecentInvoiceItem>();

        // STEP 1: Pre-populate with local/Firestore list to ensure no invoices are lost
        localList.forEach((inv) => {
          const invKey = inv.invoiceNo ? inv.invoiceNo.trim() : '';
          const invLowerKey = invKey.toLowerCase();
          if (invLowerKey) {
            const method = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
            const processed = recalculateInvoiceSisaAndStatus({
              ...inv,
              payMethod: method,
              metodePembayaran: method,
            });
            seenInvMap.set(invLowerKey, processed);
          }
        });

        // STEP 2: Merge remote GAS data into seenInvMap
        res.data.forEach((inv) => {
          let items = inv.items;
          const invKey = inv.invoiceNo ? inv.invoiceNo.trim() : '';
          const invLowerKey = invKey.toLowerCase();
          const existing = invLowerKey ? seenInvMap.get(invLowerKey) : undefined;

          if ((!items || items.length === 0) && invKey && localItemsMap.has(invKey)) {
            items = localItemsMap.get(invKey);
          } else if ((!items || items.length === 0) && existing?.items) {
            items = existing.items;
          }

          let dp = inv.dp !== undefined ? Number(inv.dp) : (localDpMap.has(invKey) ? localDpMap.get(invKey)! : (existing?.dp ?? 0));
          const payMethod = inv.payMethod || (inv as any).metodePembayaran || localPayMethodMap.get(invKey) || localPayMethodMap.get(invLowerKey) || existing?.payMethod || (existing as any)?.metodePembayaran || 'Tunai';

          const mergedInv: RecentInvoiceItem = {
            ...existing,
            ...inv,
            items: (items && items.length > 0) ? items : existing?.items,
            dp,
            payMethod,
            metodePembayaran: payMethod,
          };

          const processed = recalculateInvoiceSisaAndStatus(mergedInv);

          if (!invLowerKey) {
            seenInvMap.set(Math.random().toString(), processed);
          } else {
            seenInvMap.set(invLowerKey, processed);
          }
        });

        const mergedData: RecentInvoiceItem[] = Array.from(seenInvMap.values());
        mergedData.sort((a, b) => (b.invoiceNo || '').localeCompare(a.invoiceNo || ''));

        try {
          localStorage.setItem('strukku_recent_invoices', JSON.stringify(mergedData));
          const allHistories: PelunasanRecord[] = [];
          mergedData.forEach((inv) => {
            if (Array.isArray(inv.historiPelunasan)) {
              allHistories.push(...inv.historiPelunasan);
            }
          });
          localStorage.setItem('strukku_pelunasan_history', JSON.stringify(allHistories));
        } catch {}
        return { list: mergedData, needsScriptUpdate: false };
      } else if (res.message && (res.message.toLowerCase().includes('tidak dikenal') || res.message.toLowerCase().includes('action'))) {
        needsScriptUpdate = true;
      }
    } catch {}
    return { list: localList, needsScriptUpdate };
  };

  if (!forceRefresh && localList.length > 0) {
    // Return instant local cache & sync in background
    syncGas().catch(() => {});
    return { list: localList, needsScriptUpdate: false };
  }

  return await syncGas();
}

export async function fetchPiutangList(forceRefresh = false): Promise<PiutangItem[]> {
  const localHistoryRaw = localStorage.getItem('strukku_recent_invoices');
  let localList: RecentInvoiceItem[] = [];
  if (localHistoryRaw) {
    try { localList = JSON.parse(localHistoryRaw); } catch {}
  }

  const getLocalPiutangList = (): PiutangItem[] => {
    const piutangMap = new Map<string, PiutangItem>();
    localList.forEach((item) => {
      if (!item.invoiceNo) return;
      const invKey = item.invoiceNo.trim().toLowerCase();
      const processed = recalculateInvoiceSisaAndStatus(item);

      if (processed.sisa > 0) {
        piutangMap.set(invKey, {
          invoiceNo: processed.invoiceNo!,
          date: processed.date || '',
          customer: processed.customer || 'Umum',
          total: processed.total || 0,
          dp: processed.dp || 0,
          sisa: processed.sisa,
          deadline: '',
          historiPelunasan: processed.historiPelunasan || [],
        });
      }
    });
    return Array.from(piutangMap.values());
  };

  const syncGasPiutang = async (): Promise<PiutangItem[]> => {
    try {
      const res = await gasGet<PiutangItem[]>('getPiutang');
      if (res.success && Array.isArray(res.data)) {
        return res.data
          .map((p) => {
            const processed = recalculateInvoiceSisaAndStatus(p);
            return {
              invoiceNo: p.invoiceNo,
              date: p.date || '',
              customer: p.customer || 'Umum',
              total: p.total || 0,
              dp: processed.dp || 0,
              sisa: processed.sisa,
              deadline: p.deadline || '',
              historiPelunasan: processed.historiPelunasan || [],
            };
          })
          .filter((p) => (p.sisa || 0) > 0);
      }
    } catch {}
    return getLocalPiutangList();
  };

  const localPiutang = getLocalPiutangList();
  if (!forceRefresh && localPiutang.length > 0) {
    // Return instant local cache & sync in background
    syncGasPiutang().catch(() => {});
    return localPiutang;
  }

  return await syncGasPiutang();
}

export async function getInvoiceByNo(invoiceNo: string): Promise<GasResponse<Invoice>> {
  const cleanInv = invoiceNo.trim().toLowerCase();

  // 1. Check local cache first for instant response
  try {
    const cached = localStorage.getItem('strukku_recent_invoices');
    if (cached) {
      const list: RecentInvoiceItem[] = JSON.parse(cached);
      const target = list.find((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === cleanInv);
      if (target) {
        const historiPelunasan = target.historiPelunasan || getPelunasanHistory(target.invoiceNo);
        const method = target.payMethod || (target as any).metodePembayaran || 'Tunai';
        const inv: Invoice = {
          invoiceNo: target.invoiceNo,
          noInvoice: target.invoiceNo,
          date: target.date || '',
          time: target.time || '',
          customer: target.customer || '',
          cashier: target.cashier || '',
          subtotal: Number(target.total || 0),
          discPct: 0,
          discAmt: 0,
          taxPct: 0,
          taxAmt: 0,
          negoAmt: 0,
          total: Number(target.total || 0),
          payMethod: method,
          metodePembayaran: method,
          dp: Number(target.dp || 0),
          sisa: target.sisa !== undefined ? target.sisa : Math.max(0, Number(target.total || 0) - Number(target.dp || 0)),
          kembalian: 0,
          deadline: '',
          items: target.items || [],
          historiPelunasan,
          status: target.status || 'LUNAS',
        };
        // Background sync with GAS
        gasPost<Invoice>('getInvoice', { invoiceNo }).catch(() => {});
        return { success: true, data: inv };
      }
    }
  } catch {}

  // 2. Query GAS if not found in local cache
  const res = await gasPost<Invoice>('getInvoice', { invoiceNo });
  if (res.success && res.data) {
    const invNo = res.data.invoiceNo || invoiceNo;
    const method = res.data.payMethod || (res.data as any).metodePembayaran || 'Tunai';
    res.data.payMethod = method;
    (res.data as any).metodePembayaran = method;
    const backendHist = Array.isArray((res.data as any).historiPelunasan) ? (res.data as any).historiPelunasan : null;
    const historiPelunasan: PelunasanRecord[] = backendHist !== null ? backendHist : getPelunasanHistory(invNo);
    (res.data as any).historiPelunasan = historiPelunasan;

    if (backendHist !== null) {
      try {
        const cached = localStorage.getItem('strukku_pelunasan_history');
        let list: PelunasanRecord[] = cached ? JSON.parse(cached) : [];
        list = list.filter((x) => x.invoiceNo?.trim().toLowerCase() !== invNo.trim().toLowerCase());
        list.push(...backendHist);
        localStorage.setItem('strukku_pelunasan_history', JSON.stringify(list));
      } catch {}
    }
    return res;
  }

  return res;
}

export async function saveTransaction(payload: any): Promise<GasResponse> {
  const res = await gasPost('saveTransaction', payload);
  if (res.success) {
    addRecentInvoiceToLocal(payload);
  }
  return res;
}

export function getPelunasanTimestamp(r: any): number {
  if (!r) return 0;
  if (r.createdAt) {
    if (typeof r.createdAt === 'number') return r.createdAt;
    if (typeof r.createdAt === 'string') {
      const parsed = new Date(r.createdAt).getTime();
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
    if (typeof r.createdAt === 'object' && typeof (r.createdAt as any).toDate === 'function') {
      return (r.createdAt as any).toDate().getTime();
    }
  }

  const dateStr = String(r.date || '').trim();
  const timeStr = String(r.time || '00:00').trim();

  if (!dateStr) return 0;

  let y = 1970, m = 1, d = 1;

  if (dateStr.includes('/')) {
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        d = parseInt(parts[0], 10) || 1;
        m = parseInt(parts[1], 10) || 1;
        y = parseInt(parts[2], 10) || 1970;
      } else if (parts[0].length === 4) {
        y = parseInt(parts[0], 10) || 1970;
        m = parseInt(parts[1], 10) || 1;
        d = parseInt(parts[2], 10) || 1;
      }
    }
  } else if (dateStr.includes('-')) {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      if (parts[0].length === 4) {
        y = parseInt(parts[0], 10) || 1970;
        m = parseInt(parts[1], 10) || 1;
        d = parseInt(parts[2], 10) || 1;
      } else if (parts[2].length === 4) {
        d = parseInt(parts[0], 10) || 1;
        m = parseInt(parts[1], 10) || 1;
        y = parseInt(parts[2], 10) || 1970;
      }
    }
  }

  let hh = 0, mm = 0, ss = 0;
  if (timeStr) {
    const tParts = timeStr.split(':');
    if (tParts.length >= 2) {
      hh = parseInt(tParts[0], 10) || 0;
      mm = parseInt(tParts[1], 10) || 0;
      if (tParts.length >= 3) {
        ss = parseInt(tParts[2], 10) || 0;
      }
    }
  }

  const dateObj = new Date(y, m - 1, d, hh, mm, ss);
  const t = dateObj.getTime();
  return isNaN(t) ? 0 : t;
}

export function sortPelunasanHistoryAsc(list: PelunasanRecord[]): PelunasanRecord[] {
  if (!Array.isArray(list)) return [];
  return [...list].sort((a, b) => getPelunasanTimestamp(a) - getPelunasanTimestamp(b));
}

export function mergePelunasanHistories(hist1?: PelunasanRecord[] | null, hist2?: PelunasanRecord[] | null): PelunasanRecord[] {
  const list1 = Array.isArray(hist1) ? hist1 : [];
  const list2 = Array.isArray(hist2) ? hist2 : [];
  const combined = [...list1, ...list2];
  
  const seenIds = new Set<string>();
  const seenComposite = new Set<string>();
  const unique: PelunasanRecord[] = [];

  for (const item of combined) {
    if (!item) continue;
    const invNo = (item.invoiceNo || '').trim().toLowerCase();
    const dt = (item.date || '').trim();
    // Normalize time to HH:mm (first 5 chars) to match HH:mm with HH:mm:ss
    const tm = (item.time || '').trim().substring(0, 5);
    const jm = Math.round(Number(item.jumlahBayar || 0));
    const itemId = (item.id || '').trim();

    // 1. Check ID uniqueness if ID is provided
    if (itemId && seenIds.has(itemId)) {
      continue;
    }

    // 2. Check composite content uniqueness (same invoice, date, minute, amount)
    const compositeKey = `${invNo}_${dt}_${tm}_${jm}`;
    if (invNo && dt && seenComposite.has(compositeKey)) {
      continue;
    }

    if (itemId) seenIds.add(itemId);
    if (invNo && dt) seenComposite.add(compositeKey);
    unique.push(item);
  }

  return sortPelunasanHistoryAsc(unique);
}

export function recalculateInvoiceSisaAndStatus<T extends Partial<RecentInvoiceItem>>(inv: T): T {
  if (!inv) return inv;

  const invoiceNo = inv.invoiceNo || '';
  const backendHist = Array.isArray((inv as any).historiPelunasan)
    ? (inv as any).historiPelunasan
    : Array.isArray((inv as any).pelunasanHistory)
    ? (inv as any).pelunasanHistory
    : null;

  const localHist = invoiceNo ? getPelunasanHistory(invoiceNo) : [];
  const historiPelunasan = mergePelunasanHistories(backendHist, localHist);

  const tot = Number(inv.total || 0);
  const dp = Number(inv.dp || 0);
  const totalPaidHist = historiPelunasan.reduce((acc, h) => acc + Number(h.jumlahBayar || 0), 0);

  const initialUnpaid = Math.max(0, tot - dp);
  let sisa = inv.sisa !== undefined && inv.sisa !== null ? Number(inv.sisa) : initialUnpaid;

  if (historiPelunasan.length > 0) {
    sisa = Math.max(0, initialUnpaid - totalPaidHist);
  } else if (inv.sisa !== undefined && inv.sisa !== null) {
    sisa = Number(inv.sisa);
  } else {
    sisa = initialUnpaid;
  }

  if (String(inv.status || '').toUpperCase() === 'LUNAS') {
    sisa = 0;
  }

  const status = sisa <= 0 ? 'LUNAS' : 'DP';
  const payMethod = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';

  return {
    ...inv,
    payMethod,
    metodePembayaran: payMethod,
    sisa,
    status,
    historiPelunasan,
    pelunasanHistory: historiPelunasan,
  };
}

export function savePelunasanHistoryToLocal(record: PelunasanRecord) {
  try {
    const cached = localStorage.getItem('strukku_pelunasan_history');
    let list: PelunasanRecord[] = cached ? JSON.parse(cached) : [];
    const invKey = record.invoiceNo ? record.invoiceNo.trim().toLowerCase() : '';
    const recId = (record.id || '').trim();
    const recDate = (record.date || '').trim();
    const recTimeMin = (record.time || '').trim().substring(0, 5);
    const recAmt = Math.round(Number(record.jumlahBayar || 0));

    const isDup = list.some((x) => {
      if (recId && x.id && recId === x.id.trim()) return true;
      const xKey = (x.invoiceNo || '').trim().toLowerCase();
      const xDate = (x.date || '').trim();
      const xTimeMin = (x.time || '').trim().substring(0, 5);
      const xAmt = Math.round(Number(x.jumlahBayar || 0));
      return xKey === invKey && xDate === recDate && xTimeMin === recTimeMin && xAmt === recAmt;
    });
    if (!isDup) {
      list.push(record);
      const sorted = sortPelunasanHistoryAsc(list);
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(sorted));
    }

    const recInvRaw = localStorage.getItem('strukku_recent_invoices');
    if (recInvRaw) {
      let recList: RecentInvoiceItem[] = JSON.parse(recInvRaw);
      const idx = recList.findIndex((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === invKey);
      if (idx >= 0) {
        const newSisa = record.newSisa !== undefined ? record.newSisa : Math.max(0, (recList[idx].sisa || 0) - record.jumlahBayar);
        recList[idx].sisa = newSisa;
        recList[idx].status = newSisa <= 0 ? 'LUNAS' : 'DP';
        localStorage.setItem('strukku_recent_invoices', JSON.stringify(recList));
      }
    }
  } catch {}
}

export function getPelunasanHistory(invoiceNo: string): PelunasanRecord[] {
  if (!invoiceNo) return [];
  try {
    const cached = localStorage.getItem('strukku_pelunasan_history');
    if (!cached) return [];
    const list: PelunasanRecord[] = JSON.parse(cached);
    const filtered = list.filter((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === invoiceNo.trim().toLowerCase());
    return sortPelunasanHistoryAsc(filtered);
  } catch {
    return [];
  }
}

export async function submitPelunasan(payload: PelunasanRecord): Promise<GasResponse> {
  const res = await gasPost('pelunasan', payload);
  // Calculate newSisa if response provided or infer it
  const bayar = payload.jumlahBayar || 0;
  const sisaAwal = payload.sisaAwal !== undefined ? payload.sisaAwal : 0;
  const newSisa = res.newSisa !== undefined ? res.newSisa : Math.max(0, sisaAwal - bayar);
  
  savePelunasanHistoryToLocal({
    ...payload,
    newSisa,
    status: newSisa <= 0 ? 'LUNAS' : 'DP',
  });
  return res;
}

export async function addNewProduct(newProd: Product): Promise<GasResponse> {
  const cleanKode = (newProd.kode || '').trim();
  const cleanNama = (newProd.nama || '').trim();
  removeDeletedProduct(cleanKode);
  removeDeletedProduct(cleanNama);

  // Update local product list
  try {
    const cachedProducts = localStorage.getItem('strukku_products');
    let products: Product[] = cachedProducts ? JSON.parse(cachedProducts) : INITIAL_PRODUCTS;
    const existingIdx = products.findIndex((p) => (p.kode && cleanKode && p.kode.toLowerCase() === cleanKode.toLowerCase()) || (p.nama && cleanNama && p.nama.toLowerCase() === cleanNama.toLowerCase()));
    if (existingIdx >= 0) {
      products[existingIdx] = newProd;
    } else {
      products.unshift(newProd);
    }
    localStorage.setItem('strukku_products', JSON.stringify(products));
  } catch {}

  return gasPost('addProduct', newProd);
}

export async function updateProductDetails(
  updatedProd: Product,
  oldKode?: string,
  oldNama?: string
): Promise<GasResponse> {
  const cleanKode = (updatedProd.kode || '').trim();
  const cleanNama = (updatedProd.nama || '').trim();
  removeDeletedProduct(cleanKode);
  removeDeletedProduct(cleanNama);

  const payload = {
    ...updatedProd,
    oldKode: oldKode || updatedProd.kode,
    oldNama: oldNama || updatedProd.nama,
  };

  // Update local product list
  try {
    const cachedProducts = localStorage.getItem('strukku_products');
    let products: Product[] = cachedProducts ? JSON.parse(cachedProducts) : INITIAL_PRODUCTS;
    const targetKode = (oldKode || updatedProd.kode || '').toLowerCase();
    const targetNama = (oldNama || updatedProd.nama || '').toLowerCase();

    const existingIdx = products.findIndex(
      (p) => (p.kode && targetKode && p.kode.toLowerCase() === targetKode) || (p.nama && targetNama && p.nama.toLowerCase() === targetNama)
    );
    if (existingIdx >= 0) {
      products[existingIdx] = { ...products[existingIdx], ...updatedProd };
    } else {
      products.unshift(updatedProd);
    }
    localStorage.setItem('strukku_products', JSON.stringify(products));
  } catch {}

  const res = await gasPost('updateProduct', payload);
  if (!res.success) {
    // Fallback to addProduct action if updateProduct is not recognized in older Apps Script versions
    return gasPost('addProduct', payload);
  }
  return res;
}

export async function deleteProduct(kode: string, nama: string): Promise<GasResponse> {
  const cleanKode = (kode || '').trim();
  const cleanNama = (nama || '').trim();

  if (cleanKode) addDeletedProduct(cleanKode);
  if (cleanNama) addDeletedProduct(cleanNama);

  // Remove from localStorage cache
  try {
    const cached = localStorage.getItem('strukku_products');
    if (cached) {
      let products: Product[] = JSON.parse(cached);
      products = products.filter(
        (p) =>
          (!cleanKode || (p.kode || '').trim().toLowerCase() !== cleanKode.toLowerCase()) &&
          (!cleanNama || (p.nama || '').trim().toLowerCase() !== cleanNama.toLowerCase())
      );
      localStorage.setItem('strukku_products', JSON.stringify(products));
    }
  } catch {}

  try {
    const res = await gasPost('deleteProduct', {
      action: 'deleteProduct',
      kode: cleanKode,
      nama: cleanNama,
    });
    return res;
  } catch (err: any) {
    return {
      success: true,
      message: `Produk "${cleanNama || cleanKode}" berhasil dihapus dari sistem lokal (offline mode).`,
    };
  }
}

export async function addStockIn(payload: Omit<StockInRecord, 'id'>, updateLocalProductStock: boolean = false): Promise<GasResponse> {
  const newRecord: StockInRecord = {
    ...payload,
    id: 'STK-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
  };

  // Save to local cache history
  try {
    const cached = localStorage.getItem('strukku_stock_in_history');
    const history: StockInRecord[] = cached ? JSON.parse(cached) : [];
    history.unshift(newRecord);
    if (history.length > 300) history.pop();
    localStorage.setItem('strukku_stock_in_history', JSON.stringify(history));
  } catch {}

  // Update local product stock & hargaBeli ONLY if requested (caller already manages product state)
  if (updateLocalProductStock) {
    try {
      const cachedProducts = localStorage.getItem('strukku_products');
      if (cachedProducts) {
        const products: Product[] = JSON.parse(cachedProducts);
        const targetIdx = products.findIndex((p) => p.kode === payload.kode || p.nama.toLowerCase() === payload.nama.toLowerCase());
        if (targetIdx >= 0) {
          const curStokNum = parseInt(String(products[targetIdx].stok || '0'), 10) || 0;
          products[targetIdx].stok = (curStokNum + payload.qty).toString();
          if (payload.hargaBeli !== undefined && payload.hargaBeli !== null && Number(payload.hargaBeli) > 0) {
            products[targetIdx].hargaBeli = Number(payload.hargaBeli);
            products[targetIdx].hpp = Number(payload.hargaBeli);
          }
          localStorage.setItem('strukku_products', JSON.stringify(products));
        }
      }
    } catch {}
  }

  return gasPost('addStockIn', newRecord);
}

export async function deleteStockInHistoryLocal(id: string): Promise<void> {
  try {
    const cached = localStorage.getItem('strukku_stock_in_history');
    if (cached) {
      const history: StockInRecord[] = JSON.parse(cached);
      const filtered = history.filter((h) => h.id !== id);
      localStorage.setItem('strukku_stock_in_history', JSON.stringify(filtered));
    }
  } catch {}
}

export async function clearAllStockInHistoryLocal(): Promise<void> {
  try {
    localStorage.setItem('strukku_stock_in_history', JSON.stringify([]));
  } catch {}
}

export async function fetchStockInHistory(): Promise<StockInRecord[]> {
  const cached = localStorage.getItem('strukku_stock_in_history');
  let localList: StockInRecord[] = [];
  if (cached) {
    try {
      localList = JSON.parse(cached);
    } catch {}
  }

  try {
    const res = await gasGet<StockInRecord[]>('getStockIn');
    if (res.success && Array.isArray(res.data)) {
      const remoteList = res.data;
      localStorage.setItem('strukku_stock_in_history', JSON.stringify(remoteList));
      return remoteList;
    }
  } catch (err) {
    console.warn('Failed to fetch remote stock in history:', err);
  }

  return localList;
}

export async function initSheetsRemote(): Promise<GasResponse<any>> {
  return gasPost('init', {});
}

export async function fetchExpensesRemote(): Promise<ExpenseRecord[]> {
  const cached = localStorage.getItem('strukku_company_expenses');
  let localList: ExpenseRecord[] = [];
  if (cached) {
    try { localList = JSON.parse(cached); } catch {}
  }

  try {
    const res = await gasGet<ExpenseRecord[]>('getExpenses');
    if (res.success && Array.isArray(res.data)) {
      localStorage.setItem('strukku_company_expenses', JSON.stringify(res.data));
      return res.data;
    }
  } catch (e) {
    console.error('Failed to fetch remote expenses:', e);
  }
  return localList;
}

export function clearLocalCache() {
  try {
    localStorage.removeItem('strukku_recent_invoices');
    localStorage.removeItem('strukku_pelunasan_history');
    localStorage.removeItem('strukku_company_expenses');
    localStorage.removeItem('strukku_stock_in_history');
  } catch {}
}

export async function addExpenseRemote(expense: ExpenseRecord): Promise<GasResponse<any>> {
  try {
    const cached = localStorage.getItem('strukku_company_expenses');
    let list: ExpenseRecord[] = cached ? JSON.parse(cached) : [];
    const idx = list.findIndex(e => e && e.id === expense.id);
    if (idx >= 0) {
      list[idx] = expense;
    } else {
      list.unshift(expense);
    }
    localStorage.setItem('strukku_company_expenses', JSON.stringify(list));
  } catch {}

  return gasPost('addExpense', expense);
}

export async function deleteExpenseRemote(id: string): Promise<GasResponse<any>> {
  return gasPost('deleteExpense', { id });
}

export function updateInvoiceInLocalCache(updatedInvoice: Invoice) {
  const invNo = (updatedInvoice.invoiceNo || updatedInvoice.noInvoice || '').trim();
  if (!invNo) return;
  const invKey = invNo.toLowerCase();

  try {
    // 1. Update recent invoices cache
    const cached = localStorage.getItem('strukku_recent_invoices');
    let list: RecentInvoiceItem[] = cached ? JSON.parse(cached) : [];
    const idx = list.findIndex((x) => (x.invoiceNo ? x.invoiceNo.trim().toLowerCase() : '') === invKey);

    const method = updatedInvoice.payMethod || (updatedInvoice as any).metodePembayaran || 'Tunai';
    const recentItem: RecentInvoiceItem = {
      invoiceNo: updatedInvoice.invoiceNo,
      date: updatedInvoice.date,
      time: updatedInvoice.time,
      customer: updatedInvoice.customer,
      cashier: updatedInvoice.cashier,
      total: updatedInvoice.total,
      dp: updatedInvoice.dp !== undefined ? updatedInvoice.dp : 0,
      sisa: updatedInvoice.sisa,
      status: updatedInvoice.status,
      items: updatedInvoice.items,
      historiPelunasan: updatedInvoice.pelunasanHistory || updatedInvoice.historiPelunasan || [],
      payMethod: method,
      metodePembayaran: method,
    };

    if (idx >= 0) {
      list[idx] = recentItem;
    } else {
      list.unshift(recentItem);
    }
    localStorage.setItem('strukku_recent_invoices', JSON.stringify(list));

    // 2. If pelunasan history exists, update pelunasan cache
    if (Array.isArray(updatedInvoice.pelunasanHistory)) {
      const pelunasanCache = localStorage.getItem('strukku_pelunasan_history');
      let allPelunasan: PelunasanRecord[] = pelunasanCache ? JSON.parse(pelunasanCache) : [];
      // Remove old records of this invoice and re-insert
      allPelunasan = allPelunasan.filter((p) => (p.invoiceNo ? p.invoiceNo.trim().toLowerCase() : '') !== invKey);
      allPelunasan.push(...updatedInvoice.pelunasanHistory);
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(allPelunasan));
    }
  } catch (err) {
    console.warn('Failed to update invoice in local cache:', err);
  }
}

export async function updateInvoiceRemote(
  updatedInvoice: Invoice,
  options?: {
    editedBy?: string;
    editReason?: string;
  }
): Promise<GasResponse> {
  const processed = recalculateInvoiceSisaAndStatus(updatedInvoice);
  
  // 1. Update local storage cache immediately
  updateInvoiceInLocalCache(processed);

  // 2. Post to Google Sheets
  try {
    const payload = {
      action: 'updateInvoice',
      invoiceNo: processed.invoiceNo,
      noInvoice: processed.invoiceNo,
      date: processed.date,
      time: processed.time,
      customer: processed.customer,
      pelanggan: processed.customer,
      cashier: processed.cashier,
      kasir: processed.cashier,
      subtotal: processed.subtotal,
      discPct: processed.discPct,
      discAmt: processed.discAmt,
      taxPct: processed.taxPct,
      taxAmt: processed.taxAmt,
      negoAmt: processed.negoAmt,
      total: processed.total,
      payMethod: processed.payMethod,
      metodePembayaran: processed.payMethod,
      dp: processed.dp,
      sisa: processed.sisa,
      kembalian: processed.kembalian,
      status: processed.status,
      deadline: processed.deadline,
      items: processed.items,
      pelunasanHistory: processed.pelunasanHistory || processed.historiPelunasan || [],
      lastEditedBy: options?.editedBy || processed.lastEditedBy || 'SPV/Owner',
      editReason: options?.editReason || processed.editReason || 'Koreksi Transaksi',
    };

    const res = await gasPost('updateInvoice', payload);
    return res;
  } catch (err: any) {
    return {
      success: true,
      message: 'Perubahan transaksi berhasil disimpan di sistem lokal & database!',
    };
  }
}

export async function deleteInvoiceRemote(invoiceNo: string): Promise<GasResponse> {
  const invNo = (invoiceNo || '').trim();
  if (!invNo) return { success: false, message: 'Nomor invoice kosong' };

  // 1. Remove from local storage caches
  try {
    const raw = localStorage.getItem('strukku_recent_invoices');
    if (raw) {
      const list = JSON.parse(raw);
      const filtered = list.filter((inv: any) => (inv.invoiceNo || '').trim().toLowerCase() !== invNo.toLowerCase());
      localStorage.setItem('strukku_recent_invoices', JSON.stringify(filtered));
    }
    const rawHist = localStorage.getItem('strukku_pelunasan_history');
    if (rawHist) {
      const list = JSON.parse(rawHist);
      const filtered = list.filter((rec: any) => (rec.invoiceNo || '').trim().toLowerCase() !== invNo.toLowerCase());
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(filtered));
    }
  } catch (err) {
    console.warn('Failed to delete invoice from local cache:', err);
  }

  // 2. Post to Google Sheets
  try {
    const res = await gasPost('deleteInvoice', { action: 'deleteInvoice', invoiceNo: invNo });
    return res;
  } catch (err: any) {
    return {
      success: true,
      message: `Invoice #${invNo} berhasil dihapus dari database!`,
    };
  }
}

export function getStockOpnameHistoryFromLocal(): StockOpnameRecord[] {
  try {
    const cached = localStorage.getItem('strukku_stock_opname_history');
    if (!cached) return [];
    const list: StockOpnameRecord[] = JSON.parse(cached);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function saveStockOpnameToLocal(record: StockOpnameRecord) {
  try {
    const history = getStockOpnameHistoryFromLocal();
    const existingIdx = history.findIndex((h) => h.id === record.id);
    if (existingIdx >= 0) {
      history[existingIdx] = record;
    } else {
      history.unshift(record);
    }
    localStorage.setItem('strukku_stock_opname_history', JSON.stringify(history));

    // Update local products cache to reflect physical stock
    const cachedProducts = localStorage.getItem('strukku_products');
    if (cachedProducts && Array.isArray(record.items)) {
      const prods: Product[] = JSON.parse(cachedProducts);
      const itemMap = new Map<string, number>();
      record.items.forEach((item) => {
        if (item.kode) itemMap.set(item.kode.trim().toLowerCase(), item.stokFisik);
      });

      const updated = prods.map((p) => {
        const k = (p.kode || '').trim().toLowerCase();
        if (itemMap.has(k)) {
          return { ...p, stok: String(itemMap.get(k)) };
        }
        return p;
      });
      localStorage.setItem('strukku_products', JSON.stringify(updated));
    }
  } catch (err) {
    console.warn('Failed to save stock opname to local cache:', err);
  }
}

export function deleteStockOpnameFromLocal(id: string) {
  try {
    const history = getStockOpnameHistoryFromLocal();
    const filtered = history.filter((h) => h.id !== id);
    localStorage.setItem('strukku_stock_opname_history', JSON.stringify(filtered));
  } catch {}
}

export async function submitStockOpname(record: StockOpnameRecord): Promise<GasResponse> {
  saveStockOpnameToLocal(record);
  try {
    const res = await gasPost('stockOpname', record);
    return res;
  } catch {
    return { success: true, message: 'Stock Opname berhasil disimpan secara offline/lokal.' };
  }
}


