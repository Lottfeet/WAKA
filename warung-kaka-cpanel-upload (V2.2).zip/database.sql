-- ============================================================================
-- DUMP DATABASE MYSQL / PHPMYADMIN - WARUNG KAKA (Skema hump6894_Waka)
-- Waktu Ekspor : 2/11/2026, 21.17.57
-- Petunjuk     : Buka cPanel > phpMyAdmin > Pilih Database > Tab Import > Pilih file .sql ini
-- ============================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET NAMES utf8mb4;
SET time_zone = '+07:00';
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `produk` (
  `kode` varchar(64) NOT NULL,
  `nama` varchar(255) NOT NULL DEFAULT '',
  `harga` bigint(20) NOT NULL DEFAULT 0,
  `hargaBeli` bigint(20) NOT NULL DEFAULT 0,
  `kategori` varchar(128) DEFAULT 'Umum',
  `stok` int(11) NOT NULL DEFAULT 0,
  `satuan` varchar(64) DEFAULT 'Pcs',
  `tipeHarga` varchar(64) DEFAULT 'Eceran',
  `updatedAt` bigint(20) DEFAULT 0,
  PRIMARY KEY (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `nama` varchar(191) NOT NULL,
  `kelas` varchar(64) DEFAULT 'Reguler',
  `divisi` varchar(128) DEFAULT '',
  `diskon` varchar(64) DEFAULT '0',
  `telepon` varchar(64) DEFAULT '',
  `catatan` text DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `oldNames` longtext DEFAULT NULL,
  `updatedAt` bigint(20) DEFAULT 0,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `invoices` (
  `invoiceNo` varchar(64) NOT NULL,
  `date` varchar(32) DEFAULT '',
  `time` varchar(32) DEFAULT '',
  `customer` varchar(191) DEFAULT '',
  `cashier` varchar(128) DEFAULT '',
  `subtotal` bigint(20) DEFAULT 0,
  `discPct` decimal(10,2) DEFAULT 0.00,
  `discAmt` bigint(20) DEFAULT 0,
  `taxPct` decimal(10,2) DEFAULT 0.00,
  `taxAmt` bigint(20) DEFAULT 0,
  `negoAmt` bigint(20) DEFAULT 0,
  `total` bigint(20) DEFAULT 0,
  `payMethod` varchar(64) DEFAULT '',
  `dp` bigint(20) DEFAULT 0,
  `sisa` bigint(20) DEFAULT 0,
  `kembalian` bigint(20) DEFAULT 0,
  `deadline` varchar(64) DEFAULT '',
  `status` varchar(32) DEFAULT 'LUNAS',
  `slipNo` int(11) DEFAULT NULL,
  `slipPrinted` tinyint(4) NOT NULL DEFAULT 0,
  `slipPrintedAt` varchar(32) NOT NULL DEFAULT '',
  `customerPhone` varchar(64) DEFAULT '',
  `customerAddress` text DEFAULT NULL,
  `originalCustomer` varchar(191) DEFAULT NULL,
  `originalDivisi` varchar(128) DEFAULT NULL,
  `divisi` varchar(128) DEFAULT '',
  `lastEditedBy` varchar(128) DEFAULT NULL,
  `lastEditedAt` bigint(20) DEFAULT NULL,
  `editReason` text DEFAULT NULL,
  `items` longtext DEFAULT NULL,
  `auditLogs` longtext DEFAULT NULL,
  `createdAt` bigint(20) DEFAULT 0,
  `updatedAt` bigint(20) DEFAULT 0,
  PRIMARY KEY (`invoiceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pelunasan` (
  `id` varchar(96) NOT NULL,
  `invoiceNo` varchar(64) NOT NULL,
  `date` varchar(32) DEFAULT '',
  `time` varchar(32) DEFAULT '',
  `customer` varchar(191) DEFAULT '',
  `cashier` varchar(128) DEFAULT '',
  `payMethod` varchar(64) DEFAULT '',
  `jumlahBayar` bigint(20) DEFAULT 0,
  `sisaAwal` bigint(20) DEFAULT 0,
  `newSisa` bigint(20) DEFAULT 0,
  `kembalian` bigint(20) DEFAULT 0,
  `status` varchar(32) DEFAULT '',
  `catatan` text DEFAULT NULL,
  `createdAt` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pengeluaran` (
  `id` varchar(64) NOT NULL,
  `tanggal` varchar(32) DEFAULT '',
  `kategori` varchar(128) DEFAULT '',
  `keterangan` text DEFAULT NULL,
  `nominal` bigint(20) DEFAULT 0,
  `pj` varchar(128) DEFAULT '',
  `buktiRef` varchar(128) DEFAULT '',
  `createdAt` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stok_masuk` (
  `id` varchar(64) NOT NULL,
  `kode` varchar(64) DEFAULT '',
  `nama` varchar(255) DEFAULT '',
  `qty` int(11) DEFAULT 0,
  `hargaBeli` bigint(20) DEFAULT 0,
  `satuan` varchar(64) DEFAULT 'Pcs',
  `supplier` varchar(191) DEFAULT '',
  `cashier` varchar(128) DEFAULT '',
  `tanggal` varchar(32) DEFAULT '',
  `jam` varchar(32) DEFAULT '',
  `catatan` text DEFAULT NULL,
  `createdAt` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `kasir_users` (
  `nama` varchar(128) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '',
  `role` varchar(32) NOT NULL DEFAULT 'kasir',
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `id` tinyint(4) NOT NULL DEFAULT 1,
  `data` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `invoice_seq` (
  `prefix` varchar(16) NOT NULL,
  `yr` int(11) NOT NULL DEFAULT 2026,
  `seq` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `data`) VALUES (1, '{"name":"WARUNG KAKA","storeName":"WARUNG KAKA","tagline":"Cepat / Tepat / Berkualitas","address":"KONVEKSI HUMBEL","phone":"0821-1624-1761","footer":"Terima Kasih Atas Kunjungan Anda","rekening":"","prefixInvoice":"WKA","autoLogoutMinutes":60,"cashier":"Fazar Fiyah","id":"store","minStockThreshold":10,"NamaToko":"WARUNG KAKA","Tagline":"Cepat / Tepat / Berkualitas","Alamat":"KONVEKSI HUMBEL","Telepon":"0821-1624-1761","Footer":"Terima Kasih Atas Kunjungan Anda","PrefixInvoice":"WKA","Rekening":"","updatedAt":"2026-11-02T14:12:20.007Z"}') ON DUPLICATE KEY UPDATE `data`=VALUES(`data`);

-- Data Operator / Kasir
INSERT INTO `kasir_users` (`nama`, `password`, `role`) VALUES ('Admin', 'admin', 'owner') ON DUPLICATE KEY UPDATE `password`=VALUES(`password`), `role`=VALUES(`role`);

SET FOREIGN_KEY_CHECKS = 1;
