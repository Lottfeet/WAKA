import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  KeyRound, 
  AlertCircle, 
  CheckCircle2, 
  Save, 
  Receipt, 
  CreditCard, 
  Banknote, 
  QrCode, 
  Building2, 
  UserCheck, 
  Calendar, 
  Clock, 
  User, 
  FileText, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Printer, 
  Layers,
  ChevronRight,
  Info,
  History,
  Ticket
} from 'lucide-react';
import { Invoice, InvoiceItem, StoreSettings, KasirUser, Customer, Product, PelunasanRecord } from '../types';
import { fRp, fDateInput, formatDateFromInput, computeItemTotal, checkIsSpvOrOwner } from '../utils/formatters';
import { updateInvoiceFirebase } from '../services/firebaseService';
import { updateInvoiceRemote } from '../services/gasService';
import { generateThermalHTML, generateA5HTML, openPrintWindow } from '../utils/printUtils';

interface EditTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  settings: StoreSettings;
  kasirUsers: KasirUser[];
  customers?: Customer[];
  products?: Product[];
  currentUser?: string | null;
  onSaveSuccess?: (updatedInvoice: Invoice) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  onClose,
  invoice,
  settings,
  kasirUsers,
  customers = [],
  products = [],
  currentUser,
  onSaveSuccess,
  onShowToast,
}) => {
  // Authorization Gate State
  const [isAuthorized, setIsAuthorized] = useState<boolean>(false);
  const [authorizedBy, setAuthorizedBy] = useState<string>('');
  const [authSpvUser, setAuthSpvUser] = useState<string>('');
  const [authPassword, setAuthPassword] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Form Editing State
  const [activeSubTab, setActiveSubTab] = useState<'pembayaran' | 'items' | 'pelunasan' | 'audit'>('pembayaran');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Editable Fields
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [transactionDate, setTransactionDate] = useState<string>('');
  const [transactionTime, setTransactionTime] = useState<string>('');
  const [deadlineDate, setDeadlineDate] = useState<string>('');
  const [cashierName, setCashierName] = useState<string>('');

  // Payment Details
  const [payMethod, setPayMethod] = useState<string>('Tunai');
  const [dpAmount, setDpAmount] = useState<number>(0);
  const [discPct, setDiscPct] = useState<number>(0);
  const [taxPct, setTaxPct] = useState<number>(0);
  const [negoAmt, setNegoAmt] = useState<number>(0);

  // Items List
  const [items, setItems] = useState<InvoiceItem[]>([]);

  // Pelunasan History (Installments)
  const [pelunasanHistory, setPelunasanHistory] = useState<PelunasanRecord[]>([]);

  // Audit Reason
  const [editReasonCategory, setEditReasonCategory] = useState<string>('Salah input metode pembayaran');
  const [editReasonCustom, setEditReasonCustom] = useState<string>('');

  // Post-Save Print Dialog
  const [savedInvoice, setSavedInvoice] = useState<Invoice | null>(null);

  // Initialize and check role whenever modal opens or invoice changes
  useEffect(() => {
    if (!isOpen || !invoice) {
      setIsAuthorized(false);
      setAuthorizedBy('');
      setAuthPassword('');
      setAuthError(null);
      setSavedInvoice(null);
      return;
    }

    const activeUser = currentUser || settings.cashier || localStorage.getItem('strukku_logged_kasir') || '';
    const isUserSpv = checkIsSpvOrOwner(activeUser, kasirUsers);

    if (isUserSpv) {
      setIsAuthorized(true);
      setAuthorizedBy(activeUser);
    } else {
      setIsAuthorized(false);
      const spvCandidates = kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
      if (spvCandidates.length > 0) {
        setAuthSpvUser(spvCandidates[0].nama);
      } else if (kasirUsers.length > 0) {
        setAuthSpvUser(kasirUsers[0].nama);
      }
    }

    // Populate invoice fields
    setCustomerName(invoice.customer || invoice.pelanggan || 'Umum');
    setCustomerPhone(invoice.customerPhone || '');
    setCustomerAddress(invoice.customerAddress || '');
    setTransactionDate(invoice.date || fDateInput(new Date()));
    setTransactionTime(invoice.time || '12:00');
    setDeadlineDate(invoice.deadline || '');
    setCashierName(invoice.cashier || 'Admin');

    setPayMethod(invoice.payMethod || (invoice as any).metodePembayaran || 'Tunai');
    setDpAmount(Number(invoice.dp || 0));
    setDiscPct(Number(invoice.discPct || 0));
    setTaxPct(Number(invoice.taxPct || 0));
    setNegoAmt(Number(invoice.negoAmt || 0));

    setItems(Array.isArray(invoice.items) ? JSON.parse(JSON.stringify(invoice.items)) : []);
    
    const hist = Array.isArray(invoice.pelunasanHistory) 
      ? invoice.pelunasanHistory 
      : Array.isArray(invoice.historiPelunasan) 
      ? invoice.historiPelunasan 
      : [];
    setPelunasanHistory(JSON.parse(JSON.stringify(hist)));

    setEditReasonCategory('Salah input metode pembayaran');
    setEditReasonCustom('');
    setActiveSubTab('pembayaran');
  }, [isOpen, invoice, currentUser, settings.cashier, kasirUsers]);

  if (!isOpen || !invoice) return null;

  // Handle SPV Verification
  const handleVerifyAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (!authSpvUser) {
      setAuthError('Pilih akun SPV / Owner.');
      return;
    }

    const targetUser = kasirUsers.find((u) => u.nama.trim().toLowerCase() === authSpvUser.trim().toLowerCase());
    const validPass = targetUser?.password || 'ervo123';

    if (authPassword.trim() === validPass) {
      setIsAuthorized(true);
      setAuthorizedBy(authSpvUser);
      onShowToast(`Otorisasi diterima dari ${authSpvUser}`, 'success');
    } else {
      setAuthError(`Password / PIN otorisasi untuk ${authSpvUser} salah!`);
    }
  };

  // Calculations
  const calculatedSubtotal = items.reduce((acc, item) => acc + computeItemTotal(item), 0);
  const calculatedDiscAmt = discPct > 0 ? (calculatedSubtotal * discPct) / 100 : 0;
  const afterDisc = Math.max(0, calculatedSubtotal - calculatedDiscAmt);
  const calculatedTaxAmt = taxPct > 0 ? (afterDisc * taxPct) / 100 : 0;
  const calculatedTotal = Math.max(0, afterDisc + calculatedTaxAmt - (negoAmt || 0));

  const totalPelunasanPaid = pelunasanHistory.reduce((acc, p) => acc + Number(p.jumlahBayar || 0), 0);
  const totalPaid = dpAmount + totalPelunasanPaid;
  const calculatedSisa = Math.max(0, calculatedTotal - totalPaid);
  const calculatedStatus = calculatedSisa <= 0 ? 'LUNAS' : 'DP';

  // Handle Item Changes
  const handleItemChange = (index: number, field: keyof InvoiceItem, val: any) => {
    setItems((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: val };
      return updated;
    });
  };

  const handleAddItem = (product?: Product) => {
    const newItem: InvoiceItem = {
      kode: product ? product.kode : 'CUSTOM',
      nama: product ? product.nama : 'Item Pesanan Baru',
      harga: product ? product.harga : 0,
      qty: 1,
      satuan: product ? product.satuan : 'pcs',
      tipeHarga: product ? product.tipeHarga : 'fix',
      panjang: 1,
      lebar: 1,
      bahan: '',
      catatan: '',
      diskonItem: 0,
    };
    setItems((prev) => [...prev, newItem]);
  };

  const handleDeleteItem = (index: number) => {
    setItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Handle Pelunasan Step Changes
  const handlePelunasanChange = (index: number, field: keyof PelunasanRecord, val: any) => {
    setPelunasanHistory((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: val };
      return updated;
    });
  };

  const handleDeletePelunasan = (index: number) => {
    setPelunasanHistory((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Submit Save Changes
  const handleSaveCorrection = async () => {
    if (items.length === 0) {
      onShowToast('Transaksi harus memiliki minimal 1 item pesanan!', 'error');
      return;
    }

    const finalReason = editReasonCustom.trim() 
      ? `${editReasonCategory}: ${editReasonCustom.trim()}` 
      : editReasonCategory;

    setIsSaving(true);

    const updatedInvoice: Invoice = {
      ...invoice,
      customer: customerName.trim() || 'Umum',
      pelanggan: customerName.trim() || 'Umum',
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      date: transactionDate,
      time: transactionTime,
      deadline: deadlineDate,
      cashier: cashierName,
      subtotal: calculatedSubtotal,
      discPct: discPct,
      discAmt: calculatedDiscAmt,
      taxPct: taxPct,
      taxAmt: calculatedTaxAmt,
      negoAmt: negoAmt,
      total: calculatedTotal,
      payMethod: payMethod,
      metodePembayaran: payMethod,
      dp: dpAmount,
      sisa: calculatedSisa,
      status: calculatedStatus,
      items: items,
      pelunasanHistory: pelunasanHistory,
      historiPelunasan: pelunasanHistory,
      lastEditedBy: authorizedBy || currentUser || 'SPV/Owner',
      editReason: finalReason,
    };

    try {
      // 1. Update in Firebase Firestore
      await updateInvoiceFirebase(updatedInvoice, {
        editedBy: authorizedBy || currentUser || 'SPV/Owner',
        editReason: finalReason,
      });

      // 2. Update in Google Sheets & Local Storage
      await updateInvoiceRemote(updatedInvoice, {
        editedBy: authorizedBy || currentUser || 'SPV/Owner',
        editReason: finalReason,
      });

      setSavedInvoice(updatedInvoice);
      if (onSaveSuccess) {
        onSaveSuccess(updatedInvoice);
      }
      onShowToast(`✓ Transaksi #${updatedInvoice.invoiceNo} berhasil dikoreksi & disimpan!`, 'success');
    } catch (err: any) {
      console.error('Failed to update invoice:', err);
      onShowToast('Gagal menyimpan koreksi transaksi: ' + (err?.message || 'Error tidak diketahui'), 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Print Handlers for updated invoice
  const handlePrintThermal = () => {
    if (!savedInvoice) return;
    const html = generateThermalHTML(savedInvoice, settings);
    openPrintWindow(html, 'Struk Koreksi ' + savedInvoice.invoiceNo);
  };

  const handlePrintA5 = () => {
    if (!savedInvoice) return;
    const html = generateA5HTML(savedInvoice, settings);
    openPrintWindow(html, 'Nota A5 Koreksi ' + savedInvoice.invoiceNo);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-hidden shadow-2xl border border-stone-200 flex flex-col">
        
        {/* Header */}
        <div className="p-4 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-700 text-white flex items-center justify-center font-bold shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-stone-900 text-base">
                  Koreksi & Edit Transaksi
                </h3>
                <span className="px-2 py-0.5 rounded-md bg-stone-200 text-stone-800 font-mono text-xs font-bold">
                  {invoice.invoiceNo}
                </span>
              </div>
              <p className="text-xs text-stone-500 font-medium">
                Perbaiki kesalahan input kasir atau metode pembayaran dengan otorisasi SPV / Owner.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {!isAuthorized ? (
          /* STEP 1: SPV / OWNER AUTHORIZATION GATE */
          <div className="p-6 overflow-y-auto space-y-5">
            <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3">
              <div className="p-2 bg-red-100 text-red-800 rounded-xl mt-0.5">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="font-extrabold text-red-900 text-sm">
                  Otorisasi SPV / Owner Diperlukan
                </h4>
                <p className="text-xs text-red-800 leading-relaxed">
                  Sesuai kebijakan keamanan dan pembukuan toko, kasir tidak diizinkan mengubah data transaksi secara sepihak. Masukkan PIN / Password akun <strong>Supervisor (SPV)</strong> atau <strong>Owner</strong> untuk membuka akses koreksi.
                </p>
              </div>
            </div>

            <form onSubmit={handleVerifyAuth} className="space-y-4 max-w-md mx-auto pt-2">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-stone-500" />
                  <span>Pilih Akun Otorisator (SPV / Owner)</span>
                </label>
                <select
                  value={authSpvUser}
                  onChange={(e) => setAuthSpvUser(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                >
                  {kasirUsers.map((u, uIdx) => {
                    const isSpv = checkIsSpvOrOwner(u.nama, kasirUsers);
                    return (
                      <option key={`${u.nama}-${uIdx}`} value={u.nama}>
                        {u.nama} {isSpv ? '(SPV / Owner)' : '(Kasir)'}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-stone-500" />
                  <span>Password / PIN SPV / Owner</span>
                </label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="Masukkan password / PIN otorisasi..."
                  required
                  autoFocus
                  className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
              </div>

              {authError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 px-4 rounded-xl border border-stone-200 text-stone-700 font-bold text-xs hover:bg-stone-50 transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-red-700 hover:bg-red-800 text-white font-extrabold text-xs shadow-md flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Buka Akses Koreksi</span>
                </button>
              </div>
            </form>
          </div>
        ) : savedInvoice ? (
          /* SUCCESS / POST-SAVE PRINT DIALOG */
          <div className="p-6 text-center space-y-4">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-base font-extrabold text-stone-900">
                Koreksi Transaksi Berhasil Disimpan!
              </h4>
              <p className="text-xs text-stone-500 mt-1 max-w-md mx-auto">
                Data nota <strong>#{savedInvoice.invoiceNo}</strong> telah diperbarui di pembukuan kas, buku piutang, dan Google Sheets.
              </p>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-left max-w-md mx-auto text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-stone-500">Pelanggan:</span>
                <strong className="text-stone-900">{savedInvoice.customer}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Metode Pembayaran:</span>
                <span className="font-extrabold text-blue-700">{savedInvoice.payMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Total Transaksi:</span>
                <strong className="text-stone-900">{fRp(savedInvoice.total)}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Dibayar (DP):</span>
                <strong className="text-emerald-700">{fRp(savedInvoice.dp)}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Sisa Piutang:</span>
                <strong className={savedInvoice.sisa > 0 ? 'text-red-700' : 'text-emerald-700'}>
                  {fRp(savedInvoice.sisa)} ({savedInvoice.status})
                </strong>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handlePrintThermal}
                className="px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Ulang Struk Thermal</span>
              </button>
              <button
                onClick={handlePrintA5}
                className="px-4 py-2.5 bg-red-700 hover:bg-red-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Cetak Nota A5</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Selesai / Tutup
              </button>
            </div>
          </div>
        ) : (
          /* STEP 2: FULL CORRECTION FORM */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Sub-Navigation Tabs & SPV Badge */}
            <div className="px-4 py-2 bg-stone-100/80 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar">
                <button
                  type="button"
                  onClick={() => setActiveSubTab('pembayaran')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                    activeSubTab === 'pembayaran'
                      ? 'bg-white text-red-700 shadow-2xs border border-stone-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>1. Metode & Pembayaran</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('items')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                    activeSubTab === 'items'
                      ? 'bg-white text-red-700 shadow-2xs border border-stone-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>2. Item Pesanan ({items.length})</span>
                </button>
                {pelunasanHistory.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveSubTab('pelunasan')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                      activeSubTab === 'pelunasan'
                        ? 'bg-white text-red-700 shadow-2xs border border-stone-200'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                    }`}
                  >
                    <History className="w-3.5 h-3.5" />
                    <span>3. Angsuran ({pelunasanHistory.length})</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setActiveSubTab('audit')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${
                    activeSubTab === 'audit'
                      ? 'bg-white text-red-700 shadow-2xs border border-stone-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Alasan & Riwayat Audit</span>
                </button>
              </div>

              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-lg text-[11px] font-extrabold shrink-0 border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Otorisasi: {authorizedBy || 'SPV/Owner'}</span>
              </div>
            </div>

            {/* Tab Panes */}
            <div className="p-4 overflow-y-auto flex-1 space-y-4">
              
              {/* TAB 1: METODE PEMBAYARAN & NOMINAL DP */}
              {activeSubTab === 'pembayaran' && (
                <div className="space-y-4">
                  {/* Pilihan Metode Pembayaran Utama */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2.5">
                    <label className="block text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                      Metode Pembayaran <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'Tunai', label: '💵 Tunai / Cash', icon: Banknote, color: 'emerald' },
                        { id: 'Voucher WAKA', label: '🎟️ Voucher WAKA', icon: Ticket, color: 'emerald' },
                        { id: 'Potong Gaji', label: '📋 Potong Gaji', icon: FileText, color: 'rose' },
                        { id: 'Transfer', label: '🏦 Transfer Bank', icon: Building2, color: 'blue' },
                      ].map((m) => {
                        const Icon = m.icon;
                        const isSelected = payMethod.toLowerCase().includes(m.id.toLowerCase());
                        return (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => {
                              setPayMethod(m.id);
                              if (m.id === 'Potong Gaji') {
                                setDpAmount(0);
                              } else if (m.id === 'Voucher WAKA') {
                                setDpAmount(calculatedTotal);
                              }
                            }}
                            className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-xs font-extrabold transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-red-700 text-white border-red-700 shadow-sm'
                                : 'bg-white text-stone-700 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                            }`}
                          >
                            <Icon className="w-5 h-5" />
                            <span>{m.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Nominal Pembayaran DP / Bayar Muka */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                        Uang Muka / Nominal Bayar Awal (DP) <span className="text-red-500">*</span>
                      </label>
                      <span className="text-xs font-extrabold text-stone-900">
                        Total Order: {fRp(calculatedTotal)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-2.5 text-xs font-bold text-stone-400">Rp</span>
                        <input
                          type="number"
                          min="0"
                          value={dpAmount}
                          onChange={(e) => setDpAmount(Math.max(0, Number(e.target.value) || 0))}
                          className="w-full pl-9 pr-3 py-2.5 bg-white border border-stone-200 rounded-xl text-sm font-mono font-extrabold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        />
                      </div>
                    </div>

                    {/* Quick Shortcuts */}
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setDpAmount(calculatedTotal)}
                        className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[11px] rounded-lg border border-emerald-200 transition cursor-pointer"
                      >
                        Bayar Lunas (100%)
                      </button>
                      <button
                        type="button"
                        onClick={() => setDpAmount(Math.round(calculatedTotal / 2))}
                        className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-[11px] rounded-lg border border-blue-200 transition cursor-pointer"
                      >
                        DP 50% ({fRp(Math.round(calculatedTotal / 2))})
                      </button>
                      <button
                        type="button"
                        onClick={() => setDpAmount(0)}
                        className="px-2.5 py-1 bg-red-50 hover:bg-red-100 text-red-800 font-bold text-[11px] rounded-lg border border-red-200 transition cursor-pointer"
                      >
                        Belum Bayar / Piutang Penuh (Rp 0)
                      </button>
                    </div>

                    {/* Live Recalculated Summary Card */}
                    <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-stone-500 text-[11px] block">Status Otomatis:</span>
                        <span className={`inline-block font-extrabold uppercase px-2 py-0.5 rounded text-[10px] ${
                          calculatedStatus === 'LUNAS' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {calculatedStatus}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-stone-500 text-[11px] block">Sisa Tagihan / Piutang:</span>
                        <span className="text-sm font-mono font-extrabold text-red-700">
                          {fRp(calculatedSisa)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Data Pelanggan & Info Transaksi */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                    <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                      Informasi Pelanggan & Tanggal Nota
                    </h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          Nama Pelanggan
                        </label>
                        <input
                          type="text"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Nama Pelanggan (misal: Umum)"
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          No. Telepon / WhatsApp
                        </label>
                        <input
                          type="text"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="08..."
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-mono font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          Tanggal Transaksi
                        </label>
                        <input
                          type="text"
                          value={transactionDate}
                          onChange={(e) => setTransactionDate(e.target.value)}
                          placeholder="DD/MM/YYYY atau YYYY-MM-DD"
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          Kasir yang Menangani
                        </label>
                        <select
                          value={cashierName}
                          onChange={(e) => setCashierName(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        >
                          {kasirUsers.map((u, uIdx) => (
                            <option key={`${u.nama}-${uIdx}`} value={u.nama}>{u.nama}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: ITEM PESANAN & PERHITUNGAN */}
              {activeSubTab === 'items' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                      Daftar Item Pesanan ({items.length} Item)
                    </h4>
                    <button
                      type="button"
                      onClick={() => handleAddItem()}
                      className="px-2.5 py-1.5 bg-red-700 hover:bg-red-800 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-2xs transition cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Item</span>
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {items.map((item, idx) => {
                      const itemTotal = computeItemTotal(item);
                      const isMeteran = item.tipeHarga === 'ukuran';

                      return (
                        <div key={idx} className="p-3 bg-stone-50 border border-stone-200 rounded-2xl space-y-2.5">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-1">
                              <span className="w-6 h-6 rounded-lg bg-stone-200 text-stone-700 font-bold text-xs flex items-center justify-center">
                                {idx + 1}
                              </span>
                              <input
                                type="text"
                                value={item.nama}
                                onChange={(e) => handleItemChange(idx, 'nama', e.target.value)}
                                placeholder="Nama Barang / Jasa Cetak..."
                                className="flex-1 px-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => handleDeleteItem(idx)}
                              className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                              title="Hapus Item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Dimensions & Qty */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                            {isMeteran && (
                              <>
                                <div>
                                  <label className="block text-[10px] font-bold text-stone-500">Panjang (m)</label>
                                  <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={item.panjang || 1}
                                    onChange={(e) => handleItemChange(idx, 'panjang', parseFloat(e.target.value) || 0)}
                                    className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono text-stone-900"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[10px] font-bold text-stone-500">Lebar (m)</label>
                                  <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={item.lebar || 1}
                                    onChange={(e) => handleItemChange(idx, 'lebar', parseFloat(e.target.value) || 0)}
                                    className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono text-stone-900"
                                  />
                                </div>
                              </>
                            )}

                            <div>
                              <label className="block text-[10px] font-bold text-stone-500">Qty ({item.satuan || 'pcs'})</label>
                              <input
                                type="number"
                                step="any"
                                min="0.0001"
                                value={item.qty || 1}
                                onChange={(e) => handleItemChange(idx, 'qty', parseFloat(e.target.value) || 1)}
                                className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono font-bold text-stone-900"
                              />
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-stone-500">Harga Satuan (Rp)</label>
                              <input
                                type="number"
                                min="0"
                                value={item.harga || 0}
                                onChange={(e) => handleItemChange(idx, 'harga', parseFloat(e.target.value) || 0)}
                                className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono font-bold text-stone-900"
                              />
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-xs pt-1 border-t border-stone-200/60">
                            <span className="text-[11px] text-stone-400 font-medium">Subtotal Item:</span>
                            <span className="font-mono font-extrabold text-stone-900">{fRp(itemTotal)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Summary Totals Calculation */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2 text-xs">
                    <div className="flex justify-between text-stone-600">
                      <span>Subtotal Order:</span>
                      <span className="font-mono font-bold">{fRp(calculatedSubtotal)}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1 border-t border-stone-200/60">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500">Diskon Nota (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={discPct}
                          onChange={(e) => setDiscPct(Math.max(0, parseFloat(e.target.value) || 0))}
                          className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500">Pajak PPN (%)</label>
                        <input
                          type="number"
                          min="0"
                          value={taxPct}
                          onChange={(e) => setTaxPct(Math.max(0, parseFloat(e.target.value) || 0))}
                          className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500">Potongan Nego (Rp)</label>
                        <input
                          type="number"
                          min="0"
                          value={negoAmt}
                          onChange={(e) => setNegoAmt(Math.max(0, parseFloat(e.target.value) || 0))}
                          className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t border-stone-200 font-extrabold text-sm text-stone-900">
                      <span>Total Akhir Nota:</span>
                      <span className="text-base font-mono text-red-700">{fRp(calculatedTotal)}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: ANGSURAN PELUNASAN (JIKA ADA) */}
              {activeSubTab === 'pelunasan' && (
                <div className="space-y-3">
                  <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                    Koreksi Riwayat Angsuran / Pelunasan Lanjutan
                  </h4>

                  {pelunasanHistory.map((p, pIdx) => (
                    <div key={pIdx} className="p-3 bg-stone-50 border border-stone-200 rounded-2xl space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-stone-800">Angsuran #{pIdx + 1}</span>
                        <button
                          type="button"
                          onClick={() => handleDeletePelunasan(pIdx)}
                          className="text-red-500 hover:text-red-700 text-xs font-bold cursor-pointer"
                        >
                          Hapus Angsuran
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] font-bold text-stone-500">Nominal Angsuran (Rp)</label>
                          <input
                            type="number"
                            min="0"
                            value={p.jumlahBayar || 0}
                            onChange={(e) => handlePelunasanChange(pIdx, 'jumlahBayar', parseFloat(e.target.value) || 0)}
                            className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg font-mono font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-stone-500">Metode Angsuran</label>
                          <select
                            value={p.payMethod || 'Tunai'}
                            onChange={(e) => handlePelunasanChange(pIdx, 'payMethod', e.target.value)}
                            className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg font-bold cursor-pointer"
                          >
                            <option value="Tunai">Tunai</option>
                            <option value="Transfer">Transfer</option>
                            <option value="QRIS">QRIS</option>
                            <option value="Debet">Debet</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* TAB 4: AUDIT LOG & ALASAN KOREKSI */}
              {activeSubTab === 'audit' && (
                <div className="space-y-4">
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                    <label className="block text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                      Alasan Koreksi Transaksi <span className="text-red-500">*</span>
                    </label>

                    <div className="space-y-2">
                      {[
                        'Salah input metode pembayaran (misal: Kasir pilih Tunai padahal Transfer/QRIS)',
                        'Salah input nominal uang muka / DP',
                        'Salah pilih data pelanggan',
                        'Koreksi ukuran panjang x lebar atau kuantitas order',
                        'Lainnya (Tulis catatan khusus di bawah)',
                      ].map((reason) => (
                        <label key={reason} className="flex items-center gap-2 text-xs font-medium text-stone-700 cursor-pointer">
                          <input
                            type="radio"
                            name="editReasonCat"
                            checked={editReasonCategory === reason}
                            onChange={() => setEditReasonCategory(reason)}
                            className="accent-red-600"
                          />
                          <span>{reason}</span>
                        </label>
                      ))}
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">
                        Catatan Tambahan Koreksi (Opsional):
                      </label>
                      <textarea
                        rows={2}
                        value={editReasonCustom}
                        onChange={(e) => setEditReasonCustom(e.target.value)}
                        placeholder="Contoh: Pelanggan meminta revisi metode bayar dari QRIS ke Tunai di tempat..."
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-red-500/20"
                      />
                    </div>
                  </div>

                  {/* History of Previous Audits */}
                  {Array.isArray(invoice.auditLogs) && invoice.auditLogs.length > 0 && (
                    <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2">
                      <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
                        <History className="w-3.5 h-3.5 text-stone-500" />
                        <span>Riwayat Koreksi Sebelumnya</span>
                      </h4>
                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {invoice.auditLogs.map((log, lIdx) => (
                          <div key={lIdx} className="p-2.5 bg-white border border-stone-200/70 rounded-xl text-[11px] space-y-1">
                            <div className="flex justify-between font-bold text-stone-800">
                              <span>Oleh: {log.editedBy}</span>
                              <span className="text-stone-400">{log.editedAt}</span>
                            </div>
                            <p className="text-stone-600 italic">"{log.reason}"</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Modal Bottom Footer Actions */}
            <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={isSaving}
                className="py-2.5 px-4 rounded-xl border border-stone-200 text-stone-700 font-bold text-xs hover:bg-stone-100 transition cursor-pointer"
              >
                Batal
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveCorrection}
                  disabled={isSaving}
                  className="py-2.5 px-5 rounded-xl bg-red-700 hover:bg-red-800 text-white font-extrabold text-xs shadow-md flex items-center gap-2 transition disabled:opacity-50 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Menyimpan Koreksi...' : 'Simpan & Sinkronkan Koreksi'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
