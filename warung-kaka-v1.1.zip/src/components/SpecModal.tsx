import React, { useState, useEffect } from 'react';
import { X, Plus, Tag, ShoppingCart, Check, Calculator, AlertCircle } from 'lucide-react';
import { Product, InvoiceItem } from '../types';
import { fRp, fDec } from '../utils/formatters';

interface SpecModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (item: InvoiceItem) => void;
}

export const SpecModal: React.FC<SpecModalProps> = ({
  product,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [qty, setQty] = useState<number>(1);
  const [satuan, setSatuan] = useState<string>('pcs');
  const [hargaSatuan, setHargaSatuan] = useState<number>(0);
  const [diskonItem, setDiskonItem] = useState<number>(0);
  const [catatan, setCatatan] = useState<string>('');

  useEffect(() => {
    if (product) {
      setQty(1);
      setSatuan(product.satuan || 'pcs');
      setHargaSatuan(product.harga || 0);
      setDiskonItem(0);
      setCatatan('');
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const effectivePrice = Math.max(0, hargaSatuan - diskonItem);
  const finalTotal = qty * effectivePrice;

  const isKiloan = (satuan || '').toLowerCase().includes('kg') || (satuan || '').toLowerCase().includes('gram') || (satuan || '').toLowerCase().includes('liter');

  const handleAdjustQty = (delta: number) => {
    setQty((prev) => {
      const next = parseFloat((prev + delta).toFixed(2));
      return next > 0 ? next : 0.25;
    });
  };

  const handleSetExactQty = (val: number) => {
    setQty(val);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (qty <= 0) {
      alert('Jumlah / Qty harus lebih dari 0.');
      return;
    }

    onConfirm({
      kode: product.kode,
      nama: product.nama,
      harga: hargaSatuan,
      satuan: satuan || product.satuan || 'pcs',
      tipeHarga: 'fix',
      qty: qty || 1,
      panjang: 0,
      lebar: 0,
      bahan: '',
      catatan: catatan.trim(),
      diskonItem,
      totalItem: finalTotal,
    });
    setQty(1);
  };

  const stokNum = parseFloat(String(product.stok || '0').replace(',', '.'));
  const hasStok = !isNaN(stokNum) && stokNum > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-lg max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-100 text-red-800 flex items-center justify-center font-black shrink-0">
              <ShoppingCart className="w-5 h-5 text-red-700" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-sm sm:text-base leading-tight">
                {product.nama}
              </h3>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                {product.kode && (
                  <span className="font-mono text-[10px] bg-stone-100 text-stone-600 px-1.5 py-0.2 rounded font-semibold">
                    {product.kode}
                  </span>
                )}
                {product.kategori && (
                  <span className="text-[10px] font-bold text-red-800 bg-red-50 px-1.5 py-0.2 rounded border border-red-200">
                    {product.kategori}
                  </span>
                )}
                <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                  hasStok ? 'bg-emerald-50 text-emerald-800' : 'bg-stone-100 text-stone-600'
                }`}>
                  Stok: {product.stok || '0'} {product.satuan || 'pcs'}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Quantity & Unit Stepper */}
          <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200 space-y-2.5">
            <label className="text-xs font-bold text-stone-700 flex items-center justify-between">
              <span>Jumlah Pembelian (Qty)</span>
              <span className="text-[11px] font-bold text-red-800">
                Satuan: {satuan}
              </span>
            </label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleAdjustQty(isKiloan ? -0.5 : -1)}
                className="w-10 h-10 rounded-xl border border-stone-300 bg-white text-stone-800 hover:bg-red-50 hover:border-red-400 font-black text-lg flex items-center justify-center transition active:scale-95 shadow-2xs cursor-pointer"
              >
                -
              </button>

              <input
                type="number"
                step="any"
                min="0.0001"
                value={qty === 0 ? '' : qty}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === '') {
                    setQty(0);
                  } else {
                    setQty(parseFloat(val) || 0);
                  }
                }}
                className="flex-1 text-center py-2 px-2 bg-white border border-stone-300 rounded-xl text-base font-black text-stone-900 focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100 shadow-2xs"
              />

              <button
                type="button"
                onClick={() => handleAdjustQty(isKiloan ? 0.5 : 1)}
                className="w-10 h-10 rounded-xl border border-stone-300 bg-white text-stone-800 hover:bg-red-50 hover:border-red-400 font-black text-lg flex items-center justify-center transition active:scale-95 shadow-2xs cursor-pointer"
              >
                +
              </button>

              {/* Satuan Selector */}
              <select
                value={satuan}
                onChange={(e) => setSatuan(e.target.value)}
                className="w-28 py-2 px-2.5 bg-white border border-stone-300 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:border-red-600 shadow-2xs cursor-pointer"
              >
                <option value="pcs">pcs</option>
                <option value="kg">kg</option>
                <option value="gram">gram</option>
                <option value="bungkus">bungkus</option>
                <option value="dus">dus</option>
                <option value="sachet">sachet</option>
                <option value="renceng">renceng</option>
                <option value="liter">liter</option>
                <option value="botol">botol</option>
                <option value="kaleng">kaleng</option>
                <option value="galon">galon</option>
                <option value="tabung">tabung</option>
                <option value="pak">pak</option>
                <option value="karung">karung</option>
                <option value="bal">bal</option>
                <option value="ikat">ikat</option>
              </select>
            </div>

            {/* Quick Helper Buttons */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              <span className="text-[10px] font-bold text-stone-400 self-center mr-1">Cepat:</span>
              <button
                type="button"
                onClick={() => handleSetExactQty(1)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg border border-stone-200 bg-white hover:bg-red-50 hover:border-red-300 text-stone-700 transition cursor-pointer"
              >
                1
              </button>
              <button
                type="button"
                onClick={() => handleSetExactQty(2)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg border border-stone-200 bg-white hover:bg-red-50 hover:border-red-300 text-stone-700 transition cursor-pointer"
              >
                2
              </button>
              <button
                type="button"
                onClick={() => handleSetExactQty(5)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg border border-stone-200 bg-white hover:bg-red-50 hover:border-red-300 text-stone-700 transition cursor-pointer"
              >
                5
              </button>
              <button
                type="button"
                onClick={() => handleSetExactQty(10)}
                className="px-2.5 py-1 text-xs font-bold rounded-lg border border-stone-200 bg-white hover:bg-red-50 hover:border-red-300 text-stone-700 transition cursor-pointer"
              >
                10
              </button>
              {isKiloan && (
                <>
                  <button
                    type="button"
                    onClick={() => handleSetExactQty(0.25)}
                    className="px-2 py-1 text-[11px] font-bold rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-900 transition cursor-pointer"
                  >
                    ¼ kg (0.25)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetExactQty(0.5)}
                    className="px-2 py-1 text-[11px] font-bold rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-900 transition cursor-pointer"
                  >
                    ½ kg (0.5)
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Pricing & Discount */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-stone-700 mb-1 block">
                Harga Satuan (Rp)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-stone-400">
                  Rp
                </span>
                <input
                  type="number"
                  min="0"
                  value={hargaSatuan}
                  onChange={(e) => setHargaSatuan(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full pl-8 py-2 pr-3 border border-stone-200 rounded-xl text-xs font-black text-stone-900 focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                <span>Diskon / Potongan Item (Rp)</span>
                {diskonItem > 0 && (
                  <button
                    type="button"
                    onClick={() => setDiskonItem(0)}
                    className="text-[10px] text-red-600 hover:underline font-bold cursor-pointer"
                  >
                    Reset
                  </button>
                )}
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-stone-400">
                  Rp
                </span>
                <input
                  type="number"
                  min="0"
                  value={diskonItem}
                  onChange={(e) => setDiskonItem(Math.max(0, parseFloat(e.target.value) || 0))}
                  placeholder="0"
                  className="w-full pl-8 py-2 pr-3 border border-stone-200 rounded-xl text-xs font-black text-red-700 focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100"
                />
              </div>
            </div>
          </div>

          {/* Catatan / Keterangan Sembako */}
          <div>
            <label className="text-xs font-bold text-stone-700 mb-1 block">
              Catatan Khusus / Permintaan Pembeli (Opsional)
            </label>
            <input
              type="text"
              list="sembakoNotesList"
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              placeholder="cth: Minta kantong kresek besar, Telur packing rapi, Titip sore..."
              className="w-full py-2 px-3 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100"
            />
            <datalist id="sembakoNotesList">
              <option value="Minta kantong kresek besar" />
              <option value="Pisahkan bungkus sendiri" />
              <option value="Telur packing rapi jangan ditumpuk" />
              <option value="Titip antar ke alamat" />
              <option value="Varian Rasa Pedas / Manis" />
              <option value="Tukar Galon / Tabung Kosong" />
            </datalist>
          </div>

          {/* Live Subtotal Calculation Box */}
          <div className="p-3.5 rounded-2xl bg-red-50/80 border border-red-200 text-center space-y-1">
            <div className="text-[11px] font-extrabold text-red-900 uppercase tracking-wider">
              Total Pembelian Item Ini
            </div>
            <div className="text-xs text-stone-600 font-semibold">
              {fDec(qty, 2).replace(/\.?0+$/, '')} {satuan} × {fRp(effectivePrice)}
              {diskonItem > 0 && (
                <span className="text-red-700 font-bold ml-1">
                  (Hemat {fRp(diskonItem * qty)})
                </span>
              )}
            </div>
            <div className="text-2xl font-black text-red-700 pt-0.5">
              {fRp(finalTotal)}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-xs font-bold hover:bg-stone-50 transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-red-700 hover:bg-red-800 text-white text-xs font-black shadow-xs transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Masukkan ke Keranjang</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

