import React, { useState, useMemo, useEffect } from 'react';
import { Invoice, StoreSettings, PelunasanRecord, Customer } from '../types';
import { fRp, fDate, fTime } from '../utils/formatters';
import { 
  openPrintWindow, 
  generateRekapPiutangPDF, 
  generateSlipPotongGajiKaryawanPDF, 
  generateSlipBuktiPelunasanKaryawanPDF,
  generateA5HTML 
} from '../utils/printUtils';
import { getCustomerSlipSummary, getNextSlipNumberForCustomer } from '../utils/slipUtils';
import { 
  exportEmployeePiutangToExcel, 
  parseEmployeeNameAndDivision, 
  cleanPhoneNumber, 
  buildEmployeeExportRows,
  matchesDivisionFilter,
  getCustomerDivision as resolveCustomerDivision,
  EmployeeExportRow 
} from '../utils/excelUtils';
import { getLocalCustomers, getPelunasanHistory, mergePelunasanHistories } from '../services/gasService';
import { 
  BadgeDollarSign, 
  Search, 
  Printer, 
  Calendar, 
  User, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  RefreshCw,
  Eye,
  ChevronRight,
  Filter,
  DollarSign,
  Building,
  Building2,
  Users,
  CheckCheck,
  X,
  CreditCard,
  Trash2,
  Package,
  Layers,
  ChevronDown,
  ChevronUp,
  FileSpreadsheet,
  Download,
  Check,
  Copy,
  Maximize2,
  Minimize2
} from 'lucide-react';

interface PiutangViewProps {
  invoices: Invoice[];
  customers?: Customer[];
  settings: StoreSettings;
  cashierName?: string;
  onRefresh?: () => void;
  onRecordPelunasan?: (payload: PelunasanRecord) => Promise<void>;
  onBatchRecordPelunasan?: (payloads: PelunasanRecord[]) => Promise<void>;
  onReprintInvoice?: (invoice: Invoice) => void;
  onDeleteInvoice?: (invoiceNo: string, items?: any[]) => Promise<void> | void;
  onBatchUpdateInvoices?: (invoices: Invoice[]) => Promise<void>;
  onShowToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const PiutangView: React.FC<PiutangViewProps> = ({
  invoices,
  customers = [],
  settings,
  cashierName = 'Admin',
  onRefresh,
  onRecordPelunasan,
  onBatchRecordPelunasan,
  onReprintInvoice,
  onDeleteInvoice,
  onBatchUpdateInvoices,
  onShowToast,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'rekap_karyawan' | 'daftar_nota' | 'riwayat_pelunasan'>('rekap_karyawan');
  const [riwayatViewMode, setRiwayatViewMode] = useState<'rekap_karyawan' | 'semua_transaksi'>('rekap_karyawan');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterMethod, setFilterMethod] = useState<'all' | 'potong_gaji' | 'tunai'>('all');
  const [filterStatus, setFilterStatus] = useState<'unpaid' | 'all' | 'lunas'>('unpaid');
  const [filterDivision, setFilterDivision] = useState<string>('ALL');
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [isTableMaximized, setIsTableMaximized] = useState<boolean>(false);
  const [mobileNotaViewMode, setMobileNotaViewMode] = useState<'card' | 'table'>('card');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState<boolean>(false);
  const [copiedInvoiceNo, setCopiedInvoiceNo] = useState<string | null>(null);

  const handleCopyNoNota = (noNota: string) => {
    navigator.clipboard?.writeText(noNota);
    setCopiedInvoiceNo(noNota);
    if (onShowToast) onShowToast(`No. Nota ${noNota} disalin!`, 'info');
    setTimeout(() => setCopiedInvoiceNo(null), 2000);
  };

  // Modal Pelunasan state
  const [pelunasanTarget, setPelunasanTarget] = useState<Invoice | null>(null);
  const [bulkSettleCustomer, setBulkSettleCustomer] = useState<{ customer: string; invoices: Invoice[]; total: number } | null>(null);
  const [bayarNominal, setBayarNominal] = useState<string>('');
  const [bayarMetode, setBayarMetode] = useState<string>('Potong Gaji (Gajian)');
  const [bayarCatatan, setBayarCatatan] = useState<string>('');
  const [isProcessingPelunasan, setIsProcessingPelunasan] = useState<boolean>(false);
  const [pelunasanSuccessMsg, setPelunasanSuccessMsg] = useState<string>('');

  // Selected Invoice Detail Preview Modal
  const [viewInvoiceDetail, setViewInvoiceDetail] = useState<Invoice | null>(null);

  // Export Excel Modal & State
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [exportStartDate, setExportStartDate] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  });
  const [exportEndDate, setExportEndDate] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  });
  const [exportDivisionFilters, setExportDivisionFilters] = useState<string[]>(['ALL']);
  const [excludedExportCustomerKeys, setExcludedExportCustomerKeys] = useState<Record<string, boolean>>({});
  const [exportOnlyLocked, setExportOnlyLocked] = useState<boolean>(false);

  const isAllExportDivisions = exportDivisionFilters.includes('ALL') || exportDivisionFilters.length === 0;

  const toggleExportDivision = (div: string) => {
    setExportDivisionFilters((prev) => {
      if (div === 'ALL') {
        return ['ALL'];
      }
      const withoutAll = prev.filter((d) => d !== 'ALL');
      if (withoutAll.includes(div)) {
        const next = withoutAll.filter((d) => d !== div);
        return next.length === 0 ? ['ALL'] : next;
      } else {
        const next = [...withoutAll, div];
        if (availableExportDivisions.length > 0 && next.length === availableExportDivisions.length) {
          return ['ALL'];
        }
        return next;
      }
    });
  };

  const removeExportDivision = (div: string) => {
    setExportDivisionFilters((prev) => {
      const next = prev.filter((d) => d !== div && d !== 'ALL');
      return next.length === 0 ? ['ALL'] : next;
    });
  };

  const resetExportDivisions = () => {
    setExportDivisionFilters(['ALL']);
  };

  // Expanded Slips in Card (allows clicking history slips to see their breakdown/invoices)
  const [expandedSlips, setExpandedSlips] = useState<Record<string, boolean>>({});

  const toggleSlipExpanded = (customer: string, slipNo: number) => {
    const key = `${customer}_slip_${slipNo}`;
    setExpandedSlips((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Delete Invoice State
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);
  const [customerToDeleteLunas, setCustomerToDeleteLunas] = useState<{ customer: string; invoices: Invoice[] } | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const handleConfirmDelete = async () => {
    if (!invoiceToDelete) return;
    const invNo = (invoiceToDelete.invoiceNo || invoiceToDelete.noInvoice || '').trim();
    if (!invNo) return;
    setIsDeleting(true);
    try {
      if (onDeleteInvoice) {
        let items = invoiceToDelete.items;
        if (!items || items.length === 0) {
          const rawMatch = invoices.find(
            (i) => (i.invoiceNo || (i as any).noInvoice || '').trim().toLowerCase() === invNo.toLowerCase()
          );
          if (rawMatch && Array.isArray(rawMatch.items) && rawMatch.items.length > 0) {
            items = rawMatch.items;
          }
        }
        await onDeleteInvoice(invNo, items);
      }
      if (viewInvoiceDetail && (viewInvoiceDetail.invoiceNo || viewInvoiceDetail.noInvoice) === invNo) {
        setViewInvoiceDetail(null);
      }
      setInvoiceToDelete(null);
    } catch (err) {
      console.error('Delete invoice error:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConfirmDeleteCustomerLunas = async () => {
    if (!customerToDeleteLunas || customerToDeleteLunas.invoices.length === 0) return;
    setIsDeleting(true);
    try {
      if (onDeleteInvoice) {
        for (const inv of customerToDeleteLunas.invoices) {
          const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
          if (invNo) {
            let items = inv.items;
            if (!items || items.length === 0) {
              const rawMatch = invoices.find(
                (i) => (i.invoiceNo || (i as any).noInvoice || '').trim().toLowerCase() === invNo.toLowerCase()
              );
              if (rawMatch && Array.isArray(rawMatch.items) && rawMatch.items.length > 0) {
                items = rawMatch.items;
              }
            }
            await onDeleteInvoice(invNo, items);
          }
        }
      }
      setCustomerToDeleteLunas(null);
    } catch (err) {
      console.error('Delete customer lunas invoices error:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  // Filter invoices for Piutang view with strict deduplication
  const processedInvoices = useMemo(() => {
    // Deduplicate incoming invoices by clean invoice number
    const uniqueMap = new Map<string, Invoice>();
    invoices.forEach((inv) => {
      const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
      if (!invNo) {
        uniqueMap.set(Math.random().toString(), inv);
      } else if (!uniqueMap.has(invNo)) {
        uniqueMap.set(invNo, inv);
      } else {
        // Keep the more complete record (e.g. having more items or pelunasan history)
        const existing = uniqueMap.get(invNo)!;
        const existHistLen = (existing.pelunasanHistory?.length || 0) + (existing.historiPelunasan?.length || 0);
        const newHistLen = (inv.pelunasanHistory?.length || 0) + (inv.historiPelunasan?.length || 0);
        if (newHistLen >= existHistLen) {
          uniqueMap.set(invNo, { ...existing, ...inv });
        }
      }
    });

    return Array.from(uniqueMap.values()).map((inv) => {
      const total = Number(inv.total || 0);
      const dp = Number(inv.dp || 0);
      const payMethod = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
      const isPotongGaji = payMethod.toLowerCase().includes('potong') || payMethod.toLowerCase().includes('gaji');
      
      const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
      const localHist = invNo ? getPelunasanHistory(invNo) : [];
      const backendHist = Array.isArray(inv.pelunasanHistory) && inv.pelunasanHistory.length > 0
        ? inv.pelunasanHistory
        : Array.isArray(inv.historiPelunasan) && inv.historiPelunasan.length > 0
        ? inv.historiPelunasan
        : [];
      const historyList = mergePelunasanHistories(backendHist, localHist);
      const totalPaid = historyList.reduce((sum, h) => sum + Number(h.jumlahBayar || 0), 0);
      
      let sisa = inv.sisa !== undefined ? Number(inv.sisa) : Math.max(0, total - dp - totalPaid);
      if (historyList.length > 0) {
        sisa = Math.max(0, total - dp - totalPaid);
      }
      if (String(inv.status).toUpperCase() === 'LUNAS') {
        sisa = 0;
      }
      
      const isLunas = sisa <= 0;
      return {
        ...inv,
        payMethod,
        isPotongGaji,
        calculatedSisa: sisa,
        isLunas,
        pelunasanHistory: historyList,
        historiPelunasan: historyList,
      };
    });
  }, [invoices]);

  // Grouped by Customer (Karyawan) for Payroll Rekap
  const groupedByCustomer = useMemo(() => {
    const allCusts = customers && customers.length > 0 ? customers : getLocalCustomers();

    const resolveCanonicalName = (rawName: string): string => {
      if (!rawName || !rawName.trim()) return 'Umum';
      const clean = rawName.trim();
      const cleanLower = clean.toLowerCase();
      if (cleanLower === 'umum') return 'Umum';

      // 1. Exact match in customer directory
      const exact = allCusts.find((c) => c.nama.trim().toLowerCase() === cleanLower);
      if (exact) return exact.nama.trim();

      // 2. Match against historical oldNames / aliases
      const aliasMatch = allCusts.find((c) => {
        if (Array.isArray(c.oldNames)) {
          return c.oldNames.some((o) => o.trim().toLowerCase() === cleanLower);
        }
        return false;
      });
      if (aliasMatch) return aliasMatch.nama.trim();

      // 3. Base name match (stripping parentheses and dashes: e.g. "Budi (Gudang)" vs "Budi")
      const cleanBase = clean.replace(/\(.*?\)/g, '').replace(/[-–\/].*$/, '').trim().toLowerCase();
      if (cleanBase.length > 2) {
        const baseMatch = allCusts.find((c) => {
          const cBase = c.nama.toLowerCase().replace(/\(.*?\)/g, '').replace(/[-–\/].*$/, '').trim();
          return cBase.length > 2 && (cBase === cleanBase || cleanBase.includes(cBase) || cBase.includes(cleanBase));
        });
        if (baseMatch) return baseMatch.nama.trim();
      }

      return clean;
    };

    const map = new Map<string, {
      customer: string;
      invoices: Invoice[];
      totalUnpaid: number;
      totalInvoiceCount: number;
      phone?: string;
      potongGajiUnpaid: number;
      tunaiUnpaid: number;
    }>();

    processedInvoices.forEach((inv) => {
      const rawName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
      const custName = resolveCanonicalName(rawName);
      const sisa = inv.calculatedSisa;

      if (!map.has(custName)) {
        map.set(custName, {
          customer: custName,
          invoices: [],
          totalUnpaid: 0,
          totalInvoiceCount: 0,
          phone: inv.customerPhone,
          potongGajiUnpaid: 0,
          tunaiUnpaid: 0,
        });
      }

      const entry = map.get(custName)!;
      const invNoClean = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
      const alreadyHasInv = entry.invoices.some(
        (ex) => (ex.invoiceNo || (ex as any).noInvoice || '').trim().toLowerCase() === invNoClean
      );
      if (!alreadyHasInv) {
        entry.invoices.push(inv);
        if (sisa > 0) {
          entry.totalUnpaid += sisa;
          entry.totalInvoiceCount += 1;
          if (inv.isPotongGaji) {
            entry.potongGajiUnpaid += sisa;
          } else {
            entry.tunaiUnpaid += sisa;
          }
        }
      }
    });

    return Array.from(map.values())
      .filter((g) => g.customer.toLowerCase() !== 'umum' || g.totalUnpaid > 0)
      .sort((a, b) => b.totalUnpaid - a.totalUnpaid);
  }, [processedInvoices]);

  // Available divisions for export filter - accurately gathered from customer directory, debtors, raw invoices, and preview rows
  const availableExportDivisions = useMemo(() => {
    const divs = new Set<string>();

    // 1. Check all customers prop + local database fallback
    const allCusts = customers && customers.length > 0 ? customers : getLocalCustomers();
    allCusts.forEach((c) => {
      const parsed = parseEmployeeNameAndDivision(c.nama, c);
      const d = (c.divisi || c.division || parsed.division || '').trim().toUpperCase();
      if (d) divs.add(d);
    });

    // 2. Check all active debtors in groupedByCustomer
    groupedByCustomer.forEach((g) => {
      const custObj = allCusts.find(
        (c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === g.customer.toUpperCase().replace(/\(.*?\)/g, '').trim()
      );
      const parsed = parseEmployeeNameAndDivision(g.customer, custObj);
      const d = (custObj?.divisi || custObj?.division || parsed.division || '').trim().toUpperCase();
      if (d) divs.add(d);
    });

    // 3. Check all invoices directly
    invoices.forEach((inv) => {
      const custName = (inv.customer || (inv as any).pelanggan || '').trim();
      if (custName) {
        const custObj = allCusts.find(
          (c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === custName.toUpperCase().replace(/\(.*?\)/g, '').trim()
        );
        const parsed = parseEmployeeNameAndDivision(custName, custObj);
        const d = ((inv as any).divisi || (inv as any).division || custObj?.divisi || custObj?.division || parsed.division || '').trim().toUpperCase();
        if (d) divs.add(d);
      }
    });

    // 4. Scan preview export rows to guarantee every row's division is selectable
    const previewRows = buildEmployeeExportRows({
      groupedCustomers: groupedByCustomer,
      customers: allCusts,
      startDate: exportStartDate,
      endDate: exportEndDate,
      divisionFilter: 'ALL',
      exportScope: 'only_unpaid',
      onlyLockedTransactions: exportOnlyLocked,
    });
    previewRows.forEach((r) => {
      if (r.division && r.division.trim()) {
        divs.add(r.division.trim().toUpperCase());
      }
    });

    const result = Array.from(divs).filter(Boolean).sort();
    console.info('[ExportExcel/PiutangView:DivisiDebug]', {
      totalCustomers: allCusts.length,
      groupedDebtors: groupedByCustomer.length,
      detectedDivisions: result,
      previewRowsCount: previewRows.length,
    });
    return result;
  }, [customers, groupedByCustomer, invoices, exportStartDate, exportEndDate, exportOnlyLocked]);

  // Base generated export rows from filter criteria
  const rawExportRows = useMemo(() => {
    return buildEmployeeExportRows({
      groupedCustomers: groupedByCustomer,
      customers,
      startDate: exportStartDate,
      endDate: exportEndDate,
      divisionFilter: exportDivisionFilters,
      exportScope: 'only_unpaid',
      onlyLockedTransactions: exportOnlyLocked,
    });
  }, [groupedByCustomer, customers, exportStartDate, exportEndDate, exportDivisionFilters, exportOnlyLocked]);

  // Filtered rows by selected checkboxes (unexcluded keys)
  const selectedExportRows = useMemo(() => {
    return rawExportRows.filter((r) => !excludedExportCustomerKeys[r.rowId]);
  }, [rawExportRows, excludedExportCustomerKeys]);

  const isAllExportSelected = rawExportRows.length > 0 && rawExportRows.every((r) => !excludedExportCustomerKeys[r.rowId]);

  const toggleSelectAllExport = () => {
    if (isAllExportSelected) {
      const updated: Record<string, boolean> = {};
      rawExportRows.forEach((r) => {
        updated[r.rowId] = true;
      });
      setExcludedExportCustomerKeys(updated);
    } else {
      setExcludedExportCustomerKeys({});
    }
  };

  const handleDownloadExcel = () => {
    try {
      if (selectedExportRows.length === 0) {
        alert('Silakan pilih minimal 1 karyawan untuk diekspor.');
        return;
      }
      const filenameDate = exportStartDate === exportEndDate 
        ? exportStartDate 
        : `${exportStartDate}_sd_${exportEndDate}`;
      const finalNumberedRows = selectedExportRows.map((r, idx) => ({
        ...r,
        no: idx + 1,
      }));
      exportEmployeePiutangToExcel(finalNumberedRows, filenameDate);
      if (onShowToast) {
        onShowToast(`File Excel Rekap_WAKA_${filenameDate}.xlsx berhasil diunduh!`, 'success');
      }
      setIsExportModalOpen(false);
    } catch (e: any) {
      console.error('Export Excel failed:', e);
      alert('Gagal mengunduh Excel: ' + (e?.message || 'Error'));
    }
  };

  // Helper to extract customer division accurately
  const getCustomerDivision = (name?: string): string => {
    return resolveCustomerDivision(name, customers);
  };

  // Filtered Grouped Customers for Tab 1
  const filteredGroupedCustomers = useMemo(() => {
    const q = searchTerm.toLowerCase().trim();
    return groupedByCustomer.filter((g) => {
      const custDivision = getCustomerDivision(g.customer);
      const matchesSearch = 
        !q || 
        g.customer.toLowerCase().includes(q) || 
        (g.phone && g.phone.includes(q)) ||
        (custDivision && custDivision.toLowerCase().includes(q));

      const hasUnpaid = filterStatus === 'unpaid' ? g.totalUnpaid > 0 : filterStatus === 'lunas' ? g.totalUnpaid === 0 : true;
      const matchesMethod = 
        filterMethod === 'potong_gaji' ? g.potongGajiUnpaid > 0 :
        filterMethod === 'tunai' ? g.tunaiUnpaid > 0 : true;

      const matchesDivision = matchesDivisionFilter(custDivision, filterDivision);

      return matchesSearch && hasUnpaid && matchesMethod && matchesDivision;
    });
  }, [groupedByCustomer, searchTerm, filterStatus, filterMethod, filterDivision, customers]);

  // Filtered List for Tab 2 (Detailed Invoices)
  const filteredInvoices = useMemo(() => {
    const q = searchTerm.toLowerCase().trim();
    return processedInvoices.filter((inv) => {
      const custDivision = getCustomerDivision(inv.customer);
      const matchesSearch = 
        !q ||
        (inv.invoiceNo && inv.invoiceNo.toLowerCase().includes(q)) ||
        (inv.customer && inv.customer.toLowerCase().includes(q)) ||
        (inv.cashier && inv.cashier.toLowerCase().includes(q)) ||
        (custDivision && custDivision.toLowerCase().includes(q));

      const matchesStatus = 
        filterStatus === 'unpaid' ? inv.calculatedSisa > 0 :
        filterStatus === 'lunas' ? inv.isLunas : true;

      const matchesMethod = 
        filterMethod === 'potong_gaji' ? inv.isPotongGaji :
        filterMethod === 'tunai' ? !inv.isPotongGaji : true;

      const matchesDivision = matchesDivisionFilter(custDivision, filterDivision);

      return matchesSearch && matchesStatus && matchesMethod && matchesDivision;
    });
  }, [processedInvoices, searchTerm, filterStatus, filterMethod, filterDivision, customers]);

  // Summary Metrics based on division & current filter
  const metrics = useMemo(() => {
    let totalSisa = 0;
    let totalPotongGaji = 0;
    let totalTunai = 0;
    let totalPelangganUnpaid = 0;

    groupedByCustomer.forEach((g) => {
      const custDivision = getCustomerDivision(g.customer);
      if (!matchesDivisionFilter(custDivision, filterDivision)) return;

      if (g.totalUnpaid > 0) {
        totalSisa += g.totalUnpaid;
        totalPotongGaji += g.potongGajiUnpaid;
        totalTunai += g.tunaiUnpaid;
        totalPelangganUnpaid += 1;
      }
    });

    return {
      totalSisa,
      totalPotongGaji,
      totalTunai,
      totalPelangganUnpaid,
    };
  }, [groupedByCustomer, filterDivision, customers]);

  // All Pelunasan records for Tab 3 (Riwayat)
  const allPelunasanHistory = useMemo(() => {
    const records: Array<PelunasanRecord & { customerName?: string; totalInvoice?: number; division?: string }> = [];
    const seenIds = new Set<string>();
    const seenComposite = new Set<string>();

    processedInvoices.forEach((inv) => {
      const custDivision = getCustomerDivision(inv.customer);
      if (!matchesDivisionFilter(custDivision, filterDivision)) return;

      const histList = Array.isArray(inv.pelunasanHistory) && inv.pelunasanHistory.length > 0
        ? inv.pelunasanHistory
        : Array.isArray(inv.historiPelunasan) && inv.historiPelunasan.length > 0
        ? inv.historiPelunasan
        : [];
      const isLunas = inv.isLunas || inv.calculatedSisa <= 0;

      if (histList.length > 0) {
        histList.forEach((h) => {
          const invNo = (h.invoiceNo || '').trim().toLowerCase();
          const dt = (h.date || '').trim();
          const tm = (h.time || '').trim().substring(0, 5);
          const amt = Math.round(Number(h.jumlahBayar || 0));
          const id = (h.id || '').trim();
          const compositeKey = `${invNo}_${dt}_${tm}_${amt}`;

          if (id && seenIds.has(id)) return;
          if (invNo && dt && seenComposite.has(compositeKey)) return;

          if (id) seenIds.add(id);
          if (invNo && dt) seenComposite.add(compositeKey);

          records.push({
            ...h,
            customerName: inv.customer,
            totalInvoice: inv.total,
            division: custDivision,
          });
        });
      } else if (isLunas) {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
        const hasExistingRecord = Array.from(seenComposite).some((c) => c.startsWith(`${invNo}_`));
        if (!hasExistingRecord) {
          const dt = (inv.date || '').trim();
          const tm = (inv.time || '').trim().substring(0, 5);
          const amt = Math.round(Number(inv.total || 0));
          const compositeKey = `${invNo}_${dt}_${tm}_${amt}`;
          const id = `LUNAS-${inv.invoiceNo || (inv as any).noInvoice}`;

          if (!seenIds.has(id) && !seenComposite.has(compositeKey)) {
            if (id) seenIds.add(id);
            if (invNo && dt) seenComposite.add(compositeKey);
            records.push({
              id,
              invoiceNo: inv.invoiceNo || (inv as any).noInvoice,
              date: inv.date || '',
              time: inv.time || '',
              jumlahBayar: inv.total || 0,
              newSisa: 0,
              payMethod: inv.payMethod || (inv as any).metodePembayaran || 'Tunai',
              cashier: inv.cashier || 'Admin',
              catatan: (inv.payMethod || '').toLowerCase().includes('cash') || (inv.payMethod || '').toLowerCase().includes('tunai')
                ? 'Lunas Tunai/Cash'
                : ((inv.payMethod || '').toLowerCase().includes('gaji') ? 'Lunas Potong Gaji' : 'Lunas 100%'),
              customerName: inv.customer,
              totalInvoice: inv.total,
              division: custDivision,
            });
          }
        }
      }
    });

    // Check standalone local pelunasan cache
    try {
      const rawLocal = localStorage.getItem('strukku_pelunasan_history');
      if (rawLocal) {
        const localList: PelunasanRecord[] = JSON.parse(rawLocal);
        if (Array.isArray(localList)) {
          localList.forEach((h) => {
            const invNo = (h.invoiceNo || '').trim().toLowerCase();
            const dt = (h.date || '').trim();
            const tm = (h.time || '').trim().substring(0, 5);
            const amt = Math.round(Number(h.jumlahBayar || 0));
            const id = (h.id || '').trim();
            const compositeKey = `${invNo}_${dt}_${tm}_${amt}`;

            if (id && seenIds.has(id)) return;
            if (invNo && dt && seenComposite.has(compositeKey)) return;

            if (id) seenIds.add(id);
            if (invNo && dt) seenComposite.add(compositeKey);

            const matched = processedInvoices.find((i) => (i.invoiceNo || (i as any).noInvoice) === h.invoiceNo);
            const custDiv = (h as any).division || (matched ? getCustomerDivision(matched.customer) : '');
            if (matchesDivisionFilter(custDiv, filterDivision)) {
              records.push({
                ...h,
                customerName: (h as any).customerName || (h as any).customer || matched?.customer || 'Umum',
                totalInvoice: Number((h as any).totalInvoice || matched?.total || h.jumlahBayar || 0),
                division: custDiv,
              });
            }
          });
        }
      }
    } catch {}

    const q = searchTerm.toLowerCase().trim();
    const filteredRecords = q
      ? records.filter((r) => {
          return (
            (r.customerName || '').toLowerCase().includes(q) ||
            (r.invoiceNo || '').toLowerCase().includes(q) ||
            (r.cashier || '').toLowerCase().includes(q) ||
            (r.division || '').toLowerCase().includes(q) ||
            (r.payMethod || '').toLowerCase().includes(q)
          );
        })
      : records;

    // Sort descending by date & time
    return filteredRecords.sort((a, b) => {
      const timeA = `${a.date || ''} ${a.time || ''}`;
      const timeB = `${b.date || ''} ${b.time || ''}`;
      return timeB.localeCompare(timeA);
    });
  }, [processedInvoices, searchTerm, filterDivision, customers]);

  // Grouped Pelunasan by Customer for Tab 3 (Riwayat Pelunasan Rekap Per Karyawan)
  const groupedPelunasanByCustomer = useMemo(() => {
    const map = new Map<string, {
      customer: string;
      phone: string;
      division: string;
      totalSettled: number;
      settledInvoices: Invoice[];
      historyRecords: Array<PelunasanRecord & { customerName?: string; totalInvoice?: number }>;
      lastSettledDate: string;
      lastSettledTime: string;
    }>();

    processedInvoices.forEach((inv) => {
      const custName = (inv.customer || 'Umum').trim();
      const custDivision = getCustomerDivision(custName);
      if (!matchesDivisionFilter(custDivision, filterDivision)) return;

      const histList = Array.isArray(inv.pelunasanHistory) && inv.pelunasanHistory.length > 0
        ? inv.pelunasanHistory
        : Array.isArray(inv.historiPelunasan) && inv.historiPelunasan.length > 0
        ? inv.historiPelunasan
        : [];
      const isLunas = inv.isLunas || inv.calculatedSisa <= 0;

      if (histList.length > 0 || isLunas) {
        if (!map.has(custName)) {
          map.set(custName, {
            customer: custName,
            phone: inv.customerPhone || '',
            division: custDivision,
            totalSettled: 0,
            settledInvoices: [],
            historyRecords: [],
            lastSettledDate: '',
            lastSettledTime: '',
          });
        }
        const entry = map.get(custName)!;
        if (inv.customerPhone && !entry.phone) {
          entry.phone = inv.customerPhone;
        }
        if (custDivision && !entry.division) {
          entry.division = custDivision;
        }
        const invCleanNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
        if (!entry.settledInvoices.some((si) => (si.invoiceNo || (si as any).noInvoice || '').trim().toLowerCase() === invCleanNo)) {
          entry.settledInvoices.push(inv);
        }

        const mappedHist = histList.map((h) => ({
          ...h,
          customerName: custName,
          totalInvoice: inv.total,
        }));
        entry.historyRecords = mergePelunasanHistories(entry.historyRecords, mappedHist as any);

        const totalHistPaid = entry.historyRecords.reduce((acc, h) => acc + Number(h.jumlahBayar || 0), 0);
        entry.totalSettled = totalHistPaid > 0 
          ? totalHistPaid 
          : entry.settledInvoices.reduce((acc, si) => acc + Number(si.total || 0), 0);

        // Update latest settlement date/time
        entry.historyRecords.forEach((h) => {
          if (!entry.lastSettledDate || (h.date && h.date > entry.lastSettledDate)) {
            entry.lastSettledDate = h.date || '';
            entry.lastSettledTime = h.time || '';
          }
        });
        if (!entry.lastSettledDate && isLunas) {
          entry.lastSettledDate = inv.date || '';
          entry.lastSettledTime = inv.time || '';
        }
      }
    });

    const list = Array.from(map.values());
    const q = searchTerm.toLowerCase().trim();
    return list.filter((g) => {
      if (!q) return true;
      return (
        g.customer.toLowerCase().includes(q) || 
        (g.phone && g.phone.includes(q)) ||
        (g.division && g.division.toLowerCase().includes(q))
      );
    }).sort((a, b) => (b.lastSettledDate || '').localeCompare(a.lastSettledDate || ''));
  }, [processedInvoices, searchTerm, filterDivision, customers]);

  // Overall settled items count across all customers (unaffected by division/search filters for tab badge)
  const totalSettledCount = useMemo(() => {
    let count = 0;
    const countedInvoices = new Set<string>();
    processedInvoices.forEach((inv) => {
      const invId = inv.invoiceNo || (inv as any).noInvoice || '';
      const hist = Array.isArray(inv.pelunasanHistory) && inv.pelunasanHistory.length > 0
        ? inv.pelunasanHistory
        : Array.isArray(inv.historiPelunasan) && inv.historiPelunasan.length > 0
        ? inv.historiPelunasan
        : [];
      if (hist.length > 0) {
        count += hist.length;
        if (invId) countedInvoices.add(invId);
      } else if (inv.isLunas || inv.calculatedSisa <= 0) {
        count += 1;
        if (invId) countedInvoices.add(invId);
      }
    });

    try {
      const rawLocal = localStorage.getItem('strukku_pelunasan_history');
      if (rawLocal) {
        const localList: PelunasanRecord[] = JSON.parse(rawLocal);
        if (Array.isArray(localList)) {
          localList.forEach((h) => {
            if (h.invoiceNo && !countedInvoices.has(h.invoiceNo)) {
              count += 1;
              countedInvoices.add(h.invoiceNo);
            }
          });
        }
      }
    } catch {}

    return Math.max(count, allPelunasanHistory.length, groupedPelunasanByCustomer?.length || 0);
  }, [processedInvoices, allPelunasanHistory.length, groupedPelunasanByCustomer.length]);

  // Accurate Riwayat Pelunasan Badge Count that never falsely displays 0
  const riwayatBadgeCount = useMemo(() => {
    const directCount = Math.max(allPelunasanHistory.length, groupedPelunasanByCustomer.length);
    if (filterDivision !== 'ALL' || searchTerm) {
      return directCount;
    }
    return Math.max(directCount, totalSettledCount);
  }, [allPelunasanHistory.length, groupedPelunasanByCustomer.length, totalSettledCount, filterDivision, searchTerm]);

  // Handler: Cetak Rekap Kolektif PDF (Payroll HRD)
  const handlePrintRekapPDF = () => {
    const activeUnpaidGroups = groupedByCustomer
      .filter((g) => {
        const custDivision = getCustomerDivision(g.customer);
        const matchesDivision = matchesDivisionFilter(custDivision, filterDivision);
        const matchesMethod = g.potongGajiUnpaid > 0 || (filterMethod === 'all' && g.totalUnpaid > 0);
        return matchesDivision && matchesMethod;
      })
      .map((g) => ({
        customer: g.customer,
        totalUnpaid: filterMethod === 'potong_gaji' ? g.potongGajiUnpaid : g.totalUnpaid,
        invoiceCount: g.invoices.filter((i) => i.calculatedSisa > 0).length,
        invoices: g.invoices.filter((i) => i.calculatedSisa > 0),
        phone: g.phone,
      }));

    if (activeUnpaidGroups.length === 0) {
      alert('Tidak ada data piutang aktif yang perlu direkap.');
      return;
    }

    const html = generateRekapPiutangPDF(activeUnpaidGroups, settings, {
      printedBy: cashierName,
      title: filterMethod === 'potong_gaji' 
        ? 'REKAPITULASI PENAGIHAN POTONG GAJI KARYAWAN' 
        : 'REKAPITULASI PIUTANG & TAGIHAN BELANJA',
    });
    openPrintWindow(html, 'Rekapitulasi Tagihan Potong Gaji');
  };

  // Handler: Cetak Slip Individual Karyawan (Tagihan Belum Lunas) dengan nomor slip otomatis
  const handlePrintSlipKaryawan = async (customerName: string, custInvoices: Invoice[], targetSlipNo?: number) => {
    const slipSummary = getCustomerSlipSummary(customerName, custInvoices);
    
    // Tentukan slip group yang akan dicetak
    let targetGroup = targetSlipNo 
      ? slipSummary.allSlips.find((g) => g.slipNo === targetSlipNo)
      : slipSummary.activeSlip || slipSummary.allSlips[slipSummary.allSlips.length - 1];

    if (!targetGroup || targetGroup.invoices.length === 0) {
      const unpaidInvoices = custInvoices.filter((i) => (i.sisa !== undefined ? i.sisa : i.total) > 0 || (i as any).calculatedSisa > 0);
      if (unpaidInvoices.length === 0) {
        // Jika semua sudah lunas, cetak Slip Bukti Pelunasan Karyawan (LUNAS)
        handlePrintBuktiLunas(customerName, custInvoices, {
          date: fDate(new Date()),
          time: fTime(new Date()),
          cashier: cashierName,
          payMethod: 'Potong Gaji (Gajian)',
          catatan: 'Seluruh tagihan belanja sembako telah lunas 100%',
        });
        return;
      }
      targetGroup = {
        slipNo: 1,
        invoices: unpaidInvoices,
        total: unpaidInvoices.reduce((sum, i) => sum + (i.total || 0), 0),
        totalUnpaid: unpaidInvoices.reduce((sum, i) => sum + ((i as any).calculatedSisa || i.sisa || i.total || 0), 0),
        totalSettled: 0,
        isLunas: false,
        itemCount: unpaidInvoices.reduce((sum, i) => sum + (i.items?.length || 0), 0),
        isPrinted: false,
      };
    }

    const slipMeta = {
      slipNo: targetGroup.slipNo,
      printedAt: targetGroup.printedAt || `${fDate(new Date())} ${fTime(new Date())}`,
      cashier: cashierName,
    };

    const html = generateSlipPotongGajiKaryawanPDF(customerName, targetGroup.invoices, settings, slipMeta);
    openPrintWindow(html, `Slip Potong Gaji #${targetGroup.slipNo} - ${customerName}`);

    // Perbarui invoice menjadi slipPrinted: true sehingga slip ini ditandai tertagih
    // Dan transaksi baru berikutnya otomatis masuk ke nomor slip berikutnya (#targetGroup.slipNo + 1)
    if (onBatchUpdateInvoices) {
      const nowStr = `${fDate(new Date())} ${fTime(new Date())}`;
      const updatedInvoices: Invoice[] = targetGroup.invoices.map((inv) => ({
        ...inv,
        slipNo: targetGroup!.slipNo,
        slipPrinted: true,
        slipPrintedAt: inv.slipPrintedAt || nowStr,
      }));

      try {
        await onBatchUpdateInvoices(updatedInvoices);
        if (onShowToast) {
          onShowToast(`Slip #${targetGroup.slipNo} untuk ${customerName} dicetak! Transaksi berikutnya otomatis masuk ke Slip #${targetGroup.slipNo + 1}.`, 'success');
        }
      } catch (e) {
        console.error('Failed to update slip status:', e);
      }
    }
  };

  // Handler: Kunci / Tutup Slip Saat Ini dan Buka Slip Baru Tanpa Cetak
  const handleCloseAndCreateNewSlip = async (customerName: string, custInvoices: Invoice[]) => {
    const slipSummary = getCustomerSlipSummary(customerName, custInvoices);
    const targetGroup = slipSummary.activeSlip || slipSummary.allSlips[0];
    
    if (!targetGroup || targetGroup.invoices.length === 0) {
      if (onShowToast) onShowToast(`Tidak ada transaksi aktif yang perlu ditutup untuk ${customerName}`, 'info');
      return;
    }

    const currentSlipNo = targetGroup.slipNo;
    const nowStr = `${fDate(new Date())} ${fTime(new Date())}`;
    const updatedInvoices: Invoice[] = targetGroup.invoices.map((inv) => ({
      ...inv,
      slipNo: currentSlipNo,
      slipPrinted: true,
      slipPrintedAt: inv.slipPrintedAt || nowStr,
    }));

    if (onBatchUpdateInvoices) {
      try {
        await onBatchUpdateInvoices(updatedInvoices);
        if (onShowToast) {
          onShowToast(`Slip #${currentSlipNo} untuk ${customerName} berhasil ditutup! Transaksi baru otomatis masuk ke Slip #${currentSlipNo + 1}.`, 'success');
        }
      } catch (e) {
        console.error('Failed to close slip:', e);
      }
    }
  };

  // Handler: Cetak Slip Bukti Pelunasan Karyawan (LUNAS)
  const handlePrintBuktiLunas = (
    customerName: string,
    invoicesToPrint?: Invoice[],
    pelunasanMeta?: {
      date?: string;
      time?: string;
      cashier?: string;
      payMethod?: string;
      catatan?: string;
      jumlahBayar?: number;
      totalTagihan?: number;
    }
  ) => {
    let list = invoicesToPrint && invoicesToPrint.length > 0 ? invoicesToPrint : [];
    if (list.length === 0) {
      list = processedInvoices.filter(
        (i) => (i.customer || '').trim().toLowerCase() === customerName.trim().toLowerCase()
      );
    }
    if (list.length === 0) {
      alert(`Tidak ada data transaksi yang ditemukan untuk ${customerName}.`);
      return;
    }

    const html = generateSlipBuktiPelunasanKaryawanPDF(
      customerName,
      list,
      settings,
      pelunasanMeta
    );
    openPrintWindow(html, `Bukti Pelunasan Potong Gaji - ${customerName}`);
  };

  // Handler: Cetak Bukti Lunas dari Baris Riwayat Pelunasan
  const handlePrintBuktiLunasForHistory = (h: PelunasanRecord & { customerName?: string; totalInvoice?: number }) => {
    const custName = (h.customerName || h.customer || 'Umum').trim();
    // Cari invoice yang cocok dengan h.invoiceNo
    const matched = processedInvoices.find(
      (i) => (i.invoiceNo || (i as any).noInvoice) === h.invoiceNo
    );
    const invoiceList = matched ? [matched] : [];

    handlePrintBuktiLunas(custName, invoiceList, {
      date: h.date,
      time: h.time,
      cashier: h.cashier || cashierName,
      payMethod: h.payMethod || 'Potong Gaji',
      catatan: h.catatan,
      jumlahBayar: Number(h.jumlahBayar || 0),
      totalTagihan: Number(h.totalInvoice || matched?.total || h.jumlahBayar || 0),
    });
  };

  // Handler: Open Modal Pelunasan Satuan
  const handleOpenPelunasanSingle = (inv: Invoice) => {
    setPelunasanTarget(inv);
    const sisa = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa || inv.total);
    setBayarNominal(String(sisa));
    setBayarMetode(inv.payMethod?.includes('Gaji') ? 'Potong Gaji (Gajian)' : 'Tunai');
    setBayarCatatan('Pelunasan saat gajian');
    setPelunasanSuccessMsg('');
  };

  // Handler: Open Modal Pelunasan Bulk Karyawan (Semua Nota atau Per Slip Tertentu)
  const handleOpenBulkSettle = (
    customerName: string, 
    custInvoices: Invoice[], 
    totalUnpaid: number,
    slipNo?: number
  ) => {
    // Deduplicate custInvoices by invoice number
    const seenMap = new Map<string, Invoice>();
    custInvoices.forEach((inv) => {
      const key = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
      if (key && !seenMap.has(key)) {
        seenMap.set(key, inv);
      }
    });
    const uniqueCustInvoices = Array.from(seenMap.values());

    const unpaids = uniqueCustInvoices.filter((i) => ((i as any).calculatedSisa !== undefined ? (i as any).calculatedSisa : (i.sisa !== undefined ? i.sisa : i.total)) > 0);
    const calculatedTotalUnpaid = unpaids.reduce((acc, i) => acc + Number((i as any).calculatedSisa !== undefined ? (i as any).calculatedSisa : (i.sisa !== undefined ? i.sisa : i.total)), 0);

    setBulkSettleCustomer({
      customer: customerName,
      invoices: unpaids,
      total: calculatedTotalUnpaid,
      slipNo,
    });
    setBayarNominal(String(calculatedTotalUnpaid));
    setBayarMetode('Potong Gaji (Payroll)');
    setBayarCatatan(slipNo ? `Pelunasan Slip #${slipNo} (${unpaids.length} Nota)` : `Pelunasan Kolektif Gajian (${unpaids.length} Nota)`);
    setPelunasanSuccessMsg('');
  };

  // Handler: Submit Pelunasan
  const handleSubmitPelunasan = async () => {
    const nominal = parseFloat(bayarNominal);
    if (isNaN(nominal) || nominal <= 0) {
      alert('Masukkan jumlah pembayaran yang valid.');
      return;
    }

    setIsProcessingPelunasan(true);
    try {
      const now = new Date();
      const dateStr = fDate(now);
      const timeStr = fTime(now);

      if (bulkSettleCustomer) {
        // Bulk settle all unpaid invoices for this customer
        let remainingPayment = nominal;
        const records: PelunasanRecord[] = [];

        for (let idx = 0; idx < bulkSettleCustomer.invoices.length; idx++) {
          const inv = bulkSettleCustomer.invoices[idx];
          if (remainingPayment <= 0) break;
          const sisaInv = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa || inv.total);
          const payThis = Math.min(remainingPayment, sisaInv);
          const recId = `PEL-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
          
          records.push({
            id: recId,
            invoiceNo: inv.invoiceNo,
            date: dateStr,
            time: timeStr,
            customer: bulkSettleCustomer.customer,
            cashier: cashierName,
            kasir: cashierName,
            payMethod: bayarMetode,
            jumlahBayar: payThis,
            sisaAwal: sisaInv,
            newSisa: Math.max(0, sisaInv - payThis),
            catatan: bayarCatatan,
          });

          remainingPayment -= payThis;
        }

        if (records.length > 0) {
          if (onBatchRecordPelunasan) {
            await onBatchRecordPelunasan(records);
          } else if (onRecordPelunasan) {
            for (const rec of records) {
              await onRecordPelunasan(rec);
            }
          }
        }

        setPelunasanSuccessMsg(`Berhasil melunasi piutang ${bulkSettleCustomer.customer}!`);
        setTimeout(() => {
          setBulkSettleCustomer(null);
          if (onRefresh) onRefresh();
        }, 500);
      } else if (pelunasanTarget) {
        // Single invoice settle
        const sisaInv = (pelunasanTarget as any).calculatedSisa !== undefined ? (pelunasanTarget as any).calculatedSisa : (pelunasanTarget.sisa || pelunasanTarget.total);
        const recId = `PEL-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
        if (onRecordPelunasan) {
          await onRecordPelunasan({
            id: recId,
            invoiceNo: pelunasanTarget.invoiceNo,
            date: dateStr,
            time: timeStr,
            customer: pelunasanTarget.customer,
            cashier: cashierName,
            kasir: cashierName,
            payMethod: bayarMetode,
            jumlahBayar: nominal,
            sisaAwal: sisaInv,
            newSisa: Math.max(0, sisaInv - nominal),
            catatan: bayarCatatan,
          });
        }
        setPelunasanSuccessMsg(`Pelunasan nota ${pelunasanTarget.invoiceNo} berhasil dicatat!`);
        setTimeout(() => {
          setPelunasanTarget(null);
          if (onRefresh) onRefresh();
        }, 1200);
      }
    } catch (err: any) {
      alert(`Gagal memproses pelunasan: ${err?.message || 'Terjadi kesalahan sistem'}`);
    } finally {
      setIsProcessingPelunasan(false);
    }
  };

  return (
    <div id="piutang-view-container" className="h-full flex flex-col gap-4 overflow-y-auto pr-1 pb-8">
      {/* Top Banner Header */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-600 rounded-xl text-white shrink-0 shadow-sm">
            <BadgeDollarSign className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black tracking-tight">Rekapitulasi Piutang & Potong Gaji</h2>
              <span className="bg-red-500/30 text-red-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-500/40">
                Payroll Sembako
              </span>
            </div>
            <p className="text-stone-300 text-xs mt-0.5">
              Kelola tagihan karyawan, rekapitulasi slip pemotongan gaji bulanan, dan cetak laporan penagihan resmi.
            </p>
          </div>
        </div>

        {/* Action buttons: Export Excel, Cetak Rekap PDF & Refresh */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
          <button
            id="btn-export-excel-piutang-top"
            onClick={() => setIsExportModalOpen(true)}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition shadow-sm cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Excel</span>
          </button>
          <button
            id="btn-print-rekap-pdf"
            onClick={handlePrintRekapPDF}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak PDF Rekap Tagihan</span>
          </button>
          {onRefresh && (
            <button
              id="btn-refresh-piutang"
              onClick={onRefresh}
              className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white rounded-xl transition cursor-pointer"
              title="Sinkronkan Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Summary Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Card 1: Total Piutang Aktif */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Total Piutang Aktif</span>
            <div className="p-1.5 bg-red-50 text-red-600 rounded-lg">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-black text-red-600 tracking-tight">{fRp(metrics.totalSisa)}</div>
            <span className="text-[10px] text-stone-400 font-semibold">Semua tagihan belum lunas</span>
          </div>
        </div>

        {/* Card 2: Khusus Potong Gaji */}
        <div className="bg-white border border-amber-200 bg-amber-50/20 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider">Khusus Potong Gaji</span>
            <div className="p-1.5 bg-amber-100 text-amber-800 rounded-lg">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-black text-amber-900 tracking-tight">{fRp(metrics.totalPotongGaji)}</div>
            <span className="text-[10px] text-amber-700 font-bold">Dipotong saat gajian tiba</span>
          </div>
        </div>

        {/* Card 3: Piutang Tunai */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Piutang Tunai / DP</span>
            <div className="p-1.5 bg-stone-100 text-stone-600 rounded-lg">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-black text-stone-800 tracking-tight">{fRp(metrics.totalTunai)}</div>
            <span className="text-[10px] text-stone-400 font-semibold">Pelanggan umum / tempo</span>
          </div>
        </div>

        {/* Card 4: Jumlah Karyawan / Pelanggan Berpiutang */}
        <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Karyawan / Peminjam</span>
            <div className="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-black text-stone-800 tracking-tight">{metrics.totalPelangganUnpaid} Orang</div>
            <span className="text-[10px] text-stone-400 font-semibold">Memiliki saldo tagihan</span>
          </div>
        </div>
      </div>

      {/* Sub Tabs & Filters Bar */}
      <div className="bg-white border border-stone-200 rounded-2xl p-3 shadow-xs space-y-3">
        {/* Navigation Sub-Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-2.5">
          <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl">
            <button
              id="tab-rekap-karyawan"
              onClick={() => setActiveSubTab('rekap_karyawan')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeSubTab === 'rekap_karyawan'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-red-700" />
              <span>Rekap per Karyawan ({groupedByCustomer.filter(g => g.totalUnpaid > 0).length})</span>
            </button>
            <button
              id="tab-daftar-nota"
              onClick={() => setActiveSubTab('daftar_nota')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeSubTab === 'daftar_nota'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              <span>Semua Nota Piutang ({filteredInvoices.length})</span>
            </button>
            <button
              id="tab-riwayat-pelunasan"
              onClick={() => setActiveSubTab('riwayat_pelunasan')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeSubTab === 'riwayat_pelunasan'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
              <span>
                Riwayat Pelunasan ({riwayatBadgeCount})
              </span>
            </button>
          </div>

          {/* Quick info tag */}
          <div className="text-[11px] font-bold text-stone-500 hidden sm:block">
            Mode: <span className="text-red-700 font-black">Potong Gaji & Tunai</span>
          </div>
        </div>

        {/* Search & Filter Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-2">
          {/* Search Bar */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-search-piutang"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari nama karyawan, no invoice, kasir..."
              className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-xl text-xs bg-stone-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/20"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')} 
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Controls */}
          <div className="grid grid-cols-3 gap-1.5 w-full sm:w-auto sm:flex sm:items-center">
            {/* Division Filter */}
            <select
              id="filter-divisi-piutang"
              value={filterDivision}
              onChange={(e) => setFilterDivision(e.target.value)}
              className="w-full sm:w-auto px-1.5 sm:px-2.5 py-1.5 sm:py-2 border border-stone-200 rounded-xl text-[11px] sm:text-xs font-bold bg-white text-stone-700 focus:outline-none focus:ring-2 focus:ring-red-500/20"
            >
              <option value="ALL">Semua Divisi ({availableExportDivisions.length})</option>
              {availableExportDivisions.map((div) => (
                <option key={div} value={div}>
                  {div}
                </option>
              ))}
            </select>

            {/* Method Filter */}
            <select
              id="filter-metode-piutang"
              value={filterMethod}
              onChange={(e) => setFilterMethod(e.target.value as any)}
              className="w-full sm:w-auto px-1.5 sm:px-2.5 py-1.5 sm:py-2 border border-stone-200 rounded-xl text-[11px] sm:text-xs font-bold bg-white text-stone-700 focus:outline-none focus:ring-2 focus:ring-red-500/20"
            >
              <option value="all">Semua Metode</option>
              <option value="potong_gaji">📋 Potong Gaji</option>
              <option value="tunai">💵 Tunai (DP)</option>
            </select>

            {/* Status Filter */}
            <select
              id="filter-status-piutang"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="w-full sm:w-auto px-1.5 sm:px-2.5 py-1.5 sm:py-2 border border-stone-200 rounded-xl text-[11px] sm:text-xs font-bold bg-white text-stone-700 focus:outline-none focus:ring-2 focus:ring-red-500/20"
            >
              <option value="unpaid">Belum Lunas</option>
              <option value="all">Semua Status</option>
              <option value="lunas">Sudah Lunas</option>
            </select>
          </div>
        </div>
      </div>

      {/* SUB TAB 1: REKAP PER KARYAWAN (GROUPED VIEW) */}
      {activeSubTab === 'rekap_karyawan' && (
        <div className="space-y-3">
          {/* Quick Action Banner for Rekap Karyawan Excel Export */}
          <div className="bg-emerald-50/80 border border-emerald-200/90 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-black text-emerald-950">Export Excel Rekap Belanja Mingguan Karyawan</h4>
                  <span className="bg-emerald-200/80 text-emerald-900 text-[10px] font-bold px-2 py-0.5 rounded-md">
                    Format WAKA
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800 mt-0.5">
                  Format disesuaikan persis dengan <em>Template Import Belanja WAKA</em> (Kolom: No, No. WA, Nama, Divisi, Tanggal, Nominal, Keterangan).
                </p>
              </div>
            </div>
            <button
              id="btn-export-excel-karyawan-tab"
              onClick={() => setIsExportModalOpen(true)}
              className="w-full sm:w-auto px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black rounded-xl transition shadow-xs flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Export Excel (.xlsx)</span>
            </button>
          </div>
          {filteredGroupedCustomers.length === 0 ? (
            <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-80" />
              <h3 className="text-sm font-bold text-stone-700">Tidak ada piutang aktif yang ditemukan</h3>
              <p className="text-xs text-stone-400 mt-1">Semua transaksi karyawan sudah lunas atau sesuai filter pencarian.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredGroupedCustomers.map((g) => {
                const unpaidInvoices = g.invoices.filter((i) => i.calculatedSisa > 0);
                const hasPotongGaji = g.potongGajiUnpaid > 0;
                const slipSummary = getCustomerSlipSummary(g.customer, g.invoices);
                const currentSlipNo = slipSummary.activeSlip ? slipSummary.activeSlip.slipNo : slipSummary.activeSlipNo;
                const hasActiveUnprintedInvoices = Boolean(slipSummary.activeSlip && slipSummary.activeSlip.invoices.length > 0);
                const custDivision = getCustomerDivision(g.customer);

                return (
                  <div 
                    key={g.customer}
                    className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs hover:border-red-300 transition flex flex-col justify-between"
                  >
                    <div>
                      {/* Customer Header */}
                      <div className="flex items-start justify-between gap-2 border-b border-stone-100 pb-2.5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 font-black flex items-center justify-center text-sm shrink-0">
                            {g.customer.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h3 className="text-sm font-extrabold text-stone-900">{g.customer}</h3>
                              {custDivision && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                                  <Building2 className="w-3 h-3 text-blue-600" />
                                  <span>{custDivision}</span>
                                </span>
                              )}
                              {g.totalUnpaid > 0 && (
                                <div className="flex items-center gap-1">
                                  <span className="bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-md border border-amber-200 flex items-center gap-1">
                                    <Layers className="w-3 h-3 text-amber-700" />
                                    <span>Slip #{currentSlipNo}</span>
                                  </span>
                                  {slipSummary.activeSlip && slipSummary.activeSlip.invoices.length > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => handleCloseAndCreateNewSlip(g.customer, g.invoices)}
                                      className="bg-stone-100 hover:bg-amber-100 text-stone-700 hover:text-amber-900 border border-stone-200 hover:border-amber-300 text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer"
                                      title={`Tutup Slip #${currentSlipNo} sekarang dan mulai transaksi baru di Slip #${currentSlipNo + 1}`}
                                    >
                                      + Slip Baru
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-stone-500 font-semibold mt-0.5">
                              {g.phone ? <span>📞 {g.phone}</span> : <span>Karyawan / Pelanggan</span>}
                              <span>•</span>
                              <span>{unpaidInvoices.length} nota aktif</span>
                            </div>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <div className="text-right">
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                            g.totalUnpaid > 0
                              ? 'bg-red-50 text-red-700 border border-red-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}>
                            {g.totalUnpaid > 0 ? 'BELUM LUNAS' : 'LUNAS'}
                          </span>
                        </div>
                      </div>

                      {/* Financial Breakdown */}
                      <div className="grid grid-cols-2 gap-2 my-3 p-2.5 bg-stone-50 rounded-xl text-xs">
                        <div>
                          <div className="text-[10px] font-bold text-stone-500 uppercase">Potong Gaji (Gajian)</div>
                          <div className="font-extrabold text-amber-900 text-sm mt-0.5">
                            {fRp(g.potongGajiUnpaid)}
                          </div>
                        </div>
                        <div className="border-l border-stone-200 pl-2.5">
                          <div className="text-[10px] font-bold text-stone-500 uppercase">Total Seluruh Tagihan</div>
                          <div className="font-black text-red-600 text-sm mt-0.5">
                            {fRp(g.totalUnpaid)}
                          </div>
                        </div>
                      </div>

                      {/* History Slips List (Weekly/Periodic Slips that have been closed/printed) */}
                      {slipSummary.historySlips.length > 0 && (
                        <div className="mb-3 p-2.5 bg-stone-50 border border-stone-200/90 rounded-xl space-y-2">
                          <div className="text-[10px] font-bold text-stone-600 uppercase tracking-wider flex items-center justify-between">
                            <span className="flex items-center gap-1">
                              <Layers className="w-3 h-3 text-amber-700" />
                              <span>Daftar Slip Tertagih ({slipSummary.historySlips.length}):</span>
                            </span>
                            <span className="text-[9px] text-stone-400 font-medium">Klik slip untuk lihat rincian nota</span>
                          </div>
                          <div className="space-y-1.5">
                            {slipSummary.historySlips.map((hSlip) => {
                              const isSlipExpanded = Boolean(expandedSlips[`${g.customer}_slip_${hSlip.slipNo}`]);
                              return (
                                <div
                                  key={hSlip.slipNo}
                                  className="bg-white rounded-lg border border-stone-200 shadow-2xs overflow-hidden transition"
                                >
                                  {/* Slip Header Bar - Clickable to expand/collapse */}
                                  <div
                                    onClick={() => toggleSlipExpanded(g.customer, hSlip.slipNo)}
                                    className="flex items-center justify-between p-2 hover:bg-amber-50/60 transition cursor-pointer select-none"
                                    title="Klik untuk melihat / menutup rincian nota belanja di slip ini"
                                  >
                                    <div className="flex items-center gap-2">
                                      <ChevronDown className={`w-3.5 h-3.5 text-stone-400 transition-transform duration-200 ${isSlipExpanded ? 'rotate-180 text-amber-700' : ''}`} />
                                      <span className="font-extrabold text-stone-800 bg-amber-50 text-amber-900 border border-amber-200 px-1.5 py-0.5 rounded text-[10px]">
                                        Slip #{hSlip.slipNo}
                                      </span>
                                      <span className="text-[10px] text-stone-500 font-medium">
                                        {hSlip.invoices.length} nota
                                      </span>
                                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                                        hSlip.isLunas
                                          ? 'bg-emerald-100 text-emerald-800'
                                          : 'bg-red-100 text-red-800'
                                      }`}>
                                        {hSlip.isLunas ? 'LUNAS' : 'BELUM LUNAS'}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-bold text-red-600 font-mono text-[11px]">
                                        {fRp(hSlip.totalUnpaid)}
                                      </span>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handlePrintSlipKaryawan(g.customer, g.invoices, hSlip.slipNo);
                                        }}
                                        className="p-1 text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-md transition cursor-pointer"
                                        title={`Cetak Ulang Slip #${hSlip.slipNo}`}
                                      >
                                        <Printer className="w-3.5 h-3.5" />
                                      </button>
                                      {!hSlip.isLunas && (
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleOpenBulkSettle(g.customer, hSlip.invoices, hSlip.totalUnpaid, hSlip.slipNo);
                                          }}
                                          className="px-2 py-0.5 text-[10px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition cursor-pointer flex items-center gap-0.5"
                                          title={`Lunasi Slip #${hSlip.slipNo} (${fRp(hSlip.totalUnpaid)})`}
                                        >
                                          <CheckCheck className="w-3 h-3" />
                                          <span>Lunasi</span>
                                        </button>
                                      )}
                                    </div>
                                  </div>

                                  {/* Expanded Invoice List within this Slip */}
                                  {isSlipExpanded && (
                                    <div className="p-2 pt-1 bg-stone-50/70 border-t border-stone-100 space-y-1.5 animate-fadeIn">
                                      <div className="text-[9px] font-bold text-stone-500 uppercase tracking-wider flex items-center justify-between pb-0.5">
                                        <span>Rincian Nota di Slip #{hSlip.slipNo}:</span>
                                        <span className="text-amber-700 font-semibold">Klik nota untuk rincian menu</span>
                                      </div>
                                      {hSlip.invoices.map((inv) => {
                                        const isPotongGajiInv = (inv as any).isPotongGaji || (inv.payMethod || '').includes('Gaji') || (inv.metodePembayaran || '').includes('Gaji');
                                        const invSisa = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total);
                                        const itemsCount = inv.items ? inv.items.length : 0;
                                        return (
                                          <div
                                            key={inv.invoiceNo}
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setViewInvoiceDetail(inv);
                                            }}
                                            className="flex items-center justify-between p-2 bg-white border border-stone-200/90 rounded-lg hover:border-amber-400 hover:bg-amber-50/30 transition cursor-pointer text-xs group"
                                            title="Klik untuk membuka rincian lengkap barang/menu belanja"
                                          >
                                            <div className="flex items-center gap-2 min-w-0">
                                              <FileText className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-600 shrink-0" />
                                              <div className="min-w-0">
                                                <div className="flex items-center gap-1.5 flex-wrap">
                                                  <span className="font-bold text-stone-800 group-hover:text-amber-900">{inv.invoiceNo}</span>
                                                  <span className="text-[10px] text-stone-400">{inv.date} {inv.time ? `• ${inv.time}` : ''}</span>
                                                  {isPotongGajiInv && (
                                                    <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">
                                                      Potong Gaji
                                                    </span>
                                                  )}
                                                  <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                                                    invSisa <= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                                                  }`}>
                                                    {invSisa <= 0 ? 'LUNAS' : 'BELUM LUNAS'}
                                                  </span>
                                                </div>
                                                {inv.items && inv.items.length > 0 && (
                                                  <div className="text-[10px] text-stone-500 truncate max-w-xs mt-0.5">
                                                    {inv.items.map((it: any) => `${it.qty || it.jumlah || 1}x ${it.nama || it.name || it.namaBarang || it.menuName || 'Item'}`).join(', ')}
                                                  </div>
                                                )}
                                              </div>
                                            </div>
                                            <div className="text-right shrink-0 ml-2">
                                              <div className="font-bold text-red-600 font-mono text-[11px]">
                                                {fRp(invSisa)}
                                              </div>
                                              <div className="text-[9px] text-amber-700 font-medium group-hover:underline flex items-center justify-end gap-0.5">
                                                <Eye className="w-2.5 h-2.5" />
                                                <span>Lihat Nota</span>
                                              </div>
                                            </div>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Active Slip / Unprinted Invoices Section */}
                      <div className="space-y-1.5 mb-3">
                        <div className="text-[10px] font-bold text-stone-600 uppercase tracking-wider flex items-center justify-between">
                          <span className="flex items-center gap-1">
                            <FileText className="w-3 h-3 text-stone-500" />
                            <span>{slipSummary.activeSlip ? `Transaksi Berjalan (Slip #${slipSummary.activeSlip.slipNo}):` : 'Semua Transaksi Telah Diterbitkan'}</span>
                          </span>
                          {slipSummary.activeSlip && (
                            <span className="text-amber-800 text-[10px] font-bold">
                              {slipSummary.activeSlip.invoices.length} nota aktif
                            </span>
                          )}
                        </div>

                        {slipSummary.activeSlip && slipSummary.activeSlip.invoices.length > 0 ? (
                          slipSummary.activeSlip.invoices.slice(0, 3).map((inv) => {
                            const isPotongGajiInv = (inv as any).isPotongGaji || (inv.payMethod || '').includes('Gaji') || (inv.metodePembayaran || '').includes('Gaji');
                            const invSisa = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total);
                            return (
                              <div 
                                key={inv.invoiceNo}
                                className="flex items-center justify-between text-xs p-2 bg-white border border-stone-100 rounded-lg hover:bg-stone-50 transition cursor-pointer"
                                onClick={() => setViewInvoiceDetail(inv)}
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="w-3.5 h-3.5 text-stone-400" />
                                  <span className="font-bold text-stone-800">{inv.invoiceNo}</span>
                                  <span className="text-[10px] text-stone-400">{inv.date}</span>
                                  <span className="text-[9px] bg-stone-100 text-stone-600 font-semibold px-1 rounded">
                                    Slip #{inv.slipNo || slipSummary.activeSlip?.slipNo}
                                  </span>
                                  {isPotongGajiInv && (
                                    <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">
                                      Potong Gaji
                                    </span>
                                  )}
                                </div>
                                <span className="font-bold text-red-600 font-mono">{fRp(invSisa)}</span>
                              </div>
                            );
                          })
                        ) : (
                          <div className="text-[11px] text-stone-500 bg-stone-50 p-2 rounded-lg border border-stone-200/60 text-center">
                            Belum ada transaksi baru. Transaksi belanja kasir berikutnya otomatis masuk ke <strong>Slip #{currentSlipNo}</strong>.
                          </div>
                        )}

                        {slipSummary.activeSlip && slipSummary.activeSlip.invoices.length > 3 && (
                          <div className="text-[10px] text-stone-500 text-center font-semibold pt-0.5">
                            + {slipSummary.activeSlip.invoices.length - 3} nota lainnya di Slip #{slipSummary.activeSlip.slipNo}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons for this Employee */}
                    <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                      {g.totalUnpaid > 0 ? (
                        <>
                          <button
                            type="button"
                            disabled={!hasActiveUnprintedInvoices}
                            onClick={() => handlePrintSlipKaryawan(g.customer, g.invoices, currentSlipNo)}
                            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 border rounded-xl text-xs font-bold transition ${
                              hasActiveUnprintedInvoices
                                ? 'border-stone-200 hover:border-red-300 bg-white hover:bg-red-50/30 text-stone-800 hover:text-red-700 cursor-pointer'
                                : 'border-stone-200 bg-stone-100/90 text-stone-400 cursor-not-allowed opacity-60'
                            }`}
                            title={
                              hasActiveUnprintedInvoices
                                ? `Cetak Slip Tagihan #${currentSlipNo}. Transaksi berikutnya otomatis masuk Slip #${currentSlipNo + 1}`
                                : `Belum ada transaksi belanja baru untuk dicetak di Slip #${currentSlipNo}. Tombol dinonaktifkan.`
                            }
                          >
                            <Printer className={`w-3.5 h-3.5 ${hasActiveUnprintedInvoices ? 'text-red-600' : 'text-stone-400'}`} />
                            <span>Cetak Slip #{currentSlipNo}</span>
                          </button>

                          <button
                            onClick={() => handleOpenBulkSettle(g.customer, g.invoices, g.totalUnpaid)}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold transition shadow-xs cursor-pointer"
                            title="Lunasi seluruh nota gajian ini"
                          >
                            <CheckCheck className="w-3.5 h-3.5" />
                            <span>Lunasi Semua</span>
                          </button>
                        </>
                      ) : (
                        <div className="flex items-center gap-2 w-full">
                          <button
                            onClick={() => handlePrintBuktiLunas(g.customer, g.invoices, {
                              date: fDate(new Date()),
                              time: fTime(new Date()),
                              cashier: cashierName,
                              payMethod: 'Potong Gaji (Gajian)',
                              catatan: 'Tagihan sudah lunas',
                            })}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-black transition shadow-2xs cursor-pointer"
                            title="Cetak Slip Bukti Pelunasan Lunas"
                          >
                            <Printer className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Bukti Lunas</span>
                          </button>
                          {onDeleteInvoice && (
                            <button
                              onClick={() => setCustomerToDeleteLunas({
                                customer: g.customer,
                                invoices: g.invoices.filter((i) => i.isLunas || (i as any).calculatedSisa <= 0),
                              })}
                              className="p-2 bg-stone-100 hover:bg-red-50 text-stone-500 hover:text-red-600 border border-stone-200 hover:border-red-200 rounded-xl transition cursor-pointer"
                              title="Hapus Seluruh Nota Lunas Karyawan Ini"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SUB TAB 2: SEMUA NOTA PIUTANG (DETAILED LIST) */}
      {activeSubTab === 'daftar_nota' && (
        <div className={`bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs flex flex-col transition-all duration-200 ${
          isTableMaximized
            ? 'fixed inset-0 sm:inset-2 md:inset-4 z-50 shadow-2xl border-stone-300 rounded-none sm:rounded-2xl'
            : ''
        }`}>
          {/* Header count, mobile switcher & maximize */}
          <div className="px-3.5 sm:px-4 py-2.5 sm:py-3 bg-stone-50 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-stone-700 shrink-0">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-red-100 text-red-700 rounded-lg shrink-0">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <span className="font-black text-stone-900">Daftar Seluruh Nota Piutang</span>
                <span className="ml-1.5 text-xs font-extrabold px-2 py-0.5 rounded-full bg-red-100 text-red-800">
                  {filteredInvoices.length} Nota
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Mobile View Switcher (Kartu vs Tabel) */}
              <div className="sm:hidden flex items-center bg-stone-200/80 p-0.5 rounded-xl border border-stone-300/70">
                <button
                  type="button"
                  onClick={() => setMobileNotaViewMode('card')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    mobileNotaViewMode === 'card'
                      ? 'bg-red-700 text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>📱 Kartu</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMobileNotaViewMode('table')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    mobileNotaViewMode === 'table'
                      ? 'bg-red-700 text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>📊 Tabel</span>
                </button>
              </div>

              {/* Layar Penuh Toggle */}
              <button
                type="button"
                onClick={() => setIsTableMaximized(!isTableMaximized)}
                className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 text-stone-700 text-xs font-bold border border-stone-200 transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title={isTableMaximized ? 'Kembalikan Ukuran Normal' : 'Maksimalkan Layar Penuh'}
              >
                {isTableMaximized ? (
                  <>
                    <Minimize2 className="w-3.5 h-3.5 text-stone-600" />
                    <span className="hidden sm:inline">Perkecil</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-3.5 h-3.5 text-stone-600" />
                    <span className="hidden sm:inline">Layar Penuh</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Swipe / Mode Hint for Mobile */}
          <div className="sm:hidden flex items-center justify-between text-[10px] text-stone-500 bg-stone-50 px-3 py-1.5 border-b border-stone-200/70 shrink-0">
            {mobileNotaViewMode === 'card' ? (
              <span className="font-medium text-stone-600">📱 Mode Kartu: Mudah dibaca, rincian piutang & tombol bayar jelas</span>
            ) : (
              <span className="font-medium text-stone-600">👉 Mode Tabel: Geser horizontal untuk melihat DP, sisa piutang, & aksi</span>
            )}
            <span className="font-bold text-stone-700">{filteredInvoices.length} Nota</span>
          </div>

          {/* Scrollable Container */}
          <div className={`overflow-x-auto overflow-y-auto ${
            isTableMaximized
              ? 'flex-1 min-h-0'
              : 'h-[500px] sm:h-[620px] lg:h-[720px] min-h-[420px] max-h-[85vh]'
          }`}>
            {/* Mobile Card List (Active on mobile screen when mobileNotaViewMode === 'card') */}
            {mobileNotaViewMode === 'card' && (
              <div className="sm:hidden divide-y divide-stone-100 bg-white">
                {filteredInvoices.length > 0 ? (
                  filteredInvoices.map((inv) => {
                    const custDivision = getCustomerDivision(inv.customer);
                    const isCopied = copiedInvoiceNo === inv.invoiceNo;
                    const isLunas = inv.calculatedSisa <= 0;
                    const paidAmount = (inv.dp || 0) + (inv.pelunasanHistory?.reduce((a, b) => a + Number(b.jumlahBayar || 0), 0) || 0);

                    return (
                      <div key={inv.invoiceNo} className="p-3 hover:bg-stone-50/80 transition flex flex-col gap-2">
                        {/* Header: No Invoice, Tanggal & Jam, Status */}
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-mono font-black text-red-700 text-xs bg-red-50 px-2 py-0.5 rounded border border-red-200 flex items-center gap-1">
                              <FileText className="w-3 h-3 text-red-600" />
                              <span>{inv.invoiceNo}</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCopyNoNota(inv.invoiceNo)}
                              className="p-1 text-stone-400 hover:text-stone-700 rounded transition cursor-pointer"
                              title="Salin No. Invoice"
                            >
                              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                            <span className="text-[10px] text-stone-400 font-medium">
                              {inv.date} {inv.time}
                            </span>
                          </div>

                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full shrink-0 ${
                            isLunas
                              ? 'bg-emerald-100 text-emerald-800'
                              : inv.isPotongGaji
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {isLunas ? 'LUNAS' : inv.isPotongGaji ? 'POTONG GAJI' : 'BELUM LUNAS'}
                          </span>
                        </div>

                        {/* Customer & Method */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-stone-900 text-xs">{inv.customer || 'Umum'}</span>
                              {custDivision && (
                                <span className="inline-flex items-center gap-1 text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-blue-50 text-blue-800 border border-blue-200">
                                  <Building2 className="w-2.5 h-2.5 text-blue-600" />
                                  <span>{custDivision}</span>
                                </span>
                              )}
                            </div>
                            <div className="mt-1">
                              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded ${
                                inv.isPotongGaji
                                  ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                  : 'bg-stone-100 text-stone-700'
                              }`}>
                                {inv.isPotongGaji ? '📋 Potong Gaji' : '💵 Tunai (DP)'}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* 3-Column Financial Breakdown Card */}
                        <div className="grid grid-cols-3 gap-1.5 p-2 bg-stone-50 rounded-xl border border-stone-200/80 text-[11px]">
                          <div>
                            <span className="text-[9px] text-stone-500 font-bold block uppercase">Total Nota</span>
                            <span className="font-bold text-stone-800 font-mono">{fRp(inv.total)}</span>
                          </div>
                          <div>
                            <span className="text-[9px] text-emerald-700 font-bold block uppercase">DP / Terbayar</span>
                            <span className="font-bold text-emerald-700 font-mono">{fRp(paidAmount)}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[9px] text-red-600 font-bold block uppercase">Sisa Piutang</span>
                            <span className="font-black text-red-600 font-mono text-xs">{fRp(inv.calculatedSisa)}</span>
                          </div>
                        </div>

                        {/* Footer Actions */}
                        <div className="flex items-center justify-between gap-2 pt-1 border-t border-stone-100 text-[10px]">
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => setViewInvoiceDetail(inv)}
                              className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
                              title="Lihat Rincian Barang"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Item</span>
                            </button>
                            {onReprintInvoice && (
                              <button
                                type="button"
                                onClick={() => onReprintInvoice(inv)}
                                className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
                                title="Cetak Ulang Nota"
                              >
                                <Printer className="w-3.5 h-3.5" />
                                <span>Cetak</span>
                              </button>
                            )}
                          </div>

                          <div className="flex items-center gap-1">
                            {inv.calculatedSisa > 0 ? (
                              <button
                                type="button"
                                onClick={() => handleOpenPelunasanSingle(inv)}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-black transition shadow-xs flex items-center gap-1 cursor-pointer"
                                title="Bayar Pelunasan Sekarang"
                              >
                                <span>Bayar Pelunasan</span>
                              </button>
                            ) : (
                              onDeleteInvoice && (
                                <button
                                  type="button"
                                  onClick={() => setInvoiceToDelete(inv)}
                                  className="p-1.5 hover:bg-red-50 text-stone-400 hover:text-red-600 rounded-lg transition cursor-pointer"
                                  title="Hapus Nota Lunas"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="py-12 text-center text-stone-400">
                    <FileText className="w-10 h-10 mx-auto text-stone-300 mb-2" />
                    <p className="font-bold text-xs">Tidak ada transaksi piutang yang cocok dengan kriteria pencarian.</p>
                  </div>
                )}
              </div>
            )}

            {/* Desktop Table OR Mobile Wide Table (when mobileNotaViewMode === 'table') */}
            <table className={`${mobileNotaViewMode === 'card' ? 'hidden sm:table' : 'table'} min-w-[850px] w-full text-left text-xs border-collapse`}>
              <thead className="sticky top-0 z-10 shadow-xs">
                <tr className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                  <th className="py-3 px-3.5 bg-stone-100 whitespace-nowrap">No. Invoice</th>
                  <th className="py-3 px-3 bg-stone-100 whitespace-nowrap">Tanggal</th>
                  <th className="py-3 px-3 bg-stone-100 min-w-[140px]">Karyawan / Pelanggan</th>
                  <th className="py-3 px-3 bg-stone-100 whitespace-nowrap">Metode</th>
                  <th className="py-3 px-3 text-right bg-stone-100 whitespace-nowrap">Total</th>
                  <th className="py-3 px-3 text-right bg-stone-100 whitespace-nowrap">DP/Terbayar</th>
                  <th className="py-3 px-3 text-right bg-stone-100 whitespace-nowrap">Sisa Piutang</th>
                  <th className="py-3 px-3 text-center bg-stone-100 whitespace-nowrap">Status</th>
                  <th className="py-3 px-3.5 text-center bg-stone-100 whitespace-nowrap">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredInvoices.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-stone-400">
                      Tidak ada transaksi piutang yang cocok dengan kriteria pencarian.
                    </td>
                  </tr>
                ) : (
                  filteredInvoices.map((inv) => (
                    <tr key={inv.invoiceNo} className="hover:bg-stone-50/80 transition">
                      <td className="py-2.5 px-3.5 font-bold text-stone-900 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-red-700 shrink-0" />
                          <span>{inv.invoiceNo}</span>
                          <button
                            type="button"
                            onClick={() => handleCopyNoNota(inv.invoiceNo)}
                            className="p-1 text-stone-400 hover:text-stone-700 rounded transition cursor-pointer"
                            title="Salin No. Invoice"
                          >
                            {copiedInvoiceNo === inv.invoiceNo ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-stone-600 whitespace-nowrap">
                        <div>{inv.date}</div>
                        <div className="text-[10px] text-stone-400">{inv.time}</div>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-stone-800">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span>{inv.customer || 'Umum'}</span>
                          {getCustomerDivision(inv.customer) && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                              <Building2 className="w-2.5 h-2.5 text-blue-600" />
                              <span>{getCustomerDivision(inv.customer)}</span>
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded ${
                          inv.isPotongGaji
                            ? 'bg-amber-100 text-amber-900 border border-amber-200'
                            : 'bg-stone-100 text-stone-700'
                        }`}>
                          {inv.isPotongGaji ? '📋 Potong Gaji' : '💵 Tunai (DP)'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-semibold text-stone-700 font-mono whitespace-nowrap">
                        {fRp(inv.total)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-semibold text-emerald-700 font-mono whitespace-nowrap">
                        {fRp(inv.dp + (inv.pelunasanHistory?.reduce((a, b) => a + Number(b.jumlahBayar || 0), 0) || 0))}
                      </td>
                      <td className="py-2.5 px-3 text-right font-black text-red-600 font-mono text-xs whitespace-nowrap">
                        {fRp(inv.calculatedSisa)}
                      </td>
                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                          inv.calculatedSisa <= 0
                            ? 'bg-emerald-100 text-emerald-800'
                            : inv.isPotongGaji
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {inv.calculatedSisa <= 0 ? 'LUNAS' : inv.isPotongGaji ? 'POTONG GAJI' : 'BELUM LUNAS'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setViewInvoiceDetail(inv)}
                            className="p-1.5 hover:bg-stone-200 text-stone-600 rounded-lg transition cursor-pointer"
                            title="Lihat Rincian Barang"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {onReprintInvoice && (
                            <button
                              onClick={() => onReprintInvoice(inv)}
                              className="p-1.5 hover:bg-stone-200 text-stone-600 rounded-lg transition cursor-pointer"
                              title="Cetak Ulang Nota"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {inv.calculatedSisa > 0 ? (
                            <button
                              onClick={() => handleOpenPelunasanSingle(inv)}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-extrabold transition shadow-xs ml-1 cursor-pointer"
                              title="Bayar Pelunasan"
                            >
                              Bayar
                            </button>
                          ) : (
                            onDeleteInvoice && (
                              <button
                                onClick={() => setInvoiceToDelete(inv)}
                                className="p-1.5 hover:bg-red-50 text-stone-400 hover:text-red-600 rounded-lg transition ml-1 cursor-pointer"
                                title="Hapus Nota Lunas"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {filteredInvoices.length > 0 && (
            <div className="px-4 py-2.5 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between text-xs text-stone-600 font-medium shrink-0">
              <span className="text-[11px] text-stone-500">
                Menampilkan <strong>{filteredInvoices.length}</strong> nota transaksi
              </span>
              <div className="flex items-center gap-3">
                <span className="text-[11px]">
                  Total Piutang: <strong className="font-mono text-stone-800">{fRp(filteredInvoices.reduce((acc, i) => acc + Number(i.total || 0), 0))}</strong>
                </span>
                <span className="text-[11px]">
                  Total Sisa: <strong className="font-mono text-red-600 font-extrabold">{fRp(filteredInvoices.reduce((acc, i) => acc + (i.calculatedSisa || 0), 0))}</strong>
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB TAB 3: RIWAYAT PELUNASAN (REKAP PER KARYAWAN & LOG TRANSAKSI) */}
      {activeSubTab === 'riwayat_pelunasan' && (
        <div className="space-y-4">
          {/* Riwayat Pelunasan Sub-Header Bar with Toggle Switch */}
          <div className="bg-white border border-stone-200 rounded-2xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                <CheckCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-stone-900">Riwayat & Rekap Pelunasan</h3>
                <p className="text-[11px] text-stone-500">
                  Semua transaksi pelunasan potong gaji dan tunai yang telah diselesaikan
                </p>
              </div>
            </div>

            {/* View Mode Switcher Pills */}
            <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setRiwayatViewMode('rekap_karyawan')}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  riwayatViewMode === 'rekap_karyawan'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-emerald-600" />
                <span>Rekap Per Karyawan</span>
                <span className="ml-1 px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded-full text-[10px]">
                  {groupedPelunasanByCustomer.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setRiwayatViewMode('semua_transaksi')}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  riwayatViewMode === 'semua_transaksi'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-red-700" />
                <span>Log Transaksi</span>
                <span className="ml-1 px-1.5 py-0.2 bg-stone-200 text-stone-700 rounded-full text-[10px]">
                  {allPelunasanHistory.length}
                </span>
              </button>
            </div>
          </div>

          {/* VIEW 1: REKAP PELUNASAN PER KARYAWAN */}
          {riwayatViewMode === 'rekap_karyawan' && (
            <div>
              {groupedPelunasanByCustomer.length === 0 ? (
                <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400">
                  <Package className="w-12 h-12 mx-auto mb-2 text-stone-300" />
                  <p className="font-bold text-stone-600">Belum ada riwayat pelunasan karyawan</p>
                  <p className="text-xs text-stone-400 mt-1">
                    Transaksi yang sudah dilunasi akan otomatis terkelompok di sini
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
                  {groupedPelunasanByCustomer.map((g) => {
                    return (
                      <div
                        key={g.customer}
                        className="bg-white border border-stone-200 hover:border-stone-300 rounded-2xl p-4 shadow-xs flex flex-col justify-between transition"
                      >
                        <div>
                          {/* Card Header */}
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-black text-sm uppercase">
                                {g.customer.substring(0, 2)}
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <h4 className="font-extrabold text-stone-900 text-sm">{g.customer}</h4>
                                  {g.division && (
                                    <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                                      <Building2 className="w-2.5 h-2.5 text-blue-600" />
                                      <span>{g.division}</span>
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-stone-400 flex items-center gap-1.5 mt-0.5">
                                  <span>{g.phone || 'Karyawan'}</span>
                                  <span>•</span>
                                  <span>{g.settledInvoices.length} nota selesai</span>
                                </div>
                              </div>
                            </div>

                            <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                              LUNAS (100%)
                            </span>
                          </div>

                          {/* Financial Summary */}
                          <div className="grid grid-cols-2 gap-2 my-2.5 p-2.5 bg-stone-50 border border-stone-100 rounded-xl text-xs">
                            <div>
                              <div className="text-[10px] font-bold text-stone-500 uppercase">Total Dilunasi</div>
                              <div className="font-black text-emerald-700 text-sm mt-0.5">
                                {fRp(g.totalSettled)}
                              </div>
                            </div>
                            <div className="border-l border-stone-200 pl-2.5">
                              <div className="text-[10px] font-bold text-stone-500 uppercase">Waktu Terakhir</div>
                              <div className="font-bold text-stone-700 text-xs mt-0.5 truncate">
                                {g.lastSettledDate || '-'} {g.lastSettledTime || ''}
                              </div>
                            </div>
                          </div>

                          {/* Mini Invoices List */}
                          <div className="space-y-1.5 mb-3">
                            <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                              Daftar Nota yang Sudah Lunas:
                            </div>
                            {g.settledInvoices.slice(0, 3).map((inv) => (
                              <div
                                key={inv.invoiceNo}
                                className="flex items-center justify-between text-xs p-2 bg-stone-50/60 border border-stone-100 rounded-lg hover:bg-stone-50 transition"
                              >
                                <div
                                  className="flex items-center gap-2 flex-1 cursor-pointer truncate"
                                  onClick={() => setViewInvoiceDetail(inv)}
                                >
                                  <FileText className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                                  <span className="font-bold text-stone-800 truncate">{inv.invoiceNo}</span>
                                  <span className="text-[10px] text-stone-400 shrink-0">{inv.date}</span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <span className="font-bold text-emerald-700 font-mono">{fRp(inv.total)}</span>
                                  {onDeleteInvoice && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setInvoiceToDelete(inv);
                                      }}
                                      className="p-1 hover:bg-red-50 text-stone-400 hover:text-red-600 rounded transition cursor-pointer"
                                      title="Hapus Nota Lunas Ini"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                            {g.settledInvoices.length > 3 && (
                              <div className="text-[10px] text-stone-500 text-center font-semibold pt-0.5">
                                + {g.settledInvoices.length - 3} nota lunas lainnya
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Card Action Buttons */}
                        <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                          <button
                            type="button"
                            onClick={() => handlePrintBuktiLunas(g.customer, g.settledInvoices, {
                              date: g.lastSettledDate || fDate(new Date()),
                              time: g.lastSettledTime || fTime(new Date()),
                              cashier: cashierName,
                              payMethod: 'Potong Gaji (Gajian)',
                              catatan: 'Pelunasan Lunas 100%',
                              jumlahBayar: g.totalSettled,
                              totalTagihan: g.totalSettled,
                            })}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition shadow-xs cursor-pointer active:scale-95"
                            title="Cetak Slip Bukti Pelunasan Sah (Lunas)"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Cetak Bukti Lunas</span>
                          </button>

                          {onDeleteInvoice && (
                            <button
                              type="button"
                              onClick={() => setCustomerToDeleteLunas({
                                customer: g.customer,
                                invoices: g.settledInvoices,
                              })}
                              className="p-2 bg-stone-100 hover:bg-red-50 text-stone-600 hover:text-red-600 border border-stone-200 hover:border-red-200 rounded-xl transition cursor-pointer"
                              title="Hapus Seluruh Nota Lunas Karyawan Ini"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* VIEW 2: LOG SELURUH TRANSAKSI PELUNASAN */}
          {riwayatViewMode === 'semua_transaksi' && (
            <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs flex flex-col">
              <div className="p-3 bg-stone-50 border-b border-stone-200 flex items-center justify-between text-xs font-bold text-stone-700 shrink-0">
                <span>Daftar Log Transaksi Pelunasan Terperinci</span>
                <span className="text-stone-400 font-normal">Total: {allPelunasanHistory.length} Transaksi</span>
              </div>
              <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-420px)] min-h-[350px]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 z-10 shadow-xs">
                    <tr className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                      <th className="py-3 px-3.5 bg-stone-100">Waktu Pelunasan</th>
                      <th className="py-3 px-3 bg-stone-100">No. Invoice</th>
                      <th className="py-3 px-3 bg-stone-100">Karyawan / Pelanggan</th>
                      <th className="py-3 px-3 bg-stone-100">Kasir / Penerima</th>
                      <th className="py-3 px-3 bg-stone-100">Metode Pelunasan</th>
                      <th className="py-3 px-3 text-right bg-stone-100">Jumlah Dibayar</th>
                      <th className="py-3 px-3 text-right bg-stone-100">Sisa Akhir</th>
                      <th className="py-3 px-3 bg-stone-100">Catatan</th>
                      <th className="py-3 px-3.5 text-center bg-stone-100">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {allPelunasanHistory.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-12 text-center text-stone-400">
                          Belum ada catatan riwayat pelunasan.
                        </td>
                      </tr>
                    ) : (
                      allPelunasanHistory.map((h, idx) => {
                        const matchedInv = processedInvoices.find(
                          (i) => (i.invoiceNo || (i as any).noInvoice) === h.invoiceNo
                        );

                        return (
                          <tr key={idx} className="hover:bg-stone-50/80 transition">
                            <td className="py-2.5 px-3.5 font-semibold text-stone-800">
                              <div>{h.date}</div>
                              <div className="text-[10px] text-stone-400">{h.time}</div>
                            </td>
                            <td className="py-2.5 px-3 font-bold text-red-700">
                              {h.invoiceNo}
                            </td>
                            <td className="py-2.5 px-3 font-semibold text-stone-800">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span>{h.customerName || h.customer || '-'}</span>
                                {h.division && (
                                  <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                                    <Building2 className="w-2.5 h-2.5 text-blue-600" />
                                    <span>{h.division}</span>
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-stone-600">
                              {h.cashier || h.kasir || '-'}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-bold">
                                {h.payMethod || 'Potong Gaji'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right font-black text-emerald-700 font-mono">
                              {fRp(h.jumlahBayar)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-bold text-stone-600 font-mono">
                              {fRp(h.newSisa || 0)}
                            </td>
                            <td className="py-2.5 px-3 text-stone-500 italic text-[11px]">
                              {h.catatan || '-'}
                            </td>
                            <td className="py-2.5 px-3.5 text-center">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handlePrintBuktiLunasForHistory(h)}
                                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-black transition shadow-xs cursor-pointer active:scale-95"
                                  title="Cetak Slip Bukti Pelunasan Sah (Lunas)"
                                >
                                  <Printer className="w-3.5 h-3.5" />
                                  <span>Bukti Lunas</span>
                                </button>
                                {matchedInv && (matchedInv.isLunas || (matchedInv as any).calculatedSisa <= 0) && onDeleteInvoice && (
                                  <button
                                    type="button"
                                    onClick={() => setInvoiceToDelete(matchedInv)}
                                    className="p-1 hover:bg-red-50 text-stone-400 hover:text-red-600 rounded transition cursor-pointer"
                                    title="Hapus Nota Lunas Ini"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL: PROSES PELUNASAN (SINGLE ATAU BULK) */}
      {(pelunasanTarget || bulkSettleCustomer) && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150">
            {/* Modal Header */}
            <div className="bg-stone-900 text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <CheckCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="font-extrabold text-sm">
                  {bulkSettleCustomer 
                    ? `Pelunasan Gajian: ${bulkSettleCustomer.customer}` 
                    : `Pelunasan Nota: ${pelunasanTarget?.invoiceNo}`}
                </h3>
              </div>
              <button
                onClick={() => {
                  setPelunasanTarget(null);
                  setBulkSettleCustomer(null);
                }}
                className="p-1 text-stone-400 hover:text-white rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body (Scrollable) */}
            <div className="p-4 space-y-3.5 overflow-y-auto flex-1">
              {pelunasanSuccessMsg ? (
                <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto animate-bounce" />
                  <div className="font-extrabold text-base">{pelunasanSuccessMsg}</div>
                  <p className="text-xs text-emerald-600">Pencatatan pelunasan berhasil disimpan.</p>
                </div>
              ) : (
                <>
                  {/* Summary Box */}
                  <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 text-xs space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-stone-500 font-semibold">Nama Karyawan / Pemesan:</span>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <strong className="text-stone-900 text-sm">
                          {bulkSettleCustomer ? bulkSettleCustomer.customer : pelunasanTarget?.customer}
                        </strong>
                        {getCustomerDivision(bulkSettleCustomer ? bulkSettleCustomer.customer : pelunasanTarget?.customer) && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                            <Building2 className="w-2.5 h-2.5 text-blue-600" />
                            <span>{getCustomerDivision(bulkSettleCustomer ? bulkSettleCustomer.customer : pelunasanTarget?.customer)}</span>
                          </span>
                        )}
                      </div>
                    </div>
                    {bulkSettleCustomer && (
                      <div className="flex justify-between items-center">
                        <span className="text-stone-500 font-semibold">Jumlah Nota Diselesaikan:</span>
                        <strong className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 font-bold">
                          {bulkSettleCustomer.invoices.length} Nota Belanja
                        </strong>
                      </div>
                    )}
                    <div className="flex justify-between items-center border-t border-stone-200 pt-1.5 text-sm font-bold">
                      <span className="text-red-700">Total Tagihan Yang Harus Dilunasi:</span>
                      <span className="text-red-700 font-black font-mono text-base">
                        {fRp(bulkSettleCustomer ? bulkSettleCustomer.total : ((pelunasanTarget as any)?.calculatedSisa || pelunasanTarget?.sisa || pelunasanTarget?.total || 0))}
                      </span>
                    </div>
                  </div>

                  {/* RINCIAN ITEM YANG MAU DILUNASI */}
                  <div className="border border-amber-200 bg-amber-50/40 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-950">
                        <Package className="w-4 h-4 text-amber-600" />
                        <span>Rincian Item Barang Yang Mau Dilunasi:</span>
                      </div>
                      <span className="text-[10px] font-bold bg-amber-200/70 text-amber-900 px-2 py-0.5 rounded-full">
                        {bulkSettleCustomer 
                          ? `${bulkSettleCustomer.invoices.reduce((acc, i) => acc + (i.items?.length || 0), 0)} Item Barang`
                          : `${pelunasanTarget?.items?.length || 0} Item Barang`}
                      </span>
                    </div>

                    <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                      {bulkSettleCustomer ? (
                        bulkSettleCustomer.invoices.map((inv) => (
                          <div key={inv.invoiceNo} className="bg-white border border-stone-200 rounded-lg p-2 text-xs">
                            <div className="flex justify-between items-center font-bold text-stone-800 border-b border-stone-100 pb-1 mb-1">
                              <span className="text-red-700 font-mono">Nota: {inv.invoiceNo}</span>
                              <span className="text-stone-400 text-[10px] font-normal">{inv.date}</span>
                              <span className="text-red-600 font-mono font-bold">
                                {fRp((inv as any).calculatedSisa || inv.sisa || inv.total)}
                              </span>
                            </div>
                            <div className="space-y-1">
                              {(inv.items || []).map((it, idx) => (
                                <div key={idx} className="flex justify-between text-[11px] text-stone-600">
                                  <span className="truncate max-w-[200px]">{idx + 1}. {it.nama}</span>
                                  <span className="text-stone-400">{it.qty} {it.satuan || 'pcs'} × {fRp(it.harga)}</span>
                                  <span className="font-semibold text-stone-800 font-mono">
                                    {fRp(it.total || (it.qty * it.harga))}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="bg-white border border-stone-200 rounded-lg p-2 text-xs space-y-1">
                          {(pelunasanTarget?.items || []).map((it, idx) => (
                            <div key={idx} className="flex justify-between text-[11px] text-stone-600 py-0.5 border-b border-stone-50 last:border-0">
                              <span className="font-medium text-stone-800">{idx + 1}. {it.nama}</span>
                              <span className="text-stone-400">{it.qty} {it.satuan || 'pcs'} × {fRp(it.harga)}</span>
                              <span className="font-bold text-stone-900 font-mono">
                                {fRp(it.total || (it.qty * it.harga))}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Nominal Pelunasan Input */}
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Jumlah Uang Pelunasan (Rp) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={bayarNominal}
                      onChange={(e) => setBayarNominal(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-300 rounded-xl text-base font-black text-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Metode Pelunasan */}
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Metode Pelunasan
                    </label>
                    <select
                      value={bayarMetode}
                      onChange={(e) => setBayarMetode(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 bg-white"
                    >
                      <option value="Potong Gaji (Gajian)">📋 Potong Gaji (Payroll Bulanan)</option>
                      <option value="Tunai">💵 Tunai Langsung</option>
                      <option value="Transfer Bank">🏦 Transfer Bank</option>
                    </select>
                  </div>

                  {/* Catatan */}
                  <div>
                    <label className="text-[11px] font-bold text-stone-700 block mb-1">
                      Keterangan / Catatan Tambahan
                    </label>
                    <input
                      type="text"
                      value={bayarCatatan}
                      onChange={(e) => setBayarCatatan(e.target.value)}
                      placeholder="Contoh: Potong gaji periode Agustus 2026"
                      className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs bg-white text-stone-800"
                    />
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                    <button
                      onClick={() => {
                        setPelunasanTarget(null);
                        setBulkSettleCustomer(null);
                      }}
                      disabled={isProcessingPelunasan}
                      className="flex-1 py-2.5 px-3 border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-100 transition"
                    >
                      Batal
                    </button>
                    <button
                      onClick={handleSubmitPelunasan}
                      disabled={isProcessingPelunasan || !bayarNominal || parseFloat(bayarNominal) <= 0}
                      className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition shadow-xs disabled:opacity-50"
                    >
                      {isProcessingPelunasan ? 'Memproses...' : 'Simpan Pelunasan'}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DETAIL NOTA PREVIEW */}
      {viewInvoiceDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
            <div className="bg-stone-900 text-white p-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm">Rincian Nota: {viewInvoiceDetail.invoiceNo}</h3>
                <span className="text-[11px] text-stone-300">
                  {viewInvoiceDetail.date} • {viewInvoiceDetail.customer}
                  {viewInvoiceDetail.originalCustomer && viewInvoiceDetail.originalCustomer !== viewInvoiceDetail.customer && (
                    <span className="text-amber-300 ml-1 font-semibold">(Semula: "{viewInvoiceDetail.originalCustomer}")</span>
                  )}
                </span>
              </div>
              <button
                onClick={() => setViewInvoiceDetail(null)}
                className="p-1 text-stone-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3 flex-1">
              {viewInvoiceDetail.originalCustomer && viewInvoiceDetail.originalCustomer !== viewInvoiceDetail.customer && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Info Penyelarasan Pelanggan:</span> Nota transaksi ini awalnya dibuat atas nama <strong>"{viewInvoiceDetail.originalCustomer}"</strong>{viewInvoiceDetail.originalDivisi ? ` [Divisi: ${viewInvoiceDetail.originalDivisi}]` : ''}. Karena profil pelanggan diperbarui di master pelanggan, transaksi ini diselaraskan ke profil <strong>"{viewInvoiceDetail.customer}"</strong> agar total tagihannya tetap terakumulasi utuh.
                  </div>
                </div>
              )}
              <div className="border border-stone-200 rounded-xl overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-stone-100 font-bold text-stone-700">
                    <tr>
                      <th className="py-2 px-3">Item Barang</th>
                      <th className="py-2 px-2 text-center">Qty</th>
                      <th className="py-2 px-2 text-right">Harga</th>
                      <th className="py-2 px-3 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {(viewInvoiceDetail.items || []).map((item: any, idx: number) => {
                      const itemName = item.nama || item.name || item.namaBarang || item.menuName || 'Item';
                      const itemQty = item.qty || item.jumlah || 1;
                      const itemSatuan = item.satuan || 'pcs';
                      const itemHarga = Number(item.harga || item.price || 0);
                      const itemTotal = Number(item.total || (itemQty * itemHarga));
                      return (
                        <tr key={idx}>
                          <td className="py-2 px-3 font-semibold text-stone-800">{itemName}</td>
                          <td className="py-2 px-2 text-center">{itemQty} {itemSatuan}</td>
                          <td className="py-2 px-2 text-right">{fRp(itemHarga)}</td>
                          <td className="py-2 px-3 text-right font-bold text-stone-900">{fRp(itemTotal)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="bg-stone-50 rounded-xl p-3 space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-stone-500">Total Belanja:</span>
                  <span className="font-bold">{fRp(viewInvoiceDetail.total)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Metode Bayar:</span>
                  <span className="font-bold text-red-700">{viewInvoiceDetail.payMethod}</span>
                </div>
                <div className="flex justify-between border-t border-stone-200 pt-1 font-bold text-red-600">
                  <span>Sisa Piutang:</span>
                  <span className="text-sm">{fRp((viewInvoiceDetail as any).calculatedSisa || viewInvoiceDetail.sisa || 0)}</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-2">
              <div>
                {((viewInvoiceDetail as any).calculatedSisa <= 0 || String(viewInvoiceDetail.status).toUpperCase() === 'LUNAS') && onDeleteInvoice && (
                  <button
                    onClick={() => {
                      const target = viewInvoiceDetail;
                      setInvoiceToDelete(target);
                    }}
                    className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Nota</span>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewInvoiceDetail(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Tutup
                </button>
                {onReprintInvoice && (
                  <button
                    onClick={() => {
                      const target = viewInvoiceDetail;
                      setViewInvoiceDetail(null);
                      onReprintInvoice(target);
                    }}
                    className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Cetak Nota</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL CONFIRM DELETE INVOICE */}
      {invoiceToDelete && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150 border border-stone-200">
            <div className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900 mb-1">Hapus Nota Piutang</h3>
              <p className="text-xs text-stone-500 mb-2 leading-relaxed">
                Apakah Anda yakin ingin menghapus nota <strong className="text-stone-800">{invoiceToDelete.invoiceNo || invoiceToDelete.noInvoice}</strong> atas nama <strong className="text-stone-800">{invoiceToDelete.customer}</strong>?
                <span className="block mt-1 text-[11px] text-emerald-600 font-semibold">(Status: Lunas - Sisa Rp 0)</span>
              </p>
              <div className="mb-4 p-2 bg-emerald-50 border border-emerald-200/80 rounded-xl text-[11px] text-emerald-800 font-medium text-left flex items-start gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>Stok seluruh item barang pada nota ini akan otomatis dikembalikan ke katalog toko.</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setInvoiceToDelete(null)}
                  disabled={isDeleting}
                  className="flex-1 py-2.5 px-3 border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-100 transition disabled:opacity-50 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  disabled={isDeleting}
                  className="flex-1 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition shadow-xs disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {isDeleting ? (
                    <span>Menghapus...</span>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Ya, Hapus</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL EXPORT EXCEL SESUAI TEMPLATE WAKA */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl max-h-[92vh] flex flex-col border border-stone-200">
            {/* Modal Header */}
            <div className="bg-stone-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-600 rounded-xl text-white">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">Export Excel Belanja Karyawan</h3>
                  <p className="text-[11px] text-emerald-400">
                    Template disesuaikan persis dengan format import Excel sistem WAKA / ERVO
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 overflow-y-auto space-y-4 flex-1">
              {/* Export Configuration Controls */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                {/* Rentang Tanggal Rekap */}
                <div className="sm:col-span-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-bold text-stone-700">
                      Rentang Tanggal Rekap
                    </label>
                    <div className="flex items-center gap-1">
                      {(() => {
                        const d = new Date();
                        const todayStr = d.toISOString().split('T')[0];
                        const d6 = new Date();
                        d6.setDate(d6.getDate() - 6);
                        const past6Str = d6.toISOString().split('T')[0];
                        const d7 = new Date();
                        d7.setDate(d7.getDate() - 7);
                        const past7Str = d7.toISOString().split('T')[0];
                        const yyyy = d.getFullYear();
                        const mm = String(d.getMonth() + 1).padStart(2, '0');
                        const monthStartStr = `${yyyy}-${mm}-01`;

                        const isToday = exportStartDate === todayStr && exportEndDate === todayStr;
                        const is7Days = (exportStartDate === past6Str || exportStartDate === past7Str) && exportEndDate === todayStr;
                        const isMonth = exportStartDate === monthStartStr && exportEndDate === todayStr;
                        const isAll = !exportStartDate && !exportEndDate;

                        return (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate(todayStr);
                                setExportEndDate(todayStr);
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                isToday
                                  ? 'bg-emerald-600 text-white shadow-xs ring-1 ring-emerald-700/30'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              Hari Ini
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate(past6Str);
                                setExportEndDate(todayStr);
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                is7Days
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              7 Hari
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate(monthStartStr);
                                setExportEndDate(todayStr);
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                isMonth
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              Bulan Ini
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate('');
                                setExportEndDate('');
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                isAll
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              Semua Piutang
                            </button>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <input
                        type="date"
                        value={exportStartDate}
                        onChange={(e) => setExportStartDate(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        title="Tanggal Mulai"
                      />
                    </div>
                    <span className="text-xs font-bold text-stone-400">s/d</span>
                    <div className="flex-1">
                      <input
                        type="date"
                        value={exportEndDate}
                        onChange={(e) => setExportEndDate(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        title="Tanggal Selesai"
                      />
                    </div>
                  </div>
                </div>

                {/* Filter Divisi (Multi-Select & Deletable Tags) */}
                <div className="flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-bold text-stone-700 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Filter Divisi</span>
                      <span className="text-[10px] text-stone-400 font-normal">
                        (Bisa pilih lebih dari 1)
                      </span>
                    </label>
                    <div className="flex items-center gap-2">
                      {!isAllExportDivisions && (
                        <button
                          type="button"
                          onClick={resetExportDivisions}
                          className="text-[10px] font-extrabold text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
                        >
                          Pilih Semua
                        </button>
                      )}
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                        {isAllExportDivisions
                          ? `Semua (${availableExportDivisions.length})`
                          : `${exportDivisionFilters.length} Terpilih`}
                      </span>
                    </div>
                  </div>

                  {/* List of Available Division Toggles */}
                  <div className="flex flex-wrap gap-1.5 p-2 bg-white border border-stone-200 rounded-xl max-h-24 overflow-y-auto">
                    <button
                      type="button"
                      onClick={() => toggleExportDivision('ALL')}
                      className={`text-[11px] px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                        isAllExportDivisions
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      <span>Semua Divisi</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black ${
                        isAllExportDivisions
                          ? 'bg-emerald-800 text-emerald-100'
                          : 'bg-stone-200 text-stone-700'
                      }`}>
                        {availableExportDivisions.length}
                      </span>
                    </button>
                    {availableExportDivisions.map((div) => {
                      const isSelected = !isAllExportDivisions && exportDivisionFilters.includes(div);
                      return (
                        <button
                          key={div}
                          type="button"
                          onClick={() => toggleExportDivision(div)}
                          className={`text-[11px] px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                          <span>{div}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Active Division Badges / Deletable Tags Tray */}
              <div className="px-3.5 py-2.5 bg-emerald-50/70 border border-emerald-200/80 rounded-xl">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-950">
                    <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Divisi yang Masuk dalam Preview:</span>
                  </div>
                  {!isAllExportDivisions && (
                    <button
                      type="button"
                      onClick={resetExportDivisions}
                      className="text-[10px] font-extrabold text-emerald-800 hover:text-emerald-950 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <X className="w-3 h-3 stroke-[2.5]" />
                      <span>Hapus Semua Filter</span>
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  {isAllExportDivisions ? (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-white text-emerald-800 border border-emerald-300 shadow-2xs">
                      <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" />
                      <span>Semua Divisi ({availableExportDivisions.length} Divisi Aktif)</span>
                    </div>
                  ) : (
                    exportDivisionFilters.map((div) => (
                      <span
                        key={div}
                        className="inline-flex items-center gap-1.5 pl-2.5 pr-1 py-1 rounded-lg text-xs font-black bg-emerald-700 text-white shadow-xs border border-emerald-800 transition"
                      >
                        <span>{div}</span>
                        <button
                          type="button"
                          onClick={() => removeExportDivision(div)}
                          title={`Hapus divisi ${div} dari preview`}
                          className="w-4 h-4 rounded-md flex items-center justify-center bg-emerald-800 hover:bg-emerald-900 text-emerald-100 hover:text-white transition cursor-pointer ml-0.5"
                        >
                          <X className="w-2.5 h-2.5 stroke-[3]" />
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Scope Filter: Semua Nota Piutang vs Hanya Slip Terkunci */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 bg-stone-50 border border-stone-200 rounded-xl gap-2 text-xs">
                <span className="font-bold text-stone-700">Cakupan Data Excel:</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setExportOnlyLocked(false)}
                    className={`flex-1 sm:flex-none px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                      !exportOnlyLocked
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    Semua Nota Piutang ({rawExportRows.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setExportOnlyLocked(true)}
                    className={`flex-1 sm:flex-none px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                      exportOnlyLocked
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    Hanya Slip Terkunci
                  </button>
                </div>
              </div>

              {/* Selection Summary Bar */}
              <div className="flex items-center justify-between px-1 text-xs">
                <label className="flex items-center gap-2 font-bold text-stone-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={isAllExportSelected}
                    onChange={toggleSelectAllExport}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <span>Pilih Semua Transaksi ({selectedExportRows.length}/{rawExportRows.length} Terpilih)</span>
                </label>
                <div className="text-[11px] font-bold text-stone-500">
                  Total Belanja Terpilih: <span className="text-emerald-700 font-black font-mono">{fRp(selectedExportRows.reduce((sum, r) => sum + (r.total || r.nominal || 0), 0))}</span>
                </div>
              </div>

              {/* Live Preview Table */}
              <div className="border border-stone-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="bg-stone-800 text-stone-200 px-3 py-2 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Preview Format Excel: Rekap_WAKA_{exportStartDate === exportEndDate ? exportStartDate : `${exportStartDate}_sd_${exportEndDate}`}.xlsx</span>
                  </div>
                  <span className="text-[10px] bg-emerald-700/80 text-emerald-100 px-2.5 py-0.5 rounded-full font-sans font-bold">
                    Format Per Item & No. WA (8 Kolom)
                  </span>
                </div>
                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200 sticky top-0">
                      <tr>
                        <th className="py-2.5 px-3 border-r border-stone-200 text-center w-10 bg-stone-100">
                          <input
                            type="checkbox"
                            checked={isAllExportSelected}
                            onChange={toggleSelectAllExport}
                            className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                          />
                        </th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">No Nota</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">Nama Karyawan</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">No. WA</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">Tanggal</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">Item Barang</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 text-center bg-stone-100 w-14">Qty</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 text-right bg-stone-100">Harga Satuan</th>
                        <th className="py-2.5 px-3 text-right bg-stone-100">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono text-[11px]">
                      {rawExportRows.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="py-8 text-center text-stone-400 font-sans text-xs">
                            Tidak ada data transaksi terkunci pada filter dan rentang tanggal yang dipilih.
                          </td>
                        </tr>
                      ) : (
                        rawExportRows.map((row, idx) => {
                          const isSelected = !excludedExportCustomerKeys[row.rowId];
                          return (
                            <tr key={row.rowId || (row.name + idx)} className={`transition ${isSelected ? 'hover:bg-emerald-50/40' : 'bg-stone-50/70 opacity-40'}`}>
                              <td className="py-2 px-3 text-center border-r border-stone-100">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={(e) => {
                                    setExcludedExportCustomerKeys((prev) => ({
                                      ...prev,
                                      [row.rowId]: !e.target.checked,
                                    }));
                                  }}
                                  className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                                />
                              </td>
                              <td className="py-2 px-3 text-stone-700 font-mono font-medium border-r border-stone-100">{row.noNota || '-'}</td>
                              <td className="py-2 px-3 font-bold text-stone-900 border-r border-stone-100">{row.name}</td>
                              <td className="py-2 px-3 font-semibold text-stone-600 border-r border-stone-100">{row.phone || '-'}</td>
                              <td className="py-2 px-3 text-stone-600 border-r border-stone-100">{row.date}</td>
                              <td className="py-2 px-3 font-bold text-stone-800 border-r border-stone-100 font-sans">{row.itemName || '-'}</td>
                              <td className="py-2 px-3 text-center font-bold text-stone-700 border-r border-stone-100">{row.qty}</td>
                              <td className="py-2 px-3 text-right font-medium text-stone-700 border-r border-stone-100">
                                {Number(row.price || 0).toLocaleString('id-ID')}
                              </td>
                              <td className="py-2 px-3 text-right font-black text-emerald-700">
                                {Number(row.total || row.nominal || 0).toLocaleString('id-ID')}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-stone-50 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-[11px] text-stone-500 flex items-center gap-1.5">
                <span className="font-semibold">Nama File:</span>
                <span className="font-mono bg-stone-200 text-stone-800 px-2 py-0.5 rounded text-[10px]">
                  Rekap_WAKA_{exportStartDate === exportEndDate ? exportStartDate : `${exportStartDate}_sd_${exportEndDate}`}.xlsx
                </span>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setIsExportModalOpen(false)}
                  className="flex-1 sm:flex-initial px-4 py-2.5 border border-stone-300 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleDownloadExcel}
                  className="flex-1 sm:flex-initial px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download File Excel (.xlsx)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL CONFIRM DELETE ALL LUNAS INVOICES FOR CUSTOMER */}
      {customerToDeleteLunas && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150 border border-stone-200">
            <div className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900 mb-1">Hapus Semua Nota Lunas</h3>
              <p className="text-xs text-stone-500 mb-2 leading-relaxed">
                Apakah Anda yakin ingin menghapus <strong className="text-stone-800">{customerToDeleteLunas.invoices.length} nota yang telah LUNAS</strong> atas nama <strong className="text-stone-800">{customerToDeleteLunas.customer}</strong>?
                <span className="block mt-1 text-[11px] text-stone-400">Data nota yang dihapus akan dibersihkan dari sistem.</span>
              </p>
              <div className="mb-4 p-2 bg-emerald-50 border border-emerald-200/80 rounded-xl text-[11px] text-emerald-800 font-medium text-left flex items-start gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>Stok seluruh item barang pada nota-nota ini akan otomatis dikembalikan ke katalog toko.</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCustomerToDeleteLunas(null)}
                  disabled={isDeleting}
                  className="flex-1 py-2.5 px-3 border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-100 transition disabled:opacity-50 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeleteCustomerLunas}
                  disabled={isDeleting}
                  className="flex-1 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition shadow-xs disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {isDeleting ? (
                    <span>Menghapus...</span>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Ya, Hapus Semua</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
