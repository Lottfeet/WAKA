<?php
// ============================================================================
// WAKA API — Backend PHP/MySQL pengganti Firebase + Google Apps Script
// Upload seluruh folder ini ke public_html/api di cPanel.
// Endpoint: /api/<action> (GET & POST). Lihat README untuk daftar lengkap.
// ============================================================================

declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', '0');

if (!file_exists(__DIR__ . '/config.php')) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['success' => false, 'message' => 'config.php belum dibuat. Salin config.sample.php menjadi config.php dan isi kredensial MySQL.']);
  exit;
}
require __DIR__ . '/config.php';

// ---------- CORS & headers (hanya saat dijalankan via web) ----------
if (PHP_SAPI !== 'cli') {
  $origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
  header('Access-Control-Allow-Origin: ' . $origin);
  header('Vary: Origin');
  header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, X-Waka-Token');
  header('Cache-Control: no-store');
  header('Content-Type: application/json; charset=utf-8');
  if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }
}

// ---------- Koneksi DB ----------
function db(): PDO {
  static $pdo = null;
  if ($pdo === null) {
    try {
      $pdo = new PDO(
        'mysql:host=' . WAKA_DB_HOST . ';dbname=' . WAKA_DB_NAME . ';charset=utf8mb4',
        WAKA_DB_USER, WAKA_DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
      );
      $pdo->exec("SET SESSION sql_mode=''");
    } catch (Throwable $e) {
      if (PHP_SAPI === 'cli') throw new RuntimeException('Koneksi DB gagal: ' . $e->getMessage());
      http_response_code(500);
      echo json_encode(['success' => false, 'message' => 'Koneksi DB gagal: ' . $e->getMessage()]);
      exit;
    }
  }
  return $pdo;
}

// ---------- Helper ----------
function body(): array {
  static $b = null;
  if ($b === null) {
    $raw = file_get_contents('php://input');
    $d = json_decode($raw ?: '[]', true);
    $b = is_array($d) ? $d : [];
  }
  return $b;
}
function bval(string $k, $def = null) { return body()[$k] ?? $def; }
function q(string $name, $def = '') { return isset($_GET[$name]) ? trim((string)$_GET[$name]) : $def; }
function num($v): float { return is_numeric($v) ? (float)$v : 0.0; }
function js($v): ?string { return $v === null ? null : json_encode($v, JSON_UNESCAPED_UNICODE); }
function fromJs(?string $s) { if ($s === null || $s === '') return null; $d = json_decode($s, true); return $d === null ? null : $d; }
function ok($data = null, array $extra = []) { echo json_encode(array_merge(['success' => true], $extra, $data !== null && !isset($extra['data']) && !array_key_exists('data', $extra) ? ['data' => $data] : []), JSON_UNESCAPED_UNICODE); exit; }
function okx(array $payload) { echo json_encode(array_merge(['success' => true], $payload), JSON_UNESCAPED_UNICODE); exit; }
function fail(string $msg, int $code = 400) { http_response_code($code); echo json_encode(['success' => false, 'message' => $msg], JSON_UNESCAPED_UNICODE); exit; }

function invoiceRowToObj(array $r): array {
  $r['items'] = fromJs($r['items'] ?? null) ?? [];
  $r['auditLogs'] = fromJs($r['auditLogs'] ?? null) ?? [];
  $r['slipNo'] = $r['slipNo'] === null ? null : (int)$r['slipNo'];
  $r['slipPrinted'] = (bool)($r['slipPrinted'] ?? false);
  foreach (['subtotal','discPct','discAmt','taxPct','taxAmt','negoAmt','total','dp','sisa','kembalian'] as $f) $r[$f] = (float)$r[$f];
  return $r;
}

function recalcInvoiceSisa(PDO $pdo, string $invoiceNo): float {
  $inv = $pdo->prepare('SELECT total, dp, sisa, status FROM invoices WHERE invoiceNo=?');
  $inv->execute([$invoiceNo]); $row = $inv->fetch();
  if (!$row) return 0.0;
  $h = $pdo->prepare('SELECT COALESCE(SUM(jumlahBayar),0) s FROM pelunasan WHERE invoiceNo=?');
  $h->execute([$invoiceNo]); $histSum = (float)$h->fetchColumn();
  // historyPelunasan hanya berisi pelunasan SETELAH transaksi awal (di GAS juga begitu)
  $newSisa = max(0, round(((float)$row['total'] - (float)$row['dp']) - $histSum, 2));
  $status = $newSisa <= 0 ? 'LUNAS' : ((float)$row['dp'] > 0 ? 'DP' : 'TEMPO');
  $pdo->prepare('UPDATE invoices SET sisa=?, status=? WHERE invoiceNo=?')->execute([$newSisa, $status, $invoiceNo]);
  return $newSisa;
}

function adjustStock(PDO $pdo, string $kode, float $deltaQty): void {
  if ($kode === '' || $deltaQty == 0.0) return;
  $st = $pdo->prepare('SELECT stok FROM produk WHERE kode=?');
  $st->execute([$kode]); $row = $st->fetch();
  if (!$row) return;
  $cur = is_numeric($row['stok']) ? (float)$row['stok'] : 0.0;
  $new = $cur + $deltaQty;
  $s = rtrim(rtrim(number_format($new, 2, '.', ''), '0'), '.');
  $pdo->prepare('UPDATE produk SET stok=? WHERE kode=?')->execute([$s !== '' ? $s : '0', $kode]);
}

function logActivity(array $entry): void {
  try {
    $ts = isset($entry['timestamp']) ? (float)$entry['timestamp'] : microtime(true) * 1000;
    $id = $entry['id'] ?? ('LOG-' . (int)$ts . '-' . bin2hex(random_bytes(3)));
    $stmt = db()->prepare('REPLACE INTO activity_logs (id, ts, date, time, type, actor, title, description, metadata) VALUES (?,?,?,?,?,?,?,?,?)');
    $stmt->execute([
      substr((string)$id, 0, 96), (int)$ts,
      (string)($entry['date'] ?? ''), (string)($entry['time'] ?? ''),
      (string)($entry['type'] ?? ''), (string)($entry['actor'] ?? ''),
      substr((string)($entry['title'] ?? ''), 0, 255),
      (string)($entry['description'] ?? ''),
      js($entry['metadata'] ?? null),
    ]);
  } catch (Throwable $e) { /* jangan gagalkan request karena log */ }
}

// ---------- Router ----------
$action = $_GET['action'] ?? '';
if ($action === '' && !empty($_SERVER['PATH_INFO'])) {
  // mode skrip: /api/index.php/version -> PATH_INFO = /version
  $action = basename((string)$_SERVER['PATH_INFO']);
}
if ($action === '') {
  $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
  $scriptName = dirname($_SERVER['SCRIPT_NAME'] ?? ''); // mis. "/api" saat diakses via /api/
  if ($scriptName !== '/' && strpos($uri, $scriptName . '/') === 0) {
    $uri = substr($uri, strlen($scriptName));           // strip prefix folder API
  }
  $parts = explode('/', trim($uri, '/'));               // ["api","<action>"] atau ["index.php"]
  $action = end($parts);
  if ($action === 'api' || $action === 'index.php' || $action === '') $action = q('a');
}
// "GET:version" (bentuk ber-prefix method yang kadang dikirim proxy/browser lama) tetap dikenali
foreach ([':', '/'] as $__sep) {
  if ($action !== '' && strpos($action, $__sep) !== false) {
    $__tail = substr($action, strrpos($action, $__sep) + 1);
    if ($__tail !== '') { $action = $__tail; break; }
  }
}

// ---- Endpoint versi (tanpa DB): buka /api/version untuk memastikan file terbaru terpasang
// Deteksi robust: URI asli, PATH_INFO, maupun ?action=version (jika mod_rewrite tidak aktif)
if (!defined('WAKA_CLI')) {
  $isVersion = ($action === 'version');
  if (!$isVersion) {
    $reqPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    if ($reqPath && preg_match('#/version/?$#', $reqPath)) $isVersion = true;
  }
  if (!$isVersion && !empty($_SERVER['PATH_INFO']) && preg_match('#/version/?$#', $_SERVER['PATH_INFO'])) $isVersion = true;
  if ($isVersion) {
    header('Content-Type: application/json');
    echo json_encode(['app'=>'WARUNG KAKA','build'=>'2026.10.26-r9','api'=>'r9-full-data+total-replace-restore','time'=>date('c')]);
    exit;
  }
}

if (!defined('WAKA_CLI')) {
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
switch ("$method:$action") {

  // ======================= BOOTSTRAP / HEALTH =======================
  case 'GET:ping':
    okx(['message' => 'WAKA API OK', 'db' => db()->query('SELECT 1')->fetchColumn() == 1]);

  case 'GET:batch': // satu request untuk semua data awal (hemat quota & cepat)
    $pdo = db();
    $products = $pdo->query('SELECT * FROM produk ORDER BY nama')->fetchAll();
    foreach ($products as &$p) { $p['harga'] = (float)$p['harga']; $p['hargaBeli'] = (float)$p['hargaBeli']; }
    $customers = $pdo->query('SELECT * FROM pelanggan ORDER BY nama')->fetchAll();
    foreach ($customers as &$c) { $c['diskon'] = (float)$c['diskon']; $c['oldNames'] = fromJs($c['oldNames'] ?? null) ?? []; }
    $kasir = $pdo->query('SELECT * FROM kasir_users ORDER BY nama')->fetchAll();
    $s = $pdo->query('SELECT data FROM settings WHERE id=1')->fetch();
    $settings = $s ? (fromJs($s['data']) ?? []) : [];
    $recent = $pdo->query('SELECT * FROM invoices ORDER BY createdAt DESC, invoiceNo DESC LIMIT 1000000')->fetchAll();
    foreach ($recent as &$i) $i = invoiceRowToObj($i);
    $stockIn = $pdo->query('SELECT * FROM stok_masuk ORDER BY tanggal DESC, jam DESC, id DESC LIMIT 1000000')->fetchAll();
    foreach ($stockIn as &$sm) { $sm['qty'] = (float)$sm['qty']; $sm['hargaBeli'] = (float)$sm['hargaBeli']; $sm['date'] = $sm['tanggal']; $sm['time'] = $sm['jam']; }
    $expenses = $pdo->query('SELECT * FROM pengeluaran ORDER BY tanggal DESC, id DESC')->fetchAll();
    foreach ($expenses as &$ex) $ex['nominal'] = (float)$ex['nominal'];
    $opname = $pdo->query('SELECT * FROM stok_opname ORDER BY tanggal DESC, id DESC LIMIT 1000000')->fetchAll();
    foreach ($opname as &$op) { $op['items'] = fromJs($op['items'] ?? null) ?? []; }
    $logs = $pdo->query('SELECT * FROM activity_logs ORDER BY ts DESC LIMIT 100000')->fetchAll();
    foreach ($logs as &$l) { $l['timestamp'] = (float)$l['ts']; $l['metadata'] = fromJs($l['metadata'] ?? null); unset($l['ts']); }
    okx([
      'isBatchSupported' => true,
      'products' => $products, 'customers' => $customers, 'kasirUsers' => $kasir,
      'settings' => $settings, 'recentInvoices' => $recent, 'piutang' => piutangList(),
      'stockIn' => $stockIn, 'expenses' => $expenses, 'stockOpname' => $opname, 'activityLogs' => $logs,
    ]);

  // ======================= READ SINGLE RESOURCES =======================
  case 'GET:products':
    $rows = db()->query('SELECT * FROM produk ORDER BY nama')->fetchAll();
    foreach ($rows as &$p) { $p['harga'] = (float)$p['harga']; $p['hargaBeli'] = (float)$p['hargaBeli']; }
    ok($rows);

  case 'GET:customers':
    $rows = db()->query('SELECT * FROM pelanggan ORDER BY nama')->fetchAll();
    foreach ($rows as &$c) { $c['diskon'] = (float)$c['diskon']; $c['oldNames'] = fromJs($c['oldNames'] ?? null) ?? []; }
    ok($rows);

  case 'GET:kasir':
    ok(db()->query('SELECT * FROM kasir_users ORDER BY nama')->fetchAll());

  case 'GET:settings':
    $s = db()->query('SELECT data FROM settings WHERE id=1')->fetch();
    ok($s ? (fromJs($s['data']) ?? []) : []);

  case 'GET:invoices':
    $limit = max(1, min(1000000, (int)q('limit', 1000000)));
    $rows = db()->prepare('SELECT * FROM invoices ORDER BY createdAt DESC, invoiceNo DESC LIMIT ' . $limit);
    $rows->execute(); $list = $rows->fetchAll();
    foreach ($list as &$i) $i = invoiceRowToObj($i);
    ok($list);

  case 'GET:invoice':
    $no = q('invoiceNo');
    $st = db()->prepare('SELECT * FROM invoices WHERE invoiceNo=?');
    $st->execute([$no]); $row = $st->fetch();
    if (!$row) fail('Invoice tidak ditemukan', 404);
    $inv = invoiceRowToObj($row);
    $h = db()->prepare('SELECT * FROM pelunasan WHERE invoiceNo=? ORDER BY date, time');
    $h->execute([$no]); $hist = $h->fetchAll();
    foreach ($hist as &$x) { $x['jumlahBayar'] = (float)$x['jumlahBayar']; $x['sisaAwal'] = (float)$x['sisaAwal']; $x['newSisa'] = (float)$x['newSisa']; $x['kembalian'] = (float)$x['kembalian']; }
    $inv['historiPelunasan'] = $hist;
    ok($inv);

  case 'GET:piutang':
    ok(piutangList());

  case 'GET:stockIn':
    $rows = db()->query('SELECT * FROM stok_masuk ORDER BY tanggal DESC, jam DESC, id DESC LIMIT 5000')->fetchAll();
    foreach ($rows as &$r) { $r['qty'] = (float)$r['qty']; $r['hargaBeli'] = (float)$r['hargaBeli']; $r['date'] = $r['tanggal']; $r['time'] = $r['jam']; }
    ok($rows);

  case 'GET:expenses':
    $rows = db()->query('SELECT * FROM pengeluaran ORDER BY tanggal DESC, id DESC')->fetchAll();
    foreach ($rows as &$r) $r['nominal'] = (float)$r['nominal'];
    ok($rows);

  case 'GET:stockOpname':
    $rows = db()->query('SELECT * FROM stok_opname ORDER BY tanggal DESC, id DESC LIMIT 500')->fetchAll();
    foreach ($rows as &$r) $r['items'] = fromJs($r['items'] ?? null) ?? [];
    ok($rows);

  case 'GET:activityLogs':
    $limit = max(1, min(1000, (int)q('limit', 200)));
    $rows = db()->prepare('SELECT * FROM activity_logs ORDER BY ts DESC LIMIT ' . $limit);
    $rows->execute(); $list = $rows->fetchAll();
    foreach ($list as &$l) { $l['timestamp'] = (float)$l['ts']; $l['metadata'] = fromJs($l['metadata'] ?? null); unset($l['ts']); }
    ok($list);

  case 'GET:nextInvoiceNo':
    $invNo = nextInvoiceNumber(q('prefix', (string)(nextInvoicePrefix() ?? 'INV')));
    okx(['invoiceNo' => $invNo, 'data' => $invNo]);

  case 'GET:getRecentInvoices': // alias lama -> invoice terbaru
    $rows = db()->query('SELECT * FROM invoices ORDER BY createdAt DESC, invoiceNo DESC LIMIT 1000000')->fetchAll();
    foreach ($rows as &$i) $i = invoiceRowToObj($i);
    ok($rows);

  case 'GET:getPiutang': // alias lama -> daftar piutang
    ok(piutangList());

  // ======================= WRITE: INVOICE / TRANSAKSI =======================
  case 'POST:saveTransaction':
    $pdo = db();
    $p = bval('payload', body());
    if (!is_array($p)) fail('Payload transaksi tidak valid');
    $no = (string)($p['invoiceNo'] ?? '');
    if ($no === '') fail('invoiceNo wajib ada');
    $exists = $pdo->prepare('SELECT invoiceNo FROM invoices WHERE invoiceNo=?');
    $exists->execute([$no]);
    if ($exists->fetch()) okx(['message' => 'Invoice sudah tersimpan (idempotent)', 'invoiceNo' => $no, 'alreadyExists' => true]);

    $items = $p['items'] ?? [];
    // Opsi hemat stok: payload boleh mengirim updateStock/deductStock=false
    // (mis. saat menyimpan ulang invoice hasil pelunasan — stok tidak boleh berkurang dua kali).
    $deduct = true;
    foreach (['updateStock', 'deductStock'] as $flagKey) {
      if (array_key_exists($flagKey, $p)) $deduct = filter_var($p[$flagKey], FILTER_VALIDATE_BOOLEAN);
    }
    $noStr = trim((string)$no);
    if ($noStr !== '' && !preg_match('/^(ERV|INV|WKA|WK|TRX|JS|BON)/i', $noStr)) $deduct = false; // invoice non-POS tak menyentuh stok
    $pdo->beginTransaction();
    $st = $pdo->prepare('INSERT INTO invoices (invoiceNo,date,time,customer,cashier,subtotal,discPct,discAmt,taxPct,taxAmt,negoAmt,total,payMethod,dp,sisa,kembalian,deadline,status,slipNo,customerPhone,customerAddress,divisi,originalCustomer,originalDivisi,items,auditLogs)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $st->execute([
      $no, (string)($p['date'] ?? ''), (string)($p['time'] ?? ''), (string)($p['customer'] ?? ''),
      (string)($p['cashier'] ?? ''), num($p['subtotal'] ?? 0), num($p['discPct'] ?? 0), num($p['discAmt'] ?? 0),
      num($p['taxPct'] ?? 0), num($p['taxAmt'] ?? 0), num($p['negoAmt'] ?? 0), num($p['total'] ?? 0),
      (string)($p['payMethod'] ?? 'TUNAI'), num($p['dp'] ?? 0), num($p['sisa'] ?? 0), num($p['kembalian'] ?? 0),
      (string)($p['deadline'] ?? ''), (string)($p['status'] ?? 'LUNAS'),
      isset($p['slipNo']) && $p['slipNo'] !== '' && $p['slipNo'] !== null ? (int)$p['slipNo'] : null,
      (string)($p['customerPhone'] ?? ''), (string)($p['customerAddress'] ?? ''),
      (string)($p['divisi'] ?? ''), (string)($p['originalCustomer'] ?? ''), (string)($p['originalDivisi'] ?? ''),
      js($items), js($p['auditLogs'] ?? []),
    ]);
    // kurangi stok per item (hanya jika $deduct)
    if ($deduct) {
      foreach ($items as $it) {
        adjustStock($pdo, (string)($it['kode'] ?? ''), -num($it['qty'] ?? 0));
      }
    }
    // histori pelunasan bawaan payload (mis. import/edit)
    foreach (($p['historiPelunasan'] ?? []) as $idx => $h) {
      insertPelunasan($pdo, $no, $h, 'H-' . $no . '-' . $idx);
    }
    $pdo->commit();
    recalcInvoiceSisa($pdo, $no);
    logActivity([
      'type' => 'penjualan', 'actor' => (string)($p['cashier'] ?? ''),
      'date' => (string)($p['date'] ?? ''), 'time' => (string)($p['time'] ?? ''),
      'title' => 'Transaksi Baru ' . $no,
      'description' => count($items) . ' item untuk ' . ($p['customer'] ?: 'Umum'),
      'metadata' => ['invoiceNo' => $no, 'amount' => num($p['total'] ?? 0), 'customerName' => (string)($p['customer'] ?? ''), 'count' => count($items)],
    ]);
    okx(['message' => 'Transaksi tersimpan', 'invoiceNo' => $no]);

  case 'POST:updateInvoice':
    $pdo = db();
    $p = bval('invoice', bval('payload', body()));
    $no = (string)($p['invoiceNo'] ?? q('invoiceNo'));
    if ($no === '') fail('invoiceNo wajib ada');
    $st = $pdo->prepare('SELECT * FROM invoices WHERE invoiceNo=?');
    $st->execute([$no]); $old = $st->fetch();
    if (!$old) fail('Invoice tidak ditemukan', 404);

    $pdo->beginTransaction();
    // kembalikan stok lama, kurangi stok baru
    $oldItems = fromJs($old['items']) ?? [];
    foreach ($oldItems as $it) adjustStock($pdo, (string)($it['kode'] ?? ''), num($it['qty'] ?? 0));
    $newItems = $p['items'] ?? $oldItems;
    foreach ($newItems as $it) adjustStock($pdo, (string)($it['kode'] ?? ''), -num($it['qty'] ?? 0));

    $audit = fromJs($old['auditLogs']) ?? [];
    $audit[] = [
      'editedBy' => (string)($p['lastEditedBy'] ?? $p['editedBy'] ?? ''),
      'editedAt' => (string)($p['lastEditedAt'] ?? date('d/m/Y H:i')),
      'reason' => (string)($p['editReason'] ?? ''),
      'previousTotal' => (float)$old['total'],
      'previousDp' => (float)$old['dp'],
      'previousSisa' => (float)$old['sisa'],
      'previousCustomer' => (string)$old['customer'],
      'previousPayMethod' => (string)$old['payMethod'],
    ];
    $fields = [
      'date' => (string)($p['date'] ?? $old['date']), 'time' => (string)($p['time'] ?? $old['time']),
      'customer' => (string)($p['customer'] ?? $old['customer']), 'cashier' => (string)($p['cashier'] ?? $old['cashier']),
      'subtotal' => num($p['subtotal'] ?? $old['subtotal']), 'discPct' => num($p['discPct'] ?? $old['discPct']),
      'discAmt' => num($p['discAmt'] ?? $old['discAmt']), 'taxPct' => num($p['taxPct'] ?? $old['taxPct']),
      'taxAmt' => num($p['taxAmt'] ?? $old['taxAmt']), 'negoAmt' => num($p['negoAmt'] ?? $old['negoAmt']),
      'total' => num($p['total'] ?? $old['total']), 'payMethod' => (string)($p['payMethod'] ?? $old['payMethod']),
      'dp' => num($p['dp'] ?? $old['dp']), 'kembalian' => num($p['kembalian'] ?? $old['kembalian']),
      'deadline' => (string)($p['deadline'] ?? $old['deadline']), 'status' => (string)($p['status'] ?? $old['status']),
      'customerPhone' => (string)($p['customerPhone'] ?? $old['customerPhone']),
      'customerAddress' => (string)($p['customerAddress'] ?? $old['customerAddress']),
      'divisi' => (string)($p['divisi'] ?? $old['divisi']),
      'originalCustomer' => (string)($p['originalCustomer'] ?? $old['originalCustomer']),
      'originalDivisi' => (string)($p['originalDivisi'] ?? $old['originalDivisi']),
      'lastEditedBy' => (string)($p['lastEditedBy'] ?? ''), 'lastEditedAt' => (string)($p['lastEditedAt'] ?? ''),
      'editReason' => (string)($p['editReason'] ?? ''),
      'items' => js($newItems), 'auditLogs' => js($audit),
    ];
    $set = implode(',', array_map(fn($k) => "`$k`=?", array_keys($fields)));
    $pdo->prepare("UPDATE invoices SET $set WHERE invoiceNo=?")->execute(array_merge(array_values($fields), [$no]));
    $pdo->commit();
    recalcInvoiceSisa($pdo, $no);
    $upd = $pdo->prepare('SELECT sisa,status FROM invoices WHERE invoiceNo=?'); $upd->execute([$no]); $nr = $upd->fetch();
    okx(['message' => 'Invoice diperbarui', 'invoiceNo' => $no, 'sisa' => (float)$nr['sisa'], 'status' => $nr['status']]);

  case 'POST:deleteInvoice':
    $pdo = db();
    $no = (string)bval('invoiceNo', q('invoiceNo'));
    if ($no === '') fail('invoiceNo wajib ada');
    $st = $pdo->prepare('SELECT * FROM invoices WHERE invoiceNo=?');
    $st->execute([$no]); $old = $st->fetch();
    if (!$old) fail('Invoice tidak ditemukan', 404);
    $restore = filter_var(bval('restoreStock', true), FILTER_VALIDATE_BOOLEAN);
    $pdo->beginTransaction();
    if ($restore) {
      foreach ((fromJs($old['items']) ?? []) as $it) adjustStock($pdo, (string)($it['kode'] ?? ''), num($it['qty'] ?? 0));
    }
    $pdo->prepare('DELETE FROM pelunasan WHERE invoiceNo=?')->execute([$no]);
    $pdo->prepare('DELETE FROM invoices WHERE invoiceNo=?')->execute([$no]);
    $pdo->commit();
    logActivity([
      'type' => 'void_invoice', 'actor' => (string)bval('actor', ''),
      'date' => date('d/m/Y'), 'time' => date('H:i'),
      'title' => 'Invoice Dihapus: ' . $no,
      'description' => 'Total Rp' . number_format((float)$old['total'], 0, ',', '.') . ($restore ? ' (stok dikembalikan)' : ''),
      'metadata' => ['invoiceNo' => $no, 'amount' => (float)$old['total'], 'customerName' => (string)$old['customer']],
    ]);
    okx(['message' => 'Invoice dihapus', 'invoiceNo' => $no]);

  case 'POST:pelunasan':
    $pdo = db();
    $p = bval('payload', body());
    $no = (string)($p['invoiceNo'] ?? '');
    if ($no === '') fail('invoiceNo wajib ada');
    $st = $pdo->prepare('SELECT * FROM invoices WHERE invoiceNo=?');
    $st->execute([$no]); $inv = $st->fetch();
    if (!$inv) fail('Invoice tidak ditemukan', 404);
    // --- validasi field jumlahBayar ---
    if (!array_key_exists('jumlahBayar', $p)) fail('Field jumlahBayar wajib ada');
    $jbRaw = $p['jumlahBayar'];
    if (is_string($jbRaw)) $jbRaw = str_replace(['.', ','], ['', '.'], $jbRaw); // "50.000,00" → 50000
    if (!is_numeric($jbRaw)) fail('jumlahBayar harus berupa angka');
    $jb = round((float)$jbRaw);
    if ($jb <= 0) fail('jumlahBayar harus lebih dari 0');
    if ($jb > 1e12) fail('jumlahBayar tidak valid (melebihi batas)');
    // hitung ulang sisa terkini dari DB (bukan kolom yang mungkin basi) —
    // toleransi Rp 1000 untuk perbedaan pembulatan di sisi klien
    $sisaSaatIni = recalcInvoiceSisa($pdo, $no);
    if ($jb > $sisaSaatIni + 1000) fail('jumlahBayar (Rp' . number_format($jb, 0, ',', '.') . ') melebihi sisa tagihan (Rp' . number_format(max(0, $sisaSaatIni), 0, ',', '.') . ')');
    $id = (string)($p['id'] ?? ('PLN-' . time() . '-' . mt_rand(1000, 9999)));
    $st2 = $pdo->prepare('SELECT id FROM pelunasan WHERE id=?'); $st2->execute([$id]);
    if ($st2->fetch()) okx(['message' => 'Pelunasan sudah tercatat (idempotent)', 'invoiceNo' => $no, 'alreadyExists' => true]);
    $p['jumlahBayar'] = $jb; // simpan versi numerik yang sudah dinormalisasi
    $pdo->beginTransaction();
    insertPelunasan($pdo, $no, $p, $id);
    $pdo->commit();
    recalcInvoiceSisa($pdo, $no);
    $u = $pdo->prepare('SELECT sisa,status,total,customer FROM invoices WHERE invoiceNo=?'); $u->execute([$no]); $row = $u->fetch();
    $newSisa = (float)$row['sisa'];
    logActivity([
      'type' => 'pelunasan', 'actor' => (string)($p['cashier'] ?? ''),
      'date' => (string)($p['date'] ?? date('d/m/Y')), 'time' => (string)($p['time'] ?? date('H:i')),
      'title' => 'Pelunasan ' . $no,
      'description' => 'Bayar Rp' . number_format(num($p['jumlahBayar'] ?? 0), 0, ',', '.') . ' → sisa Rp' . number_format($newSisa, 0, ',', '.'),
      'metadata' => ['invoiceNo' => $no, 'customerName' => (string)$row['customer'], 'amount' => num($p['jumlahBayar'] ?? 0), 'payMethod' => (string)($p['payMethod'] ?? 'TUNAI')],
    ]);
    okx(['message' => 'Pelunasan tersimpan', 'invoiceNo' => $no, 'newSisa' => $newSisa, 'status' => $row['status'], 'alreadyLunas' => $newSisa <= 0]);

  // ======================= PRODUK =======================
  case 'POST:getInvoice': // versi POST dari GET:invoice (kompatibel dengan app lama)
    $no = (string)bval('invoiceNo', q('invoiceNo'));
    if ($no === '') fail('invoiceNo wajib ada');
    $st = db()->prepare('SELECT * FROM invoices WHERE invoiceNo=?');
    $st->execute([$no]); $row = $st->fetch();
    if (!$row) fail('Invoice tidak ditemukan', 404);
    $inv = invoiceRowToObj($row);
    $h = db()->prepare('SELECT * FROM pelunasan WHERE invoiceNo=? ORDER BY date, time');
    $h->execute([$no]); $hist = $h->fetchAll();
    foreach ($hist as &$x) { $x['jumlahBayar'] = (float)$x['jumlahBayar']; $x['sisaAwal'] = (float)$x['sisaAwal']; $x['newSisa'] = (float)$x['newSisa']; $x['kembalian'] = (float)$x['kembalian']; }
    $inv['historiPelunasan'] = $hist;
    ok($inv);

  case 'POST:init': // inisialisasi — tidak diperlukan di MySQL (schema sudah dibuat via phpMyAdmin)
    okx(['message' => 'Database MySQL WAKA aktif', 'sheetsInit' => false]);

  case 'POST:addProduct':
  case 'POST:updateProduct':
  case 'POST:saveProduct':
    $p = bval('product', body());
    $kode = trim((string)($p['kode'] ?? ''));
    if ($kode === '') fail('Kode produk wajib ada');
    $nama = (string)($p['nama'] ?? $kode);
    $harga = num($p['harga'] ?? 0);
    $hpp = num($p['hargaBeli'] ?? $p['hpp'] ?? 0);
    $pdo = db();
    $ex = $pdo->prepare('SELECT kode FROM produk WHERE kode=?'); $ex->execute([$kode]);
    $isEdit = (bool)$ex->fetch();
    if ($isEdit) {
      $old = $pdo->prepare('SELECT * FROM produk WHERE kode=?'); $old->execute([$kode]); $o = $old->fetch();
      $changes = [];
      if ((float)$o['harga'] !== $harga) $changes[] = 'harga ' . rtrim(rtrim(number_format((float)$o['harga'], 0, '.', ''), '0'), '.') . '→' . rtrim(rtrim(number_format($harga, 0, '.', ''), '0'), '.');
      if ((string)$o['stok'] !== (string)($p['stok'] ?? $o['stok'])) $changes[] = 'stok ' . $o['stok'] . '→' . ($p['stok'] ?? '');
      $pdo->prepare('UPDATE produk SET nama=?, harga=?, hargaBeli=?, kategori=?, stok=?, satuan=?, tipeHarga=? WHERE kode=?')
        ->execute([$nama, $harga, $hpp, (string)($p['kategori'] ?? ''), (string)($p['stok'] ?? '0'), (string)($p['satuan'] ?? 'pcs'), (string)($p['tipeHarga'] ?? 'fix'), $kode]);
      if ($changes) logActivity([
        'type' => $o['harga'] != $harga ? 'edit_harga' : 'tambah_produk', 'actor' => (string)bval('actor', ''),
        'date' => date('d/m/Y'), 'time' => date('H:i'),
        'title' => 'Edit Produk ' . $nama, 'description' => implode(', ', $changes),
        'metadata' => ['productCode' => $kode, 'productName' => $nama, 'oldValue' => $o['harga'], 'newValue' => $harga, 'changes' => $changes],
      ]);
    } else {
      $pdo->prepare('INSERT INTO produk (kode,nama,harga,hargaBeli,kategori,stok,satuan,tipeHarga) VALUES (?,?,?,?,?,?,?,?)')
        ->execute([$kode, $nama, $harga, $hpp, (string)($p['kategori'] ?? ''), (string)($p['stok'] ?? '0'), (string)($p['satuan'] ?? 'pcs'), (string)($p['tipeHarga'] ?? 'fix')]);
      logActivity([
        'type' => 'tambah_produk', 'actor' => (string)bval('actor', ''),
        'date' => date('d/m/Y'), 'time' => date('H:i'),
        'title' => 'Produk Baru: ' . $nama, 'description' => 'Kode ' . $kode . ' Rp' . number_format($harga, 0, ',', '.'),
        'metadata' => ['productCode' => $kode, 'productName' => $nama, 'newValue' => $harga],
      ]);
    }
    okx(['message' => 'Produk tersimpan']);

  case 'POST:deleteProduct':
    $kode = (string)bval('kode', q('kode'));
    if ($kode === '') fail('kode wajib ada');
    $st = db()->prepare('SELECT * FROM produk WHERE kode=?'); $st->execute([$kode]); $o = $st->fetch();
    if (!$o) fail('Produk tidak ditemukan', 404);
    db()->prepare('DELETE FROM produk WHERE kode=?')->execute([$kode]);
    logActivity([
      'type' => 'hapus_produk', 'actor' => (string)bval('actor', ''),
      'date' => date('d/m/Y'), 'time' => date('H:i'),
      'title' => 'Produk Dihapus: ' . $o['nama'], 'description' => 'Kode ' . $kode,
      'metadata' => ['productCode' => $kode, 'productName' => (string)$o['nama'], 'oldValue' => (float)$o['harga']],
    ]);
    okx(['message' => 'Produk dihapus']);

  // ======================= PELANGGAN =======================
  case 'POST:addCustomer':
  case 'POST:updateCustomer':
  case 'POST:saveCustomer':
    $c = bval('customer', body());
    $nama = trim((string)($c['nama'] ?? ''));
    if ($nama === '') fail('Nama pelanggan wajib ada');
    $oldName = (string)bval('oldName', '');
    $pdo = db();
    if ($oldName !== '' && $oldName !== $nama) {
      $st = $pdo->prepare('SELECT * FROM pelanggan WHERE nama=?'); $st->execute([$oldName]); $prev = $st->fetch();
      if ($prev) {
        $oldNames = fromJs($prev['oldNames']) ?? [];
        $oldNames[] = $oldName;
        $pdo->prepare('DELETE FROM pelanggan WHERE nama=?')->execute([$oldName]);
        $st->execute([$nama]); $dup = $st->fetch();
        if ($dup) { $oldNames = array_values(array_unique(array_merge(fromJs($dup['oldNames']) ?? [], $oldNames))); $pdo->prepare('DELETE FROM pelanggan WHERE nama=?')->execute([$nama]); }
        $pdo->prepare('INSERT INTO pelanggan (nama,kelas,divisi,diskon,telepon,catatan,alamat,oldNames) VALUES (?,?,?,?,?,?,?,?)')
          ->execute([$nama, (string)($c['kelas'] ?? 'Umum'), (string)($c['divisi'] ?? $c['division'] ?? ''), num($c['diskon'] ?? 0),
            (string)($c['telepon'] ?? ''), (string)($c['catatan'] ?? ''), (string)($c['alamat'] ?? ''), js($oldNames)]);
        $pdo->prepare('UPDATE invoices SET customer=? WHERE customer=?')->execute([$nama, $oldName]);
        $pdo->prepare('UPDATE pelunasan SET customer=? WHERE customer=?')->execute([$nama, $oldName]);
        logActivity([
          'type' => 'edit_pelanggan', 'actor' => (string)bval('actor', ''),
          'date' => date('d/m/Y'), 'time' => date('H:i'),
          'title' => 'Pelanggan Diubah: ' . $oldName . ' → ' . $nama, 'description' => 'Termasuk riwayat invoice',
          'metadata' => ['customerName' => $nama, 'oldValue' => $oldName, 'newValue' => $nama],
        ]);
        okx(['message' => 'Pelanggan disimpan', 'customer' => $c]);
      }
    }
    $st = $pdo->prepare('SELECT oldNames FROM pelanggan WHERE nama=?'); $st->execute([$nama]); $ex = $st->fetch();
    $oldNames = $ex ? (fromJs($ex['oldNames']) ?? []) : [];
    $pdo->prepare('REPLACE INTO pelanggan (nama,kelas,divisi,diskon,telepon,catatan,alamat,oldNames) VALUES (?,?,?,?,?,?,?,?)')
      ->execute([$nama, (string)($c['kelas'] ?? 'Umum'), (string)($c['divisi'] ?? $c['division'] ?? ''), num($c['diskon'] ?? 0),
        (string)($c['telepon'] ?? ''), (string)($c['catatan'] ?? ''), (string)($c['alamat'] ?? ''), js($oldNames)]);
    okx(['message' => 'Pelanggan disimpan', 'customer' => $c]);

  case 'POST:deleteCustomer':
    $nama = (string)bval('nama', bval('customerName', q('nama')));
    if ($nama === '') fail('Nama pelanggan wajib ada');
    db()->prepare('DELETE FROM pelanggan WHERE nama=?')->execute([$nama]);
    okx(['message' => 'Pelanggan dihapus']);

  // ======================= KASIR / AUTH =======================
  case 'POST:saveKasir':
  case 'POST:updatePassword':
    $u = bval('user', body());
    $nama = trim((string)($u['nama'] ?? bval('nama', '')));
    if ($nama === '') fail('Nama kasir wajib ada');
    $pass = (string)($u['password'] ?? bval('password', ''));
    $role = (string)($u['role'] ?? bval('role', 'kasir'));
    $pdo = db();
    $st = $pdo->prepare('SELECT * FROM kasir_users WHERE nama=?'); $st->execute([$nama]); $ex = $st->fetch();
    if ($ex && $pass === '') $pass = (string)$ex['password'];
    $pdo->prepare('REPLACE INTO kasir_users (nama,password,role) VALUES (?,?,?)')->execute([$nama, $pass, $role]);
    okx(['message' => 'Kasir tersimpan']);

  case 'POST:deleteKasir':
    $nama = (string)bval('nama', q('nama'));
    if ($nama === '') fail('Nama kasir wajib ada');
    db()->prepare('DELETE FROM kasir_users WHERE nama=?')->execute([$nama]);
    okx(['message' => 'Kasir dihapus']);

  // ======================= SETTINGS =======================
  case 'POST:saveSettings':
    $s = bval('settings', body());
    if (!is_array($s)) fail('Settings tidak valid');
    $pdo = db();
    $cur = $pdo->query('SELECT data FROM settings WHERE id=1')->fetch();
    $merged = array_merge(fromJs($cur['data'] ?? null) ?? [], $s);
    $pdo->prepare('REPLACE INTO settings (id,data) VALUES (1,?)')->execute([js($merged)]);
    okx(['message' => 'Pengaturan tersimpan']);

  // ======================= STOK MASUK / OPNAME =======================
  case 'POST:addStockIn':
  case 'POST:saveStockIn':
    $r = bval('record', body());
    $id = (string)($r['id'] ?? ('SM-' . time() . '-' . mt_rand(100, 999)));
    $kode = (string)($r['kode'] ?? $r['kodeProduct'] ?? '');
    $qty = num($r['qty'] ?? $r['jumlahMasuk'] ?? 0);
    $tanggal = (string)($r['tanggal'] ?? $r['date'] ?? date('d/m/Y'));
    $jam = (string)($r['jam'] ?? $r['time'] ?? date('H:i'));
    $pdo = db();
    $ex = $pdo->prepare('SELECT id FROM stok_masuk WHERE id=?'); $ex->execute([$id]);
    if ($ex->fetch()) okx(['message' => 'Barang masuk sudah tercatat (idempotent)', 'alreadyExists' => true]);
    $pdo->beginTransaction();
    $pdo->prepare('INSERT INTO stok_masuk (id,kode,nama,qty,hargaBeli,satuan,supplier,cashier,tanggal,jam,catatan) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$id, $kode, (string)($r['nama'] ?? $r['namaProduct'] ?? ''), $qty, num($r['hargaBeli'] ?? 0),
        (string)($r['satuan'] ?? ''), (string)($r['supplier'] ?? ''), (string)($r['cashier'] ?? ''), $tanggal, $jam,
        (string)($r['catatan'] ?? '')]);
    $doStock = filter_var(bval('updateProductStock', true), FILTER_VALIDATE_BOOLEAN);
    if ($doStock) adjustStock($pdo, $kode, $qty);
    $pdo->commit();
    logActivity([
      'type' => 'barang_masuk', 'actor' => (string)($r['cashier'] ?? ''),
      'date' => $tanggal, 'time' => $jam,
      'title' => 'Barang Masuk: ' . ($r['nama'] ?? $kode),
      'description' => rtrim(rtrim(number_format($qty, 2, '.', ''), '0'), '.') . ' ' . ($r['satuan'] ?? '') . ' dari ' . ($r['supplier'] ?? '-'),
      'metadata' => ['productCode' => $kode, 'productName' => (string)($r['nama'] ?? ''), 'qty' => $qty],
    ]);
    okx(['message' => 'Barang masuk tersimpan', 'id' => $id]);

  case 'POST:deleteStockIn':
    $id = (string)bval('id', q('id'));
    if ($id === '') fail('id wajib ada');
    $pdo = db();
    $st = $pdo->prepare('SELECT * FROM stok_masuk WHERE id=?'); $st->execute([$id]); $r = $st->fetch();
    if (!$r) fail('Data tidak ditemukan', 404);
    $pdo->beginTransaction();
    if (filter_var(bval('revertStock', false), FILTER_VALIDATE_BOOLEAN)) adjustStock($pdo, (string)$r['kode'], -(float)$r['qty']);
    $pdo->prepare('DELETE FROM stok_masuk WHERE id=?')->execute([$id]);
    $pdo->commit();
    okx(['message' => 'Barang masuk dihapus']);

  case 'POST:clearStockIn':
    db()->exec('DELETE FROM stok_masuk');
    okx(['message' => 'Riwayat barang masuk dibersihkan', 'count' => 0]);

  case 'POST:stockOpname':
  case 'POST:saveStockOpname':
    $rec = bval('record', body());
    $id = (string)($rec['id'] ?? ('OPN-' . date('Ym') . '-' . mt_rand(100, 999)));
    $pdo = db();
    $pdo->beginTransaction();
    $pdo->prepare('REPLACE INTO stok_opname (id,tanggal,jam,bulanPeriode,petugas,penanggungJawab,totalItemDihitung,totalItemSesuai,totalItemSelisihKurang,totalItemSelisihLebih,totalNilaiSelisihKurang,totalNilaiSelisihLebih,totalNilaiSelisih,catatanUmum,items)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$id, (string)($rec['tanggal'] ?? date('d/m/Y')), (string)($rec['jam'] ?? date('H:i')),
        (string)($rec['bulanPeriode'] ?? ''), (string)($rec['petugas'] ?? ''), (string)($rec['penanggungJawab'] ?? ''),
        (int)($rec['totalItemDihitung'] ?? 0), (int)($rec['totalItemSesuai'] ?? 0),
        (int)($rec['totalItemSelisihKurang'] ?? 0), (int)($rec['totalItemSelisihLebih'] ?? 0),
        num($rec['totalNilaiSelisihKurang'] ?? 0), num($rec['totalNilaiSelisihLebih'] ?? 0),
        num($rec['totalNilaiSelisih'] ?? 0), (string)($rec['catatanUmum'] ?? ''), js($rec['items'] ?? [])]);
    // terapkan selisih ke stok sistem
    foreach (($rec['items'] ?? []) as $it) {
      $selisih = num($it['selisih'] ?? 0);
      if ($selisih != 0 && isset($it['stokFisik'])) {
        $st = $pdo->prepare('SELECT stok FROM produk WHERE kode=?'); $st->execute([(string)$it['kode']]); $row = $st->fetch();
        if ($row) {
          $s = rtrim(rtrim(number_format(num($it['stokFisik']), 2, '.', ''), '0'), '.');
          $pdo->prepare('UPDATE produk SET stok=? WHERE kode=?')->execute([$s !== '' ? $s : '0', (string)$it['kode']]);
        }
      }
    }
    $pdo->commit();
    logActivity([
      'type' => 'stok_opname', 'actor' => (string)($rec['petugas'] ?? ''),
      'date' => (string)($rec['tanggal'] ?? date('d/m/Y')), 'time' => (string)($rec['jam'] ?? date('H:i')),
      'title' => 'Stok Opname ' . ($rec['bulanPeriode'] ?? $id),
      'description' => ($rec['totalItemDihitung'] ?? 0) . ' item dihitung, selisih Rp' . number_format(num($rec['totalNilaiSelisih'] ?? 0), 0, ',', '.'),
      'metadata' => ['count' => (int)($rec['totalItemDihitung'] ?? 0), 'amount' => num($rec['totalNilaiSelisih'] ?? 0)],
    ]);
    okx(['message' => 'Opname tersimpan', 'id' => $id]);

  case 'POST:deleteStockOpname':
    $id = (string)bval('id', q('id'));
    if ($id === '') fail('id wajib ada');
    db()->prepare('DELETE FROM stok_opname WHERE id=?')->execute([$id]);
    okx(['message' => 'Opname dihapus']);

  // ======================= PENGELUARAN =======================
  case 'POST:addExpense':
  case 'POST:saveExpense':
    $e = bval('expense', body());
    $id = (string)($e['id'] ?? ('EXP-' . time() . '-' . mt_rand(100, 999)));
    db()->prepare('REPLACE INTO pengeluaran (id,tanggal,kategori,keterangan,nominal,pj,buktiRef) VALUES (?,?,?,?,?,?,?)')
      ->execute([$id, (string)($e['tanggal'] ?? date('Y-m-d')), (string)($e['kategori'] ?? ''),
        (string)($e['keterangan'] ?? ''), num($e['nominal'] ?? 0), (string)($e['pj'] ?? ''), (string)($e['buktiRef'] ?? '')]);
    okx(['message' => 'Pengeluaran tersimpan', 'id' => $id]);

  case 'POST:deleteExpense':
    $id = (string)bval('id', q('id'));
    if ($id === '') fail('id wajib ada');
    db()->prepare('DELETE FROM pengeluaran WHERE id=?')->execute([$id]);
    okx(['message' => 'Pengeluaran dihapus']);

  // ======================= ACTIVITY LOG =======================
  case 'POST:logActivity':
    logActivity(bval('entry', body()));
    okx(['message' => 'Log tersimpan']);

  // ======================= IMPORT BACKUP JSON =======================
  case 'POST:importBackup':
    $token = (string)bval('token', $_SERVER['HTTP_X_WAKA_TOKEN'] ?? '');
    if ($token !== WAKA_IMPORT_TOKEN) fail('Token import salah / tidak diberikan. Periksa window.__WAKA_IMPORT_TOKEN__ di index.html dan WAKA_IMPORT_TOKEN di api/config.php.', 403);
    $b = body();
    // VALIDASI FORMAT: minimal harus ada satu koleksi berisi data.
    // Mencegah status "sukses" palsu ketika frontend mengirim payload kosong/rusak.
    $collections = ['produk','pelanggan','kasirUsers','invoices','pengeluaran','stokMasuk','stokOpname','activityLogs'];
    $incomingRows = 0;
    foreach ($collections as $ck) { if (isset($b[$ck]) && is_array($b[$ck])) $incomingRows += count($b[$ck]); }
    $hasSettings = isset($b['pengaturan']) || isset($b['settings']);
    if ($incomingRows === 0 && !$hasSettings) {
      fail('Payload import kosong / format tidak dikenali. Pastikan file backup JSON dimuat dengan benar sebelum menekan Pulihkan.', 400);
    }
    @set_time_limit(0);
    // mode 'replace' (restore): hapus total dulu agar database PERSIS sama
    // dengan file backup — tidak ada baris sisa dari import sebelumnya
    // (mis. invoice/user yang sudah dihapus di sumber backup).
    $replaceMode = !empty($b['replace']) || strtolower((string)bval('mode', '')) === 'replace';
    $counts = doImport($b, $replaceMode);
    // VALIDASI KEDUA: server melapor sukses tapi 0 baris tertulis -> tolak.
    $written = array_sum(array_map(fn($v) => (int)$v, $counts));
    $targetDb = defined('WAKA_DB_NAME') ? WAKA_DB_NAME : '?';
    if ($written === 0) {
      fail('Import berjalan tetapi 0 baris tersimpan ke database (DB: ' . $targetDb . '). Kemungkinan besar struktur JSON tidak dikenali — gunakan import via terminal (api/import_cli.php) atau periksa format backup.', 500);
    }
    if ($replaceMode) {
      // VALIDASI KETIGA (anti selisih jumlah): bandingkan jumlah baris DI DATABASE
      // setelah restore dengan jumlah yang seharusnya menurut payload. Kalau ada
      // selisih (mis. baris rusak dilewati), tampilkan audit lengkap agar mudah
      // diperiksa dan tidak lagi muncul "sukses" yang angkanya misterius.
      $expect = [
        'produk' => isset($b['data']['produk']) ? count($b['data']['produk']) : (isset($b['produk']) && is_array($b['produk']) ? count($b['produk']) : null),
        'pelanggan' => isset($b['data']['pelanggan']) ? count($b['data']['pelanggan']) : (isset($b['pelanggan']) && is_array($b['pelanggan']) ? count($b['pelanggan']) : null),
        'kasir_users' => isset($b['data']['kasirUsers']) ? count($b['data']['kasirUsers']) : (isset($b['kasirUsers']) && is_array($b['kasirUsers']) ? count($b['kasirUsers']) : null),
        'invoices' => isset($b['data']['invoices']) ? count($b['data']['invoices']) : (isset($b['invoices']) && is_array($b['invoices']) ? count($b['invoices']) : null),
      ];
      $dbCount = function (string $t) { try { return (int)db()->query('SELECT COUNT(*) FROM `' . $t . '`')->fetchColumn(); } catch (Throwable $e) { return -1; } };
      $audit = [];
      foreach ($expect as $tbl => $exp) {
        if ($exp === null) continue;
        $act = $dbCount($tbl);
        $audit[$tbl] = ['harusnya' => $exp, 'diDatabase' => $act];
      }
      okx([
        'message' => 'Restore selesai (penggantian total database): ' . number_format($written) . ' baris tersimpan ke database `' . $targetDb . '`',
        'database' => $targetDb,
        'counts' => $counts,
        'migratedCounts' => $counts,
        'audit' => $audit,
      ]);
    }
    // DIAGNOSTIK: sertakan DB tujuan agar pengguna bisa mencocokkan dengan nama
    // database yang dibuka di phpMyAdmin (mencegah "sukses tapi tabel kosong"
    // karena config menunjuk ke database lain).
    okx([
      'message' => 'Import selesai: ' . number_format($written) . ' baris tersimpan ke database `' . $targetDb . '`',
      'database' => $targetDb,
      'counts' => $counts,
      'migratedCounts' => $counts,
    ]);

  default:
    fail('Endpoint tidak dikenal: ' . $method . ':' . $action, 404);
}
} catch (Throwable $e) {
  if (db()->inTransaction()) { try { db()->rollBack(); } catch (Throwable $x) {} }
  fail('Server error: ' . $e->getMessage(), 500);
}

} // end web-router guard

// ============================================================================
// Fungsi bantu tambahan
// ============================================================================


function insertPelunasan(PDO $pdo, string $no, array $h, string $id): void {
  $pdo->prepare('REPLACE INTO pelunasan (id,invoiceNo,date,time,customer,cashier,payMethod,jumlahBayar,sisaAwal,newSisa,kembalian,status,catatan) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
    ->execute([
      $id, $no, (string)($h['date'] ?? ''), (string)($h['time'] ?? ''),
      (string)($h['customer'] ?? ''), (string)($h['cashier'] ?? $h['kasir'] ?? ''),
      (string)($h['payMethod'] ?? 'TUNAI'), num($h['jumlahBayar'] ?? 0), num($h['sisaAwal'] ?? 0),
      num($h['newSisa'] ?? 0), num($h['kembalian'] ?? 0), (string)($h['status'] ?? ''), (string)($h['catatan'] ?? ''),
    ]);
}

function piutangList(): array {
  $rows = db()->query("SELECT i.*, (SELECT COALESCE(SUM(jumlahBayar),0) FROM pelunasan p WHERE p.invoiceNo=i.invoiceNo) AS histSum FROM invoices i WHERE i.status<>'LUNAS' OR i.sisa>0 ORDER BY i.deadline, i.date")->fetchAll();
  $out = [];
  foreach ($rows as $r) {
    $hist = db()->prepare('SELECT * FROM pelunasan WHERE invoiceNo=? ORDER BY date,time');
    $hist->execute([$r['invoiceNo']]); $hs = $hist->fetchAll();
    foreach ($hs as &$x) { $x['jumlahBayar'] = (float)$x['jumlahBayar']; $x['sisaAwal'] = (float)$x['sisaAwal']; $x['newSisa'] = (float)$x['newSisa']; $x['kembalian'] = (float)$x['kembalian']; }
    $out[] = [
      'invoiceNo' => $r['invoiceNo'], 'date' => $r['date'], 'customer' => $r['customer'],
      'total' => (float)$r['total'], 'dp' => (float)$r['dp'], 'sisa' => (float)$r['sisa'],
      'deadline' => $r['deadline'], 'status' => $r['status'], 'cashier' => $r['cashier'],
      'historiPelunasan' => $hs,
    ];
  }
  return $out;
}

function nextInvoicePrefix(): ?string {
  try {
    $s = db()->query('SELECT data FROM settings WHERE id=1')->fetch();
    if ($s) { $d = fromJs($s['data']) ?? []; if (!empty($d['prefixInvoice'])) return (string)$d['prefixInvoice']; }
  } catch (Throwable $e) { /* abaikan */ }
  return null;
}

function nextInvoiceNumber(string $prefix): array|string {
  $pdo = db();
  $yr = (int)date('Y');
  $pdo->prepare('INSERT IGNORE INTO invoice_seq (prefix,yr,seq) VALUES (?,?,0)')->execute([$prefix, $yr]);
  // seed dari invoice yang ada agar tidak bentrok dengan data hasil import
  $mx = $pdo->prepare("SELECT MAX(CAST(SUBSTRING_INDEX(invoiceNo,'-',-1) AS UNSIGNED)) m FROM invoices WHERE invoiceNo LIKE ? AND date LIKE ?");
  $mx->execute([$prefix . '-%', '%' . $yr]);
  $maxFromInv = (int)($mx->fetchColumn() ?: 0);
  $pdo->prepare('UPDATE invoice_seq SET seq=GREATEST(seq,?) WHERE prefix=? AND yr=?')->execute([$maxFromInv, $prefix, $yr]);
  $pdo->prepare('UPDATE invoice_seq SET seq=seq+1 WHERE prefix=? AND yr=?')->execute([$prefix, $yr]);
  $st = $pdo->prepare('SELECT seq FROM invoice_seq WHERE prefix=? AND yr=?');
  $st->execute([$prefix, $yr]); $seq = (int)$st->fetchColumn();
  return $prefix . '-' . $yr . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
}

function doImport(array $backup, bool $replaceMode = false): array {
  // Backup JSON dari app mendukung format bersarang: { data: { produk: [...], ... } }.
  if (isset($backup['data']) && is_array($backup['data'])) {
    $inner = $backup['data'];
    if (isset($backup['pengaturan'])) $inner['pengaturan'] = $backup['pengaturan'];
    elseif (isset($inner['toko'])) $inner['pengaturan'] = $inner['toko'];
    if (!empty($backup['replace'])) $inner['replace'] = true; // teruskan flag mode replace
    $backup = $inner;
  }
  $pdo = db();
  $counts = [];
  $ucFirst = function (string $s): string { return $s === '' ? $s : strtoupper(substr($s, 0, 1)) . substr($s, 1); };
  $get = function (string $k) use ($backup, $ucFirst) {
    foreach ([$k, strtolower($k), $ucFirst($k)] as $c) if (isset($backup[$c]) && is_array($backup[$c])) return $backup[$c];
    return [];
  };

  // Penghapusan total (mode replace) ditunda ke sini, SETELAH payload divalidasi
  // dan koleksi dikenali — supaya file rusak/tidak dikenal tidak menghapus data.
  if ($replaceMode) {
    $trunc = ['produk','pelanggan','kasir_users','invoices','pelunasan','pengeluaran',
               'stok_masuk','stok_opname','activity_logs'];
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    foreach ($trunc as $t) $pdo->exec('TRUNCATE TABLE `' . $t . '`');
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
  }

  // pengaturan (objek tunggal ATAU array berisi objek)
  $sett = $backup['pengaturan'] ?? $backup['settings'] ?? null;
  if (is_array($sett)) {
    $one = isset($sett['name']) || isset($sett['data']) ? ($sett['data'] ?? $sett) : ($sett[0] ?? null);
    if (is_array($one)) { $pdo->prepare('REPLACE INTO settings (id,data) VALUES (1,?)')->execute([js($one)]); $counts['settings'] = 1; }
  }

  // (catatan: pemetaan koleksi sudah di-handle per-blok di bawah)

  // ---- produk ----
  foreach ($get('produk') as $p) {
    if (!isset($p['kode'])) continue;
    $pdo->prepare('REPLACE INTO produk (kode,nama,harga,hargaBeli,kategori,stok,satuan,tipeHarga) VALUES (?,?,?,?,?,?,?,?)')
      ->execute([(string)$p['kode'], (string)($p['nama'] ?? ''), num($p['harga'] ?? 0), num($p['hargaBeli'] ?? $p['hpp'] ?? 0),
        (string)($p['kategori'] ?? ''), (string)($p['stok'] ?? '0'), (string)($p['satuan'] ?? 'pcs'), (string)($p['tipeHarga'] ?? 'fix')]);
    $counts['produk'] = ($counts['produk'] ?? 0) + 1;
  }

  // ---- pelanggan ----
  foreach ($get('pelanggan') as $c) {
    if (!isset($c['nama'])) continue;
    $pdo->prepare('REPLACE INTO pelanggan (nama,kelas,divisi,diskon,telepon,catatan,alamat,oldNames) VALUES (?,?,?,?,?,?,?,?)')
      ->execute([(string)$c['nama'], (string)($c['kelas'] ?? 'Umum'), (string)($c['divisi'] ?? $c['division'] ?? ''), num($c['diskon'] ?? 0),
        (string)($c['telepon'] ?? ''), (string)($c['catatan'] ?? ''), (string)($c['alamat'] ?? ''), js($c['oldNames'] ?? [])]);
    $counts['pelanggan'] = ($counts['pelanggan'] ?? 0) + 1;
  }

  // ---- kasir ----
  foreach ($get('kasirUsers') as $k) {
    if (!isset($k['nama'])) continue;
    $pdo->prepare('REPLACE INTO kasir_users (nama,password,role) VALUES (?,?,?)')
      ->execute([(string)$k['nama'], (string)($k['password'] ?? ''), (string)($k['role'] ?? 'kasir')]);
    $counts['kasirUsers'] = ($counts['kasirUsers'] ?? 0) + 1;
  }

  // ---- invoices (+ histori pelunasan inline) ----
  $seqMax = [];
  foreach ($get('invoices') as $inv) {
    $no = (string)($inv['invoiceNo'] ?? $inv['noInvoice'] ?? '');
    if ($no === '') continue;
    // lewati baris rusak dari aplikasi lama (nomor invoice belum terisi, mis. "Memuat...")
    if (strpos($no, '...') !== false || stripos($no, 'memuat') !== false || stripos($no, 'loading') !== false) { $counts['invoicesDilewati'] = ($counts['invoicesDilewati'] ?? 0) + 1; continue; }
    $items = $inv['items'] ?? [];
    $hist = $inv['historiPelunasan'] ?? $inv['pelunasanHistory'] ?? [];
    $pdo->prepare('REPLACE INTO invoices (invoiceNo,date,time,customer,cashier,subtotal,discPct,discAmt,taxPct,taxAmt,negoAmt,total,payMethod,dp,sisa,kembalian,deadline,status,slipNo,slipPrinted,slipPrintedAt,customerPhone,customerAddress,originalCustomer,originalDivisi,divisi,lastEditedBy,lastEditedAt,editReason,items,auditLogs)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([
        $no, (string)($inv['date'] ?? ''), (string)($inv['time'] ?? ''),
        (string)($inv['customer'] ?? $inv['pelanggan'] ?? ''), (string)($inv['cashier'] ?? ''),
        num($inv['subtotal'] ?? 0), num($inv['discPct'] ?? 0), num($inv['discAmt'] ?? 0),
        num($inv['taxPct'] ?? 0), num($inv['taxAmt'] ?? 0), num($inv['negoAmt'] ?? 0), num($inv['total'] ?? 0),
        (string)($inv['payMethod'] ?? $inv['metodePembayaran'] ?? 'TUNAI'), num($inv['dp'] ?? 0), num($inv['sisa'] ?? 0), num($inv['kembalian'] ?? 0),
        (string)($inv['deadline'] ?? ''), (string)($inv['status'] ?? 'LUNAS'),
        isset($inv['slipNo']) && $inv['slipNo'] !== '' && $inv['slipNo'] !== null ? (int)$inv['slipNo'] : null,
        (int)(bool)($inv['slipPrinted'] ?? false), (string)($inv['slipPrintedAt'] ?? ''),
        (string)($inv['customerPhone'] ?? ''), (string)($inv['customerAddress'] ?? ''),
        (string)($inv['originalCustomer'] ?? ''), (string)($inv['originalDivisi'] ?? ''), (string)($inv['divisi'] ?? $inv['division'] ?? ''),
        (string)($inv['lastEditedBy'] ?? ''), (string)($inv['lastEditedAt'] ?? ''), (string)($inv['editReason'] ?? ''),
        js($items), js($inv['auditLogs'] ?? []),
      ]);
    foreach ($hist as $idx => $h) insertPelunasan($pdo, $no, is_array($h) ? $h : [], 'IMP-' . $no . '-' . $idx);
    // catat seq maksimum per prefix+tahun agar nomor invoice baru tidak bentrok
    if (preg_match('/^(.*)-(\d{4})-(\d+)$/', $no, $m)) {
      $key = $m[1] . '|' . (int)$m[2];
      $seqMax[$key] = max($seqMax[$key] ?? 0, (int)$m[3]);
    }
    $counts['invoices'] = ($counts['invoices'] ?? 0) + 1;
    if ($hist) $counts['pelunasan'] = ($counts['pelunasan'] ?? 0) + count($hist);
  }

  // ---- pengeluaran ----
  foreach ($get('pengeluaran') as $e) {
    $id = (string)($e['id'] ?? ('IMP-EXP-' . md5(json_encode($e))));
    $pdo->prepare('REPLACE INTO pengeluaran (id,tanggal,kategori,keterangan,nominal,pj,buktiRef) VALUES (?,?,?,?,?,?,?)')
      ->execute([$id, (string)($e['tanggal'] ?? ''), (string)($e['kategori'] ?? ''), (string)($e['keterangan'] ?? ''),
        num($e['nominal'] ?? 0), (string)($e['pj'] ?? ''), (string)($e['buktiRef'] ?? '')]);
    $counts['pengeluaran'] = ($counts['pengeluaran'] ?? 0) + 1;
  }

  // ---- stok masuk ----
  foreach ($get('stokMasuk') as $r) {
    $id = (string)($r['id'] ?? ('IMP-SM-' . md5(json_encode($r))));
    $pdo->prepare('REPLACE INTO stok_masuk (id,kode,nama,qty,hargaBeli,satuan,supplier,cashier,tanggal,jam,catatan) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$id, (string)($r['kode'] ?? $r['kodeProduct'] ?? ''), (string)($r['nama'] ?? $r['namaProduct'] ?? ''),
        num($r['qty'] ?? $r['jumlahMasuk'] ?? 0), num($r['hargaBeli'] ?? 0), (string)($r['satuan'] ?? ''),
        (string)($r['supplier'] ?? ''), (string)($r['cashier'] ?? ''),
        (string)($r['tanggal'] ?? $r['date'] ?? ''), (string)($r['jam'] ?? $r['time'] ?? ''), (string)($r['catatan'] ?? '')]);
    $counts['stokMasuk'] = ($counts['stokMasuk'] ?? 0) + 1;
  }

  // ---- stok opname ----
  foreach ($get('stokOpname') as $o) {
    $id = (string)($o['id'] ?? ('IMP-OPN-' . md5(json_encode($o))));
    $pdo->prepare('REPLACE INTO stok_opname (id,tanggal,jam,bulanPeriode,petugas,penanggungJawab,totalItemDihitung,totalItemSesuai,totalItemSelisihKurang,totalItemSelisihLebih,totalNilaiSelisihKurang,totalNilaiSelisihLebih,totalNilaiSelisih,catatanUmum,items) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$id, (string)($o['tanggal'] ?? ''), (string)($o['jam'] ?? ''), (string)($o['bulanPeriode'] ?? ''),
        (string)($o['petugas'] ?? ''), (string)($o['penanggungJawab'] ?? ''),
        (int)($o['totalItemDihitung'] ?? 0), (int)($o['totalItemSesuai'] ?? 0),
        (int)($o['totalItemSelisihKurang'] ?? 0), (int)($o['totalItemSelisihLebih'] ?? 0),
        num($o['totalNilaiSelisihKurang'] ?? 0), num($o['totalNilaiSelisihLebih'] ?? 0),
        num($o['totalNilaiSelisih'] ?? 0), (string)($o['catatanUmum'] ?? ''), js($o['items'] ?? [])]);
    $counts['stokOpname'] = ($counts['stokOpname'] ?? 0) + 1;
  }

  // ---- activity logs ----
  foreach ($get('activityLogs') as $l) {
    $id = (string)($l['id'] ?? ('IMP-LOG-' . md5(json_encode($l))));
    $ts = (float)($l['timestamp'] ?? 0);
    $pdo->prepare('REPLACE INTO activity_logs (id,ts,date,time,type,actor,title,description,metadata) VALUES (?,?,?,?,?,?,?,?,?)')
      ->execute([substr($id, 0, 96), (int)$ts, (string)($l['date'] ?? ''), (string)($l['time'] ?? ''),
        (string)($l['type'] ?? ''), (string)($l['actor'] ?? ''), substr((string)($l['title'] ?? ''), 0, 255),
        (string)($l['description'] ?? ''), js($l['metadata'] ?? null)]);
    $counts['activityLogs'] = ($counts['activityLogs'] ?? 0) + 1;
  }

  // ---- seed invoice_seq dari nomor invoice hasil import ----
  foreach ($seqMax as $key => $mx) {
    [$pfx, $y] = explode('|', $key);
    $pdo->prepare('INSERT INTO invoice_seq (prefix,yr,seq) VALUES (?,?,?) ON DUPLICATE KEY UPDATE seq=GREATEST(seq,VALUES(seq))')
      ->execute([$pfx, (int)$y, (int)$mx]);
  }

  return $counts;
}
