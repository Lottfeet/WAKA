import { Invoice, StoreSettings, PelunasanRecord, StockOpnameRecord, Product } from '../types';
import { fRp, fNum, fDec, escHtml, computeItemTotal } from './formatters';
import { getPelunasanHistory, sortPelunasanHistoryAsc } from '../services/gasService';

function resolveHistoryList(data: Partial<Invoice>): PelunasanRecord[] {
  const invoiceNo = data.invoiceNo || '';
  const backendHist = Array.isArray((data as any).historiPelunasan)
    ? (data as any).historiPelunasan
    : Array.isArray((data as any).history)
    ? (data as any).history
    : null;

  const rawList: PelunasanRecord[] = backendHist !== null 
    ? backendHist 
    : (invoiceNo ? getPelunasanHistory(invoiceNo) : []);

  const sorted = sortPelunasanHistoryAsc(rawList);

  const totalInvoice = Number(data.total || 0);
  const totalPelunasan = sorted.reduce((acc, item) => acc + Number(item.jumlahBayar || 0), 0);
  const sisaVal = data.sisa !== undefined ? Number(data.sisa) : totalInvoice;
  const calculatedDp = Math.max(0, totalInvoice - sisaVal - totalPelunasan);
  const dpAmount = (data.dp !== undefined && Number(data.dp) > 0) ? Number(data.dp) : calculatedDp;

  let currentBalance = Math.max(0, totalInvoice - dpAmount);

  return sorted.map((hItem) => {
    const bayar = Number(hItem.jumlahBayar || 0);
    currentBalance = Math.max(0, currentBalance - bayar);
    return {
      ...hItem,
      newSisa: currentBalance,
    };
  });
}

export function calculateCurrentSisa(data: Partial<Invoice>): number {
  const historyItems = resolveHistoryList(data);
  if (historyItems.length > 0) {
    const last = historyItems[historyItems.length - 1];
    return last.newSisa !== undefined ? last.newSisa : 0;
  }
  const total = Number(data.total || 0);
  const dp = Number(data.dp || 0);
  if (data.sisa !== undefined && data.sisa !== null) {
    return Number(data.sisa);
  }
  return Math.max(0, total - dp);
}

export function openPrintWindow(htmlContent: string, title: string) {
  const win = window.open('', '_blank', 'width=800,height=750');
  if (!win) {
    alert('Pop-up terblokir oleh browser. Izinkan pop-up untuk mencetak struk/invoice.');
    return;
  }

  const fullContent = htmlContent.includes('<html')
    ? htmlContent
    : `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>${escHtml(title)}</title>
<style>
  @page { size: 80mm auto; margin: 2mm; }
  @media print { body { margin: 0; width: 80mm; } }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { width: 80mm; font-family: 'Courier New', Courier, monospace; font-size: 10px; color: #000; line-height: 1.4; padding: 2mm; }
  .center { text-align: center; }
  .r { text-align: right; }
  .bold { font-weight: bold; }
  table { width: 100%; border-collapse: collapse; }
</style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

  win.document.write(fullContent);
  win.document.close();
  win.focus();
  setTimeout(() => {
    try {
      win.print();
    } catch {
      // Ignored
    }
  }, 500);
}

export function generateThermalHTML(data: Partial<Invoice>, s: StoreSettings): string {
  if (!data || !data.items || data.items.length === 0) {
    return `<div style="text-align:center;padding:30px 10px;color:#78716C;">
      <div style="font-size:24px;margin-bottom:8px;">🧾</div>
      <p style="font-size:10px;">Tambahkan jasa/produk untuk melihat preview struk</p>
    </div>`;
  }

  let h = '';
  h += `<div style="text-align:center;font-weight:800;font-size:13px;letter-spacing:1px;text-transform:uppercase;">${escHtml(s.name)}</div>`;
  if (s.address) h += `<div style="text-align:center;font-size:9px;font-weight:600;margin-top:2px;">${escHtml(s.address)}</div>`;
  if (s.phone) h += `<div style="text-align:center;font-size:9px;font-weight:600;margin-top:1px;">Telp/WA: ${escHtml(s.phone)}</div>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
      <tr><td style="width:60px;">No</td><td>: ${escHtml(data.invoiceNo || '')}</td></tr>
      <tr><td>Tgl</td><td>: ${escHtml(data.date || '')} ${escHtml(data.time || '')}</td></tr>
      <tr><td>Kasir</td><td>: ${escHtml(data.cashier || s.cashier || 'Admin')}</td></tr>
      <tr><td>Pelanggan</td><td>: ${escHtml(data.customer || 'Umum')}</td></tr>
      ${data.deadline ? `<tr><td>Est Selesai</td><td>: ${escHtml(data.deadline)}</td></tr>` : ''}
  </table>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="width:60%;">Jasa/Item</td><td style="width:15%;text-align:right;">Qty</td><td style="width:25%;text-align:right;">Total</td></tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">`;
  
  data.items.forEach((item) => {
    const total = item.totalItem !== undefined ? item.totalItem : computeItemTotal(item);
    const nameShort = String(item.nama || '').substring(0, 100);
    const hasDim = parseFloat(item.panjang as any) > 0 && parseFloat(item.lebar as any) > 0;
    const sizeStr = hasDim ? ` (${fDec(item.panjang, 2)}x${fDec(item.lebar, 2)}m)` : '';
    h += `<tr><td style="width:60%;padding:1px 0;vertical-align:top;">${escHtml(nameShort)}${escHtml(sizeStr)}</td><td style="width:15%;text-align:right;padding:1px 0;vertical-align:top;">${fDec(item.qty, 2).replace(/\.?0+$/, '')}</td><td style="width:25%;text-align:right;padding:1px 0;vertical-align:top;">${fNum(total)}</td></tr>`;

    const diskon = parseFloat(item.diskonItem as any) || 0;
    const hargaAsli = parseFloat(item.harga as any) || 0;
    const hargaJadi = Math.max(0, hargaAsli - diskon);
    const satuanLabel = hasDim ? '/m²' : `/${item.satuan || 'pcs'}`;

    const subParts: string[] = [];
    if (diskon > 0) {
      subParts.push(`@${fNum(hargaAsli)}<span style="color:#B91C1C;"> -${fNum(diskon)}</span> =${fNum(hargaJadi)}${satuanLabel}`);
    } else {
      subParts.push(`@${fNum(hargaJadi)}${satuanLabel}`);
    }
    if (item.bahan) subParts.push(escHtml(item.bahan));
    if (item.catatan) subParts.push(escHtml(item.catatan));
    h += `<tr><td colspan="3" style="font-size:9px;padding:0 0 3px 3px;color:#444;">${subParts.join(' · ')}</td></tr>`;
  });

  h += `</table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
      <tr><td>Subtotal</td><td style="text-align:right;">${fNum(data.subtotal || 0)}</td></tr>
      ${(data.discAmt || 0) > 0 ? `<tr><td>Diskon ${data.discPct || 0}%</td><td style="text-align:right;">-${fNum(data.discAmt!)}</td></tr>` : ''}
      ${(data.negoAmt || 0) > 0 ? `<tr><td>Nego / Potongan</td><td style="text-align:right;">-${fNum(data.negoAmt!)}</td></tr>` : ''}
      ${(data.taxAmt || 0) > 0 ? `<tr><td>PPN ${data.taxPct || 0}%</td><td style="text-align:right;">${fNum(data.taxAmt!)}</td></tr>` : ''}
  </table>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:5px 0;"></div>';
  h += `<table style="font-size:11px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="font-size:12px;">TOTAL</td><td style="text-align:right;font-size:12px;">${fNum(data.total || 0)}</td></tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;">
      <tr style="font-weight:bold;"><td>DP / Bayar Muka (${escHtml(data.payMethod || (data as any).metodePembayaran || 'Tunai')})</td><td style="text-align:right;">${fNum(data.dp || 0)}</td></tr>
      <tr style="font-weight:bold;"><td>Sisa Bayar</td><td style="text-align:right;color:${(calculateCurrentSisa(data)) > 0 ? '#B91C1C' : '#15803D'};">${fNum(calculateCurrentSisa(data))}</td></tr>
      ${(data.kembalian || 0) > 0 ? `<tr style="font-weight:bold;"><td style="color:#15803D;">Kembalian</td><td style="text-align:right;color:#15803D;">${fNum(data.kembalian!)}</td></tr>` : ''}
  </table>`;

  const rekeningVal = s.rekening || '';
  if (rekeningVal) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div style="text-align:center;font-size:8.5px;font-weight:bold;margin-top:2px;">REKENING PEMBAYARAN:</div>`;
    h += `<div style="text-align:center;font-size:8.5px;font-weight:bold;white-space:pre-line;">${escHtml(rekeningVal)}</div>`;
  }

  const historyItems = resolveHistoryList(data);
  if (historyItems.length > 0) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div style="text-align:center;font-weight:bold;font-size:10px;margin:3px 0;letter-spacing:0.5px;">HISTORI PEMBAYARAN & ANGSURAN</div>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:3px 0;"></div>';
    h += `<table style="font-size:9px;width:100%;border-collapse:collapse;">`;
    h += `<tr><td style="font-weight:bold;">1. DP / Bayar Muka (${escHtml(data.payMethod || (data as any).metodePembayaran || 'Tunai')})</td><td style="text-align:right;font-weight:bold;">${fNum(data.dp || 0)}</td></tr>`;
    h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${escHtml(data.date || '')} ${escHtml(data.time || '')}</td></tr>`;

    historyItems.forEach((hItem, idx) => {
      h += `<tr><td style="font-weight:bold;">${idx + 2}. Angsuran #${idx + 1} (${escHtml(hItem.payMethod || 'Tunai')})</td><td style="text-align:right;font-weight:bold;">${fNum(hItem.jumlahBayar || 0)}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${escHtml(hItem.date || '')} ${escHtml(hItem.time || '')} · Sisa: ${fNum(hItem.newSisa !== undefined ? hItem.newSisa : 0)}${hItem.catatan ? ` (${escHtml(hItem.catatan)})` : ''}</td></tr>`;
    });

    h += `</table>`;
  }

  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  if (s.footer) h += `<div style="text-align:center;font-weight:bold;font-size:11px;margin-top:6px;">${escHtml(s.footer)}</div>`;
  return h;
}

export function generateA5HTML(data: Partial<Invoice>, s: StoreSettings): string {
  const orderDateStr = data.date || '';
  const deadlineStr = data.deadline || '';
  const customer = data.customer || 'Umum';
  const sisa = calculateCurrentSisa(data);

  const phoneVal = data.customerPhone ? escHtml(data.customerPhone) : '';
  const addressVal = data.customerAddress ? escHtml(data.customerAddress) : '';

  let contactAndAddress = '';
  if (phoneVal && addressVal) {
    contactAndAddress = `${phoneVal} &bull; ${addressVal}`;
  } else if (phoneVal) {
    contactAndAddress = phoneVal;
  } else if (addressVal) {
    contactAndAddress = addressVal;
  } else {
    contactAndAddress = '<span style="color:#999;">—</span>';
  }

  let rows = '';
  (data.items || []).forEach((item, i) => {
    const total = item.totalItem !== undefined ? item.totalItem : computeItemTotal(item);
    const hasDim = parseFloat(item.panjang as any) > 0 && parseFloat(item.lebar as any) > 0;
    const ukuranStr = hasDim ? `${fDec(item.panjang, 2)} × ${fDec(item.lebar, 2)} m` : '-';
    const areaStr = hasDim ? `${fDec(parseFloat(item.panjang as any) * parseFloat(item.lebar as any), 2)} m²` : '-';
    const diskonItemAmt = parseFloat(item.diskonItem as any) || 0;
    const hargaCell = diskonItemAmt > 0
      ? `${fNum(item.harga || 0)}<br><span style="color:#B91C1C;font-size:8px;">-${fNum(diskonItemAmt)}</span>`
      : `${fNum(item.harga || 0)}`;

    rows += `<tr>
        <td class="tc">${i + 1}</td>
        <td><strong>${escHtml(item.nama || '')}</strong></td>
        <td>${escHtml(ukuranStr)}</td>
        <td>${escHtml(areaStr)}</td>
        <td class="tc">${fDec(item.qty, 2).replace(/\.?0+$/, '')}</td>
        <td>${escHtml(item.satuan || '')}</td>
        <td>${escHtml(item.bahan || '-')}</td>
        <td>${escHtml(item.catatan || '-')}</td>
        <td class="tr">${hargaCell}</td>
        <td class="tr bold">${fNum(total)}</td>
    </tr>`;
  });

  const historyItems = resolveHistoryList(data);
  const dpAmount = Number(data.dp || 0);
  const hasHistory = dpAmount > 0 || historyItems.length > 0;

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Invoice ${escHtml(data.invoiceNo || '')}</title>
<style>
    @page { size: A5 landscape; margin: 8mm; }
    @media print { body { margin:0; } }
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size:10px; color:#1a1a1a; }
    .page { width:100%; }
    .inv-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; padding-bottom:8px; border-bottom:2.5px solid #C2410C; }
    .inv-brand .bname { font-size:18px; font-weight:800; color:#C2410C; letter-spacing:0.5px; }
    .inv-brand .bsub { font-size:9px; color:#555; margin-top:2px; }
    .inv-title-block { text-align:right; }
    .inv-title { font-size:20px; font-weight:800; color:#C2410C; letter-spacing:1px; }
    .inv-no { font-size:9px; color:#555; margin-top:2px; }
    .inv-info { display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-bottom:8px; }
    .inv-info-box { background:#FFF7ED; border:1px solid #FED7AA; border-radius:6px; padding:5px 8px; }
    .inv-info-box-split { display:flex; gap:8px; align-items:stretch; }
    .split-col { flex:1; min-width:0; }
    .split-col-border { border-left:1px solid #FED7AA; padding-left:8px; }
    .inv-info-box .lbl { font-size:8px; color:#9A3412; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:2px; }
    .inv-info-box .val { font-size:10px; font-weight:600; color:#1a1a1a; word-break:break-word; }
    .inv-info-box .val.big { font-size:12px; font-weight:800; }
    table.items { width:100%; border-collapse:collapse; margin-bottom:8px; }
    table.items thead tr { background:#C2410C; color:white; }
    table.items thead th { padding:5px 6px; text-align:left; font-size:8.5px; font-weight:700; white-space:nowrap; }
    table.items tbody tr { border-bottom:1px solid #E7E5E4; }
    table.items tbody tr:nth-child(even) { background:#FAFAF9; }
    table.items tbody td { padding:5px 6px; font-size:9px; vertical-align:top; }
    .tc { text-align:center; }
    .tr { text-align:right; }
    .bold { font-weight:700; }
    .inv-summary { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; gap:12px; }
    .inv-rekening-box { flex:1; max-width:320px; background:#FFF7ED; border:1px solid #FED7AA; border-radius:6px; padding:6px 8px; }
    .inv-rekening-box .lbl { font-size:8px; color:#C2410C; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:3px; }
    .inv-rekening-box .val { font-size:9.5px; font-weight:700; color:#1A1A1A; line-height:1.4; white-space:pre-line; }
    .inv-summary table { width:240px; border-collapse:collapse; }
    .inv-summary td { padding:3px 6px; font-size:10px; }
    .inv-summary .total-row td { font-size:12px; font-weight:800; border-top:2px solid #C2410C; padding-top:4px; color:#C2410C; }
    .inv-summary .dp-row td { color:#15803D; font-weight:700; }
    .inv-summary .sisa-row td { color:#B91C1C; font-weight:800; font-size:11px; border-top:1px dashed #ccc; padding-top:3px; }
    .inv-footer { display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-top:10px; padding-top:8px; border-top:1px solid #E7E5E4; }
    .sig-box { text-align:center; }
    .sig-box .sig-title { font-size:9px; font-weight:700; margin-bottom:28px; color:#555; }
    .sig-box .sig-line { border-top:1px solid #333; margin:0 10px; }
    .sig-box .sig-name { font-size:9px; margin-top:3px; font-weight:600; }
    .inv-note { font-size:8px; color:#777; margin-top:6px; text-align:center; font-style:italic; }
    .status-lunas { background:#15803D; color:white; padding:2px 10px; border-radius:20px; font-size:9px; font-weight:700; display:inline-block; }
    .status-dp { background:#D97706; color:white; padding:2px 10px; border-radius:20px; font-size:9px; font-weight:700; display:inline-block; }
</style>
</head>
<body>
<div class="page">
    <div class="inv-header">
        <div class="inv-brand">
            <div class="bname">${escHtml(s.name.toUpperCase())}</div>
            <div class="bsub">${escHtml(s.address)}${s.phone ? ' &nbsp;|&nbsp; Telp/WA: ' + escHtml(s.phone) : ''}</div>
        </div>
        <div class="inv-title-block">
            <div class="inv-title">INVOICE</div>
            <div class="inv-no">No. ${escHtml(data.invoiceNo || '')}&nbsp;&nbsp;
                ${sisa <= 0 ? '<span class="status-lunas">LUNAS</span>' : '<span class="status-dp">DP / BELUM LUNAS</span>'}
            </div>
        </div>
    </div>

    <div class="inv-info">
        <div class="inv-info-box">
            <div class="lbl">Pelanggan</div>
            <div class="val big">${escHtml(customer)}</div>
        </div>
        <div class="inv-info-box">
            <div class="lbl">No. Tlp / WA</div>
            <div class="val">${phoneVal || '<span style="color:#999;">—</span>'}</div>
        </div>
        <div class="inv-info-box">
            <div class="lbl">Alamat</div>
            <div class="val">${addressVal || '<span style="color:#999;">—</span>'}</div>
        </div>
        <div class="inv-info-box inv-info-box-split">
            <div class="split-col">
                <div class="lbl">Tanggal Order</div>
                <div class="val">${escHtml(orderDateStr)} ${escHtml(data.time || '')}</div>
            </div>
            <div class="split-col split-col-border">
                <div class="lbl">Estimasi Selesai</div>
                <div class="val">${deadlineStr ? escHtml(deadlineStr) : '<span style="color:#999;">—</span>'}</div>
            </div>
        </div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th style="width:20px;" class="tc">No</th>
                <th>Nama Jasa / Item</th>
                <th>Ukuran</th>
                <th>Luas</th>
                <th class="tc">Qty</th>
                <th>Satuan</th>
                <th>Bahan / Finishing</th>
                <th>Keterangan</th>
                <th class="tr">Harga Sat.</th>
                <th class="tr">Total</th>
            </tr>
        </thead>
        <tbody>${rows}</tbody>
    </table>

    <div class="inv-summary">
        <div class="inv-rekening-box">
            <div class="lbl">💳 No. Rekening Pembayaran (Transfer Bank)</div>
            <div class="val">${s.rekening ? escHtml(s.rekening) : '<span style="color:#78350F;font-weight:normal;font-style:italic;">(Atur No. Rekening di Google Sheets "Rekening" atau Pengaturan)</span>'}</div>
            <div style="font-size:8px;color:#78350F;margin-top:3px;">* Mohon konfirmasi bukti transfer jika pembayaran dilakukan via Transfer Bank.</div>
        </div>
        <table>
            <tr><td>Subtotal</td><td class="tr">${fNum(data.subtotal || 0)}</td></tr>
            ${(data.discAmt || 0) > 0 ? `<tr><td>Diskon ${data.discPct || 0}%</td><td class="tr" style="color:#B91C1C;">- ${fNum(data.discAmt!)}</td></tr>` : ''}
            ${(data.negoAmt || 0) > 0 ? `<tr><td>Nego / Potongan</td><td class="tr" style="color:#B91C1C;">- ${fNum(data.negoAmt!)}</td></tr>` : ''}
            ${(data.taxAmt || 0) > 0 ? `<tr><td>PPN ${data.taxPct || 0}%</td><td class="tr">${fNum(data.taxAmt!)}</td></tr>` : ''}
            <tr class="total-row"><td>TOTAL</td><td class="tr">${fNum(data.total || 0)}</td></tr>
            <tr class="dp-row"><td>DP / Bayar Muka (${escHtml(data.payMethod || (data as any).metodePembayaran || 'Tunai')})</td><td class="tr">${fNum(dpAmount)}</td></tr>
            <tr class="sisa-row"><td>Sisa Bayar</td><td class="tr">${fNum(sisa)}</td></tr>
            ${(data.kembalian || 0) > 0 ? `<tr style="font-weight:800;color:#15803D;"><td>Kembalian</td><td class="tr">${fNum(data.kembalian!)}</td></tr>` : ''}
        </table>
    </div>

    ${hasHistory ? `
    <div style="margin-top:6px;margin-bottom:8px;padding:6px 8px;background:#FFF7ED;border:1px solid #FED7AA;border-radius:6px;">
        <div style="font-size:9px;font-weight:800;color:#C2410C;margin-bottom:4px;letter-spacing:0.5px;">
            HISTORI PEMBAYARAN & ANGSURAN PIUTANG
        </div>
        <table style="width:100%;font-size:8.5px;border-collapse:collapse;">
            <thead>
                <tr style="background:#EA580C;color:white;">
                    <th style="padding:3px 5px;text-align:center;width:24px;">No</th>
                    <th style="padding:3px 5px;text-align:left;">Jenis Pembayaran</th>
                    <th style="padding:3px 5px;text-align:left;">Tanggal & Waktu</th>
                    <th style="padding:3px 5px;text-align:left;">Metode</th>
                    <th style="padding:3px 5px;text-align:right;">Jumlah Bayar</th>
                    <th style="padding:3px 5px;text-align:right;">Sisa Piutang</th>
                </tr>
            </thead>
            <tbody>
                ${dpAmount > 0 ? `
                <tr style="border-bottom:1px solid #FED7AA;background:#FFFFFF;">
                    <td style="padding:3px 5px;text-align:center;">1</td>
                    <td style="padding:3px 5px;font-weight:bold;">DP / Pembayaran Awal</td>
                    <td style="padding:3px 5px;">${escHtml(orderDateStr)} ${escHtml(data.time || '')}</td>
                    <td style="padding:3px 5px;">${escHtml(data.payMethod || (data as any).metodePembayaran || 'Tunai')}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;color:#15803D;">${fNum(dpAmount)}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;">${fNum(Math.max(0, (data.total || 0) - dpAmount))}</td>
                </tr>
                ` : ''}
                ${historyItems.map((hItem, idx) => {
                  const rowNum = dpAmount > 0 ? idx + 2 : idx + 1;
                  return `
                <tr style="border-bottom:1px solid #FED7AA;background:${idx % 2 === 0 ? '#FFFAF0' : '#FFFFFF'};">
                    <td style="padding:3px 5px;text-align:center;">${rowNum}</td>
                    <td style="padding:3px 5px;font-weight:bold;">Pelunasan / Angsuran #${idx + 1}</td>
                    <td style="padding:3px 5px;">${escHtml(hItem.date || '')} ${escHtml(hItem.time || '')}</td>
                    <td style="padding:3px 5px;">${escHtml(hItem.payMethod || 'Tunai')}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;color:#15803D;">${fNum(hItem.jumlahBayar || 0)}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;color:${(hItem.newSisa || 0) > 0 ? '#B91C1C' : '#15803D'};">${fNum(hItem.newSisa !== undefined ? hItem.newSisa : 0)}</td>
                </tr>
                `;
                }).join('')}
            </tbody>
        </table>
    </div>
    ` : ''}

    <div class="inv-footer">
        <div class="sig-box">
            <div class="sig-title">Diterima Oleh (Pelanggan)</div>
            <div class="sig-line"></div>
            <div class="sig-name">(${escHtml(customer)})</div>
        </div>
        <div class="sig-box">
            <div class="sig-title">Dibuat Oleh</div>
            <div class="sig-line"></div>
            <div class="sig-name">(${escHtml(data.cashier || s.cashier || 'Admin')})</div>
        </div>
        <div class="sig-box">
            <div class="sig-title">Pimpinan / Pemilik</div>
            <div class="sig-line"></div>
            <div class="sig-name">(${escHtml(s.name)})</div>
        </div>
    </div>
    ${s.footer ? `<div class="inv-note">${escHtml(s.footer)}</div>` : ''}
</div>
</body>
</html>`;
}

export function generatePelunasanReceiptHTML(inv: any, s: StoreSettings): string {
  const bayar = inv.bayarPelunasan || inv.jumlahBayar || 0;
  const newSisa = inv.newSisa !== undefined ? inv.newSisa : 0;
  const kembalian = inv.kembalianBayar || inv.kembalian || 0;
  const payMethod = inv.payMethodBayar || inv.payMethod || (inv as any).metodePembayaran || 'Tunai';

  // Resolve items if available or retrieve from cache
  let items = Array.isArray(inv.items) && inv.items.length > 0 ? inv.items : [];
  if (items.length === 0 && inv.invoiceNo) {
    try {
      const cached = localStorage.getItem('strukku_recent_invoices');
      if (cached) {
        const list = JSON.parse(cached);
        const found = list.find((x: any) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === String(inv.invoiceNo).trim().toLowerCase());
        if (found && Array.isArray(found.items) && found.items.length > 0) {
          items = found.items;
        }
      }
    } catch {}
  }

  const orderDate = inv.orderDate || inv.invoiceDate || (inv.date && inv.paymentDate && inv.date !== inv.paymentDate ? inv.date : '');
  const paymentDate = inv.paymentDate || inv.date || '';
  const paymentTime = inv.paymentTime || inv.time || '';

  let h = '';
  h += `<div class="center bold" style="font-size:13px;letter-spacing:1px;text-align:center;">${escHtml(s.name.toUpperCase())}</div>`;
  if (s.address) h += `<div class="center" style="font-size:9px;text-align:center;">${escHtml(s.address)}</div>`;
  if (s.phone) h += `<div class="center" style="font-size:9px;text-align:center;">Telp/WA: ${escHtml(s.phone)}</div>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<div class="center bold" style="font-size:11px;letter-spacing:1px;text-align:center;font-weight:bold;">*** NOTA PELUNASAN PIUTANG ***</div>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
      <tr><td style="width:75px;">No. Invoice</td><td>: ${escHtml(String(inv.invoiceNo || ''))}</td></tr>
      ${orderDate ? `<tr><td>Tgl Order</td><td>: ${escHtml(orderDate)} ${inv.orderTime ? escHtml(inv.orderTime) : ''}</td></tr>` : ''}
      <tr><td>Tgl Bayar</td><td>: ${escHtml(paymentDate)} ${escHtml(paymentTime)}</td></tr>
      <tr><td>Kasir</td><td>: ${escHtml(inv.cashier || s.cashier || 'Admin')}</td></tr>
      <tr><td>Pelanggan</td><td>: ${escHtml(String(inv.customer || 'Umum'))}</td></tr>
      <tr><td>Metode Bayar</td><td>: ${escHtml(payMethod)}</td></tr>
      ${inv.deadline ? `<tr><td>Est Selesai</td><td>: ${escHtml(inv.deadline)}</td></tr>` : ''}
  </table>`;

  // Item / Service Details Breakdown
  if (items.length > 0) {
    h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
    h += `<table style="font-size:10px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="width:60%;">Jasa/Item</td><td style="width:15%;text-align:right;">Qty</td><td style="width:25%;text-align:right;">Total</td></tr></table>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">`;

    items.forEach((item: any) => {
      const total = item.totalItem !== undefined ? item.totalItem : computeItemTotal(item);
      const nameShort = String(item.nama || '').substring(0, 100);
      const hasDim = parseFloat(item.panjang as any) > 0 && parseFloat(item.lebar as any) > 0;
      const sizeStr = hasDim ? ` (${fDec(item.panjang, 2)}x${fDec(item.lebar, 2)}m)` : '';
      h += `<tr><td style="width:60%;padding:1px 0;vertical-align:top;">${escHtml(nameShort)}${escHtml(sizeStr)}</td><td style="width:15%;text-align:right;padding:1px 0;vertical-align:top;">${fDec(item.qty, 2).replace(/\.?0+$/, '')}</td><td style="width:25%;text-align:right;padding:1px 0;vertical-align:top;">${fNum(total)}</td></tr>`;

      const diskon = parseFloat(item.diskonItem as any) || 0;
      const hargaAsli = parseFloat(item.harga as any) || 0;
      const hargaJadi = Math.max(0, hargaAsli - diskon);
      const satuanLabel = hasDim ? '/m²' : `/${item.satuan || 'pcs'}`;

      const subParts: string[] = [];
      if (diskon > 0) {
        subParts.push(`@${fNum(hargaAsli)}<span style="color:#B91C1C;"> -${fNum(diskon)}</span> =${fNum(hargaJadi)}${satuanLabel}`);
      } else {
        subParts.push(`@${fNum(hargaJadi)}${satuanLabel}`);
      }
      if (item.bahan) subParts.push(escHtml(item.bahan));
      if (item.catatan) subParts.push(escHtml(item.catatan));
      h += `<tr><td colspan="3" style="font-size:9px;padding:0 0 3px 3px;color:#444;">${subParts.join(' · ')}</td></tr>`;
    });

    h += `</table>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
        <tr><td>Subtotal</td><td style="text-align:right;">${fNum(inv.subtotal || 0)}</td></tr>
        ${(inv.discAmt || 0) > 0 ? `<tr><td>Diskon ${inv.discPct || 0}%</td><td style="text-align:right;">-${fNum(inv.discAmt!)}</td></tr>` : ''}
        ${(inv.negoAmt || 0) > 0 ? `<tr><td>Nego / Potongan</td><td style="text-align:right;">-${fNum(inv.negoAmt!)}</td></tr>` : ''}
        ${(inv.taxAmt || 0) > 0 ? `<tr><td>PPN ${inv.taxPct || 0}%</td><td style="text-align:right;">${fNum(inv.taxAmt!)}</td></tr>` : ''}
    </table>`;
  }

  // Invoice & Pelunasan Summary Section
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<table style="font-size:11px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="font-size:12px;">TOTAL NOTA</td><td style="text-align:right;font-size:12px;">${fNum(inv.total || 0)}</td></tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;">
      <tr><td>DP Awal (${escHtml(inv.payMethod || 'Tunai')})</td><td style="text-align:right;">${fNum(Number(inv.dp || 0))}</td></tr>
      <tr><td>Sisa Sebelum Bayar</td><td style="text-align:right;">${fNum(inv.sisaAwal || 0)}</td></tr>
  </table>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:5px 0;"></div>';
  h += `<table style="font-size:11px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;">
      <td style="font-size:11px;">BAYAR PELUNASAN (${escHtml(payMethod)})</td><td style="text-align:right;font-size:11px;">${fNum(bayar)}</td>
  </tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;">
      <tr style="font-weight:bold;"><td>Sisa Akhir</td><td style="text-align:right;color:${newSisa > 0 ? '#B91C1C' : '#15803D'};">${fNum(newSisa)}</td></tr>
      ${kembalian > 0 ? `<tr style="font-weight:bold;"><td style="color:#15803D;">Kembalian</td><td style="text-align:right;color:#15803D;">${fNum(kembalian)}</td></tr>` : ''}
  </table>`;

  const rekeningPelunasan = s.rekening || '';
  if (rekeningPelunasan) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div class="center bold" style="font-size:8.5px;text-align:center;font-weight:bold;">REKENING PEMBAYARAN:</div>`;
    h += `<div class="center bold" style="font-size:8.5px;text-align:center;font-weight:bold;white-space:pre-line;">${escHtml(rekeningPelunasan)}</div>`;
  }

  const historyItems = resolveHistoryList(inv);
  if (historyItems.length > 0) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div class="center bold" style="font-size:9.5px;text-align:center;font-weight:bold;letter-spacing:0.5px;">HISTORI PEMBAYARAN & ANGSURAN</div>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:3px 0;"></div>';
    h += `<table style="font-size:8.5px;width:100%;border-collapse:collapse;">`;
    if (Number(inv.dp || 0) > 0) {
      h += `<tr><td style="font-weight:bold;">1. DP / Bayar Muka (${escHtml(inv.payMethod || (inv as any).metodePembayaran || 'Tunai')})</td><td style="text-align:right;font-weight:bold;">${fNum(Number(inv.dp || 0))}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${orderDate || inv.date || ''}</td></tr>`;
    }

    historyItems.forEach((hItem, idx) => {
      const rowIdx = Number(inv.dp || 0) > 0 ? idx + 2 : idx + 1;
      h += `<tr><td style="font-weight:bold;">${rowIdx}. Angsuran #${idx + 1} (${escHtml(hItem.payMethod || 'Tunai')})</td><td style="text-align:right;font-weight:bold;">${fNum(hItem.jumlahBayar || 0)}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${escHtml(hItem.date || '')} ${escHtml(hItem.time || '')} · Sisa: ${fNum(hItem.newSisa !== undefined ? hItem.newSisa : 0)}${hItem.catatan ? ` (${escHtml(hItem.catatan)})` : ''}</td></tr>`;
    });

    h += `</table>`;
  }

  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  const statusText = newSisa <= 0 ? '*** LUNAS ***' : 'DIBAYAR SEBAGIAN';
  h += `<div class="center bold" style="font-size:12px;margin:4px 0;text-align:center;font-weight:bold;">${statusText}</div>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  if (s.footer) h += `<div class="center bold" style="font-size:10px;margin-top:4px;text-align:center;">${escHtml(s.footer)}</div>`;

  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Nota Pelunasan ${escHtml(inv.invoiceNo)}</title>
  <style>@page{size:80mm auto;margin:2mm;}*{margin:0;padding:0;box-sizing:border-box;}body{width:80mm;font-family:'Courier New',Courier,monospace;font-size:10px;color:#000;line-height:1.4;padding:2mm;}.center{text-align:center;}.r{text-align:right;}.bold{font-weight:bold;}table{width:100%;border-collapse:collapse;}</style></head>
  <body>${h}</body></html>`;
}

// Generate Collective Payroll Rekap Report (Rekapitulasi Tagihan Potong Gaji Karyawan)
export function generateRekapPiutangPDF(
  groupedData: Array<{
    customer: string;
    totalUnpaid: number;
    invoiceCount: number;
    invoices: Invoice[];
    phone?: string;
    department?: string;
  }>,
  settings: Partial<StoreSettings>,
  meta?: {
    periode?: string;
    printedBy?: string;
    totalAmount?: number;
    title?: string;
  }
): string {
  const s = settings;
  const storeName = s.name || 'TOKO SEMBAKO & KELONTONG';
  const storeAddress = s.address || '';
  const storePhone = s.phone || '';
  const currentDate = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const grandTotal = meta?.totalAmount !== undefined 
    ? meta.totalAmount 
    : groupedData.reduce((acc, g) => acc + g.totalUnpaid, 0);
  const totalEmployees = groupedData.length;
  const totalInvoices = groupedData.reduce((acc, g) => acc + g.invoiceCount, 0);
  const docTitle = meta?.title || 'REKAPITULASI PENAGIHAN POTONG GAJI KARYAWAN';
  const periodeStr = meta?.periode || `Periode: ${currentDate}`;

  let rowsHtml = '';
  groupedData.forEach((g, idx) => {
    const invListStr = g.invoices.map((i) => `${i.invoiceNo} (${fRp(i.sisa || i.total)})`).join(', ');
    rowsHtml += `
      <tr style="border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 8px 6px; text-align: center; font-size: 11px;">${idx + 1}</td>
        <td style="padding: 8px 6px; font-weight: bold; font-size: 12px;">
          ${escHtml(g.customer)}
          ${g.phone ? `<div style="font-size: 10px; font-weight: normal; color: #6b7280;">📞 ${escHtml(g.phone)}</div>` : ''}
        </td>
        <td style="padding: 8px 6px; text-align: center; font-size: 11px;">
          <strong>${g.invoiceCount}</strong> nota
        </td>
        <td style="padding: 8px 6px; font-size: 10px; color: #4b5563; max-width: 200px; word-break: break-word;">
          ${escHtml(invListStr)}
        </td>
        <td style="padding: 8px 6px; text-align: right; font-weight: bold; font-size: 12px; color: #b91c1c; font-family: monospace;">
          ${fRp(g.totalUnpaid)}
        </td>
        <td style="padding: 8px 6px; width: 90px; text-align: center; border-left: 1px dashed #d1d5db;">
          <div style="height: 24px;"></div>
        </td>
      </tr>
    `;
  });

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>${escHtml(docTitle)} - ${escHtml(storeName)}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 15mm;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      color: #1f2937;
      background: #fff;
      font-size: 11px;
      line-height: 1.4;
      padding: 10px;
    }
    .header-table { width: 100%; border-bottom: 2px solid #111827; padding-bottom: 12px; margin-bottom: 15px; }
    .title-box { text-align: center; margin: 15px 0 20px 0; }
    .title-box h1 { font-size: 16px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; color: #111827; }
    .title-box p { font-size: 11px; color: #4b5563; margin-top: 4px; font-weight: 600; }
    .summary-grid { display: flex; justify-content: space-between; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 14px; margin-bottom: 15px; }
    .summary-col { text-align: center; }
    .summary-col .label { font-size: 10px; text-transform: uppercase; color: #6b7280; font-weight: 700; }
    .summary-col .value { font-size: 13px; font-weight: 800; color: #111827; margin-top: 2px; }
    .main-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    .main-table th { background: #f3f4f6; color: #374151; font-weight: 800; font-size: 11px; text-transform: uppercase; padding: 8px 6px; border-top: 1px solid #d1d5db; border-bottom: 2px solid #9ca3af; }
    .total-row td { background: #fef2f2; font-weight: 800; font-size: 13px; padding: 10px 6px; border-top: 2px solid #b91c1c; border-bottom: 2px solid #b91c1c; color: #991b1b; }
    .signatures { width: 100%; margin-top: 30px; page-break-inside: avoid; }
    .sign-box { text-align: center; width: 33.33%; vertical-align: top; padding: 0 10px; }
    .sign-role { font-size: 10px; font-weight: 700; color: #4b5563; text-transform: uppercase; margin-bottom: 50px; }
    .sign-name { font-size: 11px; font-weight: bold; border-top: 1px solid #374151; padding-top: 4px; display: inline-block; min-width: 130px; }
    @media print {
      body { padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <!-- Header Toko -->
  <table class="header-table">
    <tr>
      <td style="vertical-align: middle;">
        <h2 style="font-size: 18px; font-weight: 900; color: #c2410c; margin-bottom: 3px;">${escHtml(storeName)}</h2>
        <div style="font-size: 11px; color: #4b5563;">${escHtml(storeAddress)}</div>
        <div style="font-size: 11px; color: #4b5563;">Telp / WA: <strong>${escHtml(storePhone)}</strong></div>
      </td>
      <td style="text-align: right; vertical-align: middle;">
        <div style="display: inline-block; background: #fff7ed; border: 1px solid #ffedd5; padding: 6px 12px; border-radius: 6px; text-align: right;">
          <div style="font-size: 9px; font-weight: 700; color: #ea580c; text-transform: uppercase;">Lampiran Keuangan / Payroll</div>
          <div style="font-size: 11px; font-weight: 800; color: #9a3412;">DOKUMEN PENAGIHAN</div>
        </div>
      </td>
    </tr>
  </table>

  <!-- Title & Info -->
  <div class="title-box">
    <h1>${escHtml(docTitle)}</h1>
    <p>${escHtml(periodeStr)} • Dicetak pada: ${currentDate}</p>
  </div>

  <!-- Summary Cards -->
  <div class="summary-grid">
    <div class="summary-col">
      <div class="label">Total Karyawan</div>
      <div class="value">${totalEmployees} Orang</div>
    </div>
    <div class="summary-col">
      <div class="label">Jumlah Nota / Transaksi</div>
      <div class="value">${totalInvoices} Transaksi</div>
    </div>
    <div class="summary-col">
      <div class="label">Total Tagihan Potong Gaji</div>
      <div class="value" style="color: #b91c1c; font-size: 15px;">${fRp(grandTotal)}</div>
    </div>
  </div>

  <!-- Table -->
  <table class="main-table">
    <thead>
      <tr>
        <th style="width: 35px; text-align: center;">No</th>
        <th style="text-align: left;">Nama Karyawan / Pemesan</th>
        <th style="width: 80px; text-align: center;">Jml Nota</th>
        <th style="text-align: left;">Rincian No. Nota & Sisa</th>
        <th style="width: 120px; text-align: right;">Total Tagihan</th>
        <th style="width: 90px; text-align: center;">Paraf</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml}
      <tr class="total-row">
        <td colspan="4" style="text-align: right; text-transform: uppercase; letter-spacing: 0.5px;">TOTAL KESELURUHAN POTONG GAJI:</td>
        <td style="text-align: right; font-family: monospace;">${fRp(grandTotal)}</td>
        <td></td>
      </tr>
    </tbody>
  </table>

  <!-- Signatures Block -->
  <table class="signatures">
    <tr>
      <td class="sign-box">
        <div class="sign-role">Dibuat Oleh (Kasir / Admin),</div>
        <div class="sign-name">${escHtml(meta?.printedBy || s.cashier || 'Kasir / Pengelola Toko')}</div>
      </td>
      <td class="sign-box">
        <div class="sign-role">Mengetahui (HRD / Payroll),</div>
        <div class="sign-name">_________________________</div>
      </td>
      <td class="sign-box">
        <div class="sign-role">Disetujui (Keuangan / Bendahara),</div>
        <div class="sign-name">_________________________</div>
      </td>
    </tr>
  </table>

  <div style="margin-top: 25px; text-align: center; font-size: 9px; color: #9ca3af; border-top: 1px solid #f3f4f6; padding-top: 8px;">
    ${escHtml(s.footer || 'Terima kasih atas kerja samanya. Laporan ini merupakan rekapitulasi sah untuk proses pemotongan gaji.')}
  </div>
</body>
</html>`;
}

// Generate Collective Locked Unpaid Invoices PDF (Rekapitulasi Seluruh Transaksi Terkunci Belum Lunas)
export function generateRekapPiutangTerkunciPDF(
  groupedData: Array<{
    customer: string;
    phone?: string;
    division?: string;
    totalUnpaid: number;
    invoiceCount: number;
    invoices: Invoice[];
  }>,
  settings: Partial<StoreSettings>,
  meta?: {
    printedBy?: string;
    title?: string;
    periode?: string;
    filterInfo?: string;
    totalAmount?: number;
  }
): string {
  const s = settings;
  const storeName = s.name || 'TOKO SEMBAKO & KELONTONG';
  const storeAddress = s.address || '';
  const storePhone = s.phone || '';
  const now = new Date();
  const currentDate = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const currentTime = now.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const grandTotal = meta?.totalAmount !== undefined 
    ? meta.totalAmount 
    : groupedData.reduce((acc, g) => acc + g.totalUnpaid, 0);
  const totalEmployees = groupedData.length;
  const totalInvoices = groupedData.reduce((acc, g) => acc + g.invoiceCount, 0);
  const docTitle = meta?.title || 'REKAPITULASI TRANSAKSI TERKUNCI (BELUM LUNAS)';
  const periodeStr = meta?.periode || `Dicetak pada: ${currentDate} pukul ${currentTime}`;

  let rowsHtml = '';
  groupedData.forEach((g, idx) => {
    // Generate detailed invoice breakdown per customer
    const invoiceRowsHtml = g.invoices.map((inv) => {
      const invNo = inv.invoiceNo || (inv as any).noInvoice || '-';
      const invDate = inv.date || '';
      const invSlip = inv.slipNo ? `Slip #${inv.slipNo}` : 'Slip #1';
      const invTotal = inv.total || 0;
      const invSisa = (inv as any).calculatedSisa !== undefined 
        ? Number((inv as any).calculatedSisa) 
        : Number(inv.sisa !== undefined ? inv.sisa : invTotal);
      
      const itemsList = (inv.items || []).map((it) => {
        const itemTot = computeItemTotal(it);
        return `${escHtml(it.nama)} (${it.qty} ${it.satuan || 'pcs'} @${fNum(it.harga)}${itemTot > 0 ? ` = ${fRp(itemTot)}` : ''})`;
      }).join(' • ');

      return `
        <div style="margin-bottom: 4px; padding: 4px 6px; background: #f9fafb; border-radius: 4px; border: 1px solid #f3f4f6;">
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10px;">
            <div>
              <strong style="color: #b91c1c;">${escHtml(invNo)}</strong>
              <span style="color: #6b7280; margin-left: 6px;">📅 ${escHtml(invDate)}</span>
              <span style="background: #fee2e2; color: #991b1b; padding: 0.5px 4px; border-radius: 3px; margin-left: 4px; font-weight: bold; font-size: 9px;">${escHtml(invSlip)}</span>
              ${inv.slipPrintedAt ? `<span style="color: #059669; font-size: 9px; margin-left: 4px;">🔒 Terkunci: ${escHtml(inv.slipPrintedAt)}</span>` : ''}
            </div>
            <div style="font-weight: bold; font-family: monospace; color: #991b1b; font-size: 11px;">
              ${fRp(invSisa)}
            </div>
          </div>
          ${itemsList ? `<div style="font-size: 9px; color: #4b5563; margin-top: 2px; line-height: 1.3;">${itemsList}</div>` : ''}
        </div>
      `;
    }).join('');

    rowsHtml += `
      <tr style="border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 10px 6px; text-align: center; font-size: 11px; vertical-align: top; font-weight: bold;">
          ${idx + 1}
        </td>
        <td style="padding: 10px 8px; vertical-align: top;">
          <div style="font-weight: 800; font-size: 12px; color: #111827;">${escHtml(g.customer)}</div>
          <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-top: 2px;">
            ${g.division ? `<span style="font-size: 9px; font-weight: bold; background: #eff6ff; color: #1d4ed8; padding: 1px 6px; border-radius: 4px; border: 1px solid #bfdbfe;">🏢 ${escHtml(g.division)}</span>` : ''}
            ${g.phone ? `<span style="font-size: 9px; color: #4b5563;">📞 ${escHtml(g.phone)}</span>` : ''}
          </div>
        </td>
        <td style="padding: 10px 6px; text-align: center; font-size: 11px; vertical-align: top;">
          <span style="display: inline-block; background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; font-weight: 800; padding: 2px 8px; border-radius: 9999px;">
            ${g.invoiceCount} nota
          </span>
        </td>
        <td style="padding: 10px 6px; vertical-align: top; min-width: 250px;">
          ${invoiceRowsHtml}
        </td>
        <td style="padding: 10px 8px; text-align: right; font-weight: 800; font-size: 13px; color: #b91c1c; font-family: monospace; vertical-align: top;">
          ${fRp(g.totalUnpaid)}
        </td>
        <td style="padding: 10px 6px; width: 85px; text-align: center; border-left: 1px dashed #d1d5db; vertical-align: middle;">
          <div style="height: 35px; border-bottom: 1px dotted #9ca3af; margin: 0 10px;"></div>
        </td>
      </tr>
    `;
  });

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>${escHtml(docTitle)} - ${escHtml(storeName)}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 10mm 12mm;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      color: #1f2937;
      background: #fff;
      font-size: 11px;
      line-height: 1.4;
      padding: 10px;
    }
    .header-table { width: 100%; border-bottom: 2px solid #111827; padding-bottom: 12px; margin-bottom: 15px; }
    .title-box { text-align: center; margin: 12px 0 18px 0; }
    .title-box h1 { font-size: 16px; font-weight: 900; letter-spacing: 0.5px; text-transform: uppercase; color: #111827; }
    .title-box p { font-size: 11px; color: #4b5563; margin-top: 3px; font-weight: 600; }
    .summary-grid { display: flex; justify-content: space-between; background: #fff7ed; border: 1px solid #fed7aa; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; }
    .summary-col { text-align: center; }
    .summary-col .label { font-size: 10px; text-transform: uppercase; color: #9a3412; font-weight: 700; }
    .summary-col .value { font-size: 13px; font-weight: 900; color: #111827; margin-top: 2px; }
    .main-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    .main-table th { background: #f3f4f6; color: #374151; font-weight: 800; font-size: 11px; text-transform: uppercase; padding: 8px 6px; border-top: 1px solid #d1d5db; border-bottom: 2px solid #9ca3af; }
    .total-row td { background: #fef2f2; font-weight: 900; font-size: 13px; padding: 12px 6px; border-top: 2px solid #b91c1c; border-bottom: 2px solid #b91c1c; color: #991b1b; }
    .signatures { width: 100%; margin-top: 25px; page-break-inside: avoid; }
    .sign-box { text-align: center; width: 33.33%; vertical-align: top; padding: 0 10px; }
    .sign-role { font-size: 10px; font-weight: 700; color: #4b5563; text-transform: uppercase; margin-bottom: 45px; }
    .sign-name { font-size: 11px; font-weight: bold; border-top: 1px solid #374151; padding-top: 4px; display: inline-block; min-width: 130px; }
    @media print {
      body { padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <!-- Header Toko -->
  <table class="header-table">
    <tr>
      <td style="vertical-align: middle;">
        <h2 style="font-size: 18px; font-weight: 900; color: #b91c1c; margin-bottom: 3px;">${escHtml(storeName)}</h2>
        <div style="font-size: 11px; color: #4b5563;">${escHtml(storeAddress)}</div>
        <div style="font-size: 11px; color: #4b5563;">Telp / WA: <strong>${escHtml(storePhone)}</strong></div>
      </td>
      <td style="text-align: right; vertical-align: middle;">
        <div style="display: inline-block; background: #fef2f2; border: 1px solid #fecaca; padding: 6px 12px; border-radius: 6px; text-align: right;">
          <div style="font-size: 9px; font-weight: 800; color: #b91c1c; text-transform: uppercase;">🔒 STATUS TRANSAKSI TERKUNCI</div>
          <div style="font-size: 11px; font-weight: 900; color: #991b1b;">PENAGIHAN POTONG GAJI</div>
        </div>
      </td>
    </tr>
  </table>

  <!-- Title & Info -->
  <div class="title-box">
    <h1>${escHtml(docTitle)}</h1>
    <p>${escHtml(periodeStr)}</p>
    ${meta?.filterInfo ? `<p style="font-size: 10px; color: #dc2626; font-weight: bold; margin-top: 2px;">${escHtml(meta.filterInfo)}</p>` : ''}
  </div>

  <!-- Summary Cards -->
  <div class="summary-grid">
    <div class="summary-col">
      <div class="label">Total Karyawan Terkunci</div>
      <div class="value">${totalEmployees} Orang</div>
    </div>
    <div class="summary-col">
      <div class="label">Jumlah Nota Terkunci</div>
      <div class="value">${totalInvoices} Transaksi</div>
    </div>
    <div class="summary-col">
      <div class="label">Total Tagihan Belum Lunas</div>
      <div class="value" style="color: #b91c1c; font-size: 15px;">${fRp(grandTotal)}</div>
    </div>
  </div>

  <!-- Table -->
  <table class="main-table">
    <thead>
      <tr>
        <th style="width: 35px; text-align: center;">No</th>
        <th style="text-align: left; width: 170px;">Nama Karyawan / Divisi</th>
        <th style="width: 75px; text-align: center;">Jml Nota</th>
        <th style="text-align: left;">Rincian Nota & Belanja Terkunci</th>
        <th style="width: 120px; text-align: right;">Sisa Tagihan</th>
        <th style="width: 85px; text-align: center;">Paraf</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml}
      <tr class="total-row">
        <td colspan="4" style="text-align: right; text-transform: uppercase; letter-spacing: 0.5px;">TOTAL TAGIHAN TRANSAKSI TERKUNCI:</td>
        <td style="text-align: right; font-family: monospace;">${fRp(grandTotal)}</td>
        <td></td>
      </tr>
    </tbody>
  </table>

  <!-- Signatures Block -->
  <table class="signatures">
    <tr>
      <td class="sign-box">
        <div class="sign-role">Dibuat Oleh (Petugas Kasir),</div>
        <div class="sign-name">${escHtml(meta?.printedBy || s.cashier || 'Petugas Kasir')}</div>
      </td>
      <td class="sign-box">
        <div class="sign-role">Mengetahui (HRD / Personalia),</div>
        <div class="sign-name">_________________________</div>
      </td>
      <td class="sign-box">
        <div class="sign-role">Disetujui (Keuangan / Bendahara),</div>
        <div class="sign-name">_________________________</div>
      </td>
    </tr>
  </table>

  <div style="margin-top: 25px; text-align: center; font-size: 9px; color: #9ca3af; border-top: 1px solid #f3f4f6; padding-top: 8px;">
    ${escHtml(s.footer || 'Laporan resmi ini dibuat secara otomatis oleh sistem pencatatan bon toko. Hanya memuat data nota yang telah dikunci petugas.')}
  </div>
</body>
</html>`;
}

// Generate Individual Employee Deduction Slip (Slip Tagihan Potong Gaji Per Karyawan)
export function generateSlipPotongGajiKaryawanPDF(
  customerName: string,
  invoices: Invoice[],
  settings: Partial<StoreSettings>,
  customerInfoOrMeta?: { 
    phone?: string; 
    address?: string;
    slipNo?: number | string;
    periode?: string;
    cashier?: string;
    printedAt?: string;
    catatan?: string;
  },
  slipMetaArg?: {
    slipNo?: number | string;
    periode?: string;
    cashier?: string;
    printedAt?: string;
    catatan?: string;
  }
): string {
  const s = settings;
  const storeName = s.name || 'TOKO SEMBAKO & KELONTONG';
  const totalUnpaid = invoices.reduce((acc, i) => acc + Number((i as any).calculatedSisa !== undefined ? (i as any).calculatedSisa : (i.sisa !== undefined ? i.sisa : i.total)), 0);
  const totalItemsCount = invoices.reduce((acc, i) => acc + (i.items?.length || 0), 0);
  const currentDate = new Date().toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const slipMeta = slipMetaArg || (customerInfoOrMeta && (customerInfoOrMeta.slipNo !== undefined || customerInfoOrMeta.cashier !== undefined) ? customerInfoOrMeta : undefined);
  const rawSlipNoStr = slipMeta?.slipNo ? String(slipMeta.slipNo).trim() : '';
  const slipNoBadge = rawSlipNoStr
    ? (rawSlipNoStr.toUpperCase().includes('SLIP')
        ? rawSlipNoStr.toUpperCase()
        : (rawSlipNoStr.startsWith('#') ? `SLIP TAGIHAN ${rawSlipNoStr}` : `SLIP TAGIHAN #${rawSlipNoStr}`))
    : 'SLIP POTONG GAJI';

  let invoiceBlocks = '';
  invoices.forEach((inv, idx) => {
    let itemsRows = '';
    (inv.items || []).forEach((item, iIdx) => {
      const itemTot = computeItemTotal(item);
      itemsRows += `
        <tr style="border-bottom: 1px dotted #e5e7eb;">
          <td style="padding: 4px 6px; font-size: 10px;">${iIdx + 1}. ${escHtml(item.nama)}</td>
          <td style="padding: 4px 6px; text-align: center; font-size: 10px;">${item.qty} ${item.satuan || 'pcs'}</td>
          <td style="padding: 4px 6px; text-align: right; font-size: 10px;">${fNum(item.harga)}</td>
          <td style="padding: 4px 6px; text-align: right; font-size: 10px; font-weight: 600;">${fNum(itemTot)}</td>
        </tr>
      `;
    });

    invoiceBlocks += `
      <div style="border: 1px solid #e5e7eb; border-radius: 6px; margin-bottom: 10px; overflow: hidden;">
        <div style="background: #f9fafb; padding: 6px 10px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e5e7eb;">
          <div>
            <strong style="font-size: 11px; color: #c2410c;">Nota: ${escHtml(inv.invoiceNo || (inv as any).noInvoice)}</strong>
            <span style="font-size: 10px; color: #6b7280; margin-left: 8px;">📅 ${escHtml(inv.date)} ${escHtml(inv.time || '')}</span>
            ${inv.slipNo ? `<span style="font-size: 9px; background: #fee2e2; color: #991b1b; padding: 1px 5px; border-radius: 3px; margin-left: 6px; font-weight: bold;">Slip #${inv.slipNo}</span>` : ''}
          </div>
          <div style="font-size: 11px; font-weight: bold; color: #b91c1c;">
            Tagihan: ${fRp((inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total))}
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
          <thead>
            <tr style="background: #f3f4f6; color: #4b5563; font-weight: 600;">
              <th style="text-align: left; padding: 3px 6px;">Barang Sembako</th>
              <th style="text-align: center; padding: 3px 6px; width: 60px;">Qty</th>
              <th style="text-align: right; padding: 3px 6px; width: 70px;">Harga</th>
              <th style="text-align: right; padding: 3px 6px; width: 80px;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRows}
          </tbody>
        </table>
      </div>
    `;
  });

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Slip Potong Gaji ${slipMeta?.slipNo ? `#${slipMeta.slipNo} ` : ''}- ${escHtml(customerName)}</title>
  <style>
    @page { size: A5 portrait; margin: 8mm 10mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      color: #1f2937;
      background: #fff;
      font-size: 11px;
      line-height: 1.4;
      padding: 10px;
    }
    .header { border-bottom: 2px solid #111827; padding-bottom: 8px; margin-bottom: 10px; display: flex; justify-content: space-between; }
    .badge { background: #fee2e2; color: #991b1b; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 10px; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h3 style="color: #c2410c; font-size: 15px; font-weight: 800;">${escHtml(storeName)}</h3>
      <div style="font-size: 10px; color: #6b7280;">${escHtml(s.address || '')} • Telp: ${escHtml(s.phone || '')}</div>
    </div>
    <div style="text-align: right;">
      <span class="badge">${escHtml(slipNoBadge)}</span>
      <div style="font-size: 10px; color: #6b7280; margin-top: 3px;">${currentDate}</div>
    </div>
  </div>

  <div style="background: #fff7ed; border: 1px solid #fed7aa; border-radius: 6px; padding: 8px 12px; margin-bottom: 12px;">
    <table style="width: 100%; font-size: 11px;">
      <tr>
        <td style="width: 120px; color: #7c2d12;">Nama Karyawan:</td>
        <td><strong style="font-size: 13px; color: #431407;">${escHtml(customerName)}</strong></td>
      </tr>
      ${slipMeta?.slipNo ? `
      <tr>
        <td style="color: #7c2d12;">Nomor Slip:</td>
        <td><strong style="color: #ea580c; font-size: 12px;">${String(slipMeta.slipNo).toUpperCase().includes('SLIP') ? escHtml(String(slipMeta.slipNo)) : (String(slipMeta.slipNo).startsWith('#') ? `Slip Tagihan ${escHtml(String(slipMeta.slipNo))}` : `Slip Tagihan #${escHtml(String(slipMeta.slipNo))}`)}</strong></td>
      </tr>
      ` : ''}
      <tr>
        <td style="color: #7c2d12;">Total Nota:</td>
        <td><strong>${invoices.length} transaksi (${totalItemsCount} item barang)</strong></td>
      </tr>
      <tr>
        <td style="color: #7c2d12;">Total Potong Gaji:</td>
        <td><strong style="color: #b91c1c; font-size: 14px; font-family: monospace;">${fRp(totalUnpaid)}</strong></td>
      </tr>
    </table>
  </div>

  <div style="font-size: 11px; font-weight: bold; margin-bottom: 6px; color: #374151;">Rincian Transaksi Belanja Sembako:</div>
  ${invoiceBlocks}

  <div style="margin-top: 20px; display: flex; justify-content: space-between; page-break-inside: avoid;">
    <div style="text-align: center; width: 45%;">
      <div style="font-size: 10px; color: #6b7280; margin-bottom: 35px;">Kasir / Toko,</div>
      <div style="font-size: 10px; font-weight: bold; border-top: 1px solid #4b5563; padding-top: 3px;">(${escHtml(slipMeta?.cashier || s.cashier || 'Admin Toko')})</div>
    </div>
    <div style="text-align: center; width: 45%;">
      <div style="font-size: 10px; color: #6b7280; margin-bottom: 35px;">Karyawan Bersangkutan,</div>
      <div style="font-size: 10px; font-weight: bold; border-top: 1px solid #4b5563; padding-top: 3px;">(${escHtml(customerName)})</div>
    </div>
  </div>
</body>
</html>`;
}

// Generate Settled / Paid Slip (Slip Bukti Pelunasan Potong Gaji Karyawan - LUNAS)
export function generateSlipBuktiPelunasanKaryawanPDF(
  customerName: string,
  invoices: Invoice[],
  settings: Partial<StoreSettings>,
  pelunasanMeta?: {
    date?: string;
    time?: string;
    cashier?: string;
    payMethod?: string;
    catatan?: string;
    jumlahBayar?: number;
    totalTagihan?: number;
  }
): string {
  const s = settings;
  const storeName = s.name || 'TOKO SEMBAKO & KELONTONG';
  const totalAmount = pelunasanMeta?.totalTagihan !== undefined 
    ? pelunasanMeta.totalTagihan 
    : invoices.reduce((acc, i) => acc + Number(i.total || 0), 0);
  const totalPaid = pelunasanMeta?.jumlahBayar !== undefined 
    ? pelunasanMeta.jumlahBayar 
    : totalAmount;
  const totalItemsCount = invoices.reduce((acc, i) => acc + (i.items?.length || 0), 0);
  const settleDate = pelunasanMeta?.date 
    ? `${pelunasanMeta.date} ${pelunasanMeta.time || ''}`.trim()
    : new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
  const cashier = pelunasanMeta?.cashier || s.cashier || 'Admin Toko';
  const payMethod = pelunasanMeta?.payMethod || 'Potong Gaji (Gajian)';
  const catatan = pelunasanMeta?.catatan || 'Pelunasan Potong Gaji Periode Gajian';

  let invoiceBlocks = '';
  invoices.forEach((inv) => {
    let itemsRows = '';
    (inv.items || []).forEach((item, iIdx) => {
      const itemTot = computeItemTotal(item);
      itemsRows += `
        <tr style="border-bottom: 1px dotted #e5e7eb;">
          <td style="padding: 4px 6px; font-size: 10px;">${iIdx + 1}. ${escHtml(item.nama)}</td>
          <td style="padding: 4px 6px; text-align: center; font-size: 10px;">${item.qty} ${item.satuan || 'pcs'}</td>
          <td style="padding: 4px 6px; text-align: right; font-size: 10px;">${fNum(item.harga)}</td>
          <td style="padding: 4px 6px; text-align: right; font-size: 10px; font-weight: 600;">${fNum(itemTot)}</td>
        </tr>
      `;
    });

    invoiceBlocks += `
      <div style="border: 1px solid #bbf7d0; border-radius: 6px; margin-bottom: 10px; overflow: hidden; background: #fff;">
        <div style="background: #f0fdf4; padding: 6px 10px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #bbf7d0;">
          <div>
            <strong style="font-size: 11px; color: #166534;">Nota: ${escHtml(inv.invoiceNo)}</strong>
            <span style="font-size: 10px; color: #4b5563; margin-left: 8px;">📅 ${escHtml(inv.date)} ${escHtml(inv.time || '')}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="font-size: 9px; font-weight: 800; background: #dcfce7; color: #15803d; border: 1px solid #86efac; padding: 1px 6px; rounded: 4px;">✓ LUNAS</span>
            <span style="font-size: 11px; font-weight: bold; color: #15803d;">
              ${fRp(inv.total)}
            </span>
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
          <thead>
            <tr style="background: #f8fafc; color: #475569; font-weight: 600;">
              <th style="text-align: left; padding: 3px 6px;">Barang Sembako</th>
              <th style="text-align: center; padding: 3px 6px; width: 60px;">Qty</th>
              <th style="text-align: right; padding: 3px 6px; width: 70px;">Harga</th>
              <th style="text-align: right; padding: 3px 6px; width: 80px;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRows || '<tr><td colspan="4" style="text-align:center;padding:4px;color:#9ca3af;">Rincian barang</td></tr>'}
          </tbody>
        </table>
      </div>
    `;
  });

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Bukti Pelunasan Potong Gaji - ${escHtml(customerName)}</title>
  <style>
    @page { size: A5 portrait; margin: 8mm 10mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      color: #1f2937;
      background: #fff;
      font-size: 11px;
      line-height: 1.4;
      padding: 10px;
    }
    .header { border-bottom: 2px solid #166534; padding-bottom: 8px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: flex-start; }
    .badge-lunas { background: #dcfce7; color: #15803d; border: 1.5px solid #86efac; padding: 4px 10px; border-radius: 6px; font-weight: 900; font-size: 11px; letter-spacing: 0.5px; text-align: right; display: inline-block; }
  </style>
</head>
<body>
  <!-- Header -->
  <div class="header">
    <div>
      <h3 style="color: #166534; font-size: 15px; font-weight: 800; letter-spacing: -0.2px;">${escHtml(storeName)}</h3>
      <div style="font-size: 10px; color: #6b7280; margin-top: 1px;">${escHtml(s.address || '')} • Telp: ${escHtml(s.phone || '')}</div>
    </div>
    <div style="text-align: right;">
      <span class="badge-lunas">✓ BUKTI PELUNASAN (LUNAS)</span>
      <div style="font-size: 9.5px; color: #4b5563; margin-top: 3px; font-weight: 600;">Waktu: ${escHtml(settleDate)}</div>
    </div>
  </div>

  <!-- Settlement Summary Card -->
  <div style="background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 8px; padding: 10px 14px; margin-bottom: 12px;">
    <table style="width: 100%; font-size: 11px; border-collapse: collapse;">
      <tr>
        <td style="width: 130px; color: #166534; padding: 2px 0;">Nama Karyawan:</td>
        <td style="padding: 2px 0;"><strong style="font-size: 13px; color: #14532d;">${escHtml(customerName)}</strong></td>
        <td style="width: 110px; color: #166534; padding: 2px 0; text-align: right;">Status Tagihan:</td>
        <td style="padding: 2px 0; text-align: right;"><span style="color: #15803d; font-weight: 900; font-size: 12px;">SUDAH LUNAS 100%</span></td>
      </tr>
      <tr>
        <td style="color: #166534; padding: 2px 0;">Metode Pelunasan:</td>
        <td style="padding: 2px 0;"><strong>${escHtml(payMethod)}</strong></td>
        <td style="color: #166534; padding: 2px 0; text-align: right;">Kasir/Penerima:</td>
        <td style="padding: 2px 0; text-align: right;"><strong>${escHtml(cashier)}</strong></td>
      </tr>
      <tr>
        <td style="color: #166534; padding: 2px 0;">Jumlah Nota Dilunasi:</td>
        <td style="padding: 2px 0;"><strong>${invoices.length} Transaksi (${totalItemsCount} Item Barang)</strong></td>
        <td style="color: #166534; padding: 2px 0; text-align: right;">Total Dilunasi:</td>
        <td style="padding: 2px 0; text-align: right;"><strong style="color: #15803d; font-size: 14px; font-family: monospace;">${fRp(totalPaid)}</strong></td>
      </tr>
      ${catatan ? `
      <tr>
        <td style="color: #166534; padding: 2px 0; vertical-align: top;">Keterangan:</td>
        <td colspan="3" style="padding: 2px 0; color: #4b5563; font-style: italic;">"${escHtml(catatan)}"</td>
      </tr>
      ` : ''}
    </table>
  </div>

  <!-- Detailed Transaksi Breakdown -->
  <div style="font-size: 11px; font-weight: bold; margin-bottom: 6px; color: #166534; display: flex; justify-content: space-between; align-items: center;">
    <span>Rincian Transaksi Belanja yang Telah Dilunasi:</span>
    <span style="font-size: 10px; color: #4b5563; font-weight: normal;">Sisa Tagihan: <strong>Rp 0 (Lunas)</strong></span>
  </div>
  ${invoiceBlocks}

  <!-- Signatures Block -->
  <div style="margin-top: 20px; display: flex; justify-content: space-between; page-break-inside: avoid;">
    <div style="text-align: center; width: 30%;">
      <div style="font-size: 10px; color: #6b7280; margin-bottom: 35px;">Kasir / Toko,</div>
      <div style="font-size: 10px; font-weight: bold; border-top: 1px solid #4b5563; padding-top: 3px;">(${escHtml(cashier)})</div>
    </div>
    <div style="text-align: center; width: 30%;">
      <div style="font-size: 10px; color: #6b7280; margin-bottom: 35px;">HRD / Penggajian,</div>
      <div style="font-size: 10px; font-weight: bold; border-top: 1px solid #4b5563; padding-top: 3px;">(__________________)</div>
    </div>
    <div style="text-align: center; width: 30%;">
      <div style="font-size: 10px; color: #6b7280; margin-bottom: 35px;">Karyawan Bersangkutan,</div>
      <div style="font-size: 10px; font-weight: bold; border-top: 1px solid #4b5563; padding-top: 3px;">(${escHtml(customerName)})</div>
    </div>
  </div>

  <div style="margin-top: 15px; text-align: center; font-size: 9px; color: #6b7280; border-top: 1px dashed #e5e7eb; padding-top: 6px;">
    Dokumen ini adalah bukti sah pelunasan tagihan belanja sembako melalui sistem kasir.
  </div>
</body>
</html>`;
}

/**
 * Generate Berita Acara Stock Opname Resmi Format A4
 */
export function generateStockOpnameA4HTML(record: StockOpnameRecord, s: StoreSettings): string {
  const items = record.items || [];
  const rows = items.map((item, idx) => {
    const diff = item.selisih;
    let badgeColor = '#16a34a'; // green
    let badgeText = 'SESUAI';
    if (diff < 0) {
      badgeColor = '#dc2626'; // red
      badgeText = `KURANG (${diff})`;
    } else if (diff > 0) {
      badgeColor = '#2563eb'; // blue
      badgeText = `LEBIH (+${diff})`;
    }

    const rowBg = idx % 2 === 0 ? '#ffffff' : '#f9fafb';
    const highlightBg = diff !== 0 ? (diff < 0 ? '#fef2f2' : '#eff6ff') : rowBg;

    return `
      <tr style="background: ${highlightBg}; border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 6px 8px; text-align: center; font-size: 10px; color: #6b7280;">${idx + 1}</td>
        <td style="padding: 6px 8px; font-size: 10px; font-weight: bold; font-family: monospace; color: #374151;">${escHtml(item.kode || '-')}</td>
        <td style="padding: 6px 8px; font-size: 11px;">
          <div style="font-weight: 600; color: #111827;">${escHtml(item.nama)}</div>
          <div style="font-size: 9px; color: #6b7280;">Kategori: ${escHtml(item.kategori || 'Umum')}</div>
        </td>
        <td style="padding: 6px 8px; text-align: center; font-size: 10px; color: #4b5563;">${escHtml(item.satuan || 'pcs')}</td>
        <td style="padding: 6px 8px; text-align: right; font-size: 11px; font-weight: bold; color: #4b5563;">${item.stokSistem}</td>
        <td style="padding: 6px 8px; text-align: right; font-size: 11px; font-weight: 900; color: #111827;">${item.stokFisik}</td>
        <td style="padding: 6px 8px; text-align: center; font-size: 10px; font-weight: bold; color: ${badgeColor};">
          ${badgeText}
        </td>
        <td style="padding: 6px 8px; text-align: right; font-size: 10px; color: #4b5563; font-family: monospace;">${fRp(item.hargaBeli || 0)}</td>
        <td style="padding: 6px 8px; text-align: right; font-size: 11px; font-weight: bold; font-family: monospace; color: ${diff < 0 ? '#dc2626' : (diff > 0 ? '#2563eb' : '#16a34a')};">
          ${diff === 0 ? 'Rp 0' : (diff < 0 ? '-' + fRp(Math.abs(item.nilaiSelisih)) : '+' + fRp(item.nilaiSelisih))}
        </td>
        <td style="padding: 6px 8px; font-size: 9px; color: #4b5563; max-width: 120px;">${escHtml(item.catatan || '-')}</td>
      </tr>
    `;
  }).join('');

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Berita Acara Stock Opname - ${escHtml(record.id)}</title>
<style>
  @page { size: A4 portrait; margin: 12mm 15mm; }
  @media print {
    body { margin: 0; padding: 0; background: #fff; font-size: 10pt; color: #000; }
    .no-print { display: none !important; }
    tr { page-break-inside: avoid; }
  }
  * { box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    color: #1f2937;
    background: #f3f4f6;
    margin: 0;
    padding: 20px;
    font-size: 11px;
    line-height: 1.4;
  }
  .page {
    background: #fff;
    max-width: 210mm;
    margin: 0 auto;
    padding: 20mm;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    border-radius: 4px;
  }
  .table-custom {
    width: 100%;
    border-collapse: collapse;
    margin-top: 12px;
  }
  .table-custom th {
    background-color: #f1f5f9;
    color: #334155;
    font-weight: bold;
    font-size: 10px;
    padding: 8px;
    border-bottom: 2px solid #cbd5e1;
    text-transform: uppercase;
  }
  .summary-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 12px 16px;
    margin-top: 15px;
  }
</style>
</head>
<body>
  <div class="page">
    <!-- Header Toko -->
    <div style="border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: flex-start;">
      <div>
        <h1 style="margin: 0; font-size: 18px; font-weight: 900; color: #0f172a; letter-spacing: -0.5px;">${escHtml(s.name || 'TOKO ERVO')}</h1>
        <p style="margin: 3px 0 0 0; font-size: 10px; color: #475569;">${escHtml(s.address || '')}</p>
        <p style="margin: 1px 0 0 0; font-size: 10px; color: #475569;">Telp / WA: ${escHtml(s.phone || '-')}</p>
      </div>
      <div style="text-align: right;">
        <div style="background: #0f172a; color: #fff; display: inline-block; padding: 4px 10px; font-size: 11px; font-weight: bold; border-radius: 4px; letter-spacing: 0.5px;">
          BERITA ACARA AUDIT
        </div>
        <div style="font-size: 13px; font-weight: 800; color: #0f172a; margin-top: 4px;">STOCK OPNAME</div>
        <div style="font-size: 10px; color: #64748b; font-family: monospace;">No: ${escHtml(record.id)}</div>
      </div>
    </div>

    <!-- Informasi Opname -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 14px; margin-bottom: 16px;">
      <div>
        <table style="width: 100%; font-size: 10px;">
          <tr>
            <td style="color: #64748b; width: 100px; padding: 2px 0;">Periode Opname</td>
            <td style="padding: 2px 0; font-weight: bold; color: #0f172a;">: ${escHtml(record.bulanPeriode || '-')}</td>
          </tr>
          <tr>
            <td style="color: #64748b; padding: 2px 0;">Tanggal & Waktu</td>
            <td style="padding: 2px 0; font-weight: 600;">: ${escHtml(record.tanggal)} (${escHtml(record.jam || '-')})</td>
          </tr>
          <tr>
            <td style="color: #64748b; padding: 2px 0;">Petugas Auditor</td>
            <td style="padding: 2px 0; font-weight: bold; color: #0369a1;">: ${escHtml(record.petugas)}</td>
          </tr>
        </table>
      </div>
      <div>
        <table style="width: 100%; font-size: 10px;">
          <tr>
            <td style="color: #64748b; width: 120px; padding: 2px 0;">Penanggung Jawab</td>
            <td style="padding: 2px 0; font-weight: bold;">: ${escHtml(record.penanggungJawab || 'Kepala Toko / SPV')}</td>
          </tr>
          <tr>
            <td style="color: #64748b; padding: 2px 0;">Total Item Dicek</td>
            <td style="padding: 2px 0; font-weight: 600;">: ${record.totalItemDihitung} Produk</td>
          </tr>
          <tr>
            <td style="color: #64748b; padding: 2px 0;">Catatan Umum</td>
            <td style="padding: 2px 0; color: #334155; font-style: italic;">: ${escHtml(record.catatanUmum || 'Audit berkala penyesuaian stok')}</td>
          </tr>
        </table>
      </div>
    </div>

    <!-- Ringkasan Statistik Audit -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 16px;">
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 8px 10px; text-align: center;">
        <div style="font-size: 9px; color: #166534; font-weight: bold; text-transform: uppercase;">Stok Sesuai (Pas)</div>
        <div style="font-size: 16px; font-weight: 900; color: #15803d; margin-top: 2px;">${record.totalItemSesuai} Item</div>
      </div>
      <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 8px 10px; text-align: center;">
        <div style="font-size: 9px; color: #991b1b; font-weight: bold; text-transform: uppercase;">Selisih Kurang (Hilang/Rusak)</div>
        <div style="font-size: 16px; font-weight: 900; color: #b91c1c; margin-top: 2px;">${record.totalItemSelisihKurang} Item</div>
      </div>
      <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 6px; padding: 8px 10px; text-align: center;">
        <div style="font-size: 9px; color: #1e40af; font-weight: bold; text-transform: uppercase;">Selisih Lebih (Kelebihan)</div>
        <div style="font-size: 16px; font-weight: 900; color: #1d4ed8; margin-top: 2px;">${record.totalItemSelisihLebih} Item</div>
      </div>
      <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 6px; padding: 8px 10px; text-align: center;">
        <div style="font-size: 9px; color: #6b21a8; font-weight: bold; text-transform: uppercase;">Total Nilai Selisih</div>
        <div style="font-size: 14px; font-weight: 900; color: ${record.totalNilaiSelisih < 0 ? '#b91c1c' : (record.totalNilaiSelisih > 0 ? '#1d4ed8' : '#15803d')}; margin-top: 4px; font-family: monospace;">
          ${record.totalNilaiSelisih === 0 ? 'Rp 0' : (record.totalNilaiSelisih < 0 ? '-' + fRp(Math.abs(record.totalNilaiSelisih)) : '+' + fRp(record.totalNilaiSelisih))}
        </div>
      </div>
    </div>

    <!-- Tabel Rincian -->
    <div style="margin-bottom: 20px;">
      <table class="table-custom">
        <thead>
          <tr>
            <th style="width: 25px; text-align: center;">No</th>
            <th style="width: 70px; text-align: left;">Kode</th>
            <th style="text-align: left;">Nama Produk / Barang</th>
            <th style="width: 40px; text-align: center;">Sat</th>
            <th style="width: 55px; text-align: right;">Sistem</th>
            <th style="width: 55px; text-align: right;">Fisik</th>
            <th style="width: 85px; text-align: center;">Status / Selisih</th>
            <th style="width: 75px; text-align: right;">Harga Beli</th>
            <th style="width: 85px; text-align: right;">Nilai Selisih</th>
            <th style="width: 100px; text-align: left;">Alasan / Keterangan</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>

    <!-- Tanda Tangan Pengesahan -->
    <div style="margin-top: 35px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; page-break-inside: avoid;">
      <div style="text-align: center;">
        <div style="font-size: 10px; color: #64748b; margin-bottom: 50px;">Petugas Penghitung (Auditor),</div>
        <div style="font-size: 11px; font-weight: bold; border-top: 1px solid #334155; padding-top: 4px; color: #0f172a;">
          (${escHtml(record.petugas)})
        </div>
      </div>
      <div style="text-align: center;">
        <div style="font-size: 10px; color: #64748b; margin-bottom: 50px;">Bagian Gudang / Kasir,</div>
        <div style="font-size: 11px; font-weight: bold; border-top: 1px solid #334155; padding-top: 4px; color: #0f172a;">
          (_____________________)
        </div>
      </div>
      <div style="text-align: center;">
        <div style="font-size: 10px; color: #64748b; margin-bottom: 50px;">Penanggung Jawab / Pimpinan,</div>
        <div style="font-size: 11px; font-weight: bold; border-top: 1px solid #334155; padding-top: 4px; color: #0f172a;">
          (${escHtml(record.penanggungJawab || 'Owner / SPV')})
        </div>
      </div>
    </div>

    <div style="margin-top: 20px; text-align: center; font-size: 9px; color: #94a3b8; border-top: 1px dashed #cbd5e1; padding-top: 8px;">
      Dokumen Berita Acara ini telah diverifikasi dan digunakan sebagai dasar penyesuaian master stok sistem toko.
    </div>
  </div>
</body>
</html>`;
}

/**
 * Generate Lembar Kerja Hitung Fisik Blanko (Untuk dibawa staf keliling toko/gudang sebelum diinput)
 */
export function generateBlankStockOpnameSheetHTML(
  products: Product[], 
  s: StoreSettings, 
  kategoriFilter?: string,
  customTitle?: string
): string {
  const filtered = kategoriFilter && kategoriFilter !== 'Semua'
    ? products.filter((p) => (p.kategori || '').toLowerCase() === kategoriFilter.toLowerCase())
    : products;

  const titleHeader = customTitle || 'LEMBAR KERJA HITUNG FISIK (STOCK OPNAME BULANAN)';

  const rows = filtered.map((p, idx) => `
    <tr style="border-bottom: 1px solid #cbd5e1; height: 32px;">
      <td style="padding: 4px 6px; text-align: center; font-size: 10px; color: #64748b;">${idx + 1}</td>
      <td style="padding: 4px 6px; font-size: 10px; font-family: monospace; font-weight: bold;">${escHtml(p.kode || '-')}</td>
      <td style="padding: 4px 6px; font-size: 10px; font-weight: 600;">${escHtml(p.nama)}</td>
      <td style="padding: 4px 6px; text-align: center; font-size: 9px; color: #64748b;">${escHtml(p.kategori || 'Lainnya')}</td>
      <td style="padding: 4px 6px; text-align: center; font-size: 10px; color: #475569;">${escHtml(p.satuan || 'pcs')}</td>
      <td style="padding: 4px 6px; text-align: right; font-size: 10px; color: #64748b; font-weight: bold;">${p.stok || '0'}</td>
      <td style="padding: 4px 6px; background-color: #f8fafc; border-left: 2px solid #94a3b8; border-right: 2px solid #94a3b8; text-align: center; font-size: 11px;">
        &nbsp;
      </td>
      <td style="padding: 4px 6px; background-color: #f8fafc; text-align: center; font-size: 10px;">
        &nbsp;
      </td>
      <td style="padding: 4px 6px; font-size: 9px; color: #94a3b8;">
        &nbsp;
      </td>
    </tr>
  `).join('');

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Lembar Hitung Fisik Stock Opname - ${escHtml(s.name || 'Toko')}</title>
<style>
  @page { size: A4 portrait; margin: 10mm; }
  @media print {
    body { margin: 0; padding: 0; background: #fff; font-size: 9pt; }
    .no-print { display: none !important; }
    tr { page-break-inside: avoid; }
  }
  * { box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
    margin: 0;
    padding: 15px;
    color: #0f172a;
    background: #f1f5f9;
  }
  .page {
    background: #fff;
    max-width: 210mm;
    margin: 0 auto;
    padding: 15mm;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }
  table { width: 100%; border-collapse: collapse; }
  th {
    background-color: #e2e8f0;
    color: #1e293b;
    font-size: 9px;
    padding: 6px;
    border-bottom: 2px solid #64748b;
    text-transform: uppercase;
  }
</style>
</head>
<body>
  <div class="page">
    <div style="border-bottom: 2px solid #0f172a; padding-bottom: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: flex-end;">
      <div>
        <div style="font-size: 16px; font-weight: 900; color: #0f172a;">${escHtml(s.name || 'TOKO ERVO')}</div>
        <div style="font-size: 10px; color: #475569;">${escHtml(titleHeader)}</div>
      </div>
      <div style="text-align: right; font-size: 10px; color: #475569;">
        <div>Kategori: <strong>${escHtml(kategoriFilter || 'Semua Kategori')}</strong></div>
        <div>Total: <strong>${filtered.length} Produk</strong></div>
      </div>
    </div>

    <!-- Form Header Isian Tangan Petugas -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 4px; padding: 8px 12px; margin-bottom: 12px; font-size: 10px;">
      <div>Tanggal: ___________________</div>
      <div>Waktu: _____ : _____ WIB</div>
      <div>Petugas: ___________________</div>
      <div>Saksi / SPV: ________________</div>
    </div>

    <!-- Tabel Daftar Hitung Fisik -->
    <table>
      <thead>
        <tr>
          <th style="width: 25px; text-align: center;">No</th>
          <th style="width: 75px; text-align: left;">Kode</th>
          <th style="text-align: left;">Nama Barang</th>
          <th style="width: 80px; text-align: center;">Kategori</th>
          <th style="width: 35px; text-align: center;">Sat</th>
          <th style="width: 50px; text-align: right;">Stok Aplikasi</th>
          <th style="width: 75px; text-align: center; background-color: #cbd5e1;">HITUNG FISIK</th>
          <th style="width: 60px; text-align: center;">SELISIH</th>
          <th style="width: 110px; text-align: left;">KETERANGAN / KONDISI</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
      </tbody>
    </table>

    <div style="margin-top: 25px; display: flex; justify-content: space-around; font-size: 10px; page-break-inside: avoid;">
      <div style="text-align: center;">
        <div style="margin-bottom: 40px; color: #64748b;">Petugas Penghitung Fisik,</div>
        <div style="border-top: 1px solid #334155; padding-top: 3px; font-weight: bold;">(______________________)</div>
      </div>
      <div style="text-align: center;">
        <div style="margin-bottom: 40px; color: #64748b;">Kepala Toko / Penanggung Jawab,</div>
        <div style="border-top: 1px solid #334155; padding-top: 3px; font-weight: bold;">(______________________)</div>
      </div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Generate Struk Thermal Ringkas Stock Opname (80mm / 58mm)
 */
export function generateStockOpnameThermalHTML(record: StockOpnameRecord, s: StoreSettings): string {
  const items = record.items || [];
  const selisihItems = items.filter((i) => i.selisih !== 0);

  const selisihRows = selisihItems.map((i) => `
    <div style="margin-bottom: 4px; border-bottom: 1px dotted #ccc; padding-bottom: 2px;">
      <div style="font-weight: bold;">${escHtml(i.nama)}</div>
      <div style="display: flex; justify-content: space-between; font-size: 9px;">
        <span>Sistem: ${i.stokSistem} | Fisik: <strong>${i.stokFisik}</strong></span>
        <span style="font-weight: bold; color: ${i.selisih < 0 ? '#b91c1c' : '#1d4ed8'};">
          ${i.selisih < 0 ? `Kurang (${i.selisih})` : `Lebih (+${i.selisih})`}
        </span>
      </div>
      ${i.catatan ? `<div style="font-size: 8px; color: #555; font-style: italic;">Ket: ${escHtml(i.catatan)}</div>` : ''}
    </div>
  `).join('');

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Ringkasan Opname - ${escHtml(record.id)}</title>
<style>
  @page { size: 80mm auto; margin: 2mm; }
  @media print { body { margin: 0; width: 80mm; } }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { width: 80mm; font-family: 'Courier New', Courier, monospace; font-size: 10px; color: #000; line-height: 1.3; padding: 3mm; }
  .center { text-align: center; }
  .r { text-align: right; }
  .bold { font-weight: bold; }
  .divider { border-top: 1px dashed #000; margin: 4px 0; }
  .double-divider { border-top: 2px solid #000; margin: 4px 0; }
</style>
</head>
<body>
  <div class="center bold" style="font-size: 12px;">${escHtml(s.name || 'TOKO ERVO')}</div>
  <div class="center" style="font-size: 9px;">${escHtml(s.address || '')}</div>
  <div class="divider"></div>
  <div class="center bold" style="font-size: 11px;">RINGKASAN STOCK OPNAME</div>
  <div class="center" style="font-size: 9px;">${escHtml(record.id)}</div>
  <div class="divider"></div>

  <table style="width: 100%; font-size: 9px;">
    <tr><td>Periode</td><td class="r bold">${escHtml(record.bulanPeriode || '-')}</td></tr>
    <tr><td>Tanggal</td><td class="r">${escHtml(record.tanggal)} ${escHtml(record.jam || '')}</td></tr>
    <tr><td>Petugas</td><td class="r bold">${escHtml(record.petugas)}</td></tr>
    <tr><td>Total Dicek</td><td class="r">${record.totalItemDihitung} Produk</td></tr>
    <tr><td>Item Sesuai</td><td class="r bold" style="color: #16a34a;">${record.totalItemSesuai} Item</td></tr>
    <tr><td>Item Kurang</td><td class="r bold" style="color: #dc2626;">${record.totalItemSelisihKurang} Item</td></tr>
    <tr><td>Item Lebih</td><td class="r bold" style="color: #2563eb;">${record.totalItemSelisihLebih} Item</td></tr>
  </table>

  <div class="divider"></div>
  <div style="display: flex; justify-content: space-between; font-weight: bold;">
    <span>Total Nilai Selisih:</span>
    <span>${record.totalNilaiSelisih === 0 ? 'Rp 0' : (record.totalNilaiSelisih < 0 ? '-' + fRp(Math.abs(record.totalNilaiSelisih)) : '+' + fRp(record.totalNilaiSelisih))}</span>
  </div>
  <div class="divider"></div>

  ${selisihItems.length > 0 ? `
    <div class="bold" style="margin-bottom: 4px; font-size: 9px;">RINCIAN BARANG SELISIH (${selisihItems.length}):</div>
    ${selisihRows}
  ` : `
    <div class="center" style="padding: 6px 0; font-style: italic;">Semua produk sesuai (tidak ada selisih)</div>
  `}

  <div class="divider"></div>
  <div style="margin-top: 15px; display: flex; justify-content: space-between; font-size: 9px; text-align: center;">
    <div style="width: 45%;">
      <div>Petugas,</div>
      <div style="margin-top: 25px; border-top: 1px solid #000;">(${escHtml(record.petugas)})</div>
    </div>
    <div style="width: 45%;">
      <div>Penanggung Jawab,</div>
      <div style="margin-top: 25px; border-top: 1px solid #000;">(${escHtml(record.penanggungJawab || 'SPV')})</div>
    </div>
  </div>

  <div class="center" style="font-size: 8px; margin-top: 10px; color: #555;">
    Stok sistem telah diperbarui otomatis.
  </div>
</body>
</html>`;
}
