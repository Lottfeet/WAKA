import { 
  Product, 
  Customer, 
  StoreSettings, 
  Invoice, 
  InvoiceItem, 
  KasirUser, 
  StockInRecord, 
  ExpenseRecord, 
  PelunasanRecord 
} from '../types';
import firebaseConfig from '../../firebase-applet-config.json';

// OAuth Client ID configured for this applet
export const GOOGLE_OAUTH_CLIENT_ID = (firebaseConfig as any).oAuthClientId || "859212266522-u5o9930f230bla1ern5ktf2i28bi11be.apps.googleusercontent.com";

const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive'
].join(' ');

export interface GoogleAuthState {
  accessToken: string | null;
  expiresAt: number | null;
  userEmail: string | null;
  spreadsheetId: string | null;
  spreadsheetUrl: string | null;
  spreadsheetTitle: string | null;
}

// Memory & Storage caching for access token and connected spreadsheet
let currentAccessToken: string | null = null;
let tokenExpiresAt: number | null = null;

export function getStoredSpreadsheetId(): string | null {
  return localStorage.getItem('strukku_gdrive_sheet_id') || null;
}

export function setStoredSpreadsheetId(id: string, url?: string, title?: string) {
  if (id) {
    localStorage.setItem('strukku_gdrive_sheet_id', id);
    if (url) localStorage.setItem('strukku_gdrive_sheet_url', url);
    if (title) localStorage.setItem('strukku_gdrive_sheet_title', title);
  } else {
    localStorage.removeItem('strukku_gdrive_sheet_id');
    localStorage.removeItem('strukku_gdrive_sheet_url');
    localStorage.removeItem('strukku_gdrive_sheet_title');
  }
}

export function getStoredSpreadsheetInfo() {
  return {
    id: localStorage.getItem('strukku_gdrive_sheet_id'),
    url: localStorage.getItem('strukku_gdrive_sheet_url'),
    title: localStorage.getItem('strukku_gdrive_sheet_title') || 'WARUNG KAKA - Database POS & Keuangan',
  };
}

export function getStoredToken(): string | null {
  if (currentAccessToken && tokenExpiresAt && Date.now() < tokenExpiresAt) {
    return currentAccessToken;
  }
  const token = sessionStorage.getItem('strukku_gauth_token');
  const exp = sessionStorage.getItem('strukku_gauth_exp');
  if (token && exp && Number(exp) > Date.now()) {
    currentAccessToken = token;
    tokenExpiresAt = Number(exp);
    return token;
  }
  return null;
}

export function setStoredToken(token: string, expiresInSec = 3599) {
  currentAccessToken = token;
  const exp = Date.now() + expiresInSec * 1000;
  tokenExpiresAt = exp;
  sessionStorage.setItem('strukku_gauth_token', token);
  sessionStorage.setItem('strukku_gauth_exp', String(exp));
}

export function clearStoredToken() {
  currentAccessToken = null;
  tokenExpiresAt = null;
  sessionStorage.removeItem('strukku_gauth_token');
  sessionStorage.removeItem('strukku_gauth_exp');
}

/**
 * Request OAuth Access Token from user via Google Identity Services
 */
export function requestGoogleAccessToken(): Promise<string> {
  return new Promise((resolve, reject) => {
    // Check cached active token
    const existing = getStoredToken();
    if (existing) {
      return resolve(existing);
    }

    if (typeof window === 'undefined' || !(window as any).google?.accounts?.oauth2) {
      return reject(new Error('Google Identity Services library belum termuat. Harap muat ulang halaman.'));
    }

    try {
      const tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: GOOGLE_OAUTH_CLIENT_ID,
        scope: SCOPES,
        callback: (resp: any) => {
          if (resp && resp.access_token) {
            setStoredToken(resp.access_token, resp.expires_in ? Number(resp.expires_in) : 3599);
            resolve(resp.access_token);
          } else if (resp && resp.error) {
            reject(new Error(resp.error_description || resp.error || 'Autentikasi Google dibatalkan'));
          } else {
            reject(new Error('Gagal mendapatkan token autentikasi Google'));
          }
        },
        error_callback: (err: any) => {
          reject(new Error(err?.message || 'Gagal membuka dialog otorisasi Google'));
        }
      });

      tokenClient.requestAccessToken({ prompt: '' });
    } catch (err: any) {
      reject(err);
    }
  });
}

/**
 * Extract Spreadsheet ID from full URL or return ID directly
 */
export function extractSpreadsheetId(input: string): string {
  if (!input) return '';
  const trimmed = input.trim();
  const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  return trimmed;
}

/**
 * Create a brand new Google Spreadsheet configured for WARUNG KAKA
 */
export async function createWarungSpreadsheet(
  title = `WARUNG KAKA - Database POS & Keuangan (${new Date().toLocaleDateString('id-ID')})`
): Promise<{ success: boolean; spreadsheetId?: string; spreadsheetUrl?: string; message?: string }> {
  try {
    const token = await requestGoogleAccessToken();
    
    // 1. Create spreadsheet structure
    const payload = {
      properties: {
        title: title,
        timeZone: 'Asia/Jakarta',
      },
      sheets: [
        { properties: { title: 'Produk', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Transaksi', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Detail', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Pelanggan', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Pelunasan', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'BarangMasuk', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Pengeluaran', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Kasir', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Pengaturan', gridProperties: { frozenRowCount: 1 } } },
      ],
    };

    const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson?.error?.message || `Gagal membuat spreadsheet (${res.status})`);
    }

    const created = await res.json();
    const spreadsheetId = created.spreadsheetId;
    const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

    // 2. Populate Headers for all sheets
    await initializeSpreadsheetHeaders(spreadsheetId, token);

    // Save active connected sheet
    setStoredSpreadsheetId(spreadsheetId, spreadsheetUrl, title);

    return {
      success: true,
      spreadsheetId,
      spreadsheetUrl,
      message: 'Spreadsheet Google Sheets berhasil dibuat dan dikonfigurasi!',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Gagal membuat Google Spreadsheet',
    };
  }
}

/**
 * Initialize standard column headers for the spreadsheet
 */
export async function initializeSpreadsheetHeaders(spreadsheetId: string, token: string) {
  const headerData = [
    {
      range: 'Produk!A1:G1',
      values: [['Kode', 'Nama Produk', 'Harga Jual', 'Kategori', 'Stok', 'Satuan', 'HPP']],
    },
    {
      range: 'Transaksi!A1:T1',
      values: [[
        'No Invoice', 'Tanggal', 'Jam', 'Pelanggan', 'Kasir', 
        'Subtotal', 'Diskon %', 'Diskon Rp', 'Pajak %', 'Pajak Rp', 
        'Total', 'Metode Bayar', 'DP', 'Sisa', 'Kembalian', 
        'Deadline', 'Status', 'Nego Rp', 'No HP', 'Alamat'
      ]],
    },
    {
      range: 'Detail!A1:K1',
      values: [[
        'No Invoice', 'Kode', 'Nama Produk', 'Harga', 'Qty', 
        'Total Item', 'Panjang (m)', 'Lebar (m)', 'Bahan', 'Catatan', 'Diskon Item'
      ]],
    },
    {
      range: 'Pelanggan!A1:E1',
      values: [['Nama Pelanggan', 'No HP', 'Alamat', 'Kelas / Tipe', 'Catatan']],
    },
    {
      range: 'Pelunasan!A1:H1',
      values: [['Tanggal', 'Jam', 'No Invoice', 'Pelanggan', 'Jumlah Bayar', 'Metode Bayar', 'Kasir', 'Keterangan']],
    },
    {
      range: 'BarangMasuk!A1:I1',
      values: [['Tanggal', 'Jam', 'Kode Produk', 'Nama Produk', 'Qty Masuk', 'Harga Beli (HPP)', 'Supplier', 'Catatan', 'Kasir']],
    },
    {
      range: 'Pengeluaran!A1:E1',
      values: [['Tanggal', 'Kategori', 'Keterangan', 'Nominal (Rp)', 'Penanggung Jawab / PJ']],
    },
    {
      range: 'Kasir!A1:C1',
      values: [['Nama Kasir', 'Role / Jabatan', 'PIN / Password']],
    },
    {
      range: 'Pengaturan!A1:B1',
      values: [['Pengaturan', 'Nilai']],
    },
  ];

  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      valueInputOption: 'USER_ENTERED',
      data: headerData,
    }),
  });
}

/**
 * Push all active store data from Warung Kaka directly to Google Sheets
 */
export async function syncAllToGoogleSheets(
  spreadsheetId: string,
  data: {
    products: Product[];
    customers: Customer[];
    invoices: Invoice[];
    kasirUsers?: KasirUser[];
    settings?: StoreSettings;
    expenses?: ExpenseRecord[];
    stockIn?: StockInRecord[];
    pelunasan?: PelunasanRecord[];
  }
): Promise<{ success: boolean; message: string; rowsSynced?: Record<string, number> }> {
  try {
    const token = await requestGoogleAccessToken();

    // 1. Format Products rows
    const productRows = [
      ['Kode', 'Nama Produk', 'Harga Jual', 'Kategori', 'Stok', 'Satuan', 'HPP'],
      ...data.products.map((p) => [
        p.kode || '',
        p.nama || '',
        Number(p.harga || 0),
        p.kategori || 'Umum',
        Number(p.stok || 0),
        p.satuan || 'pcs',
        Number(p.hpp || p.hargaBeli || 0),
      ]),
    ];

    // 2. Format Customer rows
    const customerRows = [
      ['Nama Pelanggan', 'No HP', 'Alamat', 'Kelas / Tipe', 'Catatan'],
      ...data.customers.map((c) => [
        c.nama || '',
        c.telepon ? `'${c.telepon}` : '',
        c.alamat || '',
        c.kelas || 'Umum',
        c.catatan || '',
      ]),
    ];

    // 3. Format Transactions and Detail Items
    const invoiceRows = [
      [
        'No Invoice', 'Tanggal', 'Jam', 'Pelanggan', 'Kasir', 
        'Subtotal', 'Diskon %', 'Diskon Rp', 'Pajak %', 'Pajak Rp', 
        'Total', 'Metode Bayar', 'DP', 'Sisa', 'Kembalian', 
        'Deadline', 'Status', 'Nego Rp', 'No HP', 'Alamat'
      ],
      ...data.invoices.map((inv) => [
        inv.invoiceNo || '',
        inv.date || '',
        inv.time || '',
        inv.customer || 'Umum',
        inv.cashier || '',
        Number(inv.subtotal || 0),
        Number(inv.discPct || 0),
        Number(inv.discAmt || 0),
        Number(inv.taxPct || 0),
        Number(inv.taxAmt || 0),
        Number(inv.total || 0),
        inv.payMethod || 'Tunai',
        Number(inv.dp || 0),
        Number(inv.sisa || 0),
        Number(inv.kembalian || 0),
        inv.deadline || '',
        inv.status || (Number(inv.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
        Number(inv.negoAmt || 0),
        inv.customerPhone ? `'${inv.customerPhone}` : '',
        inv.customerAddress || '',
      ]),
    ];

    const detailRows: any[][] = [
      ['No Invoice', 'Kode', 'Nama Produk', 'Harga', 'Qty', 'Total Item', 'Panjang (m)', 'Lebar (m)', 'Bahan', 'Catatan', 'Diskon Item']
    ];
    data.invoices.forEach((inv) => {
      (inv.items || []).forEach((it) => {
        detailRows.push([
          inv.invoiceNo || '',
          it.kode || '',
          it.nama || '',
          Number(it.harga || 0),
          Number(it.qty || 0),
          Number(it.totalItem || (Number(it.harga || 0) * Number(it.qty || 0))),
          Number(it.panjang || 0),
          Number(it.lebar || 0),
          it.bahan || '',
          it.catatan || '',
          Number(it.diskonItem || 0),
        ]);
      });
    });

    // 4. Format Expenses
    const expenseRows = [
      ['Tanggal', 'Kategori', 'Keterangan', 'Nominal (Rp)', 'Penanggung Jawab / PJ'],
      ...(data.expenses || []).map((exp) => [
        exp.tanggal || '',
        exp.kategori || 'Operasional',
        exp.keterangan || '',
        Number(exp.nominal || 0),
        exp.pj || '',
      ]),
    ];

    // 5. Format Stock In
    const stockInRows = [
      ['Tanggal', 'Jam', 'Kode Produk', 'Nama Produk', 'Qty Masuk', 'Harga Beli (HPP)', 'Supplier', 'Catatan', 'Kasir'],
      ...(data.stockIn || []).map((s) => [
        s.tanggal || s.date || '',
        s.jam || s.time || '',
        s.kode || s.kodeProduct || '',
        s.nama || s.namaProduct || '',
        Number(s.qty || s.jumlahMasuk || 0),
        Number(s.hargaBeli || 0),
        s.supplier || '',
        s.catatan || '',
        s.cashier || s.penanggungJawab || '',
      ]),
    ];

    // 6. Format Kasir Users
    const kasirRows = [
      ['Nama Kasir', 'Role / Jabatan', 'PIN / Password'],
      ...(data.kasirUsers || []).map((u) => [
        u.nama || '',
        u.role || 'Kasir',
        u.password || '',
      ]),
    ];

    // 7. Format Settings
    const settingsRows = [
      ['Pengaturan', 'Nilai'],
      ['Nama Toko', data.settings?.name || 'WARUNGKU'],
      ['Tagline', data.settings?.tagline || ''],
      ['Alamat', data.settings?.address || ''],
      ['Telepon', data.settings?.phone || ''],
      ['Footer Struk', data.settings?.footer || ''],
      ['Rekening Bank', data.settings?.rekening || ''],
      ['Prefix Invoice', data.settings?.prefixInvoice || 'INV'],
      ['Auto Logout (Menit)', String(data.settings?.autoLogoutMinutes || 15)],
      ['Ambang Min Stok', String(data.settings?.minStockThreshold || 10)],
      ['Terakhir Disinkronkan', new Date().toLocaleString('id-ID')],
    ];

    // Batch Update Ranges
    const batchData = [
      { range: 'Produk!A1:G' + productRows.length, values: productRows },
      { range: 'Pelanggan!A1:E' + customerRows.length, values: customerRows },
      { range: 'Transaksi!A1:T' + invoiceRows.length, values: invoiceRows },
      { range: 'Detail!A1:K' + detailRows.length, values: detailRows },
      { range: 'Pengeluaran!A1:E' + expenseRows.length, values: expenseRows },
      { range: 'BarangMasuk!A1:I' + stockInRows.length, values: stockInRows },
      { range: 'Kasir!A1:C' + kasirRows.length, values: kasirRows },
      { range: 'Pengaturan!A1:B' + settingsRows.length, values: settingsRows },
    ];

    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: batchData,
      }),
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson?.error?.message || `Gagal mengirim data ke Google Sheets (${res.status})`);
    }

    return {
      success: true,
      message: '✓ Berhasil sinkronisasi seluruh data ke Google Sheets!',
      rowsSynced: {
        produk: data.products.length,
        pelanggan: data.customers.length,
        transaksi: data.invoices.length,
        pengeluaran: (data.expenses || []).length,
        barangMasuk: (data.stockIn || []).length,
      }
    };
  } catch (err: any) {
    return {
      success: false,
      message: 'Gagal sinkronisasi Google Sheets: ' + (err?.message || 'Error tidak diketahui'),
    };
  }
}

/**
 * Append a newly completed invoice to Google Sheets Transaksi & Detail
 */
export async function appendInvoiceToGoogleSheets(
  spreadsheetId: string,
  invoice: Invoice
): Promise<{ success: boolean; message?: string }> {
  try {
    const token = getStoredToken();
    if (!token) return { success: false, message: 'Google OAuth token belum tersedia.' };

    // 1. Append Transaksi row
    const transRow = [
      invoice.invoiceNo || '',
      invoice.date || '',
      invoice.time || '',
      invoice.customer || 'Umum',
      invoice.cashier || '',
      Number(invoice.subtotal || 0),
      Number(invoice.discPct || 0),
      Number(invoice.discAmt || 0),
      Number(invoice.taxPct || 0),
      Number(invoice.taxAmt || 0),
      Number(invoice.total || 0),
      invoice.payMethod || 'Tunai',
      Number(invoice.dp || 0),
      Number(invoice.sisa || 0),
      Number(invoice.kembalian || 0),
      invoice.deadline || '',
      invoice.status || (Number(invoice.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
      Number(invoice.negoAmt || 0),
      invoice.customerPhone ? `'${invoice.customerPhone}` : '',
      invoice.customerAddress || '',
    ];

    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Transaksi!A1:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: [transRow] }),
    });

    // 2. Append Detail items
    if (invoice.items && invoice.items.length > 0) {
      const detailRows = invoice.items.map((it) => [
        invoice.invoiceNo || '',
        it.kode || '',
        it.nama || '',
        Number(it.harga || 0),
        Number(it.qty || 0),
        Number(it.totalItem || (Number(it.harga || 0) * Number(it.qty || 0))),
        Number(it.panjang || 0),
        Number(it.lebar || 0),
        it.bahan || '',
        it.catatan || '',
        Number(it.diskonItem || 0),
      ]);

      await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Detail!A1:append?valueInputOption=USER_ENTERED`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ values: detailRows }),
      });
    }

    return { success: true, message: 'Transaksi berhasil tercatat di Google Sheets' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Gagal menyimpan transaksi ke Google Sheets' };
  }
}

/**
 * Append an expense record to Google Sheets Pengeluaran
 */
export async function appendExpenseToGoogleSheets(
  spreadsheetId: string,
  expense: ExpenseRecord
): Promise<{ success: boolean; message?: string }> {
  try {
    const token = getStoredToken();
    if (!token) return { success: false, message: 'Google OAuth token belum tersedia.' };

    const row = [
      expense.tanggal || '',
      expense.kategori || 'Operasional',
      expense.keterangan || '',
      Number(expense.nominal || 0),
      expense.pj || '',
    ];

    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Pengeluaran!A1:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: [row] }),
    });

    return { success: true, message: 'Pengeluaran tercatat di Google Sheets' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Gagal append pengeluaran ke Google Sheets' };
  }
}

/**
 * Append stock in record to Google Sheets BarangMasuk
 */
export async function appendStockInToGoogleSheets(
  spreadsheetId: string,
  stockIn: StockInRecord
): Promise<{ success: boolean; message?: string }> {
  try {
    const token = getStoredToken();
    if (!token) return { success: false, message: 'Google OAuth token belum tersedia.' };

    const row = [
      stockIn.tanggal || stockIn.date || '',
      stockIn.jam || stockIn.time || '',
      stockIn.kode || stockIn.kodeProduct || '',
      stockIn.nama || stockIn.namaProduct || '',
      Number(stockIn.qty || stockIn.jumlahMasuk || 0),
      Number(stockIn.hargaBeli || 0),
      stockIn.supplier || '',
      stockIn.catatan || '',
      stockIn.cashier || stockIn.penanggungJawab || '',
    ];

    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/BarangMasuk!A1:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: [row] }),
    });

    return { success: true, message: 'Stok masuk tercatat di Google Sheets' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Gagal append stok masuk ke Google Sheets' };
  }
}

/**
 * Pull and parse products from a Google Spreadsheet
 */
export async function pullProductsFromGoogleSheet(spreadsheetId: string): Promise<{ success: boolean; products?: Product[]; message?: string }> {
  try {
    const token = await requestGoogleAccessToken();
    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Produk!A2:H500`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!res.ok) {
      throw new Error(`Gagal membaca sheet Produk (${res.status})`);
    }

    const data = await res.json();
    const rows = data.values || [];
    const products: Product[] = rows
      .filter((r: any[]) => r && r[1] && String(r[1]).trim())
      .map((r: any[], idx: number) => ({
        kode: String(r[0] || `PRD-${idx + 1}`).trim().toUpperCase(),
        nama: String(r[1] || '').trim(),
        harga: Number(String(r[2] || 0).replace(/[^0-9.-]+/g, '')),
        kategori: String(r[3] || 'Umum').trim(),
        stok: Number(String(r[4] || 0).replace(/[^0-9.-]+/g, '')),
        satuan: String(r[5] || 'pcs').trim(),
        hpp: Number(String(r[6] || 0).replace(/[^0-9.-]+/g, '')),
        minStok: Number(String(r[7] || 10).replace(/[^0-9.-]+/g, '')),
      }));

    return { success: true, products };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Gagal menarik produk dari Google Sheets' };
  }
}
