import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { RecentInvoiceItem, getPelunasanHistory, sortPelunasanHistoryAsc } from '../services/gasService';
import { ExpenseRecord, PelunasanRecord } from '../types';
import { 
  fRp, 
  calculateCashInflowByPaymentMethod,
  getInvoicePaymentCategory,
  PeriodCashInflowBreakdown,
  PelunasanInflowItem,
  parsePaymentCategory,
  parseUniversalDate,
  isDatesDifferent,
} from './formatters';

function resolveInvoiceHistory(inv: RecentInvoiceItem): Array<{
  jenis: string;
  date: string;
  payMethod: string;
  jumlahBayar: number;
  sisa: number;
}> {
  const invoiceNo = inv.invoiceNo || '';
  const backendHist = Array.isArray((inv as any).historiPelunasan)
    ? (inv as any).historiPelunasan
    : Array.isArray((inv as any).history)
    ? (inv as any).history
    : null;

  const rawList: PelunasanRecord[] = backendHist !== null
    ? backendHist
    : (invoiceNo ? getPelunasanHistory(invoiceNo) : []);

  const sortedList = sortPelunasanHistoryAsc(rawList);
  const tot = Number(inv.total || 0);
  const totalPelunasan = sortedList.reduce((acc, item) => acc + Number(item.jumlahBayar || 0), 0);
  const sisaCurrent = inv.sisa !== undefined ? Number(inv.sisa) : tot;

  const calculatedDp = Math.max(0, tot - sisaCurrent - totalPelunasan);
  const dp = (inv.dp !== undefined && Number(inv.dp) > 0) ? Number(inv.dp) : calculatedDp;

  const sisaAwal = Math.max(0, tot - dp);
  let currentSisa = sisaAwal;

  const result: Array<{
    jenis: string;
    date: string;
    payMethod: string;
    jumlahBayar: number;
    sisa: number;
  }> = [];

  if (dp > 0) {
    const dpDate = [inv.date || '', (inv as any).time || ''].filter(Boolean).join(' ') || '-';
    result.push({
      jenis: 'DP / Pembayaran Awal',
      date: dpDate,
      payMethod: (inv as any).payMethod || 'Tunai',
      jumlahBayar: dp,
      sisa: sisaAwal,
    });
  }

  sortedList.forEach((hItem, idx) => {
    const bayar = Number(hItem.jumlahBayar || 0);
    currentSisa = Math.max(0, currentSisa - bayar);
    const hDate = [hItem.date || '', hItem.time || ''].filter(Boolean).join(' ') || '-';
    result.push({
      jenis: `Pelunasan / Angsuran #${idx + 1}`,
      date: hDate,
      payMethod: hItem.payMethod || 'Tunai',
      jumlahBayar: bayar,
      sisa: currentSisa,
    });
  });

  return result;
}

interface GeneratePdfOptions {
  periodLabel: string;
  invoices: RecentInvoiceItem[];
  stats: {
    totalGross: number;
    totalPaid: number;
    totalPiutang: number;
    count: number;
    countLunas: number;
    countDP: number;
    fromNewSales?: number;
    fromPelunasanPiutang?: number;
  };
  storeName?: string;
  printedBy?: string;
  periodCashInflow?: PeriodCashInflowBreakdown;
  pelunasanItems?: PelunasanInflowItem[];
}

export function generateMonthlyReportPdf({
  periodLabel,
  invoices,
  stats,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Kasir Utama',
  periodCashInflow,
  pelunasanItems = [],
}: GeneratePdfOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const marginX = 12; // 12mm left & right margins
  const contentWidth = pageWidth - marginX * 2; // 186mm

  // Resolve breakdown metrics
  const actualPelunasan = stats.fromPelunasanPiutang !== undefined
    ? stats.fromPelunasanPiutang
    : (periodCashInflow?.fromPelunasanPiutang ?? pelunasanItems.reduce((acc, p) => acc + (p.jumlahBayar || 0), 0));
  
  const actualNewSales = stats.fromNewSales !== undefined
    ? stats.fromNewSales
    : (periodCashInflow?.fromNewSales ?? Math.max(0, stats.totalPaid - actualPelunasan));

  // --- HEADER DECORATION ---
  // Top Banner Dark Bar
  doc.setFillColor(30, 41, 59); // Slate-800
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Top Accent Orange Strip
  doc.setFillColor(234, 88, 12); // Orange-600
  doc.rect(0, 28, pageWidth, 2, 'F');

  // Title Text inside Banner
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(203, 213, 225); // Slate-300
  doc.text('LAPORAN REKAPITULASI TRANSAKSI & PENJUALAN SALES', marginX, 18);

  // Print Meta info (Top Right)
  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Cetak: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  // --- METADATA & SUMMARY BOX ---
  let currentY = 35;

  // Period Badge
  doc.setFillColor(241, 245, 249); // Slate-100
  doc.setDrawColor(203, 213, 225); // Slate-300
  doc.roundedRect(marginX, currentY, contentWidth, 11, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42); // Slate-900
  doc.text(`PERIODE LAPORAN: ${periodLabel.toUpperCase()}`, marginX + 4, currentY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Total Transaksi: ${stats.count} Order`, pageWidth - marginX - 4, currentY + 7, { align: 'right' });

  currentY += 15;

  // Calculate exact totals directly from the sales invoices list
  let salesGross = 0;
  let salesPaid = 0;
  let salesPiutang = 0;

  invoices.forEach((inv) => {
    const tot = Number(inv.total || 0);
    const sisa = Number(inv.sisa || 0);
    const paid = Math.max(0, tot - sisa);
    salesGross += tot;
    salesPaid += paid;
    salesPiutang += sisa;
  });

  // Use calculated values from the sales invoices table
  const finalGross = salesGross > 0 || invoices.length > 0 ? salesGross : Number(stats.totalGross || 0);
  const finalPaid = salesPaid > 0 || invoices.length > 0 ? salesPaid : Number(stats.fromNewSales !== undefined ? stats.fromNewSales : stats.totalPaid || 0);
  const finalPiutang = salesPiutang > 0 || invoices.length > 0 ? salesPiutang : Number(stats.totalPiutang || 0);

  // Key Financial Metrics Grid (3 Box Columns)
  const gap = 4;
  const boxWidth = (contentWidth - gap * 2) / 3; // 59.33mm each
  const boxHeight = 18;

  // Box 1: Total Omzet (Total Nilai Transaksi Penjualan)
  doc.setFillColor(254, 243, 199); // Amber 100
  doc.setDrawColor(252, 211, 77);
  doc.roundedRect(marginX, currentY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(146, 64, 14); // Amber 800
  doc.text('TOTAL OMZET PENJUALAN', marginX + 3.5, currentY + 5.5);
  doc.setFontSize(10.5);
  doc.setTextColor(120, 53, 15);
  doc.text(fRp(finalGross), marginX + 3.5, currentY + 13);

  // Box 2: Total Dibayar / Diterima dari Penjualan Sales
  const box2X = marginX + boxWidth + gap;
  doc.setFillColor(220, 252, 231); // Emerald 100
  doc.setDrawColor(134, 239, 172);
  doc.roundedRect(box2X, currentY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(22, 101, 52); // Emerald 800
  doc.text('TOTAL DIBAYAR (DITERIMA)', box2X + 3.5, currentY + 5.5);
  doc.setFontSize(10.5);
  doc.setTextColor(20, 83, 45);
  doc.text(fRp(finalPaid), box2X + 3.5, currentY + 13);

  // Box 3: Total Sisa Piutang Penjualan
  const box3X = marginX + (boxWidth + gap) * 2;
  doc.setFillColor(254, 226, 226); // Red 100
  doc.setDrawColor(252, 165, 165);
  doc.roundedRect(box3X, currentY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(153, 27, 27); // Red 800
  doc.text('SISA PIUTANG (BELUM LUNAS)', box3X + 3.5, currentY + 5.5);
  doc.setFontSize(10.5);
  doc.setTextColor(127, 29, 29);
  doc.text(fRp(finalPiutang), box3X + 3.5, currentY + 13);

  // --- BREAKDOWN ARUS KAS MASUK BERDASARKAN METODE PEMBAYARAN TRANSAKSI SALES ---
  const monthlyCashByMethod = periodCashInflow || calculateCashInflowByPaymentMethod(invoices);
  const mBreakdownY = currentY + boxHeight + 3;
  const mBreakGap = 2.5;
  const mBreakW = (contentWidth - mBreakGap * 3) / 4;
  const mBreakH = 9.5;

  // Box 1: Tunai
  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(187, 247, 208);
  doc.roundedRect(marginX, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('KAS TUNAI', marginX + 2.5, mBreakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(monthlyCashByMethod.Tunai), marginX + 2.5, mBreakdownY + 7.5);

  // Box 2: Transfer
  const mb2X = marginX + mBreakW + mBreakGap;
  doc.setFillColor(239, 246, 255);
  doc.setDrawColor(191, 219, 254);
  doc.roundedRect(mb2X, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('TRANSFER BANK', mb2X + 2.5, mBreakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(monthlyCashByMethod.Transfer), mb2X + 2.5, mBreakdownY + 7.5);

  // Box 3: Debet
  const mb3X = marginX + (mBreakW + mBreakGap) * 2;
  doc.setFillColor(250, 245, 255);
  doc.setDrawColor(233, 213, 255);
  doc.roundedRect(mb3X, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(107, 33, 168);
  doc.text('KARTU DEBET', mb3X + 2.5, mBreakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(monthlyCashByMethod.Debet), mb3X + 2.5, mBreakdownY + 7.5);

  // Box 4: QRIS
  const mb4X = marginX + (mBreakW + mBreakGap) * 3;
  doc.setFillColor(254, 252, 232);
  doc.setDrawColor(254, 240, 138);
  doc.roundedRect(mb4X, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(133, 77, 14);
  doc.text('QRIS', mb4X + 2.5, mBreakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(monthlyCashByMethod.QRIS), mb4X + 2.5, mBreakdownY + 7.5);

  currentY = mBreakdownY + mBreakH + 6;

  // Section Label
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text('RINCIAN TRANSAKSI PENJUALAN', marginX, currentY);
  currentY += 3.5;

  // --- TRANSACTION TABLE ---
  const tableData = invoices.map((inv, idx) => {
    const totalVal = Number(inv.total || 0);
    const sisaVal = Number(inv.sisa || 0);
    const paidVal = totalVal - sisaVal;
    const isLunas = sisaVal <= 0;
    const method = getInvoicePaymentCategory(inv);

    return [
      (idx + 1).toString(),
      inv.invoiceNo || '-',
      inv.date || '-',
      inv.customer || 'Umum',
      inv.cashier || 'Kasir',
      method,
      fRp(totalVal),
      fRp(paidVal),
      fRp(sisaVal),
      isLunas ? 'LUNAS' : 'DP/SISA',
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'No. Invoice', 'Tanggal', 'Pelanggan', 'Kasir', 'Metode', 'Total', 'Dibayar', 'Sisa', 'Status']],
    body: tableData.length > 0 ? tableData : [['-', '-', '-', 'Tidak ada transaksi', '-', '-', 'Rp 0', 'Rp 0', 'Rp 0', '-']],
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: {
      overflow: 'linebreak',
      cellPadding: 1.5,
      fontSize: 7.2,
    },
    headStyles: {
      fillColor: [30, 41, 59], // Slate 800
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      halign: 'center',
      valign: 'middle',
    },
    bodyStyles: {
      fontSize: 7.2,
      textColor: [30, 41, 59],
      valign: 'middle',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },   // No
      1: { cellWidth: 28, fontStyle: 'bold' }, // No Invoice
      2: { halign: 'center', cellWidth: 18 },  // Tanggal
      3: { cellWidth: 25 },                    // Pelanggan
      4: { cellWidth: 16 },                    // Kasir
      5: { halign: 'center', cellWidth: 16 },  // Metode
      6: { halign: 'right', cellWidth: 20 },   // Total
      7: { halign: 'right', cellWidth: 20 },   // Dibayar
      8: { halign: 'right', cellWidth: 18 },   // Sisa
      9: { halign: 'center', cellWidth: 16 },  // Status
    },
    didParseCell: (data) => {
      // Highlight Status Column
      if (data.section === 'body' && data.column.index === 9) {
        if (data.cell.raw === 'LUNAS') {
          data.cell.styles.textColor = [22, 101, 52]; // Emerald 800
          data.cell.styles.fontStyle = 'bold';
        } else {
          data.cell.styles.textColor = [180, 83, 9]; // Amber 700
          data.cell.styles.fontStyle = 'bold';
        }
      }
    },
  });

  // Get position after table
  const finalY = (doc as any).lastAutoTable?.finalY || currentY + 40;

  // --- SIGNATURE / VALIDATION BLOCK ---
  let sigY = finalY + 12;
  if (sigY + 35 > pageHeight) {
    doc.addPage();
    sigY = 25;
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const leftX = marginX + 10;
  const rightX = pageWidth - marginX - 50;

  doc.text('Dibuat Oleh,', leftX, sigY);
  doc.text('Kasir / Petugas', leftX, sigY + 4.5);

  doc.text('Disetujui Oleh,', rightX, sigY);
  doc.text('Pemilik / Manager', rightX, sigY + 4.5);

  // Line for signatures
  doc.setDrawColor(148, 163, 184);
  doc.line(leftX, sigY + 22, leftX + 40, sigY + 22);
  doc.line(rightX, sigY + 22, rightX + 40, sigY + 22);

  doc.setFontSize(8);
  doc.text('( ................................. )', leftX, sigY + 26);
  doc.text('( ................................. )', rightX, sigY + 26);

  // Footer Page Number
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Dokumen Resmi Laporan Keuangan ERVO PRINT - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  // Save the PDF
  const filenameStr = periodLabel.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`Laporan_Sales_${filenameStr}_${new Date().toISOString().split('T')[0]}.pdf`);
}

export interface CustomerPiutangSummary {
  customerName: string;
  invoices: RecentInvoiceItem[];
  totalGross: number;
  totalPaid: number;
  totalSisa: number;
  count: number;
}

export function generateCustomerBillingPdf({
  customerName,
  invoices,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Kasir Utama',
  rekening,
}: {
  customerName: string;
  invoices: RecentInvoiceItem[];
  storeName?: string;
  printedBy?: string;
  rekening?: string;
}) {
  let rekeningVal = rekening;
  if (!rekeningVal) {
    try {
      const raw = localStorage.getItem('strukku_settings');
      if (raw) {
        const parsed = JSON.parse(raw);
        rekeningVal = parsed.rekening;
      }
    } catch {}
  }
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2;

  let totalGross = 0;
  let totalSisa = 0;
  invoices.forEach((inv) => {
    totalGross += Number(inv.total || 0);
    totalSisa += Number(inv.sisa || 0);
  });
  const totalPaid = totalGross - totalSisa;

  // Header Banner
  doc.setFillColor(30, 41, 59);
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setFillColor(234, 88, 12);
  doc.rect(0, 28, pageWidth, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(203, 213, 225);
  doc.text('SURAT PENAGIHAN PIUTANG / REKAP TAGIHAN PELANGGAN', marginX, 18);

  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Dokumen: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Dicetak Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  let currentY = 35;

  // Customer Target Box
  doc.setFillColor(254, 243, 199);
  doc.setDrawColor(245, 158, 11);
  doc.roundedRect(marginX, currentY, contentWidth, 16, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(146, 64, 14);
  doc.text('DITUJUKAN KEPADA PELANGGAN:', marginX + 4, currentY + 6);
  doc.setFontSize(12);
  doc.setTextColor(120, 53, 15);
  doc.text(customerName.toUpperCase(), marginX + 4, currentY + 12);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(180, 83, 9);
  doc.text(`Total Belum Lunas: ${invoices.length} Invoice`, pageWidth - marginX - 4, currentY + 10, { align: 'right' });

  currentY += 21;

  // Summary Metrics Grid
  const gap = 4;
  const boxWidth = (contentWidth - gap * 2) / 3;
  const boxHeight = 16;

  // Total Nilai Transaksi
  doc.setFillColor(241, 245, 249);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(marginX, currentY, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text('TOTAL NILAI ORDER', marginX + 3.5, currentY + 5);
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(totalGross), marginX + 3.5, currentY + 12);

  // Total DP / Sudah Bayar
  const box2X = marginX + boxWidth + gap;
  doc.setFillColor(220, 252, 231);
  doc.setDrawColor(134, 239, 172);
  doc.roundedRect(box2X, currentY, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(22, 101, 52);
  doc.text('TOTAL SUDAH DIBAYAR', box2X + 3.5, currentY + 5);
  doc.setFontSize(10);
  doc.setTextColor(20, 83, 45);
  doc.text(fRp(totalPaid), box2X + 3.5, currentY + 12);

  // Sisa Piutang Wajib Bayar
  const box3X = marginX + (boxWidth + gap) * 2;
  doc.setFillColor(254, 226, 226);
  doc.setDrawColor(239, 68, 68);
  doc.roundedRect(box3X, currentY, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(153, 27, 27);
  doc.text('SISA WAJIB DIBAYAR', box3X + 3.5, currentY + 5);
  doc.setFontSize(10.5);
  doc.setTextColor(185, 28, 28);
  doc.text(fRp(totalSisa), box3X + 3.5, currentY + 12);

  currentY += boxHeight + 7;

  // Table Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text('RINCIAN INVOICE / TAGIHAN BELUM LUNAS', marginX, currentY);
  currentY += 3.5;

  const tableData = invoices.map((inv, idx) => {
    const tot = Number(inv.total || 0);
    const sisa = Number(inv.sisa || 0);
    const paidSoFar = Math.max(0, tot - sisa);

    return [
      (idx + 1).toString(),
      inv.invoiceNo || '-',
      inv.date || '-',
      fRp(tot),
      fRp(paidSoFar),
      fRp(sisa),
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'No. Invoice', 'Tanggal Order', 'Total Order', 'DP / Dibayar', 'Sisa Tagihan']],
    body: tableData,
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: { cellPadding: 2, fontSize: 8 },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { fontStyle: 'bold', cellWidth: 40 },
      2: { halign: 'center', cellWidth: 30 },
      3: { halign: 'right', cellWidth: 32 },
      4: { halign: 'right', cellWidth: 32 },
      5: { halign: 'right', cellWidth: 42, fontStyle: 'bold', textColor: [185, 28, 28] },
    },
    didParseCell: (data) => {
      if (data.section === 'foot') {
        if (data.column.index >= 3) {
          data.cell.styles.halign = 'right';
        }
      }
    },
    foot: [
      [
        '',
        'TOTAL PIUTANG',
        '',
        fRp(totalGross),
        fRp(totalPaid),
        fRp(totalSisa),
      ],
    ],
    footStyles: {
      fillColor: [254, 226, 226],
      textColor: [185, 28, 28],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
  });

  // --- HISTORI PEMBAYARAN & ANGSURAN PIUTANG ---
  let historySectionY = (doc as any).lastAutoTable?.finalY || currentY + 40;
  historySectionY += 7;

  if (historySectionY + 25 > pageHeight) {
    doc.addPage();
    historySectionY = 20;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(194, 65, 12);
  doc.text('HISTORI PEMBAYARAN & ANGSURAN PIUTANG', marginX, historySectionY);
  historySectionY += 4;

  invoices.forEach((inv) => {
    const historyRows = resolveInvoiceHistory(inv);

    if (invoices.length > 1) {
      if (historySectionY + 15 > pageHeight) {
        doc.addPage();
        historySectionY = 20;
      }
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);
      doc.text(`Invoice: ${inv.invoiceNo || '-'} (Order: ${inv.date || '-'})`, marginX, historySectionY + 3);
      historySectionY += 5;
    }

    const tableBody = historyRows.map((r, idx) => [
      (idx + 1).toString(),
      r.jenis,
      r.date,
      r.payMethod,
      fRp(r.jumlahBayar),
      fRp(r.sisa),
    ]);

    autoTable(doc, {
      startY: historySectionY,
      head: [['No', 'Jenis Pembayaran', 'Tanggal & Waktu', 'Metode', 'Jumlah Bayar', 'Sisa Piutang']],
      body: tableBody,
      margin: { left: marginX, right: marginX },
      theme: 'grid',
      styles: { cellPadding: 2, fontSize: 8 },
      headStyles: {
        fillColor: [234, 88, 12],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        halign: 'center',
      },
      columnStyles: {
        0: { halign: 'center', cellWidth: 10 },
        1: { fontStyle: 'bold' },
        2: { halign: 'center', cellWidth: 35 },
        3: { halign: 'center', cellWidth: 25 },
        4: { halign: 'right', cellWidth: 32, fontStyle: 'bold', textColor: [22, 101, 52] },
        5: { halign: 'right', cellWidth: 35, fontStyle: 'bold', textColor: [185, 28, 28] },
      },
    });

    historySectionY = (doc as any).lastAutoTable?.finalY || historySectionY + 20;
    historySectionY += 4;
  });

  const finalY = historySectionY;

  let payInfoY = finalY + 2;
  const rekLines = rekeningVal ? rekeningVal.split('\n').map((l) => l.trim()).filter(Boolean) : [];
  const rekExtraHeight = rekLines.length > 0 ? (rekLines.length * 4.5 + 5) : 0;
  const payBoxHeight = 16 + rekExtraHeight;

  if (payInfoY + payBoxHeight + 35 > pageHeight) {
    doc.addPage();
    payInfoY = 20;
  }

  doc.setFillColor(255, 247, 237);
  doc.setDrawColor(254, 215, 170);
  doc.roundedRect(marginX, payInfoY, contentWidth, payBoxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(194, 65, 12);
  doc.text('CATATAN / PETUNJUK PEMBAYARAN:', marginX + 3.5, payInfoY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Mohon melakukan pelunasan sisa tagihan ke kasir toko atau melalui transfer bank resmi toko.', marginX + 3.5, payInfoY + 9.5);

  let currentTextY = payInfoY + 13.5;

  if (rekLines.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(154, 52, 18);
    doc.text('NO. REKENING PEMBAYARAN (TRANSFER BANK):', marginX + 3.5, currentTextY);
    currentTextY += 4;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);
    rekLines.forEach((line) => {
      doc.text(`•  ${line}`, marginX + 5, currentTextY);
      currentTextY += 4.5;
    });
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(120, 53, 15);
  doc.text('Bukti pembayaran mohon dikonfirmasi kembali kepada petugas kasir kami. Terima kasih.', marginX + 3.5, currentTextY);

  let sigY = payInfoY + payBoxHeight + 6;
  if (sigY + 35 > pageHeight) {
    doc.addPage();
    sigY = 20;
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const leftX = marginX + 10;
  const rightX = pageWidth - marginX - 50;

  doc.text('Petugas Penagihan,', leftX, sigY);
  doc.text('Diterima Oleh (Pelanggan),', rightX, sigY);

  doc.setDrawColor(148, 163, 184);
  doc.line(leftX, sigY + 20, leftX + 45, sigY + 20);
  doc.line(rightX, sigY + 20, rightX + 45, sigY + 20);

  doc.setFontSize(8);
  doc.text(`( ${printedBy} )`, leftX, sigY + 24);
  doc.text(`( ${customerName} )`, rightX, sigY + 24);

  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Surat Penagihan Resmi - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  const safeCustName = customerName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`Surat_Penagihan_${safeCustName}_${new Date().toISOString().split('T')[0]}.pdf`);
}

export function generateAllPiutangReportPdf({
  customerSummaries,
  totalPiutang,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Kasir Utama',
}: {
  customerSummaries: CustomerPiutangSummary[];
  totalPiutang: number;
  storeName?: string;
  printedBy?: string;
}) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2;

  doc.setFillColor(30, 41, 59);
  doc.rect(0, 0, pageWidth, 28, 'F');
  doc.setFillColor(234, 88, 12);
  doc.rect(0, 28, pageWidth, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(203, 213, 225);
  doc.text('REKAPITULASI SISA PIUTANG PER PELANGGAN (BELUM LUNAS)', marginX, 18);

  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Cetak: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  let currentY = 35;

  doc.setFillColor(254, 226, 226);
  doc.setDrawColor(239, 68, 68);
  doc.roundedRect(marginX, currentY, contentWidth, 14, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(153, 27, 27);
  doc.text(`TOTAL SISA PIUTANG KELUAR: ${fRp(totalPiutang)}`, marginX + 4, currentY + 8.5);
  doc.text(`Total Pelanggan Berpiutang: ${customerSummaries.length} Pelanggan`, pageWidth - marginX - 4, currentY + 8.5, { align: 'right' });

  currentY += 19;

  const tableData = customerSummaries.map((c, idx) => [
    (idx + 1).toString(),
    c.customerName,
    `${c.count} Invoice`,
    fRp(c.totalGross),
    fRp(c.totalPaid),
    fRp(c.totalSisa),
  ]);

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'Nama Pelanggan', 'Jml Invoice', 'Total Transaksi', 'Total Dibayar', 'Sisa Piutang']],
    body: tableData,
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: { cellPadding: 2, fontSize: 8 },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { fontStyle: 'bold', cellWidth: 50 },
      2: { halign: 'center', cellWidth: 25 },
      3: { halign: 'right', cellWidth: 32 },
      4: { halign: 'right', cellWidth: 32 },
      5: { halign: 'right', cellWidth: 37, fontStyle: 'bold', textColor: [185, 28, 28] },
    },
    didParseCell: (data) => {
      if (data.section === 'foot') {
        if (data.column.index === 2) {
          data.cell.styles.halign = 'center';
        } else if (data.column.index >= 3) {
          data.cell.styles.halign = 'right';
        }
      }
    },
    foot: [
      [
        '',
        'TOTAL SELURUH PIUTANG',
        `${customerSummaries.reduce((a, b) => a + b.count, 0)} Inv`,
        fRp(customerSummaries.reduce((a, b) => a + b.totalGross, 0)),
        fRp(customerSummaries.reduce((a, b) => a + b.totalPaid, 0)),
        fRp(totalPiutang),
      ],
    ],
    footStyles: {
      fillColor: [254, 226, 226],
      textColor: [185, 28, 28],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
  });

  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Rekapitulasi Piutang Pelanggan - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  doc.save(`Rekap_Piutang_Pelanggan_${new Date().toISOString().split('T')[0]}.pdf`);
}

interface GenerateFinancialReportOptions {
  periodLabel: string;
  totalOmset: number;
  totalPaid: number;
  totalPiutang: number;
  totalExpenses: number;
  expenses: ExpenseRecord[];
  expensesByCategory: Record<string, number>;
  invoices?: RecentInvoiceItem[];
  allInvoices?: RecentInvoiceItem[];
  storeName?: string;
  printedBy?: string;
  periodCashInflow?: PeriodCashInflowBreakdown;
  pelunasanItems?: PelunasanInflowItem[];
  fromNewSales?: number;
  fromPelunasanPiutang?: number;
}

function parseDateForLedgerSort(dateStr?: string, timeStr?: string): Date {
  if (!dateStr) return new Date(0);
  const parsed = parseUniversalDate(dateStr) || new Date(0);
  if (timeStr && typeof timeStr === 'string' && timeStr.includes(':')) {
    const [hh, mm] = timeStr.split(':');
    const hNum = parseInt(hh, 10);
    const mNum = parseInt(mm, 10);
    if (!isNaN(hNum) && !isNaN(mNum)) {
      parsed.setHours(hNum, mNum, 0, 0);
    }
  }
  return parsed;
}

export function generateFinancialReportPdf({
  periodLabel,
  totalOmset,
  totalPaid,
  totalPiutang,
  totalExpenses,
  expenses,
  expensesByCategory,
  invoices = [],
  allInvoices,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Owner / Manajemen',
  periodCashInflow,
  pelunasanItems = [],
  fromNewSales,
  fromPelunasanPiutang,
}: GenerateFinancialReportOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2;

  // Resolve breakdown metrics
  const actualPelunasan = fromPelunasanPiutang !== undefined
    ? fromPelunasanPiutang
    : (periodCashInflow?.fromPelunasanPiutang ?? pelunasanItems.reduce((acc, p) => acc + (p.jumlahBayar || 0), 0));
  
  const actualNewSales = fromNewSales !== undefined
    ? fromNewSales
    : (periodCashInflow?.fromNewSales ?? Math.max(0, totalPaid - actualPelunasan));

  const netBalance = totalPaid - totalExpenses;
  const netProfit = totalOmset - totalExpenses;
  const profitMarginPct = totalOmset > 0 ? ((netProfit / totalOmset) * 100).toFixed(1) : '0.0';

  // --- HEADER DECORATION ---
  doc.setFillColor(15, 23, 42); // Slate-900
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setFillColor(234, 88, 12); // Orange-600
  doc.rect(0, 28, pageWidth, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(226, 232, 240);
  doc.text(`Laporan Keuangan : ${periodLabel}`, marginX, 18);

  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Cetak: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Dicetak Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  let currentY = 34;

  // --- 1 ROW FINANCIAL INDICATORS (4 COLUMNS LEFT TO RIGHT) ---
  const cardGap = 3;
  const cardW = (contentWidth - cardGap * 3) / 4; // ~44.25mm each
  const cardH = 23;
  const cY = currentY;

  // CARD 1: TOTAL OMSET
  const c1X = marginX;
  doc.setFillColor(239, 246, 255); // Blue 50
  doc.setDrawColor(191, 219, 254); // Blue 200
  doc.roundedRect(c1X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('TOTAL OMSET', c1X + 3, cY + 5);
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(totalOmset), c1X + 3, cY + 11.5);
  doc.setDrawColor(219, 234, 254);
  doc.line(c1X + 3, cY + 14.5, c1X + cardW - 3, cY + 14.5);
  doc.setFontSize(5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`Sales Baru: ${fRp(actualNewSales)}`, c1X + 3, cY + 18.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(180, 83, 9);
  doc.text(`Piutang: ${fRp(totalPiutang)}`, c1X + cardW - 3, cY + 18.5, { align: 'right' });

  // CARD 2: TOTAL PENGELUARAN
  const c2X = marginX + cardW + cardGap;
  doc.setFillColor(254, 242, 242); // Red 50
  doc.setDrawColor(254, 202, 202); // Red 200
  doc.roundedRect(c2X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(153, 27, 27);
  doc.text('TOTAL PENGELUARAN', c2X + 3, cY + 5);
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(totalExpenses), c2X + 3, cY + 11.5);
  doc.setDrawColor(254, 226, 226);
  doc.line(c2X + 3, cY + 14.5, c2X + cardW - 3, cY + 14.5);
  doc.setFontSize(5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(153, 27, 27);
  doc.text(`${expenses.length} Trx Biaya`, c2X + 3, cY + 18.5);
  doc.text('Operasional', c2X + cardW - 3, cY + 18.5, { align: 'right' });

  // CARD 3: LABA BERSIH (PROFIT)
  const c3X = marginX + (cardW + cardGap) * 2;
  doc.setFillColor(236, 253, 245); // Emerald 50
  doc.setDrawColor(167, 243, 208); // Emerald 200
  doc.roundedRect(c3X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(6, 95, 70);
  doc.text('LABA BERSIH (PROFIT)', c3X + 3, cY + 5);
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(netProfit), c3X + 3, cY + 11.5);
  doc.setDrawColor(209, 250, 229);
  doc.line(c3X + 3, cY + 14.5, c3X + cardW - 3, cY + 14.5);
  doc.setFontSize(5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(4, 120, 87);
  doc.text('Profit Margin', c3X + 3, cY + 18.5);
  doc.setFont('helvetica', 'bold');
  doc.text(`${profitMarginPct}%`, c3X + cardW - 3, cY + 18.5, { align: 'right' });

  // CARD 4: ARUS KAS MASUK (REAL)
  const c4X = marginX + (cardW + cardGap) * 3;
  doc.setFillColor(24, 24, 27); // Zinc 900
  doc.setDrawColor(39, 39, 42); // Zinc 800
  doc.roundedRect(c4X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(228, 228, 231);
  doc.text('ARUS KAS MASUK (REAL)', c4X + 3, cY + 5);
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(fRp(totalPaid), c4X + 3, cY + 11.5);
  doc.setDrawColor(63, 63, 70);
  doc.line(c4X + 3, cY + 14.5, c4X + cardW - 3, cY + 14.5);
  doc.setFontSize(5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(161, 161, 170);
  doc.text(`Sales: ${fRp(actualNewSales)}`, c4X + 3, cY + 18.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(245, 158, 11);
  doc.text(`Pelunasan: ${fRp(actualPelunasan)}`, c4X + cardW - 3, cY + 18.5, { align: 'right' });

  // --- BREAKDOWN ARUS KAS MASUK BERDASARKAN METODE PEMBAYARAN ---
  const cashByMethod = periodCashInflow || calculateCashInflowByPaymentMethod(invoices);
  const breakdownY = cY + cardH + 3;
  const breakGap = 2.5;
  const breakW = (contentWidth - breakGap * 3) / 4; // 4 equal boxes
  const breakH = 9.5;

  // Box 1: Tunai
  doc.setFillColor(240, 253, 244); // Emerald 50
  doc.setDrawColor(187, 247, 208); // Emerald 200
  doc.roundedRect(marginX, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('KAS TUNAI', marginX + 2.5, breakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(cashByMethod.Tunai), marginX + 2.5, breakdownY + 7.5);

  // Box 2: Transfer
  const b2X = marginX + breakW + breakGap;
  doc.setFillColor(239, 246, 255); // Blue 50
  doc.setDrawColor(191, 219, 254); // Blue 200
  doc.roundedRect(b2X, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('TRANSFER BANK', b2X + 2.5, breakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(cashByMethod.Transfer), b2X + 2.5, breakdownY + 7.5);

  // Box 3: Debet
  const b3X = marginX + (breakW + breakGap) * 2;
  doc.setFillColor(250, 245, 255); // Purple 50
  doc.setDrawColor(233, 213, 255); // Purple 200
  doc.roundedRect(b3X, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(107, 33, 168);
  doc.text('KARTU DEBET', b3X + 2.5, breakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(cashByMethod.Debet), b3X + 2.5, breakdownY + 7.5);

  // Box 4: QRIS
  const b4X = marginX + (breakW + breakGap) * 3;
  doc.setFillColor(254, 252, 232); // Amber 50
  doc.setDrawColor(254, 240, 138); // Amber 200
  doc.roundedRect(b4X, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(133, 77, 14);
  doc.text('QRIS', b4X + 2.5, breakdownY + 3.2);
  doc.setFontSize(7.5);
  doc.text(fRp(cashByMethod.QRIS), b4X + 2.5, breakdownY + 7.5);

  currentY = breakdownY + breakH + 5;

  // --- SECTION TITLE: BUKU KAS & ARUS KAS ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(`BUKU KAS & MUTASI ARUS KAS (${periodLabel.toUpperCase()})`, marginX, currentY);
  currentY += 3.5;

  // --- BUILD CHRONOLOGICAL LEDGER ENTRIES ---
  interface LedgerEntry {
    date: string;
    ref: string;
    description: string;
    account: string;
    debit: number;
    kredit: number;
    rawDate: Date;
  }

  const combinedLedgerEntries: LedgerEntry[] = [];

  // 1. Initial & Same-Day Payments from Sales Created in this period
  invoices.forEach((inv) => {
    const tot = Number(inv.total || 0);
    const sisa = Number(inv.sisa || 0);
    const totalPaidOnInv = Math.max(0, tot - sisa);
    
    const histori: any[] = Array.isArray((inv as any).historiPelunasan)
      ? (inv as any).historiPelunasan
      : Array.isArray((inv as any).pelunasanHistory)
      ? (inv as any).pelunasanHistory
      : [];

    // Calculate cross-date payments on other days
    const totalCrossDatePaid = histori.reduce((sum, h) => {
      if (!h) return sum;
      const paymentDate = h.date || h.tanggal || inv.date;
      return isDatesDifferent(inv.date, paymentDate) ? sum + Number(h.jumlahBayar || 0) : sum;
    }, 0);

    // Cash received on invoice creation date (initial DP + any same-day settlement)
    const salesCashReceived = Math.max(0, totalPaidOnInv - totalCrossDatePaid);

    if (salesCashReceived > 0) {
      const payMethod = getInvoicePaymentCategory(inv);
      const statusText = sisa <= 0 ? 'Lunas Langsung' : `DP (Sisa Piutang ${fRp(sisa)})`;
      const invRefNo = inv.invoiceNo || (inv as any).noInvoice || (inv as any).id || 'INV';
      combinedLedgerEntries.push({
        date: inv.date || '-',
        ref: invRefNo,
        description: `Penjualan Baru - ${inv.customer || 'Umum'} (${statusText}) [${payMethod}]`,
        account: 'Pendapatan Penjualan',
        debit: salesCashReceived,
        kredit: 0,
        rawDate: parseDateForLedgerSort(inv.date, (inv as any).time),
      });
    }
  });

  // 2. Pelunasan & Angsuran Piutang received in this period
  pelunasanItems.forEach((pel) => {
    const noteExtra = pel.catatan ? ` - ${pel.catatan}` : '';
    const crossDateNote = pel.isCrossDate ? ` [Nota Tgl: ${pel.invoiceDate}]` : '';
    const pelRefNo = pel.invoiceNo || (pel as any).noInvoice || (pel as any).id || 'INV';
    combinedLedgerEntries.push({
      date: pel.date || '-',
      ref: pelRefNo,
      description: `Penerimaan Pelunasan/Angsuran - ${pel.customer} [${pel.payMethod}]${crossDateNote}${noteExtra}`,
      account: 'Penerimaan Piutang Usaha',
      debit: pel.jumlahBayar,
      kredit: 0,
      rawDate: parseDateForLedgerSort(pel.date, pel.time),
    });
  });

  // 3. Expenses in this period
  expenses.forEach((exp) => {
    const nom = Number(exp.nominal || 0);
    if (nom > 0) {
      const expRefNo = exp.buktiRef || exp.id || 'EXP';
      combinedLedgerEntries.push({
        date: exp.tanggal || '-',
        ref: expRefNo,
        description: `${exp.keterangan || 'Biaya Operasional'} [PJ: ${exp.pj || 'Admin'}]`,
        account: `Beban ${exp.kategori || 'Operasional'}`,
        debit: 0,
        kredit: nom,
        rawDate: parseDateForLedgerSort(exp.tanggal),
      });
    }
  });

  // Sort Chronologically
  combinedLedgerEntries.sort((a, b) => a.rawDate.getTime() - b.rawDate.getTime());

  // Compute Running Balance
  let runningBalance = 0;
  const ledgerRows = combinedLedgerEntries.map((entry, idx) => {
    runningBalance += entry.debit - entry.kredit;
    return [
      (idx + 1).toString(),
      entry.date,
      entry.ref,
      entry.description,
      entry.account,
      entry.debit > 0 ? fRp(entry.debit) : '-',
      entry.kredit > 0 ? fRp(entry.kredit) : '-',
      fRp(runningBalance),
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'Tanggal', 'No. Ref', 'Uraian Transaksi / Keterangan', 'Akun / Kategori', 'Debit (Masuk)', 'Kredit (Keluar)', 'Saldo Kas']],
    body: ledgerRows.length > 0 ? ledgerRows : [['-', '-', '-', 'Belum ada transaksi recorded pada periode ini', '-', 'Rp 0', 'Rp 0', 'Rp 0']],
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: { cellPadding: 1.5, fontSize: 7, valign: 'middle' },
    headStyles: {
      fillColor: [30, 41, 59], // Slate 800
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 7 },                  // No
      1: { halign: 'center', cellWidth: 18 },                 // Tanggal
      2: { cellWidth: 29, fontStyle: 'bold', halign: 'center' }, // No. Ref (Wide enough for ERV-202608-xxx without wrapping)
      3: { cellWidth: 48 },                                   // Uraian
      4: { cellWidth: 26 },                                   // Akun
      5: { halign: 'right', cellWidth: 19, fontStyle: 'bold', textColor: [22, 101, 52] }, // Debit (Green)
      6: { halign: 'right', cellWidth: 18, fontStyle: 'bold', textColor: [185, 28, 28] }, // Kredit (Red)
      7: { halign: 'right', cellWidth: 21, fontStyle: 'bold', textColor: [15, 23, 42] },  // Saldo
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 12;

  // Signatures Section
  if (currentY + 35 > pageHeight - 15) {
    doc.addPage();
    currentY = 20;
  }

  const signW = 60;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  // Left Signature (Manajemen Keuangan)
  doc.text('Dibuat & Divalidasi oleh,', marginX + 10, currentY);
  doc.text('Petugas / Manajemen Keuangan', marginX + 10, currentY + 4);
  doc.line(marginX + 10, currentY + 22, marginX + 10 + signW, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(`(${printedBy})`, marginX + 10, currentY + 26);

  // Right Signature (Pemilik Studio)
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Menyetujui,', pageWidth - marginX - signW - 10, currentY);
  doc.text('Pemilik / Owner', pageWidth - marginX - signW - 10, currentY + 4);
  doc.line(pageWidth - marginX - signW - 10, currentY + 22, pageWidth - marginX - 10, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text('( Owner / Direktur )', pageWidth - marginX - signW - 10, currentY + 26);

  // Footer Page Numbering
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Dokumen Resmi Laporan Keuangan - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  const filenameStr = periodLabel.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`Laporan_Keuangan_${filenameStr}_${new Date().toISOString().split('T')[0]}.pdf`);
}

