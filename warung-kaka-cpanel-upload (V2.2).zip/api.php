<?php
/**
 * ============================================================================
 * WARUNG KAKA POS — BACKEND PHP + MYSQL (api.php)
 * ============================================================================
 * Konfigurasi database MySQL terpusat di server ini.
 * Berlaku untuk SEMUA perangkat (PC Kasir, Laptop, HP Kasir, Tablet).
 * Tidak perlu lagi memasukkan nama DB atau password di browser/HP!
 * ============================================================================
 */

error_reporting(0);
ini_set('display_errors', '0');

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ============================================================================
// 1. KONFIGURASI DATABASE MYSQL CPANEL (EDIT LANGSUNG DI BAWAH INI)
// ============================================================================
// Silakan sesuaikan kredensial di bawah ini jika berbeda di hosting/cPanel Anda:
$DB_HOST = getenv('DB_HOST') ?: 'localhost';          // Host MySQL (biasanya 'localhost')
$DB_PORT = getenv('DB_PORT') ?: '3306';               // Port MySQL (default 3306)
$DB_NAME = getenv('DB_NAME') ?: 'hump6894_Wrkaka';    // Nama Database Anda di cPanel
$DB_USER = getenv('DB_USER') ?: 'hump6894_Wrkaka';    // User Database MySQL di cPanel
$DB_PASS = getenv('DB_PASS') ?: '';                   // Password User Database cPanel Anda

// Jika file db_config.php ada di server, muat pengaturannya (opsional)
$configFile = __DIR__ . '/db_config.php';
if (file_exists($configFile)) {
    @include $configFile;
}

// Parse JSON request body
$rawBody = file_get_contents('php://input');
$body = json_decode($rawBody, true);
if (!is_array($body)) {
    $body = [];
}

// ============================================================================
// 2. KONEKSI PDO MYSQL DENGAN SMART FALLBACK
// ============================================================================
function getPdoConnection($host, $port, $dbName, $user, $pass) {
    $dsn = "mysql:host={$host};port={$port};dbname={$dbName};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    return new PDO($dsn, $user, $pass, $options);
}

try {
    $pdo = getPdoConnection($DB_HOST, $DB_PORT, $DB_NAME, $DB_USER, $DB_PASS);
} catch (PDOException $e) {
    // Smart fallback jika nama database di phpMyAdmin berbeda (misal: hump6894_Wrkaka vs hump6894_Waka)
    $alternateDb = (strcasecmp($DB_NAME, 'hump6894_Wrkaka') === 0) ? 'hump6894_Waka' : 'hump6894_Wrkaka';
    $fallbackSuccess = false;
    try {
        $pdo = getPdoConnection($DB_HOST, $DB_PORT, $alternateDb, $DB_USER, $DB_PASS);
        $DB_NAME = $alternateDb;
        $fallbackSuccess = true;
    } catch (PDOException $e2) {
        $fallbackSuccess = false;
    }

    if (!$fallbackSuccess) {
        http_response_code(500);
        echo json_encode([
            'status'   => 'error',
            'success'  => false,
            'message'  => 'Koneksi MySQL Gagal: ' . $e->getMessage(),
            'database' => $DB_NAME,
            'host'     => $DB_HOST,
            'hint'     => 'Silakan buka file `api.php` di cPanel File Manager dan sesuaikan $DB_HOST, $DB_NAME, $DB_USER, serta $DB_PASS sesuai akun MySQL cPanel Anda.'
        ]);
        exit;
    }
}

// ============================================================================
// 3. AUTO-CREATE TABEL SESUAI SKEMA `hump6894_Waka`
// ============================================================================
function ensureTablesExist(PDO $pdo) {
    $queries = [
        "CREATE TABLE IF NOT EXISTS `produk` (
            `kode` varchar(64) NOT NULL,
            `nama` varchar(255) NOT NULL DEFAULT '',
            `harga` double NOT NULL DEFAULT 0,
            `hargaBeli` double NOT NULL DEFAULT 0,
            `kategori` varchar(128) NOT NULL DEFAULT 'Lainnya',
            `stok` varchar(64) NOT NULL DEFAULT '0',
            `satuan` varchar(64) NOT NULL DEFAULT 'pcs',
            `tipeHarga` varchar(32) NOT NULL DEFAULT 'fix',
            `updatedAt` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`kode`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `pelanggan` (
            `nama` varchar(191) NOT NULL,
            `kelas` varchar(64) NOT NULL DEFAULT 'Reguler',
            `divisi` varchar(128) NOT NULL DEFAULT '',
            `diskon` double NOT NULL DEFAULT 0,
            `telepon` varchar(64) NOT NULL DEFAULT '',
            `catatan` text DEFAULT NULL,
            `alamat` text DEFAULT NULL,
            `oldNames` longtext DEFAULT NULL,
            `updatedAt` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`nama`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `invoices` (
            `invoiceNo` varchar(64) NOT NULL,
            `date` varchar(32) NOT NULL DEFAULT '',
            `time` varchar(32) NOT NULL DEFAULT '',
            `customer` varchar(191) NOT NULL DEFAULT 'Umum',
            `cashier` varchar(128) NOT NULL DEFAULT 'Admin',
            `subtotal` double NOT NULL DEFAULT 0,
            `discPct` double NOT NULL DEFAULT 0,
            `discAmt` double NOT NULL DEFAULT 0,
            `taxPct` double NOT NULL DEFAULT 0,
            `taxAmt` double NOT NULL DEFAULT 0,
            `negoAmt` double NOT NULL DEFAULT 0,
            `total` double NOT NULL DEFAULT 0,
            `payMethod` varchar(64) NOT NULL DEFAULT 'Tunai',
            `dp` double NOT NULL DEFAULT 0,
            `sisa` double NOT NULL DEFAULT 0,
            `kembalian` double NOT NULL DEFAULT 0,
            `deadline` varchar(64) NOT NULL DEFAULT '',
            `status` varchar(32) NOT NULL DEFAULT 'LUNAS',
            `slipNo` int(11) DEFAULT NULL,
            `slipPrinted` tinyint(1) NOT NULL DEFAULT 0,
            `slipPrintedAt` varchar(32) NOT NULL DEFAULT '',
            `customerPhone` varchar(64) NOT NULL DEFAULT '',
            `customerAddress` text DEFAULT NULL,
            `originalCustomer` varchar(191) NOT NULL DEFAULT '',
            `originalDivisi` varchar(128) NOT NULL DEFAULT '',
            `divisi` varchar(128) NOT NULL DEFAULT '',
            `lastEditedBy` varchar(128) NOT NULL DEFAULT '',
            `lastEditedAt` varchar(32) NOT NULL DEFAULT '',
            `editReason` text DEFAULT NULL,
            `items` longtext DEFAULT NULL,
            `auditLogs` longtext DEFAULT NULL,
            `createdAt` timestamp NULL DEFAULT current_timestamp(),
            `updatedAt` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`invoiceNo`),
            KEY `idx_customer` (`customer`),
            KEY `idx_status` (`status`),
            KEY `idx_date` (`date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `pelunasan` (
            `id` varchar(128) NOT NULL,
            `invoiceNo` varchar(64) NOT NULL,
            `date` varchar(32) NOT NULL DEFAULT '',
            `time` varchar(32) NOT NULL DEFAULT '',
            `customer` varchar(191) NOT NULL DEFAULT '',
            `cashier` varchar(128) NOT NULL DEFAULT '',
            `payMethod` varchar(64) NOT NULL DEFAULT 'Tunai',
            `jumlahBayar` double NOT NULL DEFAULT 0,
            `sisaAwal` double NOT NULL DEFAULT 0,
            `newSisa` double NOT NULL DEFAULT 0,
            `kembalian` double NOT NULL DEFAULT 0,
            `status` varchar(32) NOT NULL DEFAULT 'LUNAS',
            `catatan` text DEFAULT NULL,
            `createdAt` timestamp NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `idx_invoiceNo` (`invoiceNo`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `pengeluaran` (
            `id` varchar(128) NOT NULL,
            `tanggal` varchar(32) NOT NULL DEFAULT '',
            `kategori` varchar(128) NOT NULL DEFAULT 'Operasional',
            `keterangan` text DEFAULT NULL,
            `nominal` double NOT NULL DEFAULT 0,
            `pj` varchar(128) NOT NULL DEFAULT '',
            `buktiRef` varchar(128) NOT NULL DEFAULT '',
            `createdAt` timestamp NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `stok_masuk` (
            `id` varchar(128) NOT NULL,
            `kode` varchar(64) NOT NULL DEFAULT '',
            `nama` varchar(255) NOT NULL DEFAULT '',
            `qty` double NOT NULL DEFAULT 0,
            `hargaBeli` double DEFAULT NULL,
            `satuan` varchar(64) NOT NULL DEFAULT 'pcs',
            `supplier` varchar(191) NOT NULL DEFAULT '',
            `cashier` varchar(128) NOT NULL DEFAULT '',
            `tanggal` varchar(32) NOT NULL DEFAULT '',
            `jam` varchar(32) NOT NULL DEFAULT '',
            `catatan` text DEFAULT NULL,
            `createdAt` timestamp NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `stok_opname` (
            `id` varchar(128) NOT NULL,
            `tanggal` varchar(32) NOT NULL DEFAULT '',
            `jam` varchar(32) NOT NULL DEFAULT '',
            `bulanPeriode` varchar(32) NOT NULL DEFAULT '',
            `petugas` varchar(128) NOT NULL DEFAULT '',
            `penanggungJawab` varchar(128) NOT NULL DEFAULT '',
            `totalItemDihitung` int(11) NOT NULL DEFAULT 0,
            `totalItemSesuai` int(11) NOT NULL DEFAULT 0,
            `totalItemSelisihKurang` int(11) NOT NULL DEFAULT 0,
            `totalItemSelisihLebih` int(11) NOT NULL DEFAULT 0,
            `totalNilaiSelisihKurang` double NOT NULL DEFAULT 0,
            `totalNilaiSelisihLebih` double NOT NULL DEFAULT 0,
            `totalNilaiSelisih` double NOT NULL DEFAULT 0,
            `catatanUmum` text DEFAULT NULL,
            `items` longtext DEFAULT NULL,
            `createdAt` timestamp NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `kasir_users` (
            `nama` varchar(128) NOT NULL,
            `password` varchar(255) NOT NULL DEFAULT '',
            `role` varchar(32) NOT NULL DEFAULT 'kasir',
            PRIMARY KEY (`nama`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `settings` (
            `id` tinyint(4) NOT NULL DEFAULT 1,
            `data` longtext NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `activity_logs` (
            `id` varchar(128) NOT NULL,
            `ts` bigint(20) NOT NULL DEFAULT 0,
            `date` varchar(32) NOT NULL DEFAULT '',
            `time` varchar(32) NOT NULL DEFAULT '',
            `type` varchar(64) NOT NULL DEFAULT '',
            `actor` varchar(128) NOT NULL DEFAULT '',
            `title` varchar(255) NOT NULL DEFAULT '',
            `description` text DEFAULT NULL,
            `metadata` longtext DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_ts` (`ts`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `invoice_seq` (
            `prefix` varchar(16) NOT NULL,
            `yr` int(11) NOT NULL DEFAULT 2026,
            `seq` int(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (`prefix`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
    ];

    foreach ($queries as $sql) {
        $pdo->exec($sql);
    }

    // Pastikan kolom slipNo, slipPrinted, dan slipPrintedAt tersedia dengan tipe yang tepat
    $alterStatements = [
        "ALTER TABLE `invoices` ADD COLUMN `slipNo` int(11) DEFAULT NULL",
        "ALTER TABLE `invoices` ADD COLUMN `slipPrinted` tinyint(1) NOT NULL DEFAULT 0",
        "ALTER TABLE `invoices` ADD COLUMN `slipPrintedAt` varchar(32) NOT NULL DEFAULT ''",
        "ALTER TABLE `invoices` MODIFY COLUMN `slipPrintedAt` varchar(32) NOT NULL DEFAULT ''",
    ];
    foreach ($alterStatements as $alt) {
        try {
            $pdo->exec($alt);
        } catch (Exception $e) {}
    }
}

try {
    ensureTablesExist($pdo);
} catch (Exception $e) {
    // Continue even if table alter/create warns
}

// ============================================================================
// 4. HELPER BACA & SIMPAN DATA SESUAI SKEMA `hump6894_Waka`
// ============================================================================
function safeJsonDecode($val, $fallback) {
    if ($val === null || $val === '') return $fallback;
    if (is_array($val)) return $val;
    $decoded = json_decode($val, true);
    return (json_last_error() === JSON_ERROR_NONE) ? $decoded : $fallback;
}

function fetchAllFromSchema(PDO $pdo) {
    // 1. Produk
    $products = [];
    $stmt = $pdo->query("SELECT * FROM `produk` ORDER BY `nama` ASC");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $products[] = array_merge($extra, [
            'kode'      => (string)($row['kode'] ?? ''),
            'nama'      => (string)($row['nama'] ?? ''),
            'harga'     => (float)($row['harga'] ?? 0),
            'hargaBeli' => (float)($row['hargaBeli'] ?? 0),
            'kategori'  => (string)($row['kategori'] ?? 'Umum'),
            'stok'      => (string)($row['stok'] ?? '0'),
            'satuan'    => (string)($row['satuan'] ?? 'pcs'),
            'tipeHarga' => (string)($row['tipeHarga'] ?? 'fix'),
            'updatedAt' => (string)($row['updatedAt'] ?? $row['updated_at'] ?? ''),
        ]);
    }

    // 2. Pelanggan
    $customers = [];
    $stmt = $pdo->query("SELECT * FROM `pelanggan` ORDER BY `nama` ASC");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $customers[] = array_merge($extra, [
            'nama'      => (string)($row['nama'] ?? ''),
            'kelas'     => (string)($row['kelas'] ?? 'Reguler'),
            'divisi'    => (string)($row['divisi'] ?? ''),
            'diskon'    => (string)($row['diskon'] ?? '0'),
            'telepon'   => (string)($row['telepon'] ?? ''),
            'catatan'   => (string)($row['catatan'] ?? ''),
            'alamat'    => (string)($row['alamat'] ?? ''),
            'oldNames'  => safeJsonDecode($row['oldNames'] ?? null, []),
            'updatedAt' => (string)($row['updatedAt'] ?? $row['updated_at'] ?? ''),
        ]);
    }

    // 3. Pelunasan (kelompokkan per invoiceNo)
    $pelunasanHistory = [];
    $pelunasanByInvoice = [];
    try {
        $stmt = $pdo->query("SELECT * FROM `pelunasan` ORDER BY `createdAt` ASC");
        while ($row = $stmt->fetch()) {
            $invKey = strtoupper(trim((string)($row['invoiceNo'] ?? '')));
            $item = [
                'id'          => (string)($row['id'] ?? ''),
                'invoiceNo'   => (string)($row['invoiceNo'] ?? ''),
                'date'        => (string)($row['date'] ?? ''),
                'tanggal'     => (string)($row['date'] ?? ''),
                'time'        => (string)($row['time'] ?? ''),
                'waktu'       => (string)($row['time'] ?? ''),
                'customer'    => (string)($row['customer'] ?? ''),
                'cashier'     => (string)($row['cashier'] ?? ''),
                'kasir'       => (string)($row['cashier'] ?? ''),
                'payMethod'   => (string)($row['payMethod'] ?? 'Transfer'),
                'metode'      => (string)($row['payMethod'] ?? 'Transfer'),
                'jumlahBayar' => (float)($row['jumlahBayar'] ?? 0),
                'nominal'     => (float)($row['jumlahBayar'] ?? 0),
                'sisaAwal'    => (float)($row['sisaAwal'] ?? 0),
                'newSisa'     => (float)($row['newSisa'] ?? 0),
                'kembalian'   => (float)($row['kembalian'] ?? 0),
                'status'      => (string)($row['status'] ?? 'LUNAS'),
                'catatan'     => (string)($row['catatan'] ?? ''),
                'createdAt'   => (string)($row['createdAt'] ?? ''),
            ];
            $pelunasanHistory[] = $item;
            if ($invKey !== '') {
                if (!isset($pelunasanByInvoice[$invKey])) {
                    $pelunasanByInvoice[$invKey] = [];
                }
                $pelunasanByInvoice[$invKey][] = $item;
            }
        }
    } catch (Exception $e) {}

    // 4. Invoices
    $invoices = [];
    $stmt = $pdo->query("SELECT * FROM `invoices` ORDER BY `createdAt` DESC, `invoiceNo` DESC");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $invNo = trim((string)($row['invoiceNo'] ?? $row['no_invoice'] ?? $extra['invoiceNo'] ?? ''));
        $invKey = strtoupper($invNo);
        $tablePel = $pelunasanByInvoice[$invKey] ?? [];
        $embeddedPel = isset($row['pelunasanHistory']) ? safeJsonDecode($row['pelunasanHistory'], []) : ($extra['pelunasanHistory'] ?? []);

        // Gabungkan pelunasan dari tabel `pelunasan` + embedded
        $mergedMap = [];
        foreach (array_merge(is_array($embeddedPel) ? $embeddedPel : [], $tablePel) as $idx => $p) {
            $pid = (string)($p['id'] ?? (($p['date'] ?? '') . '_' . ($p['time'] ?? '') . '_' . ($p['jumlahBayar'] ?? $p['nominal'] ?? $idx)));
            $mergedMap[$pid] = $p;
        }
        $finalPel = array_values($mergedMap);

        $status = strtoupper((string)($row['status'] ?? $extra['status'] ?? 'LUNAS'));
        $rawSisa = (float)($row['sisa'] ?? $extra['sisa'] ?? 0);
        $sisa = ($status === 'LUNAS') ? 0 : $rawSisa;

        $rawPrinted = $row['slipPrinted'] ?? $extra['slipPrinted'] ?? 0;
        $rawPrintedAt = trim((string)($row['slipPrintedAt'] ?? $extra['slipPrintedAt'] ?? ''));
        if ($rawPrintedAt === '0' || strtolower($rawPrintedAt) === 'null' || strtolower($rawPrintedAt) === 'false' || strpos($rawPrintedAt, '0000-00-00') === 0) {
            $rawPrintedAt = '';
        }
        $isSlipPrinted = ($rawPrinted === true || $rawPrinted === 1 || $rawPrinted === '1' || strtolower((string)$rawPrinted) === 'true') && $rawPrintedAt !== '';
        if (!$isSlipPrinted) {
            $rawPrintedAt = '';
        }

        $invoices[] = array_merge($extra, [
            'invoiceNo'        => $invNo,
            'date'             => (string)($row['date'] ?? $row['tanggal'] ?? $extra['date'] ?? ''),
            'time'             => (string)($row['time'] ?? $extra['time'] ?? ''),
            'customer'         => (string)($row['customer'] ?? $row['pelanggan'] ?? $extra['customer'] ?? 'Umum'),
            'cashier'          => (string)($row['cashier'] ?? $extra['cashier'] ?? ''),
            'subtotal'         => (float)($row['subtotal'] ?? $extra['subtotal'] ?? 0),
            'discPct'          => (float)($row['discPct'] ?? $extra['discPct'] ?? 0),
            'discAmt'          => (float)($row['discAmt'] ?? $extra['discAmt'] ?? 0),
            'taxPct'           => (float)($row['taxPct'] ?? $extra['taxPct'] ?? 0),
            'taxAmt'           => (float)($row['taxAmt'] ?? $extra['taxAmt'] ?? 0),
            'negoAmt'          => (float)($row['negoAmt'] ?? $extra['negoAmt'] ?? 0),
            'total'            => (float)($row['total'] ?? $extra['total'] ?? 0),
            'payMethod'        => (string)($row['payMethod'] ?? $extra['payMethod'] ?? 'Tunai'),
            'dp'               => (float)($row['dp'] ?? $extra['dp'] ?? 0),
            'sisa'             => $sisa,
            'kembalian'        => (float)($row['kembalian'] ?? $extra['kembalian'] ?? 0),
            'deadline'         => (string)($row['deadline'] ?? $extra['deadline'] ?? ''),
            'status'           => $status,
            'slipNo'           => ($row['slipNo'] !== null && $row['slipNo'] !== '') ? (int)$row['slipNo'] : ($extra['slipNo'] ?? null),
            'slipPrinted'      => $isSlipPrinted,
            'slipPrintedAt'    => $rawPrintedAt,
            'customerPhone'    => (string)($row['customerPhone'] ?? $extra['customerPhone'] ?? ''),
            'customerAddress'  => (string)($row['customerAddress'] ?? $extra['customerAddress'] ?? ''),
            'originalCustomer' => (string)($row['originalCustomer'] ?? $extra['originalCustomer'] ?? ''),
            'originalDivisi'   => (string)($row['originalDivisi'] ?? $extra['originalDivisi'] ?? ''),
            'divisi'           => (string)($row['divisi'] ?? $extra['divisi'] ?? ''),
            'lastEditedBy'     => (string)($row['lastEditedBy'] ?? $extra['lastEditedBy'] ?? ''),
            'lastEditedAt'     => (string)($row['lastEditedAt'] ?? $extra['lastEditedAt'] ?? ''),
            'editReason'       => (string)($row['editReason'] ?? $extra['editReason'] ?? ''),
            'items'            => safeJsonDecode($row['items'] ?? null, $extra['items'] ?? []),
            'auditLogs'        => safeJsonDecode($row['auditLogs'] ?? null, $extra['auditLogs'] ?? []),
            'pelunasanHistory' => $finalPel,
            'historiPelunasan' => $finalPel,
            'createdAt'        => (string)($row['createdAt'] ?? $extra['createdAt'] ?? ''),
            'updatedAt'        => (string)($row['updatedAt'] ?? $row['updated_at'] ?? $extra['updatedAt'] ?? ''),
        ]);
    }

    // 5. Pengeluaran
    $expenses = [];
    $stmt = $pdo->query("SELECT * FROM `pengeluaran` ORDER BY `createdAt` DESC");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $expenses[] = array_merge($extra, [
            'id'         => (string)($row['id'] ?? ''),
            'tanggal'    => (string)($row['tanggal'] ?? $row['date'] ?? ''),
            'kategori'   => (string)($row['kategori'] ?? 'Operasional'),
            'keterangan' => (string)($row['keterangan'] ?? ''),
            'nominal'    => (float)($row['nominal'] ?? 0),
            'pj'         => (string)($row['pj'] ?? ''),
            'buktiRef'   => (string)($row['buktiRef'] ?? ''),
            'createdAt'  => (string)($row['createdAt'] ?? ''),
        ]);
    }

    // 6. Stok Masuk
    $stockIn = [];
    $stmt = $pdo->query("SELECT * FROM `stok_masuk` ORDER BY `createdAt` DESC");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $tgl = (string)($row['tanggal'] ?? $row['date'] ?? '');
        $jam = (string)($row['jam'] ?? $row['time'] ?? '');
        $stockIn[] = array_merge($extra, [
            'id'        => (string)($row['id'] ?? ''),
            'kode'      => (string)($row['kode'] ?? ''),
            'nama'      => (string)($row['nama'] ?? ''),
            'qty'       => (float)($row['qty'] ?? 0),
            'hargaBeli' => (float)($row['hargaBeli'] ?? 0),
            'satuan'    => (string)($row['satuan'] ?? 'pcs'),
            'supplier'  => (string)($row['supplier'] ?? ''),
            'cashier'   => (string)($row['cashier'] ?? ''),
            'date'      => $tgl,
            'tanggal'   => $tgl,
            'time'      => $jam,
            'jam'       => $jam,
            'catatan'   => (string)($row['catatan'] ?? ''),
            'createdAt' => (string)($row['createdAt'] ?? ''),
        ]);
    }

    // 7. Stok Opname
    $stockOpname = [];
    $stmt = $pdo->query("SELECT * FROM `stok_opname` ORDER BY `createdAt` DESC");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $stockOpname[] = array_merge($extra, [
            'id'                      => (string)($row['id'] ?? ''),
            'tanggal'                 => (string)($row['tanggal'] ?? ''),
            'jam'                     => (string)($row['jam'] ?? ''),
            'bulanPeriode'            => (string)($row['bulanPeriode'] ?? ''),
            'petugas'                 => (string)($row['petugas'] ?? ''),
            'penanggungJawab'         => (string)($row['penanggungJawab'] ?? ''),
            'totalItemDihitung'       => (int)($row['totalItemDihitung'] ?? 0),
            'totalItemSesuai'         => (int)($row['totalItemSesuai'] ?? 0),
            'totalItemSelisihKurang'  => (int)($row['totalItemSelisihKurang'] ?? 0),
            'totalItemSelisihLebih'   => (int)($row['totalItemSelisihLebih'] ?? 0),
            'totalNilaiSelisihKurang' => (float)($row['totalNilaiSelisihKurang'] ?? 0),
            'totalNilaiSelisihLebih'  => (float)($row['totalNilaiSelisihLebih'] ?? 0),
            'totalNilaiSelisih'       => (float)($row['totalNilaiSelisih'] ?? 0),
            'catatanUmum'             => (string)($row['catatanUmum'] ?? ''),
            'items'                   => safeJsonDecode($row['items'] ?? null, []),
            'createdAt'               => (string)($row['createdAt'] ?? ''),
        ]);
    }

    // 8. Kasir Users
    $kasirUsers = [];
    $stmt = $pdo->query("SELECT * FROM `kasir_users`");
    while ($row = $stmt->fetch()) {
        $extra = isset($row['data']) ? safeJsonDecode($row['data'], []) : [];
        $kasirUsers[] = array_merge($extra, [
            'nama'     => (string)($row['nama'] ?? ''),
            'password' => (string)($row['password'] ?? ''),
            'role'     => (string)($row['role'] ?? 'kasir'),
        ]);
    }

    // 9. Settings
    $settings = new stdClass();
    try {
        $stmt = $pdo->query("SELECT * FROM `settings` LIMIT 1");
        if ($row = $stmt->fetch()) {
            $rawJson = $row['data'] ?? $row['setting_value'] ?? '{}';
            $decoded = safeJsonDecode($rawJson, []);
            if (!empty($decoded)) {
                $settings = $decoded;
            }
        }
    } catch (Exception $e) {}

    // 10. Activity Logs
    $activityLogs = [];
    try {
        $stmt = $pdo->query("SELECT * FROM `activity_logs` ORDER BY `ts` DESC LIMIT 2000");
        while ($row = $stmt->fetch()) {
            $ts = (int)($row['ts'] ?? $row['timestamp'] ?? 0);
            $meta = safeJsonDecode($row['metadata'] ?? null, null);
            $logItem = [
                'id'          => (string)($row['id'] ?? ''),
                'ts'          => $ts,
                'timestamp'   => $ts,
                'date'        => (string)($row['date'] ?? ''),
                'time'        => (string)($row['time'] ?? ''),
                'type'        => (string)($row['type'] ?? ''),
                'actor'       => (string)($row['actor'] ?? ''),
                'title'       => (string)($row['title'] ?? ''),
                'description' => (string)($row['description'] ?? ''),
            ];
            if ($meta !== null) {
                $logItem['metadata'] = $meta;
            }
            $activityLogs[] = $logItem;
        }
    } catch (Exception $e) {}

    // 11. Invoice Seq
    $invoiceSeq = [];
    try {
        $stmt = $pdo->query("SELECT * FROM `invoice_seq`");
        while ($row = $stmt->fetch()) {
            $prefix = strtoupper(trim((string)($row['prefix'] ?? '')));
            if ($prefix !== '') {
                $invoiceSeq[$prefix] = [
                    'yr'  => (int)($row['yr'] ?? date('Y')),
                    'seq' => (int)($row['seq'] ?? 0),
                ];
            }
        }
    } catch (Exception $e) {}

    return [
        'products'         => $products,
        'customers'        => $customers,
        'kasirUsers'       => $kasirUsers,
        'settings'         => $settings,
        'invoices'         => $invoices,
        'pelunasanHistory' => $pelunasanHistory,
        'expenses'         => $expenses,
        'stockIn'          => $stockIn,
        'stockOpname'      => $stockOpname,
        'activityLogs'     => $activityLogs,
        'invoiceSeq'       => $invoiceSeq,
    ];
}

function upsertRecord(PDO $pdo, $collection, $item) {
    if (!is_array($item)) return;
    $now = round(microtime(true) * 1000);

    switch ($collection) {
        case 'products':
        case 'produk':
            $kode = trim((string)($item['kode'] ?? ''));
            if ($kode === '') return;
            $sql = "INSERT INTO `produk` (`kode`, `nama`, `harga`, `hargaBeli`, `kategori`, `stok`, `satuan`, `tipeHarga`)
                    VALUES (:kode, :nama, :harga, :hargaBeli, :kategori, :stok, :satuan, :tipeHarga)
                    ON DUPLICATE KEY UPDATE
                        `nama` = VALUES(`nama`),
                        `harga` = VALUES(`harga`),
                        `hargaBeli` = VALUES(`hargaBeli`),
                        `kategori` = VALUES(`kategori`),
                        `stok` = VALUES(`stok`),
                        `satuan` = VALUES(`satuan`),
                        `tipeHarga` = VALUES(`tipeHarga`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':kode'      => $kode,
                ':nama'      => (string)($item['nama'] ?? ''),
                ':harga'     => (float)($item['harga'] ?? 0),
                ':hargaBeli' => (float)($item['hargaBeli'] ?? $item['hpp'] ?? 0),
                ':kategori'  => (string)($item['kategori'] ?? 'Lainnya'),
                ':stok'      => (string)($item['stok'] ?? '0'),
                ':satuan'    => (string)($item['satuan'] ?? 'pcs'),
                ':tipeHarga' => (string)($item['tipeHarga'] ?? 'fix'),
            ]);
            break;

        case 'customers':
        case 'pelanggan':
            $nama = trim((string)($item['nama'] ?? ''));
            if ($nama === '') return;
            $sql = "INSERT INTO `pelanggan` (`nama`, `kelas`, `divisi`, `diskon`, `telepon`, `catatan`, `alamat`, `oldNames`)
                    VALUES (:nama, :kelas, :divisi, :diskon, :telepon, :catatan, :alamat, :oldNames)
                    ON DUPLICATE KEY UPDATE
                        `kelas` = VALUES(`kelas`),
                        `divisi` = VALUES(`divisi`),
                        `diskon` = VALUES(`diskon`),
                        `telepon` = VALUES(`telepon`),
                        `catatan` = VALUES(`catatan`),
                        `alamat` = VALUES(`alamat`),
                        `oldNames` = VALUES(`oldNames`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nama'     => $nama,
                ':kelas'    => (string)($item['kelas'] ?? 'Reguler'),
                ':divisi'   => (string)($item['divisi'] ?? $item['division'] ?? ''),
                ':diskon'   => (float)($item['diskon'] ?? 0),
                ':telepon'  => (string)($item['telepon'] ?? ''),
                ':catatan'  => (string)($item['catatan'] ?? ''),
                ':alamat'   => (string)($item['alamat'] ?? ''),
                ':oldNames' => json_encode($item['oldNames'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);
            break;

        case 'invoices':
            $invNo = trim((string)($item['invoiceNo'] ?? $item['noInvoice'] ?? $item['no_invoice'] ?? ''));
            if ($invNo === '') return;
            $slipNoVal = (isset($item['slipNo']) && $item['slipNo'] !== '' && $item['slipNo'] !== null)
                ? (int)$item['slipNo']
                : null;
            $sql = "INSERT INTO `invoices` (
                        `invoiceNo`, `date`, `time`, `customer`, `cashier`,
                        `subtotal`, `discPct`, `discAmt`, `taxPct`, `taxAmt`, `negoAmt`, `total`,
                        `payMethod`, `dp`, `sisa`, `kembalian`, `deadline`, `status`,
                        `slipNo`, `slipPrinted`, `slipPrintedAt`, `customerPhone`, `customerAddress`,
                        `originalCustomer`, `originalDivisi`, `divisi`, `lastEditedBy`, `lastEditedAt`, `editReason`,
                        `items`, `auditLogs`
                    ) VALUES (
                        :invoiceNo, :date, :time, :customer, :cashier,
                        :subtotal, :discPct, :discAmt, :taxPct, :taxAmt, :negoAmt, :total,
                        :payMethod, :dp, :sisa, :kembalian, :deadline, :status,
                        :slipNo, :slipPrinted, :slipPrintedAt, :customerPhone, :customerAddress,
                        :originalCustomer, :originalDivisi, :divisi, :lastEditedBy, :lastEditedAt, :editReason,
                        :items, :auditLogs
                    ) ON DUPLICATE KEY UPDATE
                        `date` = VALUES(`date`),
                        `time` = VALUES(`time`),
                        `customer` = VALUES(`customer`),
                        `cashier` = VALUES(`cashier`),
                        `subtotal` = VALUES(`subtotal`),
                        `discPct` = VALUES(`discPct`),
                        `discAmt` = VALUES(`discAmt`),
                        `taxPct` = VALUES(`taxPct`),
                        `taxAmt` = VALUES(`taxAmt`),
                        `negoAmt` = VALUES(`negoAmt`),
                        `total` = VALUES(`total`),
                        `payMethod` = VALUES(`payMethod`),
                        `dp` = VALUES(`dp`),
                        `sisa` = VALUES(`sisa`),
                        `kembalian` = VALUES(`kembalian`),
                        `deadline` = VALUES(`deadline`),
                        `status` = VALUES(`status`),
                        `slipNo` = VALUES(`slipNo`),
                        `slipPrinted` = VALUES(`slipPrinted`),
                        `slipPrintedAt` = VALUES(`slipPrintedAt`),
                        `customerPhone` = VALUES(`customerPhone`),
                        `customerAddress` = VALUES(`customerAddress`),
                        `originalCustomer` = VALUES(`originalCustomer`),
                        `originalDivisi` = VALUES(`originalDivisi`),
                        `divisi` = VALUES(`divisi`),
                        `lastEditedBy` = VALUES(`lastEditedBy`),
                        `lastEditedAt` = VALUES(`lastEditedAt`),
                        `editReason` = VALUES(`editReason`),
                        `items` = VALUES(`items`),
                        `auditLogs` = VALUES(`auditLogs`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':invoiceNo'        => $invNo,
                ':date'             => (string)($item['date'] ?? $item['tanggal'] ?? ''),
                ':time'             => (string)($item['time'] ?? $item['jam'] ?? ''),
                ':customer'         => (string)($item['customer'] ?? $item['pelanggan'] ?? 'Umum'),
                ':cashier'          => (string)($item['cashier'] ?? $item['kasir'] ?? 'Admin'),
                ':subtotal'         => (float)($item['subtotal'] ?? $item['total'] ?? 0),
                ':discPct'          => (float)($item['discPct'] ?? 0),
                ':discAmt'          => (float)($item['discAmt'] ?? 0),
                ':taxPct'           => (float)($item['taxPct'] ?? 0),
                ':taxAmt'           => (float)($item['taxAmt'] ?? 0),
                ':negoAmt'          => (float)($item['negoAmt'] ?? 0),
                ':total'            => (float)($item['total'] ?? 0),
                ':payMethod'        => (string)($item['payMethod'] ?? $item['metodePembayaran'] ?? 'Tunai'),
                ':dp'               => (float)($item['dp'] ?? 0),
                ':sisa'             => (float)($item['sisa'] ?? 0),
                ':kembalian'        => (float)($item['kembalian'] ?? 0),
                ':deadline'         => (string)($item['deadline'] ?? ''),
                ':status'           => (string)($item['status'] ?? 'LUNAS'),
                ':slipNo'           => $slipNoVal,
                ':slipPrinted'      => (!empty($item['slipPrinted']) && $item['slipPrinted'] !== '0' && strtolower((string)$item['slipPrinted']) !== 'false') ? 1 : 0,
                ':slipPrintedAt'    => (!empty($item['slipPrinted']) && $item['slipPrinted'] !== '0' && strtolower((string)$item['slipPrinted']) !== 'false' && isset($item['slipPrintedAt']) && (string)$item['slipPrintedAt'] !== '0') ? (string)$item['slipPrintedAt'] : '',
                ':customerPhone'    => (string)($item['customerPhone'] ?? ''),
                ':customerAddress'  => (string)($item['customerAddress'] ?? ''),
                ':originalCustomer' => (string)($item['originalCustomer'] ?? ''),
                ':originalDivisi'   => (string)($item['originalDivisi'] ?? ''),
                ':divisi'           => (string)($item['divisi'] ?? $item['division'] ?? ''),
                ':lastEditedBy'     => (string)($item['lastEditedBy'] ?? ''),
                ':lastEditedAt'     => (string)($item['lastEditedAt'] ?? ''),
                ':editReason'       => (string)($item['editReason'] ?? ''),
                ':items'            => json_encode($item['items'] ?? [], JSON_UNESCAPED_UNICODE),
                ':auditLogs'        => json_encode($item['auditLogs'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);

            // Jika invoice memiliki pelunasanHistory / historiPelunasan, simpan juga ke tabel `pelunasan`
            $pelList = $item['pelunasanHistory'] ?? $item['historiPelunasan'] ?? [];
            if (is_array($pelList)) {
                foreach ($pelList as $idx => $pel) {
                    if (!is_array($pel)) continue;
                    $pel['invoiceNo'] = $pel['invoiceNo'] ?? $invNo;
                    $pel['customer'] = $pel['customer'] ?? ($item['customer'] ?? '');
                    if (empty($pel['id'])) {
                        $pel['id'] = 'PEL-' . ($pel['createdAt'] ?? $now) . '-' . $idx;
                    }
                    upsertRecord($pdo, 'pelunasan', $pel);
                }
            }

            // Update `invoice_seq` jika nomor nota menggunakan format PREFIX-YYYY-NNNN
            if (preg_match('/^([A-Z0-9]+)-(\d{4,6})-(\d+)$/i', $invNo, $m)) {
                $prefix = strtoupper($m[1]);
                $yr = (int)substr($m[2], 0, 4);
                $seq = (int)$m[3];
                try {
                    $seqStmt = $pdo->prepare("INSERT INTO `invoice_seq` (`prefix`, `yr`, `seq`) VALUES (:p, :y, :s)
                        ON DUPLICATE KEY UPDATE `yr` = VALUES(`yr`), `seq` = GREATEST(`seq`, VALUES(`seq`))");
                    $seqStmt->execute([':p' => $prefix, ':y' => $yr, ':s' => $seq]);
                } catch (Exception $e) {}
            }
            break;

        case 'pelunasan':
            $id = trim((string)($item['id'] ?? ''));
            if ($id === '') {
                $id = 'PEL-' . $now . '-' . substr(md5(json_encode($item)), 0, 4);
            }
            $sql = "INSERT INTO `pelunasan` (
                        `id`, `invoiceNo`, `date`, `time`, `customer`, `cashier`, `payMethod`,
                        `jumlahBayar`, `sisaAwal`, `newSisa`, `kembalian`, `status`, `catatan`
                    ) VALUES (
                        :id, :invoiceNo, :date, :time, :customer, :cashier, :payMethod,
                        :jumlahBayar, :sisaAwal, :newSisa, :kembalian, :status, :catatan
                    ) ON DUPLICATE KEY UPDATE
                        `invoiceNo` = VALUES(`invoiceNo`),
                        `date` = VALUES(`date`),
                        `time` = VALUES(`time`),
                        `customer` = VALUES(`customer`),
                        `cashier` = VALUES(`cashier`),
                        `payMethod` = VALUES(`payMethod`),
                        `jumlahBayar` = VALUES(`jumlahBayar`),
                        `sisaAwal` = VALUES(`sisaAwal`),
                        `newSisa` = VALUES(`newSisa`),
                        `kembalian` = VALUES(`kembalian`),
                        `status` = VALUES(`status`),
                        `catatan` = VALUES(`catatan`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id'          => $id,
                ':invoiceNo'   => (string)($item['invoiceNo'] ?? ''),
                ':date'        => (string)($item['date'] ?? $item['tanggal'] ?? ''),
                ':time'        => (string)($item['time'] ?? $item['waktu'] ?? ''),
                ':customer'    => (string)($item['customer'] ?? ''),
                ':cashier'     => (string)($item['cashier'] ?? $item['kasir'] ?? ''),
                ':payMethod'   => (string)($item['payMethod'] ?? $item['metode'] ?? 'Transfer'),
                ':jumlahBayar' => (float)($item['jumlahBayar'] ?? $item['nominal'] ?? 0),
                ':sisaAwal'    => (float)($item['sisaAwal'] ?? 0),
                ':newSisa'     => (float)($item['newSisa'] ?? 0),
                ':kembalian'   => (float)($item['kembalian'] ?? 0),
                ':status'      => (string)($item['status'] ?? 'LUNAS'),
                ':catatan'     => (string)($item['catatan'] ?? ''),
            ]);
            break;

        case 'expenses':
        case 'pengeluaran':
            $id = trim((string)($item['id'] ?? ''));
            if ($id === '') $id = 'EXP-' . $now;
            $sql = "INSERT INTO `pengeluaran` (`id`, `tanggal`, `kategori`, `keterangan`, `nominal`, `pj`, `buktiRef`)
                    VALUES (:id, :tanggal, :kategori, :keterangan, :nominal, :pj, :buktiRef)
                    ON DUPLICATE KEY UPDATE
                        `tanggal` = VALUES(`tanggal`),
                        `kategori` = VALUES(`kategori`),
                        `keterangan` = VALUES(`keterangan`),
                        `nominal` = VALUES(`nominal`),
                        `pj` = VALUES(`pj`),
                        `buktiRef` = VALUES(`buktiRef`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id'         => $id,
                ':tanggal'    => (string)($item['tanggal'] ?? $item['date'] ?? ''),
                ':kategori'   => (string)($item['kategori'] ?? 'Operasional'),
                ':keterangan' => (string)($item['keterangan'] ?? ''),
                ':nominal'    => (float)($item['nominal'] ?? 0),
                ':pj'         => (string)($item['pj'] ?? ''),
                ':buktiRef'   => (string)($item['buktiRef'] ?? ''),
            ]);
            break;

        case 'stockIn':
        case 'stock_in':
        case 'stok_masuk':
            $id = trim((string)($item['id'] ?? ''));
            if ($id === '') $id = 'SI-' . $now;
            $sql = "INSERT INTO `stok_masuk` (`id`, `kode`, `nama`, `qty`, `hargaBeli`, `satuan`, `supplier`, `cashier`, `tanggal`, `jam`, `catatan`)
                    VALUES (:id, :kode, :nama, :qty, :hargaBeli, :satuan, :supplier, :cashier, :tanggal, :jam, :catatan)
                    ON DUPLICATE KEY UPDATE
                        `kode` = VALUES(`kode`),
                        `nama` = VALUES(`nama`),
                        `qty` = VALUES(`qty`),
                        `hargaBeli` = VALUES(`hargaBeli`),
                        `satuan` = VALUES(`satuan`),
                        `supplier` = VALUES(`supplier`),
                        `cashier` = VALUES(`cashier`),
                        `tanggal` = VALUES(`tanggal`),
                        `jam` = VALUES(`jam`),
                        `catatan` = VALUES(`catatan`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id'        => $id,
                ':kode'      => (string)($item['kode'] ?? ''),
                ':nama'      => (string)($item['nama'] ?? ''),
                ':qty'       => (float)($item['qty'] ?? 0),
                ':hargaBeli' => isset($item['hargaBeli']) && $item['hargaBeli'] !== '' ? (float)$item['hargaBeli'] : null,
                ':satuan'    => (string)($item['satuan'] ?? 'pcs'),
                ':supplier'  => (string)($item['supplier'] ?? ''),
                ':cashier'   => (string)($item['cashier'] ?? ''),
                ':tanggal'   => (string)($item['tanggal'] ?? $item['date'] ?? ''),
                ':jam'       => (string)($item['jam'] ?? $item['time'] ?? ''),
                ':catatan'   => (string)($item['catatan'] ?? ''),
            ]);
            break;

        case 'stockOpname':
        case 'stock_opname':
        case 'stok_opname':
            $id = trim((string)($item['id'] ?? ''));
            if ($id === '') $id = 'SO-' . $now;
            $sql = "INSERT INTO `stok_opname` (
                        `id`, `tanggal`, `jam`, `bulanPeriode`, `petugas`, `penanggungJawab`,
                        `totalItemDihitung`, `totalItemSesuai`, `totalItemSelisihKurang`, `totalItemSelisihLebih`,
                        `totalNilaiSelisihKurang`, `totalNilaiSelisihLebih`, `totalNilaiSelisih`,
                        `catatanUmum`, `items`
                    ) VALUES (
                        :id, :tanggal, :jam, :bulanPeriode, :petugas, :penanggungJawab,
                        :totalItemDihitung, :totalItemSesuai, :totalItemSelisihKurang, :totalItemSelisihLebih,
                        :totalNilaiSelisihKurang, :totalNilaiSelisihLebih, :totalNilaiSelisih,
                        :catatanUmum, :items
                    ) ON DUPLICATE KEY UPDATE
                        `tanggal` = VALUES(`tanggal`),
                        `jam` = VALUES(`jam`),
                        `bulanPeriode` = VALUES(`bulanPeriode`),
                        `petugas` = VALUES(`petugas`),
                        `penanggungJawab` = VALUES(`penanggungJawab`),
                        `totalItemDihitung` = VALUES(`totalItemDihitung`),
                        `totalItemSesuai` = VALUES(`totalItemSesuai`),
                        `totalItemSelisihKurang` = VALUES(`totalItemSelisihKurang`),
                        `totalItemSelisihLebih` = VALUES(`totalItemSelisihLebih`),
                        `totalNilaiSelisihKurang` = VALUES(`totalNilaiSelisihKurang`),
                        `totalNilaiSelisihLebih` = VALUES(`totalNilaiSelisihLebih`),
                        `totalNilaiSelisih` = VALUES(`totalNilaiSelisih`),
                        `catatanUmum` = VALUES(`catatanUmum`),
                        `items` = VALUES(`items`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id'                      => $id,
                ':tanggal'                 => (string)($item['tanggal'] ?? ''),
                ':jam'                     => (string)($item['jam'] ?? ''),
                ':bulanPeriode'            => (string)($item['bulanPeriode'] ?? ''),
                ':petugas'                 => (string)($item['petugas'] ?? ''),
                ':penanggungJawab'         => (string)($item['penanggungJawab'] ?? ''),
                ':totalItemDihitung'       => (int)($item['totalItemDihitung'] ?? 0),
                ':totalItemSesuai'         => (int)($item['totalItemSesuai'] ?? 0),
                ':totalItemSelisihKurang'  => (int)($item['totalItemSelisihKurang'] ?? 0),
                ':totalItemSelisihLebih'   => (int)($item['totalItemSelisihLebih'] ?? 0),
                ':totalNilaiSelisihKurang' => (float)($item['totalNilaiSelisihKurang'] ?? 0),
                ':totalNilaiSelisihLebih'  => (float)($item['totalNilaiSelisihLebih'] ?? 0),
                ':totalNilaiSelisih'       => (float)($item['totalNilaiSelisih'] ?? 0),
                ':catatanUmum'             => (string)($item['catatanUmum'] ?? ''),
                ':items'                   => json_encode($item['items'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);
            break;

        case 'kasirUsers':
        case 'kasir_users':
            $nama = trim((string)($item['nama'] ?? ''));
            if ($nama === '') return;
            $sql = "INSERT INTO `kasir_users` (`nama`, `password`, `role`)
                    VALUES (:nama, :password, :role)
                    ON DUPLICATE KEY UPDATE
                        `password` = VALUES(`password`),
                        `role` = VALUES(`role`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nama'     => $nama,
                ':password' => (string)($item['password'] ?? ''),
                ':role'     => (string)($item['role'] ?? 'kasir'),
            ]);
            break;

        case 'settings':
            $jsonVal = json_encode($item, JSON_UNESCAPED_UNICODE);
            $sql = "INSERT INTO `settings` (`id`, `data`) VALUES (1, :data)
                    ON DUPLICATE KEY UPDATE `data` = VALUES(`data`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':data' => $jsonVal]);
            break;

        case 'activityLogs':
        case 'activity_logs':
            $id = trim((string)($item['id'] ?? ''));
            if ($id === '') $id = 'LOG-' . $now . '-' . substr(md5(json_encode($item)), 0, 5);
            $ts = (int)($item['ts'] ?? $item['timestamp'] ?? $now);
            $meta = isset($item['metadata']) ? json_encode($item['metadata'], JSON_UNESCAPED_UNICODE) : null;
            $sql = "INSERT INTO `activity_logs` (`id`, `ts`, `date`, `time`, `type`, `actor`, `title`, `description`, `metadata`)
                    VALUES (:id, :ts, :date, :time, :type, :actor, :title, :description, :metadata)
                    ON DUPLICATE KEY UPDATE
                        `ts` = VALUES(`ts`),
                        `title` = VALUES(`title`),
                        `description` = VALUES(`description`),
                        `metadata` = VALUES(`metadata`)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id'          => $id,
                ':ts'          => $ts,
                ':date'        => (string)($item['date'] ?? ''),
                ':time'        => (string)($item['time'] ?? ''),
                ':type'        => (string)($item['type'] ?? 'SYSTEM'),
                ':actor'       => (string)($item['actor'] ?? 'System'),
                ':title'       => (string)($item['title'] ?? ''),
                ':description' => (string)($item['description'] ?? ''),
                ':metadata'    => $meta,
            ]);
            break;
    }
}

// ============================================================================
// 5. ROUTING ACTION API
// ============================================================================
$action = $_GET['action'] ?? $body['action'] ?? 'ping';
$collection = $_GET['collection'] ?? $body['collection'] ?? '';

try {
    if ($action === 'ping' || $action === 'status' || $action === 'test_connection' || $action === 'sync_check') {
        $all = fetchAllFromSchema($pdo);
        $latestInvNo = '';
        if (!empty($all['invoices'])) {
            $latestInvNo = (string)($all['invoices'][0]['invoiceNo'] ?? $all['invoices'][0]['noInvoice'] ?? '');
        }
        echo json_encode([
            'success'         => true,
            'status'          => 'ok',
            'engine'          => 'cPanel PHP + MySQL (PDO) - hump6894_Waka Schema',
            'database'        => $DB_NAME,
            'host'            => $DB_HOST,
            'message'         => "Terhubung ke MySQL ({$DB_NAME})!",
            'latestInvoiceNo' => $latestInvNo,
            'totalInvoices'   => count($all['invoices']),
            'counts'          => [
                'products'     => count($all['products']),
                'customers'    => count($all['customers']),
                'invoices'     => count($all['invoices']),
                'pelunasan'    => count($all['pelunasanHistory']),
                'expenses'     => count($all['expenses']),
                'stockIn'      => count($all['stockIn']),
                'stockOpname'  => count($all['stockOpname']),
                'kasirUsers'   => count($all['kasirUsers']),
                'activityLogs' => count($all['activityLogs']),
            ]
        ]);
        exit;
    }

    if ($action === 'init_tables') {
        ensureTablesExist($pdo);
        echo json_encode([
            'success' => true,
            'status'  => 'ok',
            'message' => 'Seluruh tabel database MySQL (skema hump6894_Waka) berhasil dibuat / diverifikasi!'
        ]);
        exit;
    }

    if ($action === 'get_all') {
        $all = fetchAllFromSchema($pdo);
        echo json_encode([
            'success' => true,
            'status'  => 'ok',
            'data'    => $all
        ]);
        exit;
    }

    if ($action === 'list') {
        $all = fetchAllFromSchema($pdo);
        $mapKey = [
            'products'      => 'products',
            'produk'        => 'products',
            'customers'     => 'customers',
            'pelanggan'     => 'customers',
            'invoices'      => 'invoices',
            'pelunasan'     => 'pelunasanHistory',
            'expenses'      => 'expenses',
            'pengeluaran'   => 'expenses',
            'stock_in'      => 'stockIn',
            'stockIn'       => 'stockIn',
            'stok_masuk'    => 'stockIn',
            'stock_opname'  => 'stockOpname',
            'stockOpname'   => 'stockOpname',
            'stok_opname'   => 'stockOpname',
            'kasir_users'   => 'kasirUsers',
            'kasirUsers'    => 'kasirUsers',
            'settings'      => 'settings',
            'activity_logs' => 'activityLogs',
            'activityLogs'  => 'activityLogs',
        ];
        $target = $mapKey[$collection] ?? 'products';
        $items = $all[$target] ?? [];
        echo json_encode([
            'success' => true,
            'status'  => 'ok',
            'items'   => $items,
            'data'    => $items
        ]);
        exit;
    }

    if ($action === 'save' || $action === 'upsert') {
        $batch = $body['items'] ?? $body['records'] ?? null;
        if (is_array($batch)) {
            $pdo->beginTransaction();
            foreach ($batch as $rec) {
                upsertRecord($pdo, $collection, $rec);
            }
            $pdo->commit();
            echo json_encode(['success' => true, 'status' => 'ok', 'count' => count($batch)]);
            exit;
        }
        $record = $body['item'] ?? $body['record'] ?? $body['data'] ?? null;
        if ($record !== null) {
            upsertRecord($pdo, $collection, $record);
        }
        echo json_encode(['success' => true, 'status' => 'ok']);
        exit;
    }

    if ($action === 'batch_save') {
        $records = $body['items'] ?? $body['records'] ?? $body['data'] ?? [];
        if (is_array($records)) {
            $pdo->beginTransaction();
            foreach ($records as $rec) {
                upsertRecord($pdo, $collection, $rec);
            }
            $pdo->commit();
        }
        echo json_encode(['success' => true, 'status' => 'ok', 'count' => is_array($records) ? count($records) : 0]);
        exit;
    }

    if ($action === 'delete') {
        $id = (string)($body['id'] ?? $_GET['id'] ?? '');
        if ($id !== '') {
            switch ($collection) {
                case 'products':
                case 'produk':
                    $stmt = $pdo->prepare("DELETE FROM `produk` WHERE `kode` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
                case 'customers':
                case 'pelanggan':
                    $stmt = $pdo->prepare("DELETE FROM `pelanggan` WHERE `nama` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
                case 'invoices':
                    $stmt = $pdo->prepare("DELETE FROM `invoices` WHERE `invoiceNo` = :id");
                    $stmt->execute([':id' => $id]);
                    $stmt2 = $pdo->prepare("DELETE FROM `pelunasan` WHERE `invoiceNo` = :id");
                    $stmt2->execute([':id' => $id]);
                    break;
                case 'expenses':
                case 'pengeluaran':
                    $stmt = $pdo->prepare("DELETE FROM `pengeluaran` WHERE `id` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
                case 'stock_in':
                case 'stockIn':
                case 'stok_masuk':
                    $stmt = $pdo->prepare("DELETE FROM `stok_masuk` WHERE `id` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
                case 'stock_opname':
                case 'stockOpname':
                case 'stok_opname':
                    $stmt = $pdo->prepare("DELETE FROM `stok_opname` WHERE `id` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
                case 'kasir_users':
                case 'kasirUsers':
                    $stmt = $pdo->prepare("DELETE FROM `kasir_users` WHERE `nama` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
                case 'activity_logs':
                case 'activityLogs':
                    $stmt = $pdo->prepare("DELETE FROM `activity_logs` WHERE `id` = :id");
                    $stmt->execute([':id' => $id]);
                    break;
            }
        }
        echo json_encode(['success' => true, 'status' => 'ok']);
        exit;
    }

    if ($action === 'clear') {
        $tableMap = [
            'products'         => 'produk',
            'produk'           => 'produk',
            'customers'        => 'pelanggan',
            'pelanggan'        => 'pelanggan',
            'invoices'         => 'invoices',
            'pelunasan'        => 'pelunasan',
            'pelunasanHistory' => 'pelunasan',
            'expenses'         => 'pengeluaran',
            'pengeluaran'      => 'pengeluaran',
            'stock_in'         => 'stok_masuk',
            'stockIn'          => 'stok_masuk',
            'stok_masuk'       => 'stok_masuk',
            'stock_opname'     => 'stok_opname',
            'stockOpname'      => 'stok_opname',
            'stok_opname'      => 'stok_opname',
            'kasir_users'      => 'kasir_users',
            'kasirUsers'       => 'kasir_users',
            'activity_logs'    => 'activity_logs',
            'activityLogs'     => 'activity_logs',
            'invoice_seq'      => 'invoice_seq',
            'invoiceSeq'       => 'invoice_seq',
        ];
        if (isset($tableMap[$collection])) {
            $tbl = $tableMap[$collection];
            $pdo->exec("DELETE FROM `{$tbl}`");
            if ($tbl === 'invoices') {
                try { $pdo->exec("DELETE FROM `pelunasan`"); } catch (Exception $e) {}
                try { $pdo->exec("DELETE FROM `invoice_seq`"); } catch (Exception $e) {}
            }
        }
        echo json_encode(['success' => true, 'status' => 'ok']);
        exit;
    }

    if ($action === 'migrate') {
        $payload = $body['payload'] ?? $body['data'] ?? [];
        $replaceAll = !empty($body['replace']);
        $migratedCounts = [];
        if (is_array($payload)) {
            $pdo->beginTransaction();
            if ($replaceAll) {
                if (isset($payload['products'])) $pdo->exec("DELETE FROM `produk`");
                if (isset($payload['customers'])) $pdo->exec("DELETE FROM `pelanggan`");
                if (isset($payload['invoices'])) {
                    $pdo->exec("DELETE FROM `invoices`");
                    $pdo->exec("DELETE FROM `pelunasan`");
                }
                if (isset($payload['expenses'])) $pdo->exec("DELETE FROM `pengeluaran`");
                if (isset($payload['stockIn'])) $pdo->exec("DELETE FROM `stok_masuk`");
                if (isset($payload['stockOpname'])) $pdo->exec("DELETE FROM `stok_opname`");
                if (isset($payload['kasirUsers'])) $pdo->exec("DELETE FROM `kasir_users`");
            }
            if (!empty($payload['products']) && is_array($payload['products'])) {
                foreach ($payload['products'] as $p) upsertRecord($pdo, 'products', $p);
                $migratedCounts['products'] = count($payload['products']);
            }
            if (!empty($payload['customers']) && is_array($payload['customers'])) {
                foreach ($payload['customers'] as $c) upsertRecord($pdo, 'customers', $c);
                $migratedCounts['customers'] = count($payload['customers']);
            }
            if (!empty($payload['kasirUsers']) && is_array($payload['kasirUsers'])) {
                foreach ($payload['kasirUsers'] as $u) upsertRecord($pdo, 'kasirUsers', $u);
                $migratedCounts['kasirUsers'] = count($payload['kasirUsers']);
            }
            if (!empty($payload['settings']) && is_array($payload['settings'])) {
                upsertRecord($pdo, 'settings', $payload['settings']);
                $migratedCounts['settings'] = 1;
            }
            if (!empty($payload['invoices']) && is_array($payload['invoices'])) {
                foreach ($payload['invoices'] as $inv) upsertRecord($pdo, 'invoices', $inv);
                $migratedCounts['invoices'] = count($payload['invoices']);
            }
            if (!empty($payload['pelunasanHistory']) && is_array($payload['pelunasanHistory'])) {
                foreach ($payload['pelunasanHistory'] as $pel) upsertRecord($pdo, 'pelunasan', $pel);
                $migratedCounts['pelunasan'] = count($payload['pelunasanHistory']);
            }
            if (!empty($payload['expenses']) && is_array($payload['expenses'])) {
                foreach ($payload['expenses'] as $exp) upsertRecord($pdo, 'expenses', $exp);
                $migratedCounts['expenses'] = count($payload['expenses']);
            }
            if (!empty($payload['stockIn']) && is_array($payload['stockIn'])) {
                foreach ($payload['stockIn'] as $si) upsertRecord($pdo, 'stockIn', $si);
                $migratedCounts['stockIn'] = count($payload['stockIn']);
            }
            if (!empty($payload['stockOpname']) && is_array($payload['stockOpname'])) {
                foreach ($payload['stockOpname'] as $so) upsertRecord($pdo, 'stockOpname', $so);
                $migratedCounts['stockOpname'] = count($payload['stockOpname']);
            }
            if (!empty($payload['activityLogs']) && is_array($payload['activityLogs'])) {
                foreach ($payload['activityLogs'] as $log) upsertRecord($pdo, 'activityLogs', $log);
                $migratedCounts['activityLogs'] = count($payload['activityLogs']);
            }
            $pdo->commit();
        }
        echo json_encode([
            'success'        => true,
            'status'         => 'ok',
            'migratedCounts' => $migratedCounts,
            'message'        => 'Seluruh data berhasil dimigrasikan ke MySQL cPanel (skema hump6894_Waka)'
        ]);
        exit;
    }

    echo json_encode(['success' => true, 'status' => 'ok', 'action' => $action]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'status'  => 'error',
        'message' => $e->getMessage()
    ]);
}
