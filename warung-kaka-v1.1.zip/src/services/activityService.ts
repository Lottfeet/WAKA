import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit, 
  writeBatch,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './firebase';
import { ActivityLog } from '../types';
import { sanitizeForFirestore } from './firebaseService';

const LOCAL_STORAGE_KEY = 'strukku_activity_logs';

export function getLocalActivityLogs(): ActivityLog[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveLocalActivityLogs(logs: ActivityLog[]): void {
  try {
    // Keep up to 500 recent logs locally
    const trimmed = logs.slice(0, 500);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.warn('Failed to save activity logs to local storage:', err);
  }
}

/**
 * Record a new system activity log
 */
export async function logActivity(
  entry: Omit<ActivityLog, 'id' | 'timestamp'> & { id?: string; timestamp?: number }
): Promise<ActivityLog> {
  const now = new Date();
  const timestamp = entry.timestamp || now.getTime();
  const id = entry.id || `LOG-${timestamp}-${Math.random().toString(36).substring(2, 7)}`;

  const fullLog: ActivityLog = {
    ...entry,
    id,
    timestamp,
  };

  // 1. Save to local storage immediately
  const existing = getLocalActivityLogs();
  const updated = [fullLog, ...existing.filter((l) => l.id !== id)];
  saveLocalActivityLogs(updated);

  // 2. Persist to Firebase Firestore
  try {
    const cleanData = sanitizeForFirestore(fullLog);
    await setDoc(doc(db, 'activityLogs', id), {
      ...cleanData,
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('Failed to persist activity log to Firestore:', err);
  }

  return fullLog;
}

/**
 * Fetch activity logs from Firestore with fallback to local storage
 */
export async function fetchActivityLogs(maxCount = 200): Promise<ActivityLog[]> {
  try {
    const q = query(
      collection(db, 'activityLogs'),
      orderBy('timestamp', 'desc'),
      limit(maxCount)
    );
    const snap = await getDocs(q);
    const logs: ActivityLog[] = [];
    snap.forEach((d) => {
      const data = d.data();
      logs.push({
        id: d.id,
        timestamp: Number(data.timestamp) || 0,
        date: data.date || '',
        time: data.time || '',
        type: data.type || 'lainnya',
        actor: data.actor || 'Sistem',
        title: data.title || '',
        description: data.description || '',
        metadata: data.metadata || {},
      });
    });

    if (logs.length > 0) {
      saveLocalActivityLogs(logs);
      return logs;
    }
  } catch (err) {
    console.warn('fetchActivityLogs from Firestore error, falling back to local:', err);
  }

  return getLocalActivityLogs();
}

/**
 * Subscribe to real-time activity log changes in Firestore
 */
export function subscribeActivityLogs(
  callback: (logs: ActivityLog[]) => void,
  maxCount = 200
): () => void {
  try {
    const q = query(
      collection(db, 'activityLogs'),
      orderBy('timestamp', 'desc'),
      limit(maxCount)
    );

    return onSnapshot(
      q,
      (snap) => {
        const logs: ActivityLog[] = [];
        snap.forEach((d) => {
          const data = d.data();
          logs.push({
            id: d.id,
            timestamp: Number(data.timestamp) || 0,
            date: data.date || '',
            time: data.time || '',
            type: data.type || 'lainnya',
            actor: data.actor || 'Sistem',
            title: data.title || '',
            description: data.description || '',
            metadata: data.metadata || {},
          });
        });

        if (logs.length > 0) {
          saveLocalActivityLogs(logs);
          callback(logs);
        } else {
          // If empty in Firestore, check local
          callback(getLocalActivityLogs());
        }
      },
      (err) => {
        console.warn('subscribeActivityLogs error, using local fallback:', err);
        callback(getLocalActivityLogs());
      }
    );
  } catch (err) {
    console.warn('Failed to initialize subscribeActivityLogs:', err);
    callback(getLocalActivityLogs());
    return () => {};
  }
}

/**
 * Delete a single activity log (Restricted action)
 */
export async function deleteActivityLog(id: string): Promise<void> {
  const cleanId = (id || '').trim();
  if (!cleanId) return;

  // Local remove
  const current = getLocalActivityLogs();
  saveLocalActivityLogs(current.filter((l) => l.id !== cleanId));

  // Firestore remove
  try {
    await deleteDoc(doc(db, 'activityLogs', cleanId));
  } catch (err) {
    console.warn('deleteActivityLog from Firestore error:', err);
  }
}

/**
 * Clear all activity logs (Restricted to Owner)
 */
export async function clearAllActivityLogs(): Promise<{ success: boolean; count: number }> {
  // Local clear
  localStorage.removeItem(LOCAL_STORAGE_KEY);

  let count = 0;
  try {
    const snap = await getDocs(collection(db, 'activityLogs'));
    if (!snap.empty) {
      const batch = writeBatch(db);
      snap.forEach((d) => {
        batch.delete(d.ref);
        count++;
      });
      await batch.commit();
    }
    return { success: true, count };
  } catch (err) {
    console.warn('clearAllActivityLogs Firestore error:', err);
    return { success: false, count };
  }
}
