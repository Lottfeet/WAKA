import React, { useState, useMemo } from 'react';
import { 
  X, 
  Award, 
  Calendar, 
  Search, 
  Filter, 
  TrendingUp, 
  ShoppingBag, 
  Layers, 
  Printer, 
  FileSpreadsheet,
  CheckCircle2,
  BarChart3
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';
import { RecentInvoiceItem } from '../services/gasService';
import { fRp } from '../utils/formatters';

interface TopProductsModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoices: RecentInvoiceItem[];
  initialScope?: 'today' | '7d' | '30d' | 'month' | 'custom' | 'all';
}

export const parseInvoiceDate = (dateStr?: string): Date | null => {
  if (!dateStr || typeof dateStr !== 'string' || !dateStr.trim()) return null;
  const cleaned = dateStr.trim();

  if (cleaned.includes('/')) {
    const spaceSplit = cleaned.split(' ')[0];
    const parts = spaceSplit.split('/');
    if (parts.length === 3) {
      const day = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const year = parseInt(parts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month, day);
      }
    }
  }

  if (cleaned.includes('-')) {
    const spaceSplit = cleaned.split('T')[0].split(' ')[0];
    const parts = spaceSplit.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month, day);
      }
    }
  }

  const d = new Date(cleaned);
  if (!isNaN(d.getTime())) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }

  return null;
};

export const TopProductsModal: React.FC<TopProductsModalProps> = ({
  isOpen,
  onClose,
  invoices,
  initialScope = '30d',
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const thirtyDaysAgoStr = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [period, setPeriod] = useState<'today' | '7d' | '30d' | 'month' | 'custom' | 'all'>(initialScope);
  const [startDate, setStartDate] = useState<string>(thirtyDaysAgoStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [topLimit, setTopLimit] = useState<number>(10);

  if (!isOpen) return null;

  // Filter Invoices by selected date period
  const filteredInvoices = invoices.filter((inv) => {
    if (period === 'all') return true;

    const itemDate = parseInvoiceDate(inv.date);
    if (!itemDate) return false;

    const now = new Date();
    const todayLocal = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    if (period === 'today') {
      return (
        itemDate.getFullYear() === todayLocal.getFullYear() &&
        itemDate.getMonth() === todayLocal.getMonth() &&
        itemDate.getDate() === todayLocal.getDate()
      );
    }

    if (period === '7d') {
      const sevenDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 6);
      const endOfToday = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59, 999);
      return itemDate >= sevenDaysAgo && itemDate <= endOfToday;
    }

    if (period === '30d') {
      const thirtyDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 29);
      const endOfToday = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59, 999);
      return itemDate >= thirtyDaysAgo && itemDate <= endOfToday;
    }

    if (period === 'month') {
      return (
        itemDate.getFullYear() === todayLocal.getFullYear() &&
        itemDate.getMonth() === todayLocal.getMonth()
      );
    }

    if (period === 'custom') {
      if (!startDate && !endDate) return true;
      const startD = startDate ? new Date(startDate + 'T00:00:00') : new Date(0);
      const endD = endDate ? new Date(endDate + 'T23:59:59.999') : new Date(8640000000000000);
      return itemDate >= startD && itemDate <= endD;
    }

    return true;
  });

  // Aggregate Product Performance
  const aggregatedProducts = (() => {
    const map: Record<
      string,
      {
        fullName: string;
        kode?: string;
        jumlahOrder: number;
        totalNilai: number;
        satuan?: string;
      }
    > = {};

    filteredInvoices.forEach((inv) => {
      if (inv.items && Array.isArray(inv.items) && inv.items.length > 0) {
        inv.items.forEach((it) => {
          if (!it.nama || !it.nama.trim()) return;
          const nameKey = it.nama.trim();
          if (!map[nameKey]) {
            map[nameKey] = {
              fullName: nameKey,
              kode: it.kode || '',
              jumlahOrder: 0,
              totalNilai: 0,
              satuan: it.satuan || 'pcs',
            };
          }
          const qty = Number(it.qty || 1);
          const price = Number(it.harga || 0);
          const tot = Number(it.totalItem || qty * price);

          map[nameKey].jumlahOrder += qty;
          map[nameKey].totalNilai += tot;
          if (it.kode && !map[nameKey].kode) {
            map[nameKey].kode = it.kode;
          }
        });
      }
    });

    let list = Object.values(map);

    // Apply Search Filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.fullName.toLowerCase().includes(q) ||
          (p.kode && p.kode.toLowerCase().includes(q))
      );
    }

    // Sort descending by order volume
    list.sort((a, b) => b.jumlahOrder - a.jumlahOrder);
    return list;
  })();

  const topProductsList = aggregatedProducts.slice(0, topLimit);

  // Overall Statistics for this period
  const totalOmzetAllProducts = aggregatedProducts.reduce((acc, p) => acc + p.totalNilai, 0);
  const totalQtyAllProducts = aggregatedProducts.reduce((acc, p) => acc + p.jumlahOrder, 0);
  const totalSkuCount = aggregatedProducts.length;
  const top1Product = aggregatedProducts.length > 0 ? aggregatedProducts[0] : null;

  // Chart Data
  const chartData = topProductsList.slice(0, 10).map((p) => ({
    name: p.fullName.length > 20 ? p.fullName.substring(0, 20) + '...' : p.fullName,
    fullName: p.fullName,
    jumlahOrder: p.jumlahOrder,
    totalNilai: p.totalNilai,
  }));

  const BAR_COLORS = [
    '#b91c1c', '#dc2626', '#ef4444', '#f87171', '#fca5a5',
    '#059669', '#10b981', '#2563eb', '#3b82f6', '#8b5cf6'
  ];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="top-products-modal-container"
        className="bg-white border border-stone-200 rounded-3xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden text-stone-800"
      >
        {/* Modal Header */}
        <div className="bg-stone-900 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-red-700 rounded-2xl text-white shadow-xs">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>Analisis Barang & Jasa Cetak Terlaris</span>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-red-500/30 text-red-200 border border-red-500/40 uppercase">
                  Rank & Sales Volume
                </span>
              </h2>
              <p className="text-xs text-stone-300 mt-0.5">
                Pantau volume pesanan dan total nilai omzet penjualan berdasarkan rentang tanggal.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white transition cursor-pointer"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Scrollable */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {/* Filter Periode Tanggal Controls */}
          <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs font-bold text-stone-800">
                <Filter className="w-4 h-4 text-red-700 shrink-0" />
                <span>Filter Periode Tanggal:</span>
              </div>

              {/* Quick Period Buttons */}
              <div className="flex flex-wrap items-center gap-1.5 bg-white p-1 rounded-xl border border-stone-200 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setPeriod('today')}
                  className={`px-3 py-1.5 rounded-lg transition active:scale-95 cursor-pointer ${
                    period === 'today'
                      ? 'bg-red-700 text-white font-black shadow-xs'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  Hari Ini
                </button>
                <button
                  type="button"
                  onClick={() => setPeriod('7d')}
                  className={`px-3 py-1.5 rounded-lg transition active:scale-95 cursor-pointer ${
                    period === '7d'
                      ? 'bg-red-700 text-white font-black shadow-xs'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  7 Hari
                </button>
                <button
                  type="button"
                  onClick={() => setPeriod('30d')}
                  className={`px-3 py-1.5 rounded-lg transition active:scale-95 cursor-pointer ${
                    period === '30d'
                      ? 'bg-red-700 text-white font-black shadow-xs'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  30 Hari
                </button>
                <button
                  type="button"
                  onClick={() => setPeriod('month')}
                  className={`px-3 py-1.5 rounded-lg transition active:scale-95 cursor-pointer ${
                    period === 'month'
                      ? 'bg-red-700 text-white font-black shadow-xs'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  Bulan Ini
                </button>
                <button
                  type="button"
                  onClick={() => setPeriod('custom')}
                  className={`px-3 py-1.5 rounded-lg transition active:scale-95 cursor-pointer ${
                    period === 'custom'
                      ? 'bg-red-700 text-white font-black shadow-xs'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  Custom Tanggal
                </button>
                <button
                  type="button"
                  onClick={() => setPeriod('all')}
                  className={`px-3 py-1.5 rounded-lg transition active:scale-95 cursor-pointer ${
                    period === 'all'
                      ? 'bg-stone-800 text-white font-black shadow-xs'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  Semua
                </button>
              </div>
            </div>

            {/* Custom Date Range Picker inputs */}
            {period === 'custom' && (
              <div className="pt-2 border-t border-stone-200/80 flex flex-wrap items-center gap-3 animate-in fade-in duration-150">
                <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-stone-200">
                  <Calendar className="w-4 h-4 text-red-700" />
                  <span className="text-xs font-bold text-stone-700">Mulai:</span>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="text-xs font-extrabold text-stone-800 bg-transparent focus:outline-none"
                  />
                </div>

                <span className="text-stone-400 font-bold text-xs">sampai</span>

                <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-stone-200">
                  <Calendar className="w-4 h-4 text-red-700" />
                  <span className="text-xs font-bold text-stone-700">Selesai:</span>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="text-xs font-extrabold text-stone-800 bg-transparent focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* Search Bar & Limit Filter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari nama barang / jasa cetak..."
                  className="w-full pl-9 pr-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500/20 shadow-2xs"
                />
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-bold text-stone-600">Tampilkan:</span>
                <select
                  value={topLimit}
                  onChange={(e) => setTopLimit(Number(e.target.value))}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-extrabold text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500/20 shadow-2xs"
                >
                  <option value={5}>Top 5 Produk</option>
                  <option value={10}>Top 10 Produk</option>
                  <option value={20}>Top 20 Produk</option>
                  <option value={50}>Top 50 Produk</option>
                  <option value={1000}>Semua Item</option>
                </select>
              </div>
            </div>
          </div>

          {/* KPI Highlight Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-gradient-to-br from-red-50 to-rose-50/60 border border-red-200 rounded-2xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-black text-red-900 uppercase tracking-wider block">Total Volume Order</span>
              <div className="text-xl font-black text-red-950 mt-0.5">
                {totalQtyAllProducts.toLocaleString('id-ID')} <span className="text-xs font-bold text-red-800">x</span>
              </div>
              <span className="text-[10px] font-bold text-red-700/90 mt-1 block">Item/jasa terproses</span>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-50/60 border border-emerald-200 rounded-2xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-black text-emerald-900 uppercase tracking-wider block">Est. Total Omzet</span>
              <div className="text-xl font-black text-emerald-950 mt-0.5">
                {fRp(totalOmzetAllProducts)}
              </div>
              <span className="text-[10px] font-bold text-emerald-700/90 mt-1 block">Nilai transaksi produk</span>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50/60 border border-blue-200 rounded-2xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-black text-blue-900 uppercase tracking-wider block">Jenis Produk Terjual</span>
              <div className="text-xl font-black text-blue-950 mt-0.5">
                {totalSkuCount} <span className="text-xs font-bold text-blue-800">SKU</span>
              </div>
              <span className="text-[10px] font-bold text-blue-700/90 mt-1 block">Varian produk/jasa</span>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50/60 border border-purple-200 rounded-2xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-black text-purple-900 uppercase tracking-wider block">Juara 1 Terlaris</span>
              <div className="text-xs font-black text-purple-950 truncate mt-1" title={top1Product?.fullName || '-'}>
                {top1Product ? top1Product.fullName : '-'}
              </div>
              <span className="text-[10px] font-extrabold text-purple-800 mt-1 block">
                {top1Product ? `${top1Product.jumlahOrder} Order • ${fRp(top1Product.totalNilai)}` : 'Belum ada data'}
              </span>
            </div>
          </div>

          {/* Bar Chart Visualization */}
          {chartData.length > 0 && (
            <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-2">
              <h3 className="font-extrabold text-stone-900 text-xs flex items-center gap-2 border-b border-stone-100 pb-2">
                <BarChart3 className="w-4 h-4 text-red-700" />
                <span>Grafik Perbandingan Top {chartData.length} Barang & Jasa Cetak</span>
              </h3>

              <div className="h-64 w-full pt-1">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                    <XAxis type="number" tick={{ fontSize: 10, fill: '#78716c' }} />
                    <YAxis dataKey="name" type="category" width={125} tick={{ fontSize: 11, fill: '#44403c', fontWeight: 700 }} />
                    <Tooltip 
                      formatter={(value: any, name: any) => [
                        name === 'jumlahOrder' ? `${value} Order` : fRp(Number(value)),
                        name === 'jumlahOrder' ? 'Total Order' : 'Est. Omzet'
                      ]}
                      contentStyle={{ borderRadius: '12px', fontSize: '12px', fontWeight: 600 }}
                    />
                    <Bar dataKey="jumlahOrder" radius={[0, 8, 8, 0]} barSize={22}>
                      {chartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={BAR_COLORS[index % BAR_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Detailed Ranking Table */}
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2.5">
              <h3 className="font-extrabold text-stone-900 text-xs sm:text-sm flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-red-700" />
                <span>Tabel Peringkat Penjualan ({topProductsList.length} Item)</span>
              </h3>

              <span className="text-[11px] font-bold text-stone-500">
                Filter: <strong className="text-stone-900">{filteredInvoices.length} Nota Transaksi</strong>
              </span>
            </div>

            {topProductsList.length === 0 ? (
              <div className="py-12 text-center text-stone-400 text-xs font-medium bg-stone-50/50 rounded-2xl border border-dashed border-stone-200">
                Tidak ada data barang/jasa cetak terlaris pada periode tanggal ini.
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-stone-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100 text-stone-700 font-extrabold uppercase text-[10px] border-b border-stone-200">
                    <tr>
                      <th className="p-3 text-center w-12">Rank</th>
                      <th className="p-3">Nama Barang / Jasa Cetak</th>
                      <th className="p-3 text-center">Volume Order</th>
                      <th className="p-3 text-right">Estimasi Omzet</th>
                      <th className="p-3 text-right">Kontribusi (%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-semibold text-stone-800">
                    {topProductsList.map((item, idx) => {
                      const rank = idx + 1;
                      const pct = totalOmzetAllProducts > 0 ? ((item.totalNilai / totalOmzetAllProducts) * 100).toFixed(1) : '0';

                      let rankBadge = (
                        <span className="w-6 h-6 rounded-full bg-stone-200 text-stone-800 font-black text-xs flex items-center justify-center mx-auto">
                          {rank}
                        </span>
                      );

                      if (rank === 1) {
                        rankBadge = (
                          <span className="w-6 h-6 rounded-full bg-amber-400 text-amber-950 font-black text-xs flex items-center justify-center mx-auto shadow-xs border border-amber-500">
                            🥇
                          </span>
                        );
                      } else if (rank === 2) {
                        rankBadge = (
                          <span className="w-6 h-6 rounded-full bg-stone-300 text-stone-900 font-black text-xs flex items-center justify-center mx-auto shadow-xs border border-stone-400">
                            🥈
                          </span>
                        );
                      } else if (rank === 3) {
                        rankBadge = (
                          <span className="w-6 h-6 rounded-full bg-amber-700 text-white font-black text-xs flex items-center justify-center mx-auto shadow-xs border border-amber-800">
                            🥉
                          </span>
                        );
                      }

                      return (
                        <tr key={item.fullName + idx} className="hover:bg-stone-50 transition">
                          <td className="p-3 text-center">{rankBadge}</td>
                          <td className="p-3">
                            <div className="font-extrabold text-stone-900 text-xs">{item.fullName}</div>
                            {item.kode && (
                              <span className="text-[10px] font-mono font-bold text-stone-500 bg-stone-100 px-1.5 py-0.2 rounded mt-0.5 inline-block">
                                Kode: {item.kode}
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            <span className="px-2.5 py-1 bg-red-100 text-red-900 font-black rounded-lg text-xs">
                              {item.jumlahOrder} {item.satuan || 'pcs'}
                            </span>
                          </td>
                          <td className="p-3 text-right font-black text-emerald-700 text-xs">
                            {fRp(item.totalNilai)}
                          </td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <div className="w-16 bg-stone-100 rounded-full h-2 overflow-hidden border border-stone-200">
                                <div 
                                  className="bg-red-700 h-2 rounded-full"
                                  style={{ width: `${Math.min(100, Number(pct))}%` }}
                                />
                              </div>
                              <span className="font-extrabold text-stone-700 text-xs min-w-[36px]">
                                {pct}%
                              </span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-stone-100 border-t border-stone-200 p-3 sm:p-4 flex items-center justify-between shrink-0">
          <div className="text-xs text-stone-500 font-bold">
            Total {aggregatedProducts.length} varian produk tercatat.
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / PDF</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white font-extrabold text-xs rounded-xl transition active:scale-95 cursor-pointer"
            >
              Selesai
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
