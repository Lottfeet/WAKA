========================================================================
  WAKA (WARUNG KAKA) - VERSI cPanel (PHP + MySQL, TANPA Node.js)
  Paket deploy siap upload - dibuat 26 Oktober 2026
========================================================================

ISI PAKET
---------
  index.html            -> halaman utama aplikasi (React hasil build)
  assets/               -> file JS & CSS aplikasi
  api/index.php         -> backend REST API (pengganti Firebase + Apps Script)
  api/config.sample.php -> contoh konfigurasi database
  .htaccess             -> routing SPA + keamanan
  schema.sql            -> struktur database MySQL
  Backup_WARUNG_KAKA_20261026_112227.json -> data lama Anda (untuk import)

LANGKAH DEPLOY DI cPanel (±15 menit)
------------------------------------
1. BUAT DATABASE
   - Login cPanel -> "MySQL Databases" (atau phpMyAdmin).
   - Buat database baru, misal: user_waka
   - Buat user MySQL baru + password kuat, lalu hubungkan user ke
     database dengan privilege ALL.

2. IMPORT STRUKTUR TABEL
   - Buka phpMyAdmin -> pilih database "user_waka" -> tab "Import".
   - Import file: schema.sql

3. UPLOAD APLIKASI
   - File Manager cPanel -> masuk public_html (kosongkan dulu bila ada
     file default).
   - Upload semua isi paket ini (index.html, assets/, api/, .htaccess,
     schema.sql, Backup_*.json), atau upload waka-cpanel.zip lalu
     Extract di sini.
   - Struktur akhir:
        public_html/index.html
        public_html/assets/...
        public_html/api/index.php
        public_html/api/config.sample.php
        public_html/.htaccess
        public_html/schema.sql          (boleh dihapus setelah step 2)
        public_html/Backup_WARUNG_KAKA_20261026_112227.json

4. KONFIGURASI API
   - Di folder api/, RENAME config.sample.php menjadi config.php.
   - Edit config.php, isi:
        WAKA_DB_HOST = 'localhost'
        WAKA_DB_NAME = 'user_waka'      (nama lengkap dari cPanel)
        WAKA_DB_USER = 'user_wakadb'
        WAKA_DB_PASS = 'password_anda'
        WAKA_IMPORT_TOKEN = 'TOKEN_RAHASIA_BARU_ANDA'  <-- WAJIB DIGANTI!

5. SAMAKAN TOKEN IMPORT (WAJIB agar Restore Backup / Migrasi tersimpan ke DB!)
   - Token di config.php harus sama dengan yang dipakai aplikasi.
   - Aplikasi membaca token dari file public_html/index.html, baris:
        window.__WAKA_IMPORT_TOKEN__ = 'waka-import-2026';
   - Setelah mengganti WAKA_IMPORT_TOKEN di config.php, EDIT juga index.html
     lewat File Manager cPanel dan samakan nilainya dengan token baru Anda.
     (Keduanya tidak harus rahasia — yang penting SAMA.)
   - Jika token berbeda/kosong, aplikasi sekarang menampilkan pesan error
     "GAGAL masuk database" — bukan lagi toast sukses palsu.
   - ATAU lewati langkah 5 & 6 dan gunakan CARA C di bawah (paling aman).

6. IMPORT DATA LAMA (backup JSON)
   CARA IMPORT LEWAT BROWSER:
     - Buka aplikasi di browser, login kasir.
     - Masuk menu Pengaturan -> "Migrasikan Data" / "Import Backup",
       pilih file Backup_WARUNG_KAKA_20261026_112227.json.
     - Pastikan token sudah disamakan (langkah 5).
     - Sukses sejati ditandai pesan "... Tersimpan ke database: NNNN baris".
   Hasil yang diharapkan: 163 produk, 55 pelanggan, 1.326 invoice,
   1.809 stok masuk, 4 pengeluaran, 3 kasir, 1 pengaturan.

   CARA C (PALING MUDAH - tanpa buka aplikasi, jalankan import_cli.php):
     - Upload juga file import_cli.php ke public_html/api/ (ada di paket).
     - Via cPanel Terminal (atau ganti URL bila hosting tak punya terminal):
         cd ~/public_html/api && php import_cli.php ../Backup_WARUNG_KAKA_20261026_112227.json
     - Script membaca config.php sendiri -> tidak perlu token browser.

7. TES
   - Buka https://domainanda.com -> harus muncul halaman login.
   - Tes transaksi baru: buat penjualan, cek stok berkurang, cek
     laporan piutang.
   - Jika muncul "API error" / halaman putih: cek langkah 3 & 4,
     dan pastikan mod_rewrite aktif (standar di cPanel).

CATATAN PENTING
---------------
* Aplikasi ini TIDAK lagi butuh Firebase maupun Google Apps Script.
  Semua data tersimpan di MySQL hosting Anda.
* Data realtime digantikan sistem polling (auto-refresh tiap 15-30 dtk).
* Password kasir masih plaintext seperti sistem lama. Ganti segera
  password default (ervo123) lewat menu Kasir setelah deploy.
* Setelah import sukses, HAPUS file schema.sql dan Backup_*.json dari
  public_html (atau biarkan - .htaccess sudah memblokir aksesnya).
* Backup rutin: phpMyAdmin -> Export database secara berkala.

KEBUTUHAN SERVER
----------------
  PHP 7.4 atau lebih baru (disarankan 8.x), ekstensi pdo_mysql,
  mod_rewrite, MySQL 5.7+/MariaDB 10.3+. Semua standar cPanel.

Masalah umum:
  - "config.php belum dibuat" -> lakukan langkah 4.
  - Error 500 saat simpan transaksi -> cek privilege MySQL user.
  - Halaman putih -> pastikan folder assets ikut ter-upload dan
    .htaccess berada di public_html (bukan di subfolder).
========================================================================

================================================================================
CATATAN PENTING: RESTORE BACKUP DARI APLIKASI (v1.2 - perbaikan bug "sukses
palsu"). Jika restore dari menu Pengaturan melaporkan sukses, data kini
DIVERIFIKASI ULANG otomatis oleh aplikasi dengan menarik kembali daftar produk
dari MySQL. Bila verifikasi gagal, aplikasi akan menampilkan pesan error dan
Anda bisa memastikan isi tabel lewat phpMyAdmin (tab SQL):
  SELECT COUNT(*) FROM produk;   -- harus = jumlah di backup (mis. 163)
Cara paling andal untuk import awal tetap via Terminal cPanel:
  cd ~/public_html/api && php import_cli.php ../Backup_WARUNG_KAKA_*.json

============================================================
 CARA MEMASTIKAN FILE ANDA = VERSI TERBARU  (build r5)
============================================================
Versi paket ini : 2026.10.26-r5  (memuat fix "restore sukses tapi data tidak masuk DB")

1) COKOK TANDA TANGAN ZIP (paling akurat). Setelah download, jalankan:
     md5sum waka-cpanel.zip        (Linux/Terminal cPanel)
   atau certutil -hashfile waka-cpanel.zip MD5   (Windows CMD)
   Nilai yang benar ada di file pendamping CHECKSUMS.txt (diunduh berdampingan).

2) CEK LEWAT BROWSER SETELAH DEPLOY (tanpa perlu login/DB):
     https://domain-anda.com/api/version
   Harus muncul: {"app":"WARUNG KAKA","build":"2026.10.26-r5",...}
   Kalau 404/error -> api/index.php di server masih versi lama, upload ulang.

3) CEK SOURCE HALAMAN: View Source index.html di server, cari baris
     window.__WAKA_BUILD__ = '2026.10.26-r5';
   dan pastikan bundle yang dirujuk = assets/index-cHVCqhDF.js

4) CEK DARI BROWSER YANG SUDAH TERBUKA: tekan F12 -> Console, ketik
     window.__WAKA_BUILD__
   Bila 'undefined' -> browser serve cache lama: Ctrl+F5 (hard reload),
   atau DevTools -> Network -> centang Disable cache lalu reload.

Tips: update sebagian? Upload minimal 3 file ini agar fix restore aktif:
  index.html, api/index.php, dan assets/index-cHVCqhDF.js

================================================================================
CATATAN v1.3 (r8) - PENTING!
================================================================================

A) PERINGATAN "PHP Warning: JIT is incompatible with third party extensions..."
   -> AMAN, BUKAN penyebab kegagalan restore. Itu hanya catatan di error_log
      (biasanya dari extension ionCube/imagick bersebelahan dengan opcache-JIT).
      Sudah disertakan file .user.ini untuk mematikan JIT agar log bersih.

B) MENGAPA VERSI API TETAP LAMA WALAHUN SUDAH UPLOAD ULANG?
   Penyebab paling umum: OPcache server masih menyimpan kompilasi index.php lama.
   Solusi (pilih salah satu):
     1. cPanel -> Software -> MultiPHP INI Editor -> turunkan nilai
        "opcache.revalidate_freq" menjadi 0, ATAU
     2. Restart PHP-FPM / "Restart Applications" di cPanel, ATAU
     3. Biarkan saja: file .user.ini baru dalam paket ini sudah mengatur
        revalidate_freq=0 (efektif setelah upload).
   Setelah itu cek https://domain-anda.com/api/version
   -> build HARUS menampilkan "2026.10.26-r8". Jika masih r5/r6/r7, berarti
      file api/index.php yang di server belum benar-benar terganti (cek nama
      folder upload: harus public_html/api/index.php, bukan api/index.php di
      dalam subfolder lain).

C) RESTORE SUKSES TAPI phpMyAdmin KOSONG? CEK 3 HAL BERIKUT:
   1. DATABASE SALAH: bandingkan WAKA_DB_NAME di api/config.php dengan nama DB
      yang dibuka di phpMyAdmin. Respons import kini menyertakan pesan seperti
      "'waka_db.produk' = 163 baris" - angka inilah bukti nyata ke DB mana data
      ditulis. Jika jumlah > 0 tapi phpMyAdmin kosong, Anda melihat DB yang
      BEDA (sering terjadi jika punya beberapa akun/cPanel addon domain).
   2. CACHE BROWSER: hard-reload (Ctrl+F5) halaman phpMyAdmin & aplikasi.
   3. USER MYSQL: pastikan user di config.php punya privilege INSERT ke DB tsb.

D) CARA TERMUADAL (JIKA UI RESTORE MASIH BERMASALAH):
   Jalankan import via Terminal cPanel (langsung, tanpa HTTP/token/cache):
     cd ~/public_html/api && php import_cli.php ../Backup_WARUNG_KAKA_*.json
   Skrip CLI mencetak jumlah baris per tabel; jika ia melaporkan N>0 maka data
   PASTI ada di DB - tinggal buka DB yang sama di phpMyAdmin.
