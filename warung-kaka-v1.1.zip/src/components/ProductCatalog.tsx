import React, { useState, useMemo } from 'react';
import { Search, Package, Plus, Sparkles, X, AlertCircle, AlertTriangle, Filter, CheckCircle2 } from 'lucide-react';
import { Product, StoreSettings } from '../types';
import { fRp, escHtml } from '../utils/formatters';

interface ProductCatalogProps {
  products: Product[];
  settings?: StoreSettings;
  onSelectProduct: (product: Product) => void;
  onLoadSample: () => void;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  settings,
  onSelectProduct,
  onLoadSample,
}) => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('Semua');
  const [filterLowStockOnly, setFilterLowStockOnly] = useState(false);

  const minStockThreshold = settings?.minStockThreshold ?? 10;

  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      const katRaw = String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '');
      if (katRaw && katRaw.toLowerCase() !== 'semua') {
        const parts = katRaw.split(/[,;/]/).map((s) => s.trim()).filter(Boolean);
        if (parts.length > 0) {
          parts.forEach((pt) => set.add(pt));
        } else {
          set.add('Lainnya');
        }
      } else if (!katRaw) {
        set.add('Lainnya');
      }
    });
    const sorted = Array.from(set).sort((a, b) => a.localeCompare(b, 'id'));
    return ['Semua', ...sorted];
  }, [products]);

  // Helper to parse numeric stock
  const parseStok = (stokVal: any): number | null => {
    const stokStr = String(stokVal ?? '').trim();
    if (stokStr === '' || stokStr === '-') return null;
    const normalized = stokStr.replace(',', '.');
    const match = normalized.match(/-?\d+(?:\.\d+)?/);
    if (match) {
      const parsed = parseFloat(match[0]);
      return isNaN(parsed) ? null : parsed;
    }
    return null;
  };

  // Products with low stock or out of stock (<= threshold)
  const lowStockCount = useMemo(() => {
    return products.filter((p) => {
      const stokNum = parseStok(p.stok);
      return stokNum !== null && stokNum <= minStockThreshold;
    }).length;
  }, [products, minStockThreshold]);

  const outOfStockCount = useMemo(() => {
    return products.filter((p) => {
      const stokNum = parseStok(p.stok);
      return stokNum !== null && stokNum <= 0;
    }).length;
  }, [products]);

  const filteredProducts = useMemo(() => {
    let list = products;

    // Filter Low Stock Only Toggle
    if (filterLowStockOnly) {
      list = list.filter((p) => {
        const stokNum = parseStok(p.stok);
        return stokNum !== null && stokNum <= minStockThreshold;
      });
    }

    if (activeCategory !== 'Semua') {
      const target = activeCategory.trim().toLowerCase();
      list = list.filter((p) => {
        const katRaw = String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '').toLowerCase();
        if (katRaw === 'semua') return true;
        const parts = katRaw.split(/[,;/]/).map((s) => s.trim());
        return katRaw === target || parts.includes(target);
      });
    }

    if (search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.nama.toLowerCase().includes(q) ||
          (p.kode || '').toLowerCase().includes(q) ||
          (p.kategori || '').toLowerCase().includes(q)
      );
    }
    return list;
  }, [products, activeCategory, search, filterLowStockOnly, minStockThreshold]);

  return (
    <div className="bg-white border border-stone-200 rounded-xl flex flex-col h-full overflow-hidden shadow-xs">
      {/* Header */}
      <div className="px-4 py-3 border-b border-stone-200 flex items-center justify-between bg-stone-50">
        <div className="flex items-center gap-2 font-bold text-sm text-stone-900">
          <Package className="w-4 h-4 text-red-700" />
          <span>Katalog Produk & Kasir</span>
        </div>
        <div className="flex items-center gap-2">
          {lowStockCount > 0 && (
            <button
              type="button"
              onClick={() => setFilterLowStockOnly((prev) => !prev)}
              className={`px-2 py-0.5 rounded-full text-[10px] font-black flex items-center gap-1 transition cursor-pointer ${
                filterLowStockOnly
                  ? 'bg-red-700 text-white ring-2 ring-red-300'
                  : 'bg-red-100 text-red-800 hover:bg-red-200 border border-red-200'
              }`}
              title={`Klik untuk memfilter produk dengan sisa stok ≤ ${minStockThreshold}`}
            >
              <AlertTriangle className="w-3 h-3 text-red-600" />
              <span>{lowStockCount} Menipis</span>
            </button>
          )}
          <span className="text-xs font-medium text-stone-500">
            {filteredProducts.length} produk
          </span>
        </div>
      </div>

      {/* Peringatan Stok Menipis Banner (jika filter aktif atau ada stok habis) */}
      {filterLowStockOnly && (
        <div className="px-3 py-2 bg-red-50 border-b border-red-200 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-red-900 font-bold text-[11px]">
            <AlertTriangle className="w-3.5 h-3.5 text-red-700 shrink-0" />
            <span>
              Menampilkan <strong>{filteredProducts.length}</strong> produk di bawah batas stok (≤ {minStockThreshold} item)
            </span>
          </div>
          <button
            type="button"
            onClick={() => setFilterLowStockOnly(false)}
            className="text-[10px] text-red-700 hover:text-red-900 underline font-bold cursor-pointer"
          >
            Tampilkan Semua
          </button>
        </div>
      )}

      {/* Search Input */}
      <div className="p-3 pb-2">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama barang, kode produk, atau kategori..."
            className="w-full pl-9 pr-8 py-2 border border-stone-200 rounded-lg text-xs bg-white focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100 transition"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex gap-1.5 px-3 pb-2 overflow-x-auto shrink-0 scrollbar-none">
        {categories.map((cat, idx) => (
          <button
            key={`${cat}-${idx}`}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition border cursor-pointer ${
              activeCategory === cat
                ? 'bg-red-700 text-white border-red-700 shadow-xs'
                : 'bg-white text-stone-600 border-stone-200 hover:border-red-500 hover:text-red-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Product Grid / List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {products.length === 0 ? (
          <div className="text-center py-10 px-4 text-stone-500">
            <Package className="w-10 h-10 mx-auto mb-3 opacity-30 text-stone-400" />
            <p className="font-semibold text-sm text-stone-800">Belum Ada Data Produk</p>
            <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
              Katalog produk kosong. Sinkronkan dengan Google Sheets, impor CSV, atau tambah produk baru.
            </p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-10 px-4 text-stone-500">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-30 text-stone-400" />
            <p className="font-semibold text-xs text-stone-700">Tidak ada produk ditemukan</p>
            <p className="text-[11px] text-stone-400 mt-0.5">
              {filterLowStockOnly 
                ? `Tidak ada produk dengan stok ≤ ${minStockThreshold}` 
                : 'Coba ubah kata kunci pencarian'}
            </p>
          </div>
        ) : (
          filteredProducts.map((p, idx) => {
            const stokStr = String(p.stok ?? '').trim();
            const stokNum = parseStok(p.stok);

            const isOutOfStock = stokNum !== null && stokNum <= 0;
            const isLowStock = stokNum !== null && stokNum > 0 && stokNum <= minStockThreshold;
            const isSafeStock = stokNum !== null && stokNum > minStockThreshold;

            return (
              <div
                key={`${p.kode || p.nama || 'prod'}-${idx}`}
                onClick={() => !isOutOfStock && onSelectProduct(p)}
                className={`p-3 rounded-xl border transition duration-150 flex items-center justify-between gap-2 ${
                  isOutOfStock
                    ? 'opacity-60 bg-red-50/40 border-red-200 cursor-not-allowed'
                    : isLowStock
                    ? 'bg-amber-50/40 border-amber-300 hover:border-red-600 hover:bg-red-50/40 cursor-pointer hover:shadow-xs active:scale-[0.99]'
                    : 'bg-white border-stone-200 hover:border-red-600 hover:bg-red-50/30 cursor-pointer hover:shadow-xs active:scale-[0.99]'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="text-xs sm:text-sm font-bold text-stone-900 truncate">
                    {p.nama}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1">
                    {p.kode && (
                      <span className="font-mono text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded">
                        {p.kode}
                      </span>
                    )}
                    {p.kategori && (
                      <span className="text-[10px] font-semibold text-stone-700 bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">
                        {p.kategori}
                      </span>
                    )}
                    {p.satuan && (
                      <span className="text-[10px] font-medium text-stone-600 bg-stone-100 px-1.5 py-0.5 rounded">
                        {p.satuan}
                      </span>
                    )}
                    {p.tipeHarga === 'ukuran' && (
                      <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                        per m²
                      </span>
                    )}
                    
                    {/* Status Badge Stok */}
                    {isOutOfStock ? (
                      <span className="text-[10px] font-black text-red-700 bg-red-100 border border-red-200 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                        <span>●</span> Stok Habis (0)
                      </span>
                    ) : isLowStock ? (
                      <span className="text-[10px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                        <AlertTriangle className="w-2.5 h-2.5 text-amber-700" />
                        <span>Menipis: {stokStr} {p.satuan || ''}</span>
                      </span>
                    ) : isSafeStock ? (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-full">
                        Stok: {stokStr} {p.satuan || ''}
                      </span>
                    ) : stokStr && stokStr !== '-' ? (
                      <span className="text-[10px] font-medium text-stone-600 bg-stone-100 px-1.5 py-0.5 rounded">
                        Stok: {stokStr}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div
                    className={`text-xs sm:text-sm font-extrabold ${
                      isOutOfStock ? 'text-stone-400' : 'text-red-700'
                    }`}
                  >
                    {fRp(p.harga)}
                  </div>
                  {!isOutOfStock && (
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-red-700 mt-0.5">
                      <Plus className="w-3 h-3" /> Tambah
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
