import React, { useState } from 'react';
import { Store, Lock, User, Eye, EyeOff, KeyRound, RefreshCw, CheckCircle2, AlertCircle, ArrowRight, ShieldCheck, Search } from 'lucide-react';
import { KasirUser, StoreSettings } from '../types';
import { updateKasirPassword } from '../services/gasService';

interface LoginScreenProps {
  kasirUsers: KasirUser[];
  settings: StoreSettings;
  onLoginSuccess: (kasirName: string) => void;
  onRefreshKasir: () => Promise<void>;
  onUpdateKasirUsers?: (users: KasirUser[]) => void;
  onOpenPublicRekap?: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  kasirUsers,
  settings,
  onLoginSuccess,
  onRefreshKasir,
  onUpdateKasirUsers,
  onOpenPublicRekap,
  onShowToast,
}) => {
  const [selectedKasir, setSelectedKasir] = useState<string>(
    kasirUsers.length > 0 ? kasirUsers[0].nama : 'Admin'
  );
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Change Password state
  const [isChangePassOpen, setIsChangePassOpen] = useState<boolean>(false);
  const [changeKasir, setChangeKasir] = useState<string>('');
  const [oldPassInput, setOldPassInput] = useState<string>('');
  const [newPassInput, setNewPassInput] = useState<string>('');
  const [confirmPassInput, setConfirmPassInput] = useState<string>('');
  const [isSavingPass, setIsSavingPass] = useState<boolean>(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const targetUser = kasirUsers.find(
      (u) => u.nama.trim().toLowerCase() === selectedKasir.trim().toLowerCase()
    );

    const expectedPass = targetUser && targetUser.password ? targetUser.password : 'ervo123';

    if (password === expectedPass) {
      onShowToast(`Selamat datang, ${selectedKasir}!`, 'success');
      onLoginSuccess(selectedKasir);
    } else {
      setErrorMessage('Password salah! Password default adalah ervo123 jika belum diganti.');
    }
  };

  const handleOpenChangePass = () => {
    setChangeKasir(selectedKasir || (kasirUsers[0]?.nama ?? 'Admin'));
    setOldPassInput('');
    setNewPassInput('');
    setConfirmPassInput('');
    setIsChangePassOpen(true);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassInput.trim()) {
      onShowToast('Password baru tidak boleh kosong!', 'error');
      return;
    }
    if (newPassInput !== confirmPassInput) {
      onShowToast('Konfirmasi password baru tidak cocok!', 'error');
      return;
    }

    const targetUser = kasirUsers.find(
      (u) => u.nama.trim().toLowerCase() === changeKasir.trim().toLowerCase()
    );
    const expectedOldPass = targetUser && targetUser.password ? targetUser.password : 'ervo123';

    if (oldPassInput !== expectedOldPass) {
      onShowToast('Password lama Anda salah!', 'error');
      return;
    }

    setIsSavingPass(true);
    try {
      const newPass = newPassInput.trim();
      const res = await updateKasirPassword(changeKasir, newPass);
      
      const updatedUsers = kasirUsers.map((u) => {
        if (u.nama.trim().toLowerCase() === changeKasir.trim().toLowerCase()) {
          return { ...u, password: newPass };
        }
        return u;
      });
      if (!updatedUsers.some((u) => u.nama.trim().toLowerCase() === changeKasir.trim().toLowerCase())) {
        updatedUsers.push({ nama: changeKasir, password: newPass });
      }

      if (onUpdateKasirUsers) {
        onUpdateKasirUsers(updatedUsers);
      }

      onShowToast(`Password ${changeKasir} berhasil diperbarui!`, 'success');
      setIsChangePassOpen(false);
      setPassword(newPass);
      setSelectedKasir(changeKasir);
      setErrorMessage(null);
    } catch {
      onShowToast('Terjadi kesalahan saat menyimpan password', 'error');
    } finally {
      setIsSavingPass(false);
    }
  };

  const handleSyncKasir = async () => {
    setIsRefreshing(true);
    await onRefreshKasir();
    setIsRefreshing(false);
    onShowToast('Daftar kasir disinkronkan dari Google Sheets', 'info');
  };

  return (
    <div className="min-h-screen bg-stone-100 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden">
        {/* Header Branding */}
        <div className="bg-black p-6 text-white text-center relative border-b border-stone-800">
          <div className="w-16 h-16 bg-stone-900 rounded-2xl border border-stone-800 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Store className="w-8 h-8 text-red-500" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-wider uppercase text-white">
            {settings.name || 'WARUNGKU'}
          </h1>
          <p className="text-xs text-red-400 mt-1.5 font-semibold">
            {settings.tagline || 'Cepat / Tepat / Berkualitas'}
          </p>
          <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-stone-900 rounded-full text-[11px] text-stone-300 font-semibold border border-stone-800">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Login Akses Operator Kasir</span>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Akses Ditolak</p>
                <p className="text-[11px] mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Kasir Select */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                <User className="w-4 h-4 text-red-700" />
                <span>Pilih Operator / Kasir</span>
              </label>
              <button
                type="button"
                onClick={handleSyncKasir}
                disabled={isRefreshing}
                className="text-[11px] text-red-700 hover:text-red-900 font-bold flex items-center gap-1 transition cursor-pointer"
                title="Refresh daftar kasir dari Google Sheets"
              >
                <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>Sync Kasir</span>
              </button>
            </div>
            <select
              value={selectedKasir}
              onChange={(e) => {
                setSelectedKasir(e.target.value);
                setErrorMessage(null);
              }}
              className="w-full py-2.5 px-3.5 border border-stone-300 rounded-xl text-xs font-bold bg-stone-50 text-stone-900 focus:bg-white focus:ring-2 focus:ring-red-200 focus:border-red-600 transition"
            >
              {kasirUsers.map((u, idx) => (
                <option key={`${u.nama}-${idx}`} value={u.nama}>
                  {u.nama}
                </option>
              ))}
            </select>
          </div>

          {/* Password Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-red-700" />
                <span>Password Kasir</span>
              </label>
              <span className="text-[10px] text-stone-400 font-medium">Default: ervo123</span>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrorMessage(null);
                }}
                placeholder="Ketik password kasir..."
                className="w-full py-2.5 pl-3.5 pr-10 border border-stone-300 rounded-xl text-xs font-semibold bg-white text-stone-900 focus:ring-2 focus:ring-red-200 focus:border-red-600 transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <button
            type="submit"
            className="w-full py-3 bg-red-700 hover:bg-red-800 text-white text-xs font-extrabold rounded-xl shadow-md transition flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
          >
            <span>Masuk Aplikasi Kasir</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="pt-2 border-t border-stone-200 flex items-center justify-between text-xs">
            {onOpenPublicRekap ? (
              <button
                type="button"
                onClick={onOpenPublicRekap}
                className="text-red-700 hover:text-red-900 font-bold flex items-center gap-1 transition cursor-pointer"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Cari Rekap (Umum)</span>
              </button>
            ) : <div />}
            <button
              type="button"
              onClick={handleOpenChangePass}
              className="text-stone-600 hover:text-red-800 font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-red-700" />
              <span>Ganti Password Kasir</span>
            </button>
          </div>
        </form>

        <div className="bg-stone-50 px-6 py-3 border-t border-stone-200 text-center text-[11px] text-stone-500 font-medium">
          Toko: <strong className="text-stone-700">{settings.name || 'ERVO PRINT'}</strong> •WA: {settings.phone || '0812-2247-2007'}
        </div>
      </div>

      {/* Change Password Modal */}
      {isChangePassOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-red-700" />
                <span>Ganti Password Kasir</span>
              </h3>
              <button
                onClick={() => setIsChangePassOpen(false)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Pilih Kasir
                </label>
                <select
                  value={changeKasir}
                  onChange={(e) => setChangeKasir(e.target.value)}
                  className="w-full p-2 border border-stone-300 rounded-lg text-xs font-bold bg-stone-50"
                >
                  {kasirUsers.map((u, idx) => (
                    <option key={`${u.nama}-${idx}`} value={u.nama}>
                      {u.nama}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Password Lama
                </label>
                <input
                  type="password"
                  value={oldPassInput}
                  onChange={(e) => setOldPassInput(e.target.value)}
                  placeholder="Ketik password lama (default: ervo123)"
                  className="w-full p-2 border border-stone-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Password Baru
                </label>
                <input
                  type="password"
                  value={newPassInput}
                  onChange={(e) => setNewPassInput(e.target.value)}
                  placeholder="Ketik password baru..."
                  className="w-full p-2 border border-stone-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Konfirmasi Password Baru
                </label>
                <input
                  type="password"
                  value={confirmPassInput}
                  onChange={(e) => setConfirmPassInput(e.target.value)}
                  placeholder="Ulangi password baru..."
                  className="w-full p-2 border border-stone-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsChangePassOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSavingPass}
                  className="px-4 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  {isSavingPass ? 'Menyimpan...' : 'Simpan Password'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
