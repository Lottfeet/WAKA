import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Users, 
  BadgeDollarSign, 
  CheckCheck, 
  FileText, 
  Printer, 
  Trash2, 
  X, 
  Phone, 
  Clock, 
  DollarSign, 
  User, 
  ArrowRight,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Eye,
  SlidersHorizontal,
  Package,
  Calendar,
  CheckCircle2,
  AlertCircle,
  LogIn,
  Store,
  ShieldCheck,
  Layers,
  FileSpreadsheet,
  Download,
  Building2,
  Check
} from 'lucide-react';
import { Invoice, StoreSettings, PelunasanRecord, Customer } from '../types';
import { fRp, fDate, fTime } from '../utils/formatters';
import { 
  generateSlipPotongGajiKaryawanPDF, 
  generateSlipBuktiPelunasanKaryawanPDF, 
  generateRekapPiutangPDF,
  generateRekapPiutangTerkunciPDF,
  openPrintWindow 
} from '../utils/printUtils';
import { getCustomerSlipSummary, getNextSlipNumberForCustomer, isInvoiceLocked, isSameCustomer } from '../utils/slipUtils';
import { 
  exportEmployeePiutangToExcel, 
  buildEmployeeExportRows, 
  EmployeeExportRow,
  parseEmployeeNameAndDivision,
  getCustomerDivision 
} from '../utils/excelUtils';
import { getLocalCustomers } from '../services/gasService';

interface PencarianRekapViewProps {
  invoices: Invoice[];
  customers?: Customer[];
  settings: StoreSettings;
  cashierName?: string;
  isLoggedIn?: boolean;
  onLoginClick?: () => void;
  onRecordPelunasan?: (payload: PelunasanRecord) => Promise<void>;
  onBatchRecordPelunasan?: (payloads: PelunasanRecord[]) => Promise<void>;
  onDeleteInvoice?: (invoiceNo: string, items?: any[]) => Promise<void>;
  onReprintInvoice?: (invoice: Invoice) => void;
  onBatchUpdateInvoices?: (invoices: Invoice[]) => Promise<void>;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const PencarianRekapView: React.FC<PencarianRekapViewProps> = ({
  invoices,
  customers = [],
  settings,
  cashierName = 'Admin',
  isLoggedIn = true,
  onLoginClick,
  onRecordPelunasan,
  onBatchRecordPelunasan,
  onDeleteInvoice,
  onReprintInvoice,
  onBatchUpdateInvoices,
  onShowToast,
}) => {
  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<'all' | 'unpaid' | 'lunas'>('all');
  
  // Selected Customer for Detailed Modal View
  const [selectedCustomerDetail, setSelectedCustomerDetail] = useState<string | null>(null);
  const [detailTab, setDetailTab] = useState<'unpaid' | 'history'>('unpaid');
  
  // Settlement Modal State
  const [settleTarget, setSettleTarget] = useState<{
    customer: string;
    invoices: Invoice[];
    total: number;
  } | null>(null);
  const [bayarNominal, setBayarNominal] = useState('');
  const [bayarMetode, setBayarMetode] = useState('Potong Gaji (Payroll)');
  const [bayarCatatan, setBayarCatatan] = useState('Pelunasan saat gajian');
  const [isProcessing, setIsProcessing] = useState(false);

  // Delete Modals State
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);
  const [customerToDeleteLunas, setCustomerToDeleteLunas] = useState<{ customer: string; invoices: Invoice[] } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Excel Export State (WAKA Template Matching)
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportStartDate, setExportStartDate] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  });
  const [exportEndDate, setExportEndDate] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  });
  const [exportDivisionFilters, setExportDivisionFilters] = useState<string[]>(['ALL']);
  const [excludedExportCustomerKeys, setExcludedExportCustomerKeys] = useState<Record<string, boolean>>({});
  const [exportOnlyLocked, setExportOnlyLocked] = useState<boolean>(true);

  const isAllExportDivisions = exportDivisionFilters.includes('ALL') || exportDivisionFilters.length === 0;

  const toggleExportDivision = (div: string) => {
    setExportDivisionFilters((prev) => {
      if (div === 'ALL') {
        return ['ALL'];
      }
      const withoutAll = prev.filter((d) => d !== 'ALL');
      if (withoutAll.includes(div)) {
        const next = withoutAll.filter((d) => d !== div);
        return next.length === 0 ? ['ALL'] : next;
      } else {
        const next = [...withoutAll, div];
        if (availableExportDivisions.length > 0 && next.length === availableExportDivisions.length) {
          return ['ALL'];
        }
        return next;
      }
    });
  };

  const removeExportDivision = (div: string) => {
    setExportDivisionFilters((prev) => {
      const next = prev.filter((d) => d !== div && d !== 'ALL');
      return next.length === 0 ? ['ALL'] : next;
    });
  };

  const resetExportDivisions = () => {
    setExportDivisionFilters(['ALL']);
  };

  // View specific invoice items detail
  const [viewInvoiceItemDetail, setViewInvoiceItemDetail] = useState<Invoice | null>(null);

  // Expanded Slips in Card (allows clicking history slips to see their breakdown/invoices)
  const [expandedSlips, setExpandedSlips] = useState<Record<string, boolean>>({});

  const toggleSlipExpanded = (customer: string, slipNo: number) => {
    const key = `${customer}_slip_${slipNo}`;
    setExpandedSlips((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Process invoices with accurate sisa & status calculations (strictly deduplicated)
  const processedInvoices = useMemo(() => {
    const uniqueMap = new Map<string, Invoice>();
    invoices.forEach((inv) => {
      const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
      if (!invNo) {
        uniqueMap.set(Math.random().toString(), inv);
      } else if (!uniqueMap.has(invNo)) {
        uniqueMap.set(invNo, inv);
      } else {
        const existing = uniqueMap.get(invNo)!;
        const existHistLen = (existing.pelunasanHistory?.length || 0) + (existing.historiPelunasan?.length || 0);
        const newHistLen = (inv.pelunasanHistory?.length || 0) + (inv.historiPelunasan?.length || 0);
        if (newHistLen >= existHistLen) {
          uniqueMap.set(invNo, { ...existing, ...inv });
        }
      }
    });

    return Array.from(uniqueMap.values()).map((inv) => {
      const history = Array.isArray(inv.pelunasanHistory) 
        ? inv.pelunasanHistory 
        : Array.isArray(inv.historiPelunasan) 
        ? inv.historiPelunasan 
        : [];
      
      const totalPaidHistory = history.reduce((sum, h) => sum + Number(h.jumlahBayar || 0), 0);
      const isPotongGaji = (inv.payMethod || '').includes('Gaji') || (inv.metodePembayaran || '').includes('Gaji');
      const effectiveDp = isPotongGaji ? 0 : Number(inv.dp || 0);
      const calculatedSisa = Math.max(0, Number(inv.total || 0) - effectiveDp - totalPaidHistory);
      const isLunas = calculatedSisa <= 0;

      return {
        ...inv,
        calculatedSisa,
        isLunas,
        effectiveDp,
        totalPaidHistory,
        pelunasanHistory: history,
      };
    });
  }, [invoices]);

  // Aggregate data by Customer / Employee (filtered by search term)
  const searchedCustomerGroups = useMemo(() => {
    const map = new Map<string, {
      customer: string;
      kelas: string;
      phone: string;
      address: string;
      totalBelanja: number;
      totalUnpaid: number;
      totalSettled: number;
      invoices: typeof processedInvoices;
      unpaidInvoices: typeof processedInvoices;
      settledInvoices: typeof processedInvoices;
      historyRecords: Array<PelunasanRecord & { customerName?: string; totalInvoice?: number }>;
      lastSettledDate: string;
      lastSettledTime: string;
      lastOrderDate: string;
    }>();

    // Seed with existing customers if available
    customers.forEach((c) => {
      const name = (c.nama || '').trim();
      if (!name) return;
      map.set(name, {
        customer: name,
        kelas: c.kelas || 'Karyawan',
        phone: c.telepon || '',
        address: c.alamat || '',
        totalBelanja: 0,
        totalUnpaid: 0,
        totalSettled: 0,
        invoices: [],
        unpaidInvoices: [],
        settledInvoices: [],
        historyRecords: [],
        lastSettledDate: '',
        lastSettledTime: '',
        lastOrderDate: '',
      });
    });

    const resolveCanonicalName = (rawName: string): string => {
      if (!rawName || !rawName.trim()) return 'Umum';
      const clean = rawName.trim();
      const cleanLower = clean.toLowerCase();
      if (cleanLower === 'umum') return 'Umum';

      // 1. Exact match in customer directory
      const exact = customers.find((c) => c.nama.trim().toLowerCase() === cleanLower);
      if (exact) return exact.nama.trim();

      // 2. Match against historical oldNames / aliases
      const aliasMatch = customers.find((c) => {
        if (Array.isArray(c.oldNames)) {
          return c.oldNames.some((o) => o.trim().toLowerCase() === cleanLower);
        }
        return false;
      });
      if (aliasMatch) return aliasMatch.nama.trim();

      // 3. Base name match (stripping parentheses and dashes)
      const cleanBase = clean.replace(/\(.*?\)/g, '').replace(/[-–\/].*$/, '').trim().toLowerCase();
      if (cleanBase.length > 2) {
        const baseMatch = customers.find((c) => {
          const cBase = c.nama.toLowerCase().replace(/\(.*?\)/g, '').replace(/[-–\/].*$/, '').trim();
          return cBase.length > 2 && (cBase === cleanBase || cleanBase.includes(cBase) || cBase.includes(cleanBase));
        });
        if (baseMatch) return baseMatch.nama.trim();
      }

      return clean;
    };

    // Populate with invoice records
    processedInvoices.forEach((inv) => {
      const rawName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
      const custName = resolveCanonicalName(rawName);
      if (!map.has(custName)) {
        map.set(custName, {
          customer: custName,
          kelas: 'Karyawan',
          phone: inv.customerPhone || '',
          address: inv.customerAddress || '',
          totalBelanja: 0,
          totalUnpaid: 0,
          totalSettled: 0,
          invoices: [],
          unpaidInvoices: [],
          settledInvoices: [],
          historyRecords: [],
          lastSettledDate: '',
          lastSettledTime: '',
          lastOrderDate: '',
        });
      }

      const entry = map.get(custName)!;
      if (inv.customerPhone && !entry.phone) entry.phone = inv.customerPhone;
      if (inv.customerAddress && !entry.address) entry.address = inv.customerAddress;

      const invCleanNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
      const alreadyHasInv = entry.invoices.some(
        (ex) => (ex.invoiceNo || (ex as any).noInvoice || '').trim().toLowerCase() === invCleanNo
      );

      if (!alreadyHasInv) {
        entry.invoices.push(inv);
        entry.totalBelanja += Number(inv.total || 0);

        if (!entry.lastOrderDate || (inv.date && inv.date > entry.lastOrderDate)) {
          entry.lastOrderDate = inv.date;
        }

        if (inv.calculatedSisa > 0) {
          entry.unpaidInvoices.push(inv);
          entry.totalUnpaid += inv.calculatedSisa;
        } else {
          entry.settledInvoices.push(inv);
        }

        // Collect payment history
        inv.pelunasanHistory.forEach((h) => {
          const hKey = (h.id && h.id.trim())
            ? h.id.trim()
            : `${(h.invoiceNo || '').trim().toLowerCase()}_${(h.date || '').trim()}_${(h.time || '').trim().substring(0, 5)}_${Math.round(Number(h.jumlahBayar || 0))}`;
          const alreadyHasHist = entry.historyRecords.some((ex) => {
            const exKey = (ex.id && ex.id.trim())
              ? ex.id.trim()
              : `${(ex.invoiceNo || '').trim().toLowerCase()}_${(ex.date || '').trim()}_${(ex.time || '').trim().substring(0, 5)}_${Math.round(Number(ex.jumlahBayar || 0))}`;
            return exKey === hKey;
          });

          if (!alreadyHasHist) {
            entry.historyRecords.push({
              ...h,
              customerName: custName,
              totalInvoice: inv.total,
            });
            entry.totalSettled += Number(h.jumlahBayar || 0);
            if (!entry.lastSettledDate || (h.date && h.date > entry.lastSettledDate)) {
              entry.lastSettledDate = h.date || '';
              entry.lastSettledTime = h.time || '';
            }
          }
        });

        if (inv.pelunasanHistory.length === 0 && inv.isLunas) {
          entry.totalSettled += Number(inv.total || 0);
          if (!entry.lastSettledDate || (inv.date && inv.date > entry.lastSettledDate)) {
            entry.lastSettledDate = inv.date || '';
            entry.lastSettledTime = inv.time || '';
          }
        }
      }
    });

    const allList = Array.from(map.values()).filter((g) => g.invoices.length > 0 || g.totalUnpaid > 0 || g.totalSettled > 0);

    // If public mode (not logged in) and search query is empty, do not show any employee data for privacy
    const q = searchTerm.toLowerCase().trim();
    if (!isLoggedIn && !q) {
      return [];
    }

    // Filter by search query
    return allList.filter((g) => {
      if (!q) return true;
      const custDivision = getCustomerDivision(g.customer, customers);
      const matchCust = g.customer.toLowerCase().includes(q);
      const matchDivision = custDivision && custDivision.toLowerCase().includes(q);
      const matchPhone = g.phone && g.phone.includes(q);
      const matchInv = g.invoices.some((i) => (i.invoiceNo || (i as any).noInvoice || '').toLowerCase().includes(q));
      return matchCust || matchDivision || matchPhone || matchInv;
    });
  }, [processedInvoices, customers, searchTerm, isLoggedIn]);

  // Overall Statistics computed from searched items (stable across category filter changes)
  const overallStats = useMemo(() => {
    let totalUnpaidSum = 0;
    let totalSettledSum = 0;
    let totalUnpaidCount = 0;
    let totalSettledCount = 0;

    searchedCustomerGroups.forEach((g) => {
      totalUnpaidSum += g.totalUnpaid;
      totalSettledSum += g.totalSettled;
      if (g.totalUnpaid > 0) totalUnpaidCount++;
      if (g.totalUnpaid === 0 && g.totalSettled > 0) totalSettledCount++;
    });

    return {
      totalUnpaidSum,
      totalSettledSum,
      totalUnpaidCount,
      totalSettledCount,
      totalEmployees: searchedCustomerGroups.length,
    };
  }, [searchedCustomerGroups]);

  // Statistics of locked unpaid transactions across processed invoices
  const lockedUnpaidStats = useMemo(() => {
    let count = 0;
    let totalRp = 0;
    const custSet = new Set<string>();

    processedInvoices.forEach((inv) => {
      const sisa = Number(
        (inv as any).calculatedSisa !== undefined 
          ? (inv as any).calculatedSisa 
          : (inv.sisa !== undefined ? inv.sisa : inv.total || 0)
      );
      if (sisa <= 0) return;

      const isLocked = Boolean(
        inv.slipPrinted || 
        (inv as any).isLocked || 
        (inv as any).terkunci || 
        (inv as any).locked
      );
      if (!isLocked) return;

      count += 1;
      totalRp += sisa;
      const c = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
      if (c) custSet.add(c);
    });

    return {
      count,
      totalRp,
      custCount: custSet.size,
    };
  }, [processedInvoices]);

  // Filtered and Sorted Customer Recap List for display
  const customerRecapList = useMemo(() => {
    let filtered = [...searchedCustomerGroups];

    // Filter by status category
    if (filterCategory === 'unpaid') {
      filtered = filtered.filter((g) => g.totalUnpaid > 0);
    } else if (filterCategory === 'lunas') {
      filtered = filtered.filter((g) => g.totalUnpaid === 0 && g.totalSettled > 0);
    }

    // Sort: Unpaid highest first, then settled date
    return filtered.sort((a, b) => {
      if (b.totalUnpaid !== a.totalUnpaid) {
        return b.totalUnpaid - a.totalUnpaid;
      }
      return (b.lastOrderDate || '').localeCompare(a.lastOrderDate || '');
    });
  }, [searchedCustomerGroups, filterCategory]);

  // Grouped customer data specifically prepared for Excel Export (Full scope regardless of search bar query)
  const groupedCustomersForExport = useMemo(() => {
    const map = new Map<string, {
      customer: string;
      invoices: Invoice[];
      totalUnpaid: number;
      phone?: string;
      potongGajiUnpaid: number;
    }>();

    processedInvoices.forEach((inv) => {
      const custName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
      const sisa = inv.calculatedSisa;

      if (!map.has(custName)) {
        map.set(custName, {
          customer: custName,
          invoices: [],
          totalUnpaid: 0,
          phone: inv.customerPhone,
          potongGajiUnpaid: 0,
        });
      }

      const entry = map.get(custName)!;
      entry.invoices.push(inv);
      if (sisa > 0) {
        entry.totalUnpaid += sisa;
        const isPotongGaji = (inv.payMethod || '').includes('Gaji') || (inv.metodePembayaran || '').includes('Gaji');
        if (isPotongGaji) {
          entry.potongGajiUnpaid += sisa;
        }
      }
    });

    return Array.from(map.values());
  }, [processedInvoices]);

  // Available divisions for export filter - accurately gathered from customer directory, debtors, raw invoices, and preview rows
  const availableExportDivisions = useMemo(() => {
    const divs = new Set<string>();

    // 1. Check all customers prop + local database fallback
    const allCusts = customers && customers.length > 0 ? customers : getLocalCustomers();
    allCusts.forEach((c) => {
      const parsed = parseEmployeeNameAndDivision(c.nama, c);
      const d = (c.divisi || c.division || parsed.division || '').trim().toUpperCase();
      if (d) divs.add(d);
    });

    // 2. Check grouped customers for export
    groupedCustomersForExport.forEach((g) => {
      const custObj = allCusts.find((c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === g.customer.toUpperCase().replace(/\(.*?\)/g, '').trim());
      const parsed = parseEmployeeNameAndDivision(g.customer, custObj);
      const d = (custObj?.divisi || custObj?.division || parsed.division || '').trim().toUpperCase();
      if (d) divs.add(d);
    });

    // 3. Check all raw invoices directly
    invoices.forEach((inv) => {
      const custName = (inv.customer || (inv as any).pelanggan || '').trim();
      if (custName) {
        const custObj = allCusts.find((c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === custName.toUpperCase().replace(/\(.*?\)/g, '').trim());
        const parsed = parseEmployeeNameAndDivision(custName, custObj);
        const d = ((inv as any).divisi || (inv as any).division || custObj?.divisi || custObj?.division || parsed.division || '').trim().toUpperCase();
        if (d) divs.add(d);
      }
    });

    // 4. Scan preview export rows to guarantee every row's division is selectable
    const previewRows = buildEmployeeExportRows({
      groupedCustomers: groupedCustomersForExport,
      customers: allCusts,
      startDate: exportStartDate,
      endDate: exportEndDate,
      divisionFilter: 'ALL',
      exportScope: 'only_unpaid',
      onlyLockedTransactions: exportOnlyLocked,
    });
    previewRows.forEach((r) => {
      if (r.division && r.division.trim()) {
        divs.add(r.division.trim().toUpperCase());
      }
    });

    const result = Array.from(divs).filter(Boolean).sort();
    console.info('[ExportExcel/PencarianRekapView:DivisiDebug]', {
      totalCustomers: allCusts.length,
      groupedDebtors: groupedCustomersForExport.length,
      detectedDivisions: result,
      previewRowsCount: previewRows.length,
    });
    return result;
  }, [customers, groupedCustomersForExport, invoices, exportStartDate, exportEndDate, exportOnlyLocked]);

  // Base generated export rows from filter criteria
  const rawExportRows = useMemo(() => {
    return buildEmployeeExportRows({
      groupedCustomers: groupedCustomersForExport,
      customers,
      startDate: exportStartDate,
      endDate: exportEndDate,
      divisionFilter: exportDivisionFilters,
      exportScope: 'only_unpaid',
      onlyLockedTransactions: exportOnlyLocked,
    });
  }, [groupedCustomersForExport, customers, exportStartDate, exportEndDate, exportDivisionFilters, exportOnlyLocked]);

  // Filtered rows by selected checkboxes (unexcluded keys)
  const selectedExportRows = useMemo(() => {
    return rawExportRows.filter((r) => !excludedExportCustomerKeys[r.rowId]);
  }, [rawExportRows, excludedExportCustomerKeys]);

  const isAllExportSelected = rawExportRows.length > 0 && rawExportRows.every((r) => !excludedExportCustomerKeys[r.rowId]);

  const toggleSelectAllExport = () => {
    if (isAllExportSelected) {
      const updated: Record<string, boolean> = {};
      rawExportRows.forEach((r) => {
        updated[r.rowId] = true;
      });
      setExcludedExportCustomerKeys(updated);
    } else {
      setExcludedExportCustomerKeys({});
    }
  };

  const handleDownloadExcel = () => {
    try {
      if (selectedExportRows.length === 0) {
        alert('Silakan pilih minimal 1 karyawan untuk diekspor.');
        return;
      }
      const filenameDate = exportStartDate === exportEndDate 
        ? exportStartDate 
        : `${exportStartDate}_sd_${exportEndDate}`;
      const finalNumberedRows = selectedExportRows.map((r, idx) => ({
        ...r,
        no: idx + 1,
      }));
      exportEmployeePiutangToExcel(finalNumberedRows, filenameDate);
      if (onShowToast) {
        onShowToast(`File Excel Rekap_WAKA_${filenameDate}.xlsx berhasil diunduh!`, 'success');
      }
      setIsExportModalOpen(false);
    } catch (e: any) {
      console.error('Export Excel failed:', e);
      alert('Gagal mengunduh Excel: ' + (e?.message || 'Error'));
    }
  };

  // Handler: Cetak PDF Seluruh Transaksi Belum Lunas yang Terkunci oleh Petugas
  const handlePrintRekapPDFLocked = () => {
    const q = searchTerm.toLowerCase().trim();

    const map = new Map<string, {
      customer: string;
      phone?: string;
      division?: string;
      totalUnpaid: number;
      invoiceCount: number;
      invoices: Invoice[];
    }>();

    const allCusts = customers && customers.length > 0 ? customers : getLocalCustomers();

    processedInvoices.forEach((inv) => {
      const sisa = Number(
        (inv as any).calculatedSisa !== undefined 
          ? (inv as any).calculatedSisa 
          : (inv.sisa !== undefined ? inv.sisa : inv.total || 0)
      );
      if (sisa <= 0) return; // Hanya transaksi belum lunas

      const isLocked = isInvoiceLocked(inv);
      if (!isLocked) return; // Hanya transaksi yang sudah dikunci oleh petugas

      const custName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
      
      // Filter pencarian jika ada kata kunci
      if (q) {
        const phone = (inv.customerPhone || '').toLowerCase();
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').toLowerCase();
        const cLower = custName.toLowerCase();
        if (!cLower.includes(q) && !phone.includes(q) && !invNo.includes(q)) {
          return;
        }
      }

      if (!map.has(custName)) {
        const custObj = allCusts.find(
          (c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === custName.toUpperCase().replace(/\(.*?\)/g, '').trim()
        );
        const parsed = parseEmployeeNameAndDivision(custName, custObj);
        const div = (custObj?.divisi || custObj?.division || parsed.division || (inv as any).divisi || '').trim();
        const phone = custObj?.telepon || inv.customerPhone || parsed.phone || '';

        map.set(custName, {
          customer: custName,
          phone,
          division: div,
          totalUnpaid: 0,
          invoiceCount: 0,
          invoices: [],
        });
      }

      const entry = map.get(custName)!;
      entry.invoices.push(inv);
      entry.totalUnpaid += sisa;
      entry.invoiceCount += 1;
    });

    const targetGroups = Array.from(map.values()).sort((a, b) => a.customer.localeCompare(b.customer));

    if (targetGroups.length === 0) {
      const msg = q
        ? `Tidak ditemukan transaksi belum lunas yang berstatus terkunci untuk pencarian "${searchTerm}".`
        : 'Tidak ada data transaksi belum lunas yang berstatus terkunci oleh petugas saat ini.';
      if (onShowToast) {
        onShowToast(msg, 'info');
      } else {
        alert(msg);
      }
      return;
    }

    const totalInvs = targetGroups.reduce((acc, g) => acc + g.invoiceCount, 0);
    const totalAmount = targetGroups.reduce((acc, g) => acc + g.totalUnpaid, 0);

    const html = generateRekapPiutangTerkunciPDF(targetGroups, settings, {
      printedBy: cashierName || 'Petugas Kasir',
      title: 'REKAPITULASI TRANSAKSI TERKUNCI (BELUM LUNAS)',
      filterInfo: q ? `Hasil Pencarian: "${searchTerm}"` : 'Seluruh Transaksi Terkunci Petugas',
    });

    openPrintWindow(html, `Rekap_Terkunci_${new Date().toISOString().split('T')[0]}`);
    if (onShowToast) {
      onShowToast(`PDF Rekap Terkunci (${targetGroups.length} Karyawan, ${totalInvs} Nota, ${fRp(totalAmount)}) siap dicetak!`, 'success');
    }
  };

  // Handler: Cetak PDF dari dalam Modal Export Excel
  const handlePrintPDFFromExportModal = () => {
    try {
      if (selectedExportRows.length === 0) {
        alert('Silakan pilih minimal 1 baris transaksi untuk dicetak ke PDF.');
        return;
      }

      const filenameDate = exportStartDate === exportEndDate 
        ? exportStartDate 
        : `${exportStartDate}_sd_${exportEndDate}`;

      const selectedNotaSet = new Set(selectedExportRows.map((r) => r.noNota).filter((n) => n && n !== '-'));
      const map = new Map<string, {
        customer: string;
        phone?: string;
        division?: string;
        totalUnpaid: number;
        invoiceCount: number;
        invoices: Invoice[];
      }>();

      processedInvoices.forEach((inv) => {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
        if (!selectedNotaSet.has(invNo)) return;

        const custName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
        const sisa = Number(
          (inv as any).calculatedSisa !== undefined 
            ? (inv as any).calculatedSisa 
            : (inv.sisa !== undefined ? inv.sisa : inv.total || 0)
        );

        if (!map.has(custName)) {
          const matchingRow = selectedExportRows.find((r) => r.name.toLowerCase() === custName.toLowerCase() || r.noNota === invNo);
          map.set(custName, {
            customer: custName,
            phone: matchingRow?.phone || inv.customerPhone || '',
            division: matchingRow?.division || (inv as any).divisi || '',
            totalUnpaid: 0,
            invoiceCount: 0,
            invoices: [],
          });
        }

        const entry = map.get(custName)!;
        entry.invoices.push(inv);
        entry.totalUnpaid += sisa;
        entry.invoiceCount += 1;
      });

      const targetGroups = Array.from(map.values()).sort((a, b) => a.customer.localeCompare(b.customer));

      if (targetGroups.length === 0) {
        const rowMap = new Map<string, { customer: string; phone?: string; division?: string; totalUnpaid: number; invoiceCount: number; invoices: Invoice[] }>();
        selectedExportRows.forEach((r) => {
          if (!rowMap.has(r.name)) {
            rowMap.set(r.name, {
              customer: r.name,
              phone: r.phone,
              division: r.division,
              totalUnpaid: 0,
              invoiceCount: 0,
              invoices: [],
            });
          }
          const entry = rowMap.get(r.name)!;
          entry.totalUnpaid += Number(r.nominal || r.total || 0);
          entry.invoiceCount += 1;
        });
        targetGroups.push(...Array.from(rowMap.values()));
      }

      const totalInvs = targetGroups.reduce((acc, g) => acc + g.invoiceCount, 0);
      const totalAmount = targetGroups.reduce((acc, g) => acc + g.totalUnpaid, 0);

      const html = generateRekapPiutangTerkunciPDF(targetGroups, settings, {
        printedBy: cashierName || 'Petugas Kasir',
        title: 'REKAPITULASI TRANSAKSI TERKUNCI (BELUM LUNAS)',
        periode: `Periode: ${filenameDate}`,
        filterInfo: exportOnlyLocked ? 'Hanya Slip & Nota Terkunci' : 'Transaksi Terpilih',
      });

      openPrintWindow(html, `Rekap_Terkunci_${filenameDate}`);
      if (onShowToast) {
        onShowToast(`PDF Rekap Terkunci (${targetGroups.length} Karyawan, ${totalInvs} Nota, ${fRp(totalAmount)}) siap dicetak!`, 'success');
      }
    } catch (e: any) {
      console.error('Print PDF from modal failed:', e);
      alert('Gagal mencetak PDF: ' + (e?.message || 'Error'));
    }
  };

  // Selected customer data for detail drawer/modal
  const activeSelectedData = useMemo(() => {
    if (!selectedCustomerDetail) return null;
    return searchedCustomerGroups.find((g) => g.customer === selectedCustomerDetail) || null;
  }, [searchedCustomerGroups, selectedCustomerDetail]);

  // Slip summary calculation for the active selected customer in the detail modal
  const modalSlipSummary = useMemo(() => {
    if (!activeSelectedData) return null;
    return getCustomerSlipSummary(activeSelectedData.customer, activeSelectedData.invoices, customers);
  }, [activeSelectedData, customers]);

  // Handler: Open Fast Bulk Settle Modal
  const handleOpenSettle = (customerName: string, unpaidInvs: Invoice[], totalUnpaid: number) => {
    // Deduplicate input invoices by invoiceNo
    const seenMap = new Map<string, Invoice>();
    unpaidInvs.forEach((inv) => {
      const key = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
      if (key && !seenMap.has(key)) {
        seenMap.set(key, inv);
      }
    });
    const uniqueInvs = Array.from(seenMap.values());
    const realTotal = uniqueInvs.reduce(
      (acc, i) => acc + Number((i as any).calculatedSisa !== undefined ? (i as any).calculatedSisa : (i.sisa !== undefined ? i.sisa : i.total)),
      0
    );

    setSettleTarget({
      customer: customerName,
      invoices: uniqueInvs,
      total: realTotal,
    });
    setBayarNominal(String(realTotal));
    setBayarMetode('Potong Gaji (Payroll)');
    setBayarCatatan(`Pelunasan Gajian Kolektif (${uniqueInvs.length} Nota)`);
  };

  // Handler: Submit Fast Pelunasan
  const handleSubmitSettle = async () => {
    if (!settleTarget) return;
    const nominal = parseFloat(bayarNominal);
    if (isNaN(nominal) || nominal <= 0) {
      alert('Masukkan jumlah pembayaran yang valid.');
      return;
    }

    setIsProcessing(true);
    try {
      const now = new Date();
      const dateStr = fDate(now);
      const timeStr = fTime(now);

      const records: PelunasanRecord[] = [];
      let remainingPayment = nominal;

      for (let idx = 0; idx < settleTarget.invoices.length; idx++) {
        const inv = settleTarget.invoices[idx];
        if (remainingPayment <= 0) break;
        const sisaInv = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : inv.sisa || inv.total;
        const payThis = Math.min(remainingPayment, sisaInv);
        const recId = `PEL-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
        
        records.push({
          id: recId,
          invoiceNo: inv.invoiceNo || (inv as any).noInvoice,
          date: dateStr,
          time: timeStr,
          customer: settleTarget.customer,
          cashier: cashierName,
          kasir: cashierName,
          payMethod: bayarMetode,
          jumlahBayar: payThis,
          sisaAwal: sisaInv,
          newSisa: Math.max(0, sisaInv - payThis),
          catatan: bayarCatatan,
        });

        remainingPayment -= payThis;
      }

      if (records.length > 0) {
        if (onBatchRecordPelunasan) {
          await onBatchRecordPelunasan(records);
        } else if (onRecordPelunasan) {
          for (const rec of records) {
            await onRecordPelunasan(rec);
          }
        }
      }

      onShowToast(`Pelunasan gajian ${settleTarget.customer} (${fRp(nominal)}) berhasil!`, 'success');
      setSettleTarget(null);
    } catch (err: any) {
      onShowToast(`Gagal memproses pelunasan: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handler: Print Slip Tagihan Belum Lunas dengan nomor slip otomatis
  const handlePrintSlip = async (customerName: string, unpaids?: Invoice[], targetSlipNo?: number) => {
    // Ambil seluruh invoice pelanggan ini dari processedInvoices agar mendapatkan histori slip terkunci secara utuh
    const allCustInvoices = processedInvoices.filter((i) => {
      const invCust = (i.customer || (i as any).pelanggan || '').trim();
      return isSameCustomer(customerName, invCust, customers);
    });

    const sourceInvoices = allCustInvoices.length > 0 
      ? allCustInvoices 
      : (unpaids && unpaids.length > 0 ? unpaids : processedInvoices.filter((i) => isSameCustomer(customerName, (i.customer || (i as any).pelanggan || '').trim(), customers)));

    const slipSummary = getCustomerSlipSummary(customerName, sourceInvoices, customers);

    // KASUS 1: Nomor slip spesifik ditentukan (misal klik Cetak Slip #1 atau Slip #2)
    if (targetSlipNo !== undefined) {
      const targetGroup = slipSummary.allSlips.find((g) => g.slipNo === targetSlipNo);
      if (targetGroup && targetGroup.invoices.length > 0) {
        // PERIKSA: Hanya cetak transaksi yang SUDAH DIKUNCI oleh petugas
        const lockedInSlip = targetGroup.invoices.filter((i) => isInvoiceLocked(i));

        if (!targetGroup.isPrinted || lockedInSlip.length === 0) {
          const msg = `Slip #${targetSlipNo} untuk ${customerName} belum dikunci oleh petugas kasir. Hanya slip resmi yang sudah dikunci yang dapat dicetak.`;
          if (onShowToast) {
            onShowToast(msg, 'warning');
          } else {
            alert(msg);
          }
          return;
        }

        const unpaidInThisSlip = lockedInSlip.filter((i) => {
          const s = (i as any).calculatedSisa !== undefined ? (i as any).calculatedSisa : (i.sisa !== undefined ? i.sisa : i.total);
          return Number(s) > 0;
        });
        const invoicesToPrint = unpaidInThisSlip.length > 0 ? unpaidInThisSlip : lockedInSlip;

        const slipMeta = {
          slipNo: targetGroup.slipNo,
          printedAt: targetGroup.printedAt || `${fDate(new Date())} ${fTime(new Date())}`,
          cashier: cashierName,
          catatan: `Slip Resmi Terkunci Petugas (Slip #${targetGroup.slipNo})`,
        };

        const html = generateSlipPotongGajiKaryawanPDF(customerName, invoicesToPrint, settings, slipMeta);
        openPrintWindow(html, `Slip Tagihan #${targetGroup.slipNo} - ${customerName}`);
        onShowToast?.(`Slip Tagihan #${targetGroup.slipNo} untuk ${customerName} berhasil disiapkan untuk dicetak!`, 'success');
        return;
      }
    }

    // KASUS 2: Tombol Cetak dari Modal Rincian (targetSlipNo tidak ditentukan)
    // WAJIB HANYA MENCETAK TRANSAKSI YANG SUDAH DIKUNCI OLEH PETUGAS (Slip #1, Slip #2, dst)
    const lockedInvoices: Invoice[] = [];
    const lockedSlipNos: number[] = [];

    // Kumpulkan seluruh nota dari slip yang sudah terkunci oleh petugas (historySlips)
    slipSummary.historySlips.forEach((s) => {
      s.invoices.forEach((inv) => {
        if (isInvoiceLocked(inv)) {
          const invSisa = (inv as any).calculatedSisa !== undefined 
            ? Number((inv as any).calculatedSisa) 
            : Number(inv.sisa !== undefined ? inv.sisa : inv.total || 0);
          if (invSisa > 0) {
            const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
            if (!lockedInvoices.some((x) => (x.invoiceNo || (x as any).noInvoice || '').trim() === invNo)) {
              lockedInvoices.push(inv);
            }
            if (!lockedSlipNos.includes(s.slipNo)) {
              lockedSlipNos.push(s.slipNo);
            }
          }
        }
      });
    });

    // Jika seluruh slip terkunci sudah lunas, tetap ambil seluruh nota terkunci
    if (lockedInvoices.length === 0 && slipSummary.historySlips.length > 0) {
      slipSummary.historySlips.forEach((s) => {
        s.invoices.forEach((inv) => {
          if (isInvoiceLocked(inv)) {
            const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
            if (!lockedInvoices.some((x) => (x.invoiceNo || (x as any).noInvoice || '').trim() === invNo)) {
              lockedInvoices.push(inv);
            }
            if (!lockedSlipNos.includes(s.slipNo)) {
              lockedSlipNos.push(s.slipNo);
            }
          }
        });
      });
    }

    // Periksa juga semua invoice milik pelanggan yang berstatus terkunci via isInvoiceLocked
    sourceInvoices.forEach((inv) => {
      if (isInvoiceLocked(inv)) {
        const invSisa = (inv as any).calculatedSisa !== undefined 
          ? Number((inv as any).calculatedSisa) 
          : Number(inv.sisa !== undefined ? inv.sisa : inv.total || 0);
        if (invSisa > 0) {
          const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
          if (!lockedInvoices.some((x) => (x.invoiceNo || (x as any).noInvoice || '').trim() === invNo)) {
            lockedInvoices.push(inv);
            const sNo = Number(inv.slipNo) || 1;
            if (!lockedSlipNos.includes(sNo)) {
              lockedSlipNos.push(sNo);
            }
          }
        }
      }
    });

    if (lockedInvoices.length > 0) {
      lockedSlipNos.sort((a, b) => a - b);
      const slipLabel = lockedSlipNos.length === 1 
        ? `#${lockedSlipNos[0]}` 
        : lockedSlipNos.map((n) => `#${n}`).join(', ');

      const slipMeta = {
        slipNo: lockedSlipNos.length === 1 ? lockedSlipNos[0] : `TERKUNCI (${slipLabel})`,
        printedAt: `${fDate(new Date())} ${fTime(new Date())}`,
        cashier: cashierName,
        catatan: `Slip Resmi Terkunci Petugas (${lockedInvoices.length} Nota di Slip ${slipLabel})`,
      };

      const html = generateSlipPotongGajiKaryawanPDF(customerName, lockedInvoices, settings, slipMeta);
      openPrintWindow(html, `Slip Tagihan Terkunci (${slipLabel}) - ${customerName}`);
      onShowToast?.(`Slip tagihan terkunci (${slipLabel}) untuk ${customerName} berhasil disiapkan untuk dicetak!`, 'success');
      return;
    }

    // KASUS 3: Belum ada slip yang dikunci oleh petugas sama sekali
    const activeSlipNo = slipSummary.activeSlip ? slipSummary.activeSlip.slipNo : slipSummary.activeSlipNo;
    const msg = `Belum ada slip transaksi yang dikunci oleh petugas kasir untuk ${customerName}. Transaksi saat ini masih berada di Slip #${activeSlipNo} (menunggu penguncian oleh kasir).`;
    if (onShowToast) {
      onShowToast(msg, 'info');
    } else {
      alert(msg);
    }
    return;
  };

  // Handler: Kunci / Tutup Slip Saat Ini dan Buka Slip Baru Tanpa Cetak
  const handleCloseAndCreateNewSlip = async (customerName: string, custInvoices: Invoice[]) => {
    const slipSummary = getCustomerSlipSummary(customerName, custInvoices);
    const targetGroup = slipSummary.activeSlip || slipSummary.allSlips[0];
    
    if (!targetGroup || targetGroup.invoices.length === 0) {
      onShowToast(`Tidak ada transaksi aktif yang perlu ditutup untuk ${customerName}`, 'info');
      return;
    }

    const currentSlipNo = targetGroup.slipNo;
    const nowStr = `${fDate(new Date())} ${fTime(new Date())}`;
    const updatedInvoices: Invoice[] = targetGroup.invoices.map((inv) => ({
      ...inv,
      slipNo: currentSlipNo,
      slipPrinted: true,
      slipPrintedAt: inv.slipPrintedAt || nowStr,
    }));

    if (onBatchUpdateInvoices) {
      try {
        await onBatchUpdateInvoices(updatedInvoices);
        onShowToast(`Slip #${currentSlipNo} untuk ${customerName} berhasil ditutup! Transaksi baru otomatis masuk ke Slip #${currentSlipNo + 1}.`, 'success');
      } catch (e) {
        console.error('Failed to close slip:', e);
      }
    }
  };

  // Handler: Print Bukti Pelunasan Lunas Sah
  const handlePrintBuktiLunas = (
    customerName: string, 
    invoicesToPrint?: Invoice[],
    meta?: any
  ) => {
    let list = invoicesToPrint && invoicesToPrint.length > 0 ? invoicesToPrint : [];
    if (list.length === 0) {
      list = processedInvoices.filter(
        (i) => (i.customer || '').trim().toLowerCase() === customerName.trim().toLowerCase()
      );
    }
    const html = generateSlipBuktiPelunasanKaryawanPDF(customerName, list, settings, meta);
    openPrintWindow(html, `Bukti Pelunasan - ${customerName}`);
  };

  // Handler: Delete Single Settled Invoice
  const handleConfirmDeleteSingle = async () => {
    if (!invoiceToDelete || !onDeleteInvoice) return;
    setIsDeleting(true);
    try {
      const invNo = (invoiceToDelete.invoiceNo || (invoiceToDelete as any).noInvoice || '').trim();
      let items = invoiceToDelete.items;
      if (!items || items.length === 0) {
        const rawMatch = invoices.find(
          (i) => (i.invoiceNo || (i as any).noInvoice || '').trim().toLowerCase() === invNo.toLowerCase()
        );
        if (rawMatch && Array.isArray(rawMatch.items) && rawMatch.items.length > 0) {
          items = rawMatch.items;
        }
      }
      await onDeleteInvoice(invNo, items);
      setInvoiceToDelete(null);
      if (viewInvoiceItemDetail && (viewInvoiceItemDetail.invoiceNo === invNo || (viewInvoiceItemDetail as any).noInvoice === invNo)) {
        setViewInvoiceItemDetail(null);
      }
    } catch (err: any) {
      onShowToast(`Gagal menghapus: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Handler: Delete All Lunas Invoices for Customer
  const handleConfirmDeleteAllLunas = async () => {
    if (!customerToDeleteLunas || !onDeleteInvoice) return;
    setIsDeleting(true);
    try {
      for (const inv of customerToDeleteLunas.invoices) {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
        if (invNo) {
          let items = inv.items;
          if (!items || items.length === 0) {
            const rawMatch = invoices.find(
              (i) => (i.invoiceNo || (i as any).noInvoice || '').trim().toLowerCase() === invNo.toLowerCase()
            );
            if (rawMatch && Array.isArray(rawMatch.items) && rawMatch.items.length > 0) {
              items = rawMatch.items;
            }
          }
          await onDeleteInvoice(invNo, items);
        }
      }
      setCustomerToDeleteLunas(null);
    } catch (err: any) {
      onShowToast(`Gagal menghapus nota: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="h-full flex flex-col gap-3 overflow-hidden">
      {/* Public Portal Banner when not logged in */}
      {!isLoggedIn && (
        <div className="bg-stone-900 text-white rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md border border-stone-800 shrink-0">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-10 h-10 rounded-xl bg-red-700 text-white flex items-center justify-center font-black shrink-0 shadow-sm">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h1 className="text-base sm:text-lg font-black text-white">{settings.name || settings.storeName || 'WARUNGKU'}</h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/30">
                  Portal Publik
                </span>
              </div>
              <p className="text-xs text-stone-300 mt-0.5">
                {settings.tagline ? `${settings.tagline} · ` : ''}Pencarian Informasi Rekapan Piutang & Bukti Pelunasan Karyawan
              </p>
            </div>
          </div>

          {onLoginClick && (
            <button
              type="button"
              onClick={onLoginClick}
              className="w-full sm:w-auto px-4 py-2 bg-red-700 hover:bg-red-800 active:scale-95 text-white text-xs font-extrabold rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Masuk Kasir / Admin</span>
            </button>
          )}
        </div>
      )}

      {/* Top Search & Filter Bar */}
      <div className="bg-white border border-stone-200/80 rounded-2xl p-3 sm:p-4 shadow-xs shrink-0 flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Main Title */}
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center font-bold shrink-0 shadow-2xs">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-stone-900 leading-tight">
                Pencarian Bon WAKA
              </h2>
              <p className="text-[11px] text-stone-500">
                Cari data rincian piutang, nota potong gaji, dan bukti pelunasan per karyawan
              </p>
            </div>
          </div>

          {/* Action Buttons: Filter and Export Excel */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Quick Filter Buttons or Public Privacy Badge */}
            {isLoggedIn || searchTerm.trim() ? (
              <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setFilterCategory('all')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                    filterCategory === 'all'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>Semua</span>
                  <span className="px-1.5 py-0.2 bg-stone-200 text-stone-700 rounded-full text-[10px]">
                    {overallStats.totalEmployees}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setFilterCategory('unpaid')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                    filterCategory === 'unpaid'
                      ? 'bg-red-700 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>Belum Lunas</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${filterCategory === 'unpaid' ? 'bg-red-800 text-white' : 'bg-red-100 text-red-700'}`}>
                    {overallStats.totalUnpaidCount}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setFilterCategory('lunas')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                    filterCategory === 'lunas'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>Sudah Lunas</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${filterCategory === 'lunas' ? 'bg-emerald-700 text-white' : 'bg-emerald-100 text-emerald-700'}`}>
                    {overallStats.totalSettledCount}
                  </span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-600">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Privasi Terjaga: Hasil tampil saat dicari</span>
              </div>
            )}

            {/* Cetak PDF Button (Locked Unpaid Transactions) */}
            <button
              type="button"
              onClick={handlePrintRekapPDFLocked}
              className="px-3.5 py-2 bg-red-600 hover:bg-red-700 active:scale-95 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-xs cursor-pointer"
              title={`Cetak PDF Seluruh Transaksi Belum Lunas yang Terkunci (${lockedUnpaidStats.count} Nota Terkunci, ${lockedUnpaidStats.custCount} Karyawan)`}
            >
              <Printer className="w-4 h-4" />
              <span>Cetak PDF (Terkunci)</span>
              {lockedUnpaidStats.count > 0 && (
                <span className="px-1.5 py-0.2 bg-red-800 text-white rounded-full text-[10px]">
                  {lockedUnpaidStats.count}
                </span>
              )}
            </button>

            {/* Export Excel Button (WAKA/ERVO Template - Locked Transactions) */}
            <button
              type="button"
              onClick={() => {
                setExportOnlyLocked(true);
                setIsExportModalOpen(true);
              }}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl transition flex items-center gap-2 shadow-xs cursor-pointer"
              title="Export Rekap Belanja Karyawan Terkunci ke Format Excel WAKA/ERVO"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Export Excel (Terkunci)</span>
            </button>
          </div>
        </div>

        {/* Live Search Input Bar */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari berdasarkan nama karyawan, nomor telepon, atau no. invoice..."
            className="w-full pl-10 pr-10 py-2.5 bg-stone-50 border border-stone-200 focus:border-red-600 focus:bg-white rounded-xl text-xs font-semibold text-stone-800 placeholder-stone-400 outline-none transition shadow-2xs"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Grid View of Employee Cards */}
      <div className="flex-1 overflow-y-auto pr-1">
        {!isLoggedIn && !searchTerm.trim() ? (
          <div className="bg-white border border-stone-200/90 rounded-2xl p-6 sm:p-10 text-center flex flex-col items-center justify-center max-w-2xl mx-auto my-4 shadow-xs">
            <div className="w-14 h-14 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mb-4 shadow-xs">
              <Search className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-black text-stone-900 mb-1.5">
              Cari Rekapan Piutang & Bukti Pelunasan
            </h3>
            <p className="text-xs sm:text-sm text-stone-500 max-w-md mb-6 leading-relaxed">
              Demi menjaga privasi data antar karyawan, silakan masukkan <strong>Nama Karyawan</strong>, <strong>Nomor HP</strong>, atau <strong>Nomor Invoice</strong> pada kolom pencarian di atas untuk melihat rincian nota Anda.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full text-left">
              <div className="bg-stone-50 border border-stone-200/80 rounded-xl p-3">
                <div className="w-6 h-6 rounded-lg bg-red-100 text-red-700 flex items-center justify-center font-bold text-xs mb-2">
                  1
                </div>
                <div className="text-xs font-bold text-stone-800">Ketik Nama / No. HP</div>
                <div className="text-[11px] text-stone-500 mt-0.5">Masukkan identitas Anda di kolom pencarian.</div>
              </div>

              <div className="bg-stone-50 border border-stone-200/80 rounded-xl p-3">
                <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs mb-2">
                  2
                </div>
                <div className="text-xs font-bold text-stone-800">Lihat Rincian Nota</div>
                <div className="text-[11px] text-stone-500 mt-0.5">Lihat daftar nota transaksi potong gaji atau riwayat lunas.</div>
              </div>

              <div className="bg-stone-50 border border-stone-200/80 rounded-xl p-3">
                <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs mb-2">
                  3
                </div>
                <div className="text-xs font-bold text-stone-800">Cetak Slip Resmi</div>
                <div className="text-[11px] text-stone-500 mt-0.5">Cetak slip tagihan atau bukti pelunasan sah.</div>
              </div>
            </div>
          </div>
        ) : customerRecapList.length === 0 ? (
          <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400 flex flex-col items-center justify-center">
            <Users className="w-12 h-12 mb-3 text-stone-300" />
            <p className="font-bold text-stone-700 text-sm">Data Karyawan / Pelanggan Tidak Ditemukan</p>
            <p className="text-xs text-stone-400 mt-1 max-w-sm">
              {searchTerm 
                ? `Tidak ada data yang cocok dengan pencarian "${searchTerm}"`
                : 'Belum ada data transaksi piutang atau pelunasan karyawan'}
            </p>
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="mt-3 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Reset Pencarian
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
            {customerRecapList.map((g) => {
              const isFullyLunas = g.totalUnpaid === 0;
              const slipSummary = getCustomerSlipSummary(g.customer, g.invoices);
              const currentSlipNo = slipSummary.activeSlip ? slipSummary.activeSlip.slipNo : slipSummary.activeSlipNo;
              const hasActiveUnprintedInvoices = Boolean(slipSummary.activeSlip && slipSummary.activeSlip.invoices.length > 0);
              const custDivision = getCustomerDivision(g.customer, customers);

              return (
                <div
                  key={g.customer}
                  className={`bg-white border rounded-2xl p-4 shadow-xs flex flex-col justify-between transition hover:shadow-md ${
                    isFullyLunas
                      ? 'border-stone-200/80 hover:border-emerald-300'
                      : 'border-red-200 hover:border-red-300 bg-linear-to-b from-white to-red-50/20'
                  }`}
                >
                  <div>
                    {/* Card Header */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-sm uppercase ${
                            isFullyLunas
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {g.customer.substring(0, 2)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-extrabold text-stone-900 text-sm leading-tight">{g.customer}</h4>
                            {custDivision && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                                <Building2 className="w-3 h-3 text-blue-600" />
                                <span>{custDivision}</span>
                              </span>
                            )}
                            {!isFullyLunas && (
                              <div className="flex items-center gap-1">
                                <span className="bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-md border border-amber-200 flex items-center gap-1">
                                  <Layers className="w-3 h-3 text-amber-700" />
                                  <span>Slip #{currentSlipNo}</span>
                                </span>
                                {isLoggedIn && slipSummary.activeSlip && slipSummary.activeSlip.invoices.length > 0 && (
                                  <button
                                    type="button"
                                    onClick={() => handleCloseAndCreateNewSlip(g.customer, g.invoices)}
                                    className="bg-stone-100 hover:bg-amber-100 text-stone-700 hover:text-amber-900 border border-stone-200 hover:border-amber-300 text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer"
                                    title={`Tutup Slip #${currentSlipNo} sekarang dan mulai transaksi baru di Slip #${currentSlipNo + 1}`}
                                  >
                                    + Slip Baru
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                          <div className="text-[11px] text-stone-400 flex items-center gap-1.5 mt-0.5">
                            <span>{g.phone || 'Karyawan'}</span>
                            <span>•</span>
                            <span>{g.invoices.length} total nota</span>
                          </div>
                        </div>
                      </div>

                      {isFullyLunas ? (
                        <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                          LUNAS (100%)
                        </span>
                      ) : (
                        <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 animate-pulse">
                          BELUM LUNAS
                        </span>
                      )}
                    </div>

                    {/* Financial Figures Box */}
                    <div className="grid grid-cols-2 gap-2 my-2.5 p-2.5 bg-stone-50 border border-stone-100 rounded-xl text-xs">
                      <div>
                        <div className="text-[10px] font-bold text-stone-500 uppercase">
                          {isFullyLunas ? 'Total Dilunasi' : 'Sisa Tagihan'}
                        </div>
                        <div
                          className={`font-black text-sm mt-0.5 ${
                            isFullyLunas ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {fRp(isFullyLunas ? g.totalSettled : g.totalUnpaid)}
                        </div>
                      </div>

                      <div className="border-l border-stone-200 pl-2.5">
                        <div className="text-[10px] font-bold text-stone-500 uppercase">Total Belanja</div>
                        <div className="font-bold text-stone-700 text-xs mt-0.5">
                          {fRp(g.totalBelanja)}
                        </div>
                      </div>
                    </div>

                    {/* Previous Printed Slips if any */}
                    {!isFullyLunas && slipSummary.historySlips.length > 0 && (
                      <div className="mb-3 p-2.5 bg-stone-50 border border-stone-200/90 rounded-xl space-y-2">
                        <div className="text-[10px] font-bold text-stone-600 uppercase tracking-wider flex items-center justify-between">
                          <span className="flex items-center gap-1">
                            <Layers className="w-3 h-3 text-amber-700" />
                            <span>Daftar Slip Tertagih ({slipSummary.historySlips.length}):</span>
                          </span>
                          <span className="text-[9px] text-stone-400 font-medium">Klik slip untuk lihat rincian nota</span>
                        </div>
                        <div className="space-y-1.5">
                          {slipSummary.historySlips.map((hSlip) => {
                            const isSlipExpanded = Boolean(expandedSlips[`${g.customer}_slip_${hSlip.slipNo}`]);
                            return (
                              <div
                                key={hSlip.slipNo}
                                className="bg-white rounded-lg border border-stone-200 shadow-2xs overflow-hidden transition"
                              >
                                {/* Slip Header Bar */}
                                <div
                                  onClick={() => toggleSlipExpanded(g.customer, hSlip.slipNo)}
                                  className="flex items-center justify-between p-2 hover:bg-amber-50/60 transition cursor-pointer select-none"
                                  title="Klik untuk melihat / menutup rincian nota belanja di slip ini"
                                >
                                  <div className="flex items-center gap-2">
                                    <ChevronDown className={`w-3.5 h-3.5 text-stone-400 transition-transform duration-200 ${isSlipExpanded ? 'rotate-180 text-amber-700' : ''}`} />
                                    <span className="font-extrabold text-stone-800 bg-amber-50 text-amber-900 border border-amber-200 px-1.5 py-0.5 rounded text-[10px]">
                                      Slip #{hSlip.slipNo}
                                    </span>
                                    <span className="text-[10px] text-stone-500 font-medium">
                                      {hSlip.invoices.length} nota
                                    </span>
                                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                                      hSlip.isLunas
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : 'bg-red-100 text-red-800'
                                    }`}>
                                      {hSlip.isLunas ? 'LUNAS' : 'BELUM LUNAS'}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-bold text-red-600 font-mono text-[11px]">
                                      {fRp(hSlip.totalUnpaid)}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handlePrintSlip(g.customer, g.invoices, hSlip.slipNo);
                                      }}
                                      className="px-2 py-0.5 text-[10px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-md transition cursor-pointer flex items-center gap-1 shadow-2xs"
                                      title={`Cetak Slip Tagihan #${hSlip.slipNo} Terkunci`}
                                    >
                                      <Printer className="w-3 h-3 text-amber-700" />
                                      <span>Cetak #{hSlip.slipNo}</span>
                                    </button>
                                    {!hSlip.isLunas && isLoggedIn && (
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleOpenSettle(g.customer, hSlip.invoices, hSlip.totalUnpaid);
                                        }}
                                        className="px-2 py-0.5 text-[10px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition cursor-pointer flex items-center gap-0.5"
                                        title={`Lunasi Slip #${hSlip.slipNo} (${fRp(hSlip.totalUnpaid)})`}
                                      >
                                        <CheckCheck className="w-3 h-3" />
                                        <span>Lunasi</span>
                                      </button>
                                    )}
                                  </div>
                                </div>

                                {/* Expanded Invoices within this Slip */}
                                {isSlipExpanded && (
                                  <div className="p-2 pt-1 bg-stone-50/70 border-t border-stone-100 space-y-1.5 animate-fadeIn">
                                    <div className="text-[9px] font-bold text-stone-500 uppercase tracking-wider flex items-center justify-between pb-0.5">
                                      <span>Rincian Nota di Slip #{hSlip.slipNo}:</span>
                                      <span className="text-amber-700 font-semibold">Klik nota untuk rincian menu</span>
                                    </div>
                                    {hSlip.invoices.map((inv) => {
                                      const isPotongGajiInv = (inv as any).isPotongGaji || (inv.payMethod || '').includes('Gaji') || (inv.metodePembayaran || '').includes('Gaji');
                                      const invSisa = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total);
                                      return (
                                        <div
                                          key={inv.invoiceNo}
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setViewInvoiceItemDetail(inv);
                                          }}
                                          className="flex items-center justify-between p-2 bg-white border border-stone-200/90 rounded-lg hover:border-amber-400 hover:bg-amber-50/30 transition cursor-pointer text-xs group"
                                          title="Klik untuk membuka rincian lengkap barang/menu belanja"
                                        >
                                          <div className="flex items-center gap-2 min-w-0">
                                            <FileText className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-600 shrink-0" />
                                            <div className="min-w-0">
                                              <div className="flex items-center gap-1.5 flex-wrap">
                                                <span className="font-bold text-stone-800 group-hover:text-amber-900">{inv.invoiceNo}</span>
                                                <span className="text-[10px] text-stone-400">{inv.date} {inv.time ? `• ${inv.time}` : ''}</span>
                                                {isPotongGajiInv && (
                                                  <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">
                                                    Potong Gaji
                                                  </span>
                                                )}
                                                <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                                                  invSisa <= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                                                }`}>
                                                  {invSisa <= 0 ? 'LUNAS' : 'BELUM LUNAS'}
                                                </span>
                                              </div>
                                              {inv.items && inv.items.length > 0 && (
                                                <div className="text-[10px] text-stone-500 truncate max-w-xs mt-0.5">
                                                  {inv.items.map((it: any) => `${it.qty || it.jumlah || 1}x ${it.nama || it.name || it.namaBarang || it.menuName || 'Item'}`).join(', ')}
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                          <div className="text-right shrink-0 ml-2">
                                            <div className="font-bold text-red-600 font-mono text-[11px]">
                                              {fRp(invSisa)}
                                            </div>
                                            <div className="text-[9px] text-amber-700 font-medium group-hover:underline flex items-center justify-end gap-0.5">
                                              <Eye className="w-2.5 h-2.5" />
                                              <span>Lihat Nota</span>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Quick Mini Invoice List */}
                    <div className="space-y-1.5 mb-3">
                      <div className="flex items-center justify-between text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                        <span>{isFullyLunas ? 'Nota Selesai' : 'Nota Belum Lunas'}</span>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedCustomerDetail(g.customer);
                            setDetailTab(isFullyLunas ? 'history' : 'unpaid');
                          }}
                          className="text-red-700 hover:text-red-800 font-extrabold flex items-center gap-0.5 cursor-pointer"
                        >
                          <span>Rincian</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>

                      {(isFullyLunas ? g.settledInvoices : g.unpaidInvoices).slice(0, 2).map((inv) => (
                        <div
                          key={inv.invoiceNo}
                          className="flex items-center justify-between text-xs p-2 bg-stone-50/70 border border-stone-100 rounded-lg hover:bg-stone-50 transition cursor-pointer"
                          onClick={() => setViewInvoiceItemDetail(inv)}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                            <span className="font-bold text-stone-800 truncate">{inv.invoiceNo}</span>
                            <span className="text-[10px] text-stone-400 shrink-0">{inv.date}</span>
                            {inv.slipNo && (
                              <span className="text-[9px] bg-stone-100 text-stone-600 font-semibold px-1 rounded">
                                Slip #{inv.slipNo}
                              </span>
                            )}
                          </div>
                          <span className={`font-bold font-mono shrink-0 ${isFullyLunas ? 'text-emerald-700' : 'text-red-600'}`}>
                            {fRp(isFullyLunas ? inv.total : (inv as any).calculatedSisa)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Card Action Controls */}
                  {((!isFullyLunas && isLoggedIn) || isFullyLunas) && (
                    <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                      {!isFullyLunas ? (
                        <button
                          type="button"
                          onClick={() => handleOpenSettle(g.customer, g.unpaidInvoices, g.totalUnpaid)}
                          className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold transition shadow-xs cursor-pointer active:scale-95"
                          title="Lunasi Seluruh Nota Gajian"
                        >
                          <CheckCheck className="w-3.5 h-3.5" />
                          <span>Lunasi Gajian</span>
                        </button>
                      ) : (
                        isLoggedIn ? (
                        <>
                          <button
                            type="button"
                            onClick={() => handlePrintBuktiLunas(g.customer, g.settledInvoices, {
                              date: g.lastSettledDate || fDate(new Date()),
                              time: g.lastSettledTime || fTime(new Date()),
                              cashier: cashierName,
                              payMethod: 'Potong Gaji (Gajian)',
                              catatan: 'Pelunasan Lunas 100%',
                              jumlahBayar: g.totalSettled,
                              totalTagihan: g.totalSettled,
                            })}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-black transition shadow-2xs cursor-pointer active:scale-95"
                            title="Cetak Slip Bukti Pelunasan Sah (Lunas)"
                          >
                            <Printer className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Bukti Pelunasan</span>
                          </button>

                          {onDeleteInvoice && (
                            <button
                              type="button"
                              onClick={() => setCustomerToDeleteLunas({
                                customer: g.customer,
                                invoices: g.settledInvoices,
                              })}
                              className="p-2 bg-stone-100 hover:bg-red-50 text-stone-500 hover:text-red-600 border border-stone-200 hover:border-red-200 rounded-xl transition cursor-pointer"
                              title="Hapus Seluruh Nota Lunas Karyawan Ini"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handlePrintBuktiLunas(g.customer, g.settledInvoices, {
                            date: g.lastSettledDate || fDate(new Date()),
                            time: g.lastSettledTime || fTime(new Date()),
                            cashier: cashierName,
                            payMethod: 'Potong Gaji (Gajian)',
                            catatan: 'Pelunasan Lunas 100%',
                            jumlahBayar: g.totalSettled,
                            totalTagihan: g.totalSettled,
                          })}
                          className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-black transition shadow-2xs cursor-pointer active:scale-95"
                          title="Cetak Slip Bukti Pelunasan Sah (Lunas)"
                        >
                          <Printer className="w-4 h-4 text-emerald-700" />
                          <span>Cetak Bukti Pelunasan Sah (Lunas)</span>
                        </button>
                      )
                    )}
                  </div>
                )}
              </div>
            );
            })}
          </div>
        )}
      </div>

      {/* DETAIL MODAL / DRAWER FOR SELECTED CUSTOMER */}
      {activeSelectedData && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150 border border-stone-200">
            {/* Header */}
            <div className="p-4 bg-stone-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-700 text-white flex items-center justify-center font-black text-sm uppercase">
                  {activeSelectedData.customer.substring(0, 2)}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-extrabold text-base text-white">{activeSelectedData.customer}</h3>
                    {getCustomerDivision(activeSelectedData.customer, customers) && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-950/80 text-blue-200 border border-blue-500/40">
                        <Building2 className="w-3 h-3 text-blue-400" />
                        <span>{getCustomerDivision(activeSelectedData.customer, customers)}</span>
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-stone-300 flex items-center gap-2 mt-0.5">
                    <span>{activeSelectedData.phone || 'Karyawan'}</span>
                    <span>•</span>
                    <span>{activeSelectedData.invoices.length} Total Nota</span>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCustomerDetail(null)}
                className="p-2 text-stone-400 hover:text-white rounded-xl hover:bg-white/10 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Financial Status Summary Ribbon */}
            <div className="p-3 bg-stone-50 border-b border-stone-200 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-white p-2 rounded-xl border border-stone-200 shadow-2xs">
                <div className="text-[10px] text-stone-400 font-bold uppercase">Total Belanja</div>
                <div className="font-black text-stone-800 text-sm mt-0.5">{fRp(activeSelectedData.totalBelanja)}</div>
              </div>
              <div className="bg-white p-2 rounded-xl border border-red-200 shadow-2xs">
                <div className="text-[10px] text-red-500 font-bold uppercase">Sisa Piutang Aktif</div>
                <div className="font-black text-red-600 text-sm mt-0.5">{fRp(activeSelectedData.totalUnpaid)}</div>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-200 shadow-2xs">
                <div className="text-[10px] text-emerald-600 font-bold uppercase">Total Telah Lunas</div>
                <div className="font-black text-emerald-700 text-sm mt-0.5">{fRp(activeSelectedData.totalSettled)}</div>
              </div>
            </div>

            {/* Detail Tabs */}
            <div className="flex border-b border-stone-200 bg-stone-100/70 p-1.5 gap-1.5 text-xs font-bold">
              <button
                type="button"
                onClick={() => setDetailTab('unpaid')}
                className={`flex-1 py-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 ${
                  detailTab === 'unpaid'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>Nota Belum Lunas ({activeSelectedData.unpaidInvoices.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setDetailTab('history')}
                className={`flex-1 py-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 ${
                  detailTab === 'history'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Riwayat & Nota Lunas ({activeSelectedData.settledInvoices.length})</span>
              </button>
            </div>

            {/* Content List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {detailTab === 'unpaid' ? (
                activeSelectedData.unpaidInvoices.length === 0 ? (
                  <div className="p-8 text-center text-stone-400">
                    <CheckCheck className="w-10 h-10 mx-auto mb-2 text-emerald-500" />
                    <p className="font-bold text-stone-700">Semua Tagihan Sudah Lunas</p>
                    <p className="text-xs text-stone-400 mt-1">Tidak ada nota aktif yang tertunda untuk karyawan ini.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* DAFTAR SLIP TERKUNCI PETUGAS (JIKA ADA) */}
                    {modalSlipSummary && modalSlipSummary.historySlips.length > 0 && (
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between pb-1 border-b border-amber-200">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black text-amber-950 uppercase tracking-wide flex items-center gap-1.5">
                              <Layers className="w-4 h-4 text-amber-700" />
                              <span>Slip Terkunci Petugas ({modalSlipSummary.historySlips.length} Slip)</span>
                            </span>
                            <span className="text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-full">
                              Sah Diterbitkan
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handlePrintSlip(activeSelectedData.customer, activeSelectedData.invoices)}
                            className="px-2.5 py-1 text-[11px] font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg transition cursor-pointer flex items-center gap-1 shadow-2xs"
                            title="Cetak PDF Seluruh Slip yang Sudah Dikunci Petugas"
                          >
                            <Printer className="w-3 h-3" />
                            <span>Cetak Semua Slip Terkunci</span>
                          </button>
                        </div>

                        {modalSlipSummary.historySlips.map((hSlip) => (
                          <div
                            key={hSlip.slipNo}
                            className="bg-amber-50/40 border border-amber-200/90 rounded-xl overflow-hidden space-y-2 p-3"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="font-extrabold text-amber-950 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md text-xs">
                                  Slip #{hSlip.slipNo}
                                </span>
                                <span className="text-[11px] text-stone-500 font-medium">
                                  {hSlip.invoices.length} nota
                                </span>
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  hSlip.isLunas
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                    : 'bg-red-100 text-red-800 border border-red-300'
                                }`}>
                                  {hSlip.isLunas ? 'LUNAS' : 'BELUM LUNAS'}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-black text-red-600 font-mono text-xs">
                                  {fRp(hSlip.totalUnpaid)}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handlePrintSlip(activeSelectedData.customer, activeSelectedData.invoices, hSlip.slipNo)}
                                  className="px-2.5 py-1 text-xs font-bold bg-white hover:bg-amber-100 text-amber-950 border border-amber-300 rounded-lg transition cursor-pointer flex items-center gap-1 shadow-2xs"
                                  title={`Cetak Slip Tagihan #${hSlip.slipNo} Terkunci`}
                                >
                                  <Printer className="w-3 h-3 text-amber-700" />
                                  <span>Cetak #{hSlip.slipNo}</span>
                                </button>
                              </div>
                            </div>

                            {/* Invoices inside this locked slip */}
                            <div className="space-y-1.5 pt-1">
                              {hSlip.invoices.map((inv) => (
                                <div
                                  key={inv.invoiceNo}
                                  className="bg-white border border-stone-200/80 rounded-lg p-2.5 space-y-1 text-xs"
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <span className="font-bold text-stone-900">{inv.invoiceNo}</span>
                                      <span className="text-[10px] text-stone-400">{inv.date}</span>
                                    </div>
                                    <span className="font-black text-red-600 font-mono text-xs">
                                      Sisa: {fRp((inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total))}
                                    </span>
                                  </div>
                                  <div className="text-[11px] text-stone-600">
                                    {(inv.items || []).map((item, idx) => (
                                      <div key={idx} className="flex items-center justify-between text-stone-700">
                                        <span>{item.nama} ({item.qty} {item.satuan || 'pcs'})</span>
                                        <span className="font-semibold">{fRp(item.qty * item.harga)}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* TRANSAKSI AKTIF YANG BELUM DIKUNCI PETUGAS (JIKA ADA) */}
                    {modalSlipSummary && modalSlipSummary.activeSlip && modalSlipSummary.activeSlip.invoices.length > 0 && (
                      <div className="space-y-2.5 pt-2 border-t border-dashed border-stone-200">
                        <div className="flex items-center justify-between pb-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-stone-700 uppercase tracking-wide flex items-center gap-1.5">
                              <Clock className="w-4 h-4 text-stone-500" />
                              <span>Transaksi Belum Dikunci (Slip #{modalSlipSummary.activeSlip.slipNo})</span>
                            </span>
                            <span className="text-[10px] font-bold bg-stone-100 text-stone-600 border border-stone-200 px-2 py-0.5 rounded-full">
                              Menunggu Petugas
                            </span>
                          </div>
                          {isLoggedIn && (
                            <button
                              type="button"
                              onClick={() => handleCloseAndCreateNewSlip(activeSelectedData.customer, activeSelectedData.invoices)}
                              className="px-2.5 py-1 text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg transition cursor-pointer flex items-center gap-1"
                              title={`Tutup dan kunci Slip #${modalSlipSummary.activeSlip.slipNo}`}
                            >
                              <Layers className="w-3 h-3 text-amber-700" />
                              <span>+ Kunci Slip #{modalSlipSummary.activeSlip.slipNo}</span>
                            </button>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-500 italic bg-stone-50 p-2 rounded-lg border border-stone-200/80">
                          ℹ️ Transaksi di bawah ini belum dikunci oleh petugas kasir dan belum masuk ke tagihan slip resmi pemotongan gaji.
                        </p>

                        <div className="space-y-1.5">
                          {modalSlipSummary.activeSlip.invoices.map((inv) => (
                            <div
                              key={inv.invoiceNo}
                              className="bg-stone-50/80 border border-stone-200 rounded-lg p-2.5 space-y-1 text-xs"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-stone-800">{inv.invoiceNo}</span>
                                  <span className="text-[10px] text-stone-400">{inv.date}</span>
                                </div>
                                <span className="font-black text-red-600 font-mono text-xs">
                                  Sisa: {fRp((inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total))}
                                </span>
                              </div>
                              <div className="text-[11px] text-stone-600">
                                {(inv.items || []).map((item, idx) => (
                                  <div key={idx} className="flex items-center justify-between text-stone-700">
                                    <span>{item.nama} ({item.qty} {item.satuan || 'pcs'})</span>
                                    <span className="font-semibold">{fRp(item.qty * item.harga)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* JIKA TIDAK ADA PENGELOMPOKAN SLIP (FALLBACK) */}
                    {(!modalSlipSummary || (modalSlipSummary.historySlips.length === 0 && (!modalSlipSummary.activeSlip || modalSlipSummary.activeSlip.invoices.length === 0))) && (
                      activeSelectedData.unpaidInvoices.map((inv) => (
                        <div key={inv.invoiceNo} className="bg-stone-50 border border-stone-200 rounded-xl p-3 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-red-700 text-xs">{inv.invoiceNo}</span>
                              <span className="text-[11px] text-stone-400">{inv.date}</span>
                            </div>
                            <span className="font-black text-red-600 text-xs font-mono">
                              Sisa: {fRp((inv as any).calculatedSisa)}
                            </span>
                          </div>
                          <div className="bg-white border border-stone-200/80 rounded-lg p-2 space-y-1 text-[11px]">
                            {(inv.items || []).map((item, idx) => (
                              <div key={idx} className="flex items-center justify-between text-stone-700">
                                <span>{item.nama} ({item.qty} {item.satuan})</span>
                                <span className="font-semibold">{fRp(item.qty * item.harga)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )
              ) : (
                /* History / Settled Tab */
                <div className="space-y-3">
                  <div className="text-xs font-bold text-stone-700 uppercase tracking-wider">Log Riwayat Pembayaran</div>
                  {activeSelectedData.historyRecords.length === 0 ? (
                    <p className="text-xs text-stone-400 text-center py-4">Belum ada log pembayaran tercatat.</p>
                  ) : (
                    activeSelectedData.historyRecords.map((h, idx) => (
                      <div key={idx} className="p-2.5 bg-emerald-50/50 border border-emerald-100 rounded-xl flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-stone-900">{h.invoiceNo} - {h.payMethod}</div>
                          <div className="text-[11px] text-stone-500">{h.date} {h.time} • Kasir: {h.cashier || h.kasir || '-'}</div>
                          {h.catatan && <div className="text-[10px] text-stone-400 italic mt-0.5">{h.catatan}</div>}
                        </div>
                        <div className="text-right">
                          <div className="font-black text-emerald-700 font-mono text-sm">{fRp(h.jumlahBayar)}</div>
                          <div className="text-[10px] text-stone-400">Sisa Akhir: {fRp(h.newSisa || 0)}</div>
                        </div>
                      </div>
                    ))
                  )}

                  <div className="text-xs font-bold text-stone-700 uppercase tracking-wider pt-2">Daftar Nota Lunas</div>
                  {activeSelectedData.settledInvoices.map((inv) => (
                    <div key={inv.invoiceNo} className="bg-stone-50 border border-stone-200 rounded-xl p-3 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-stone-900">{inv.invoiceNo}</div>
                        <div className="text-[11px] text-stone-400">{inv.date} • Total: {fRp(inv.total)}</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {isLoggedIn && onDeleteInvoice && (
                          <button
                            type="button"
                            onClick={() => setInvoiceToDelete(inv)}
                            className="p-1.5 hover:bg-red-50 text-stone-400 hover:text-red-600 rounded-lg transition cursor-pointer"
                            title="Hapus Nota Lunas Ini"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Modal Bottom Actions */}
            <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setSelectedCustomerDetail(null)}
                className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl text-xs font-bold cursor-pointer"
              >
                Tutup
              </button>

              <div className="flex items-center gap-2">
                {modalSlipSummary && modalSlipSummary.historySlips.filter((s) => s.totalUnpaid > 0).length > 0 ? (
                  <>
                    <button
                      type="button"
                      onClick={() => handlePrintSlip(activeSelectedData.customer, activeSelectedData.invoices)}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                      title="Cetak PDF Seluruh Slip yang Telah Dikunci Petugas (Slip #1, Slip #2, dst)"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak PDF Slip Terkunci ({fRp(modalSlipSummary.historySlips.filter((s) => s.totalUnpaid > 0).reduce((acc, s) => acc + s.totalUnpaid, 0))})</span>
                    </button>
                    {isLoggedIn && (
                      <button
                        type="button"
                        onClick={() => {
                          const lockedInvs: Invoice[] = [];
                          modalSlipSummary.historySlips.forEach((s) => {
                            s.invoices.forEach((inv) => {
                              const sisa = (inv as any).calculatedSisa !== undefined ? (inv as any).calculatedSisa : (inv.sisa !== undefined ? inv.sisa : inv.total || 0);
                              if (sisa > 0) lockedInvs.push(inv);
                            });
                          });
                          const totalSisa = lockedInvs.reduce((acc, i) => acc + ((i as any).calculatedSisa !== undefined ? (i as any).calculatedSisa : (i.sisa !== undefined ? i.sisa : i.total || 0)), 0);
                          handleOpenSettle(activeSelectedData.customer, lockedInvs, totalSisa);
                        }}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer"
                      >
                        <CheckCheck className="w-3.5 h-3.5" />
                        <span>Lunasi Slip Terkunci</span>
                      </button>
                    )}
                  </>
                ) : activeSelectedData.totalUnpaid > 0 ? (
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-amber-700 font-semibold italic">
                      Belum ada slip transaksi yang dikunci petugas kasir.
                    </span>
                    {isLoggedIn && (
                      <button
                        type="button"
                        onClick={() => handleCloseAndCreateNewSlip(activeSelectedData.customer, activeSelectedData.invoices)}
                        className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Layers className="w-3.5 h-3.5" />
                        <span>Kunci & Buka Slip Baru</span>
                      </button>
                    )}
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => handlePrintBuktiLunas(activeSelectedData.customer, activeSelectedData.settledInvoices, {
                      date: activeSelectedData.lastSettledDate || fDate(new Date()),
                      time: activeSelectedData.lastSettledTime || fTime(new Date()),
                      cashier: cashierName,
                      payMethod: 'Potong Gaji (Gajian)',
                      catatan: 'Pelunasan Lunas 100%',
                      jumlahBayar: activeSelectedData.totalSettled,
                      totalTagihan: activeSelectedData.totalSettled,
                    })}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Cetak Bukti Lunas</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FAST SETTLEMENT MODAL */}
      {settleTarget && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150 border border-stone-200">
            <div className="p-4 bg-emerald-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCheck className="w-5 h-5" />
                <h3 className="font-bold text-sm">Lunasi Gajian - {settleTarget.customer}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSettleTarget(null)}
                disabled={isProcessing}
                className="text-emerald-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-3">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-emerald-800 font-semibold block">Total Tagihan ({settleTarget.invoices.length} Nota):</span>
                  <span className="text-base font-black text-emerald-800">{fRp(settleTarget.total)}</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-200 text-emerald-900">
                  Potong Gaji
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Jumlah Pembayaran (Rp)</label>
                <input
                  type="number"
                  value={bayarNominal}
                  onChange={(e) => setBayarNominal(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl text-base font-black text-stone-900 outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Metode Pelunasan</label>
                <select
                  value={bayarMetode}
                  onChange={(e) => setBayarMetode(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-800"
                >
                  <option value="Potong Gaji (Payroll)">Potong Gaji (Payroll)</option>
                  <option value="Tunai (Cash)">Tunai (Cash)</option>
                  <option value="Transfer Bank">Transfer Bank</option>
                  <option value="QRIS">QRIS</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Catatan</label>
                <input
                  type="text"
                  value={bayarCatatan}
                  onChange={(e) => setBayarCatatan(e.target.value)}
                  placeholder="Catatan pelunasan gajian..."
                  className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                />
              </div>
            </div>

            <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSettleTarget(null)}
                disabled={isProcessing}
                className="px-4 py-2 border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-100 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSubmitSettle}
                disabled={isProcessing}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isProcessing ? <span>Memproses...</span> : <span>Konfirmasi Lunasi</span>}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODALS */}
      {invoiceToDelete && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 text-center shadow-2xl border border-stone-200">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-stone-900 mb-1">Hapus Nota Piutang</h3>
            <p className="text-xs text-stone-500 mb-4 leading-relaxed">
              Hapus nota <strong className="text-stone-800">{invoiceToDelete.invoiceNo || (invoiceToDelete as any).noInvoice}</strong> atas nama <strong className="text-stone-800">{invoiceToDelete.customer}</strong>?
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                disabled={isDeleting}
                className="flex-1 py-2.5 px-3 border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-100 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteSingle}
                disabled={isDeleting}
                className="flex-1 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isDeleting ? 'Menghapus...' : 'Ya, Hapus'}
              </button>
            </div>
          </div>
        </div>
      )}

      {customerToDeleteLunas && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 text-center shadow-2xl border border-stone-200">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-stone-900 mb-1">Hapus Semua Nota Lunas</h3>
            <p className="text-xs text-stone-500 mb-4 leading-relaxed">
              Hapus <strong className="text-stone-800">{customerToDeleteLunas.invoices.length} nota LUNAS</strong> milik <strong className="text-stone-800">{customerToDeleteLunas.customer}</strong>?
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCustomerToDeleteLunas(null)}
                disabled={isDeleting}
                className="flex-1 py-2.5 px-3 border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-100 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAllLunas}
                disabled={isDeleting}
                className="flex-1 py-2.5 px-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isDeleting ? 'Menghapus...' : 'Ya, Hapus Semua'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DETAIL NOTA PREVIEW */}
      {viewInvoiceItemDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl max-h-[90vh] flex flex-col border border-stone-200">
            <div className="bg-stone-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Rincian Nota: {viewInvoiceItemDetail.invoiceNo}</h3>
                  <span className="text-[11px] text-stone-300">
                    {viewInvoiceItemDetail.date} {viewInvoiceItemDetail.time ? `• ${viewInvoiceItemDetail.time}` : ''} • {viewInvoiceItemDetail.customer}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewInvoiceItemDetail(null)}
                className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3 flex-1">
              <div className="border border-stone-200 rounded-xl overflow-hidden shadow-2xs">
                <table className="w-full text-xs text-left">
                  <thead className="bg-stone-100 font-bold text-stone-700">
                    <tr>
                      <th className="py-2.5 px-3">Item Barang / Menu</th>
                      <th className="py-2.5 px-2 text-center">Qty</th>
                      <th className="py-2.5 px-2 text-right">Harga</th>
                      <th className="py-2.5 px-3 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {(viewInvoiceItemDetail.items || []).map((item: any, idx: number) => {
                      const itemName = item.nama || item.name || item.namaBarang || item.menuName || 'Item';
                      const itemQty = item.qty || item.jumlah || 1;
                      const itemSatuan = item.satuan || 'pcs';
                      const itemHarga = Number(item.harga || item.price || 0);
                      const itemTotal = Number(item.total || (itemQty * itemHarga));
                      return (
                        <tr key={idx} className="hover:bg-stone-50/60">
                          <td className="py-2.5 px-3 font-semibold text-stone-800">{itemName}</td>
                          <td className="py-2.5 px-2 text-center text-stone-600">{itemQty} {itemSatuan}</td>
                          <td className="py-2.5 px-2 text-right font-mono text-stone-600">{fRp(itemHarga)}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-stone-900 font-mono">{fRp(itemTotal)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="bg-stone-50 rounded-xl p-3 space-y-1.5 text-xs border border-stone-200/60">
                <div className="flex justify-between text-stone-600">
                  <span>Pelanggan / Karyawan:</span>
                  <span className="font-bold text-stone-900">{viewInvoiceItemDetail.customer}</span>
                </div>
                {viewInvoiceItemDetail.slipNo && (
                  <div className="flex justify-between text-stone-600">
                    <span>Slip Tagihan:</span>
                    <span className="font-bold bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded text-[10px]">
                      Slip #{viewInvoiceItemDetail.slipNo}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-stone-600">
                  <span>Metode Pembayaran:</span>
                  <span className="font-bold text-amber-800 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                    {viewInvoiceItemDetail.payMethod || viewInvoiceItemDetail.metodePembayaran || 'Potong Gaji'}
                  </span>
                </div>
                <div className="flex justify-between text-stone-600 pt-1 border-t border-stone-200/60">
                  <span>Total Belanja:</span>
                  <span className="font-bold font-mono text-stone-900 text-sm">{fRp(viewInvoiceItemDetail.total)}</span>
                </div>
                <div className="flex justify-between font-bold text-red-600">
                  <span>Sisa Piutang:</span>
                  <span className="text-sm font-mono">
                    {fRp((viewInvoiceItemDetail as any).calculatedSisa !== undefined ? (viewInvoiceItemDetail as any).calculatedSisa : (viewInvoiceItemDetail.sisa !== undefined ? viewInvoiceItemDetail.sisa : viewInvoiceItemDetail.total))}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-2">
              <div>
                {isLoggedIn && onDeleteInvoice && (
                  <button
                    type="button"
                    onClick={() => {
                      const target = viewInvoiceItemDetail;
                      setViewInvoiceItemDetail(null);
                      setInvoiceToDelete(target);
                    }}
                    className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Nota</span>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setViewInvoiceItemDetail(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Tutup
                </button>
                {onReprintInvoice && (
                  <button
                    type="button"
                    onClick={() => {
                      const target = viewInvoiceItemDetail;
                      setViewInvoiceItemDetail(null);
                      onReprintInvoice(target);
                    }}
                    className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Cetak Struk Nota</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {/* MODAL EXPORT EXCEL WAKA/ERVO TEMPLATE */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150 border border-stone-200">
            {/* Modal Header */}
            <div className="p-4 bg-stone-900 border-b border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">Export Excel Belanja Karyawan</h3>
                  <p className="text-[11px] text-emerald-400">
                    Template disesuaikan persis dengan format import Excel sistem WAKA / ERVO
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 overflow-y-auto space-y-4 flex-1">
              {/* Export Configuration Controls */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                {/* Rentang Tanggal Rekap */}
                <div className="sm:col-span-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-bold text-stone-700">
                      Rentang Tanggal Rekap
                    </label>
                    <div className="flex items-center gap-1">
                      {(() => {
                        const d = new Date();
                        const todayStr = d.toISOString().split('T')[0];
                        const d6 = new Date();
                        d6.setDate(d6.getDate() - 6);
                        const past6Str = d6.toISOString().split('T')[0];
                        const d7 = new Date();
                        d7.setDate(d7.getDate() - 7);
                        const past7Str = d7.toISOString().split('T')[0];
                        const yyyy = d.getFullYear();
                        const mm = String(d.getMonth() + 1).padStart(2, '0');
                        const monthStartStr = `${yyyy}-${mm}-01`;

                        const isToday = exportStartDate === todayStr && exportEndDate === todayStr;
                        const is7Days = (exportStartDate === past6Str || exportStartDate === past7Str) && exportEndDate === todayStr;
                        const isMonth = exportStartDate === monthStartStr && exportEndDate === todayStr;
                        const isAll = !exportStartDate && !exportEndDate;

                        return (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate(todayStr);
                                setExportEndDate(todayStr);
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                isToday
                                  ? 'bg-emerald-600 text-white shadow-xs ring-1 ring-emerald-700/30'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              Hari Ini
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate(past6Str);
                                setExportEndDate(todayStr);
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                is7Days
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              7 Hari
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate(monthStartStr);
                                setExportEndDate(todayStr);
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                isMonth
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              Bulan Ini
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setExportStartDate('');
                                setExportEndDate('');
                              }}
                              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                                isAll
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                              }`}
                            >
                              Semua Piutang
                            </button>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <input
                        type="date"
                        value={exportStartDate}
                        onChange={(e) => setExportStartDate(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        title="Tanggal Mulai"
                      />
                    </div>
                    <span className="text-xs font-bold text-stone-400">s/d</span>
                    <div className="flex-1">
                      <input
                        type="date"
                        value={exportEndDate}
                        onChange={(e) => setExportEndDate(e.target.value)}
                        className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        title="Tanggal Selesai"
                      />
                    </div>
                  </div>
                </div>

                {/* Filter Divisi (Multi-Select & Deletable Tags) */}
                <div className="flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-bold text-stone-700 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Filter Divisi</span>
                      <span className="text-[10px] text-stone-400 font-normal">
                        (Bisa pilih lebih dari 1)
                      </span>
                    </label>
                    <div className="flex items-center gap-2">
                      {!isAllExportDivisions && (
                        <button
                          type="button"
                          onClick={resetExportDivisions}
                          className="text-[10px] font-extrabold text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
                        >
                          Pilih Semua
                        </button>
                      )}
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                        {isAllExportDivisions
                          ? `Semua (${availableExportDivisions.length})`
                          : `${exportDivisionFilters.length} Terpilih`}
                      </span>
                    </div>
                  </div>

                  {/* List of Available Division Toggles */}
                  <div className="flex flex-wrap gap-1.5 p-2 bg-white border border-stone-200 rounded-xl max-h-24 overflow-y-auto">
                    <button
                      type="button"
                      onClick={() => toggleExportDivision('ALL')}
                      className={`text-[11px] px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                        isAllExportDivisions
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      <span>Semua Divisi</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black ${
                        isAllExportDivisions
                          ? 'bg-emerald-800 text-emerald-100'
                          : 'bg-stone-200 text-stone-700'
                      }`}>
                        {availableExportDivisions.length}
                      </span>
                    </button>
                    {availableExportDivisions.map((div) => {
                      const isSelected = !isAllExportDivisions && exportDivisionFilters.includes(div);
                      return (
                        <button
                          key={div}
                          type="button"
                          onClick={() => toggleExportDivision(div)}
                          className={`text-[11px] px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                          <span>{div}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Active Division Badges / Deletable Tags Tray */}
              <div className="px-3.5 py-2.5 bg-emerald-50/70 border border-emerald-200/80 rounded-xl">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-950">
                    <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Divisi yang Masuk dalam Preview:</span>
                  </div>
                  {!isAllExportDivisions && (
                    <button
                      type="button"
                      onClick={resetExportDivisions}
                      className="text-[10px] font-extrabold text-emerald-800 hover:text-emerald-950 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <X className="w-3 h-3 stroke-[2.5]" />
                      <span>Hapus Semua Filter</span>
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  {isAllExportDivisions ? (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-white text-emerald-800 border border-emerald-300 shadow-2xs">
                      <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" />
                      <span>Semua Divisi ({availableExportDivisions.length} Divisi Aktif)</span>
                    </div>
                  ) : (
                    exportDivisionFilters.map((div) => (
                      <span
                        key={div}
                        className="inline-flex items-center gap-1.5 pl-2.5 pr-1 py-1 rounded-lg text-xs font-black bg-emerald-700 text-white shadow-xs border border-emerald-800 transition"
                      >
                        <span>{div}</span>
                        <button
                          type="button"
                          onClick={() => removeExportDivision(div)}
                          title={`Hapus divisi ${div} dari preview`}
                          className="w-4 h-4 rounded-md flex items-center justify-center bg-emerald-800 hover:bg-emerald-900 text-emerald-100 hover:text-white transition cursor-pointer ml-0.5"
                        >
                          <X className="w-2.5 h-2.5 stroke-[3]" />
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Scope Filter: Semua Nota Piutang vs Hanya Slip Terkunci */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 bg-stone-50 border border-stone-200 rounded-xl gap-2 text-xs">
                <span className="font-bold text-stone-700">Cakupan Data:</span>
                {isLoggedIn ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setExportOnlyLocked(false)}
                      className={`flex-1 sm:flex-none px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                        !exportOnlyLocked
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      Semua Nota Piutang ({rawExportRows.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setExportOnlyLocked(true)}
                      className={`flex-1 sm:flex-none px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                        exportOnlyLocked
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      Hanya Slip Terkunci
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 font-bold text-xs">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                    <span>Hanya Transaksi Terkunci Petugas</span>
                  </div>
                )}
              </div>

              {/* Selection Summary Bar */}
              <div className="flex items-center justify-between px-1 text-xs">
                <label className="flex items-center gap-2 font-bold text-stone-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={isAllExportSelected}
                    onChange={toggleSelectAllExport}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <span>Pilih Semua Transaksi ({selectedExportRows.length}/{rawExportRows.length} Terpilih)</span>
                </label>
                <div className="text-[11px] font-bold text-stone-500">
                  Total Belanja Terpilih: <span className="text-emerald-700 font-black font-mono">{fRp(selectedExportRows.reduce((sum, r) => sum + (r.total || r.nominal || 0), 0))}</span>
                </div>
              </div>

              {/* Live Preview Table */}
              <div className="border border-stone-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="bg-stone-800 text-stone-200 px-3 py-2 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Preview Format Excel: Rekap_WAKA_{exportStartDate === exportEndDate ? exportStartDate : `${exportStartDate}_sd_${exportEndDate}`}.xlsx</span>
                  </div>
                  <span className="text-[10px] bg-emerald-700/80 text-emerald-100 px-2.5 py-0.5 rounded-full font-sans font-bold">
                    Format Per Item & No. WA (8 Kolom)
                  </span>
                </div>
                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200 sticky top-0">
                      <tr>
                        <th className="py-2.5 px-3 border-r border-stone-200 text-center w-10 bg-stone-100">
                          <input
                            type="checkbox"
                            checked={isAllExportSelected}
                            onChange={toggleSelectAllExport}
                            className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                          />
                        </th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">No Nota</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">Nama Karyawan</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">No. WA</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">Tanggal</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 bg-stone-100">Item Barang</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 text-center bg-stone-100 w-14">Qty</th>
                        <th className="py-2.5 px-3 border-r border-stone-200 text-right bg-stone-100">Harga Satuan</th>
                        <th className="py-2.5 px-3 text-right bg-stone-100">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono text-[11px]">
                      {rawExportRows.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="py-8 text-center text-stone-400 font-sans text-xs">
                            Tidak ada data transaksi terkunci pada filter dan rentang tanggal yang dipilih.
                          </td>
                        </tr>
                      ) : (
                        rawExportRows.map((row, idx) => {
                          const isSelected = !excludedExportCustomerKeys[row.rowId];
                          return (
                            <tr key={row.rowId || (row.name + idx)} className={`transition ${isSelected ? 'hover:bg-emerald-50/40' : 'bg-stone-50/70 opacity-40'}`}>
                              <td className="py-2 px-3 text-center border-r border-stone-100">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={(e) => {
                                    setExcludedExportCustomerKeys((prev) => ({
                                      ...prev,
                                      [row.rowId]: !e.target.checked,
                                    }));
                                  }}
                                  className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                                />
                              </td>
                              <td className="py-2 px-3 text-stone-700 font-mono font-medium border-r border-stone-100">{row.noNota || '-'}</td>
                              <td className="py-2 px-3 font-bold text-stone-900 border-r border-stone-100">{row.name}</td>
                              <td className="py-2 px-3 font-semibold text-stone-600 border-r border-stone-100">{row.phone || '-'}</td>
                              <td className="py-2 px-3 text-stone-600 border-r border-stone-100">{row.date}</td>
                              <td className="py-2 px-3 font-bold text-stone-800 border-r border-stone-100 font-sans">{row.itemName || '-'}</td>
                              <td className="py-2 px-3 text-center font-bold text-stone-700 border-r border-stone-100">{row.qty}</td>
                              <td className="py-2 px-3 text-right font-medium text-stone-700 border-r border-stone-100">
                                {Number(row.price || 0).toLocaleString('id-ID')}
                              </td>
                              <td className="py-2 px-3 text-right font-black text-emerald-700">
                                {Number(row.total || row.nominal || 0).toLocaleString('id-ID')}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-stone-50 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-[11px] text-stone-500 flex items-center gap-1.5">
                <span className="font-semibold">Nama File:</span>
                <span className="font-mono bg-stone-200 text-stone-800 px-2 py-0.5 rounded text-[10px]">
                  Rekap_WAKA_{exportStartDate === exportEndDate ? exportStartDate : `${exportStartDate}_sd_${exportEndDate}`}.xlsx
                </span>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setIsExportModalOpen(false)}
                  className="flex-1 sm:flex-initial px-4 py-2.5 border border-stone-300 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handlePrintPDFFromExportModal}
                  className="flex-1 sm:flex-initial px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  title="Cetak PDF Rekap Transaksi Terkunci yang Dipilih"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak PDF ({selectedExportRows.length})</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadExcel}
                  className="flex-1 sm:flex-initial px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download File Excel (.xlsx)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
