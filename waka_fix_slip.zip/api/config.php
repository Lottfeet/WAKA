<?php
// ============================================================================
// Konfigurasi database WAKA — EDIT SESUAI DATA cPanel/phpMyAdmin Anda
// Letakkan file ini di folder /api di hosting cPanel.
// ============================================================================

const WAKA_DB_HOST = 'localhost';        // biasanya 'localhost' di cPanel
const WAKA_DB_NAME = 'hump6894_Waka';  // nama database yang dibuat di phpMyAdmin
const WAKA_DB_USER = 'hump6894_hump6894_Waka';  // username MySQL
const WAKA_DB_PASS = '10203040@waka';   // password MySQL

// Token rahasia untuk endpoint import backup (samakan dengan nilai di app)
const WAKA_IMPORT_TOKEN = 'wakakakak-import-2026';
