import React, { useState, useEffect } from 'react';
import { X, UserPlus, Edit3, Phone, MapPin, Tag, FileText, CheckCircle2, User, Users, Building2 } from 'lucide-react';
import { Customer } from '../types';
import { addCustomer, deleteCustomer } from '../services/gasService';
import { saveCustomerFirebase, deleteCustomerFirebase } from '../services/firebaseService';

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCustomerAdded: (customer: Customer, oldCustomer?: Customer | null) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  initialName?: string;
  customerToEdit?: Customer | null;
  onOpenGasGuide?: () => void;
}

export const AddCustomerModal: React.FC<AddCustomerModalProps> = ({
  isOpen,
  onClose,
  onCustomerAdded,
  onShowToast,
  initialName = '',
  customerToEdit,
  onOpenGasGuide,
}) => {
  const [nama, setNama] = useState('');
  const [divisi, setDivisi] = useState('');
  const [kelas, setKelas] = useState<'Umum' | 'Karyawan'>('Umum');
  const [telepon, setTelepon] = useState('');
  const [catatan, setCatatan] = useState('');
  const [alamat, setAlamat] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const resetForm = () => {
    setNama('');
    setDivisi('');
    setKelas('Umum');
    setTelepon('');
    setCatatan('');
    setAlamat('');
  };

  useEffect(() => {
    if (isOpen) {
      if (customerToEdit) {
        setNama(customerToEdit.nama || '');
        const rawKelas = (customerToEdit.kelas || '').toLowerCase();
        setKelas(rawKelas.includes('karyawan') ? 'Karyawan' : 'Umum');
        setDivisi(customerToEdit.divisi || customerToEdit.division || '');
        setTelepon(customerToEdit.telepon || '');
        setCatatan(customerToEdit.catatan || '');
        setAlamat(customerToEdit.alamat || '');
      } else if (initialName) {
        setNama(initialName);
        setDivisi('');
        setKelas('Umum');
        setTelepon('');
        setCatatan('');
        setAlamat('');
      } else {
        resetForm();
      }
    } else {
      resetForm();
    }
  }, [isOpen, customerToEdit, initialName]);

  if (!isOpen) return null;

  const isEdit = Boolean(customerToEdit);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = nama.trim();
    if (!cleanName) {
      onShowToast('Nama pelanggan wajib diisi!', 'error');
      return;
    }

    const cleanDivisi = divisi.trim();
    if (kelas === 'Karyawan' && !cleanDivisi) {
      onShowToast('Divisi wajib diisi untuk kategori Karyawan!', 'error');
      return;
    }

    const existingOldNames = Array.isArray(customerToEdit?.oldNames) ? customerToEdit.oldNames : [];
    const oldName = (isEdit && customerToEdit) ? customerToEdit.nama.trim() : undefined;
    const oldDiv = (isEdit && customerToEdit) ? (customerToEdit.divisi || customerToEdit.division || '').trim() : '';

    const updatedOldNames = Array.from(new Set([
      ...existingOldNames,
      ...(oldName && oldName.toLowerCase() !== cleanName.toLowerCase() ? [oldName] : []),
      ...(oldName && oldDiv ? [`${oldName} (${oldDiv})`] : []),
    ]));

    const newCust: Customer = {
      nama: cleanName,
      kelas: kelas,
      divisi: cleanDivisi,
      division: cleanDivisi,
      diskon: 0,
      telepon: telepon.trim(),
      catatan: catatan.trim(),
      alamat: alamat.trim(),
      oldNames: updatedOldNames,
    };

    setIsSaving(true);
    try {
      const oldName = (isEdit && customerToEdit) ? customerToEdit.nama.trim() : undefined;
      if (oldName && oldName !== cleanName) {
        await deleteCustomerFirebase(oldName).catch(() => {});
        await deleteCustomer(oldName).catch(() => {});
      }

      await saveCustomerFirebase(newCust, oldName).catch(() => {});
      const res = await addCustomer(newCust, oldName);
      if (isEdit) {
        onShowToast(`Data pelanggan "${cleanName}" berhasil diperbarui!`, 'success');
      } else {
        if (res.isSheetSynced) {
          onShowToast(res.message, 'success');
        } else if (res.needsScriptUpdate) {
          onShowToast(`Pelanggan "${cleanName}" tersimpan lokal. Silakan update Kode Apps Script v4 di Google Sheets agar tersinkron otomatis.`, 'info');
          if (onOpenGasGuide) {
            setTimeout(() => onOpenGasGuide(), 800);
          }
        } else {
          onShowToast(res.message, 'info');
        }
      }

      onCustomerAdded(res.customer || newCust, customerToEdit);
      resetForm();
      onClose();
    } catch {
      onShowToast('Terjadi kesalahan saat menyimpan pelanggan', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl border border-stone-200">
        {/* Modal Header */}
        <div className={`p-4 text-white flex items-center justify-between ${isEdit ? 'bg-blue-800' : 'bg-red-700'}`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center font-bold">
              {isEdit ? <Edit3 className="w-5 h-5 text-white" /> : <UserPlus className="w-5 h-5 text-white" />}
            </div>
            <div>
              <h3 className="font-extrabold text-white text-sm sm:text-base leading-tight">
                {isEdit ? 'Edit Data Pelanggan' : 'Tambah Pelanggan Baru'}
              </h3>
              <p className="text-[11px] text-red-100 font-medium">
                Kategori: Umum & Karyawan (Tersimpan ke Firebase & Google Sheets)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
          {/* Row: Nama Pelanggan & Divisi Berdampingan */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Nama Pelanggan */}
            <div>
              <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-red-700" />
                <span>Nama Pelanggan / Usaha <span className="text-red-500">*</span></span>
              </label>
              <input
                type="text"
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                placeholder="Contoh: Ahmad, Siti Rahma"
                className="w-full p-2.5 border border-stone-300 rounded-xl text-xs font-semibold focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100"
                required
                autoFocus
              />
            </div>

            {/* Divisi */}
            <div>
              <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-red-700" />
                  <span>Divisi</span>
                </span>
                {kelas === 'Karyawan' ? (
                  <span className="text-[10px] font-extrabold text-red-600 bg-red-50 px-1.5 py-0.2 rounded border border-red-200">Wajib Diisi</span>
                ) : (
                  <span className="text-[10px] text-stone-400 font-normal">Opsional</span>
                )}
              </label>
              <input
                type="text"
                value={divisi}
                onChange={(e) => setDivisi(e.target.value)}
                placeholder={kelas === 'Karyawan' ? "Wajib diisi (mis: ERVO PRINT)" : "Contoh: ERVO PRINT, STORE"}
                required={kelas === 'Karyawan'}
                className={`w-full p-2.5 border rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 ${
                  kelas === 'Karyawan' && !divisi.trim()
                    ? 'border-red-300 bg-red-50/30 focus:border-red-600 focus:ring-red-100 placeholder:text-red-400'
                    : 'border-stone-300 bg-white focus:border-red-600 focus:ring-red-100'
                }`}
              />
            </div>
          </div>

          {/* Kategori Pelanggan: Umum vs Karyawan */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1.5 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-red-700" />
              <span>Kategori Pelanggan <span className="text-red-500">*</span></span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setKelas('Umum')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-extrabold transition-all cursor-pointer ${
                  kelas === 'Umum'
                    ? 'bg-red-700 text-white border-red-700 shadow-xs ring-2 ring-red-200'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <User className="w-4 h-4" />
                  <span className="text-sm">Umum</span>
                </div>
                <span className={`text-[10px] font-normal ${kelas === 'Umum' ? 'text-red-100' : 'text-stone-500'}`}>
                  Pembayaran Tunai (Cash)
                </span>
              </button>

              <button
                type="button"
                onClick={() => setKelas('Karyawan')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-extrabold transition-all cursor-pointer ${
                  kelas === 'Karyawan'
                    ? 'bg-rose-800 text-white border-rose-800 shadow-xs ring-2 ring-rose-200'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">Karyawan</span>
                </div>
                <span className={`text-[10px] font-normal ${kelas === 'Karyawan' ? 'text-rose-100' : 'text-stone-500'}`}>
                  Voucher WAKA / Potong Gaji
                </span>
              </button>
            </div>
          </div>

          {/* Telepon / WA */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-stone-500" />
              <span>No. Telepon / WhatsApp</span>
            </label>
            <input
              type="text"
              value={telepon}
              onChange={(e) => setTelepon(e.target.value)}
              placeholder="Contoh: 0812 9988 7766"
              className="w-full p-2.5 border border-stone-300 rounded-xl text-xs font-medium focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100"
            />
          </div>

          {/* Alamat / Lokasi */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-stone-500" />
              <span>Alamat / Lokasi</span>
            </label>
            <textarea
              rows={2}
              value={alamat}
              onChange={(e) => setAlamat(e.target.value)}
              placeholder="Contoh: Perum Graha Indah Blok B / Jl. Raya No. 12"
              className="w-full p-2 border border-stone-300 rounded-xl text-xs font-medium focus:outline-none focus:border-red-600"
            />
          </div>

          {/* Catatan */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-stone-500" />
              <span>Catatan Khusus (Opsional)</span>
            </label>
            <input
              type="text"
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              placeholder="Contoh: Shift Pagi / Bagian Cutting"
              className="w-full p-2 border border-stone-300 rounded-xl text-xs font-medium focus:outline-none focus:border-red-600"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className={`px-5 py-2 rounded-xl text-white text-xs font-bold shadow-xs transition active:scale-95 disabled:opacity-50 flex items-center gap-1.5 cursor-pointer ${
                isEdit ? 'bg-blue-800 hover:bg-blue-900' : 'bg-red-700 hover:bg-red-800'
              }`}
            >
              {isEdit ? <Edit3 className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
              <span>{isSaving ? 'Menyimpan...' : isEdit ? 'Simpan Perubahan' : 'Simpan Pelanggan'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

