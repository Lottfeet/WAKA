import React, { useState } from 'react';
import { Customer } from '../types';
import { 
  Users, 
  Search, 
  UserPlus, 
  Phone, 
  MapPin, 
  FileText,
  Trash2,
  AlertTriangle,
  Edit3,
  User,
  BadgeCheck,
  Building2
} from 'lucide-react';
import { getCustomerDivision } from '../utils/excelUtils';

interface PelangganViewProps {
  customers: Customer[];
  onOpenAddCustomer: () => void;
  onEditCustomer?: (customer: Customer) => void;
  onSelectCustomerToOrder?: (customerName: string) => void;
  onDeleteCustomer?: (customerName: string) => void;
}

export const PelangganView: React.FC<PelangganViewProps> = ({
  customers,
  onOpenAddCustomer,
  onEditCustomer,
  onSelectCustomerToOrder,
  onDeleteCustomer,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  // Deduplicate customers by case-insensitive name
  const uniqueCustomers = React.useMemo(() => {
    const map = new Map<string, Customer>();
    customers.forEach((c) => {
      const name = (c.nama || '').trim();
      if (!name) return;
      const key = name.toLowerCase();
      if (!map.has(key)) {
        map.set(key, c);
      }
    });
    return Array.from(map.values());
  }, [customers]);

  const filteredCustomers = uniqueCustomers.filter((c) => {
    const q = searchTerm.toLowerCase().trim();
    const custDivision = getCustomerDivision(c.nama, uniqueCustomers, c);
    const matchesSearch =
      !q ||
      c.nama.toLowerCase().includes(q) ||
      (custDivision && custDivision.toLowerCase().includes(q)) ||
      (Boolean(c.divisi || c.division) && (c.divisi || c.division)!.toLowerCase().includes(q)) ||
      (c.telepon && c.telepon.toLowerCase().includes(q)) ||
      (c.alamat && c.alamat.toLowerCase().includes(q));

    const matchesClass = selectedClass === 'all' || (c.kelas || '').toLowerCase() === selectedClass.toLowerCase();

    return matchesSearch && matchesClass;
  });

  const rawClasses = uniqueCustomers
    .map((c) => c.kelas)
    .filter((k): k is string => typeof k === 'string' && k.length > 0);
  const defaultClasses: string[] = ['Umum', 'Karyawan'];
  const allAvailableClasses: string[] = Array.from(new Set<string>([...defaultClasses, ...rawClasses]));

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1">
      {/* Top Banner */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-700 rounded-xl text-white shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Database & Kelola Pelanggan</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-red-500/30 text-red-200 border border-red-500/40 uppercase">
                {uniqueCustomers.length} Terdaftar
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              Kelola kategori pelanggan (Umum & Karyawan), kontak WhatsApp, dan alamat pengiriman.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAddCustomer}
          className="px-3.5 py-2 bg-red-700 hover:bg-red-800 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-2 transition shrink-0 active:scale-95 cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>+ Tambah Pelanggan Baru</span>
        </button>
      </div>

      {/* Controls Bar: Search & Filter */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-stone-200 shadow-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
          <input
            type="text"
            placeholder="Cari nama pelanggan, nomor HP, atau alamat..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/20"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-xs font-bold text-stone-500 whitespace-nowrap">Kategori:</span>
          <button
            onClick={() => setSelectedClass('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
              selectedClass === 'all'
                ? 'bg-red-700 text-white shadow-xs'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            Semua
          </button>
          {allAvailableClasses.map((cls, idx) => (
            <button
              key={`${cls}-${idx}`}
              onClick={() => setSelectedClass(cls)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                selectedClass.toLowerCase() === cls.toLowerCase()
                  ? 'bg-red-700 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {cls}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 flex-1">
        {filteredCustomers.length === 0 ? (
          <div className="col-span-full bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400">
            <Users className="w-10 h-10 mx-auto text-stone-300 mb-2" />
            <p className="text-xs font-bold">Tidak ada data pelanggan yang cocok.</p>
          </div>
        ) : (
          filteredCustomers.map((c, idx) => {
            const isKaryawan = (c.kelas || '').toLowerCase().includes('karyawan');
            const custDivision = getCustomerDivision(c.nama, customers, c);

            return (
              <div
                key={`${c.nama}-${idx}`}
                className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs hover:border-red-300 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <h4 className="font-extrabold text-sm text-stone-900">{c.nama}</h4>
                      <div className="flex items-center gap-1.5 flex-wrap mt-1">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                            isKaryawan
                              ? 'bg-red-100 text-red-800 border-red-200'
                              : 'bg-stone-100 text-stone-700 border-stone-200'
                          }`}
                        >
                          {isKaryawan ? <BadgeCheck className="w-3 h-3 text-red-700" /> : <User className="w-3 h-3 text-stone-500" />}
                          <span>{c.kelas || 'Umum'}</span>
                        </span>
                        {custDivision && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                            <Building2 className="w-3 h-3 text-blue-600" />
                            <span>{custDivision}</span>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onEditCustomer && onEditCustomer(c)}
                        className="p-1.5 rounded-lg text-stone-500 hover:text-blue-700 hover:bg-blue-50 transition cursor-pointer"
                        title="Edit Data Pelanggan"
                      >
                        <Edit3 className="w-4 h-4 text-blue-600" />
                      </button>

                      <button
                        type="button"
                        onClick={() => setCustomerToDelete(c)}
                        className="p-1.5 rounded-lg text-stone-400 hover:text-red-700 hover:bg-red-50 transition cursor-pointer"
                        title="Hapus Pelanggan"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-stone-600 mt-3 border-t border-stone-100 pt-3">
                    {c.telepon && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <a
                          href={`https://wa.me/${c.telepon.replace(/^0/, '62')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-red-700 font-semibold hover:underline"
                        >
                          {c.telepon}
                        </a>
                      </div>
                    )}

                    {c.alamat && (
                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                        <span className="text-stone-600 line-clamp-2">{c.alamat}</span>
                      </div>
                    )}

                    {c.catatan && (
                      <div className="flex items-start gap-2 text-stone-500 italic text-[11px] mt-1">
                        <FileText className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                        <span>"{c.catatan}"</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-4">
                  {onSelectCustomerToOrder && (
                    <button
                      onClick={() => onSelectCustomerToOrder(c.nama)}
                      className="flex-1 py-2 bg-stone-100 hover:bg-red-700 hover:text-white text-stone-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Pilih untuk Order Kasir</span>
                      <span>→</span>
                    </button>
                  )}

                  {onEditCustomer && (
                    <button
                      type="button"
                      onClick={() => onEditCustomer(c)}
                      className="px-3 py-2 bg-blue-50 hover:bg-blue-700 hover:text-white text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition flex items-center justify-center gap-1 shrink-0 cursor-pointer"
                      title="Edit Data Pelanggan"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setCustomerToDelete(c)}
                    className="px-3 py-2 bg-stone-100 hover:bg-red-600 hover:text-white text-stone-600 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1 shrink-0 cursor-pointer"
                    title="Hapus Pelanggan Ini"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Hapus</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* CONFIRMATION MODAL HAPUS PELANGGAN */}
      {customerToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl overflow-hidden border border-stone-200">
            <div className="p-5 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-stone-900 text-base">Hapus Pelanggan?</h3>
                <p className="text-xs text-stone-500 mt-1">
                  Apakah Anda yakin ingin menghapus data pelanggan <strong className="text-stone-900 font-bold">"{customerToDelete.nama}"</strong>?
                </p>
              </div>
            </div>

            <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteCustomer && customerToDelete) {
                    onDeleteCustomer(customerToDelete.nama);
                  }
                  setCustomerToDelete(null);
                }}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Hapus</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
