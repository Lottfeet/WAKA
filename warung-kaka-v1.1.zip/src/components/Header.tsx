import React from 'react';
import { 
  Printer, 
  RotateCw, 
  Settings, 
  Search,
  Wifi, 
  WifiOff, 
  Clock, 
  LogOut, 
  Flame,
  FileSpreadsheet,
  ExternalLink
} from 'lucide-react';
import { StoreSettings } from '../types';
import { getStoredSpreadsheetInfo } from '../services/googleSheetsService';

interface HeaderProps {
  settings: StoreSettings;
  currentUser?: string | null;
  isConnected: boolean;
  isSyncing: boolean;
  lastSyncTime: string | null;
  onSync: () => void;
  onOpenSettings: () => void;
  onOpenReprint?: () => void;
  onOpenCariRekap?: () => void;
  onOpenGasGuide?: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  currentUser,
  isConnected,
  isSyncing,
  lastSyncTime,
  onSync,
  onOpenSettings,
  onOpenReprint,
  onOpenCariRekap,
  onOpenGasGuide,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-stone-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 h-16 flex items-center justify-between gap-3">
        {/* Brand & Connection Badge */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-red-700 flex items-center justify-center text-white font-bold shadow-xs shrink-0">
            <Printer className="w-6 h-6" />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2 leading-none">
              <span className="font-black text-xl tracking-tight text-stone-900 truncate">
                {settings.name || 'WARUNGKU'}
              </span>
              <span className="hidden sm:inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
                {settings.tagline || 'Cepat / Tepat / Berkualitas'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-stone-500 mt-1 flex-wrap">
              <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-red-100 text-red-900 border border-red-200">
                <Flame className="w-3 h-3 text-red-600 fill-red-500" />
                <span className="hidden sm:inline">Firebase Cloud Active</span>
                <span className="sm:hidden">Firestore Active</span>
              </span>

              {getStoredSpreadsheetInfo().url ? (
                <a
                  href={getStoredSpreadsheetInfo().url!}
                  target="_blank"
                  rel="noreferrer noopener"
                  title="Buka Google Sheets di tab baru"
                  className="inline-flex items-center gap-1 text-[11px] text-emerald-800 font-extrabold bg-emerald-50 hover:bg-emerald-100 px-1.5 py-0.5 rounded border border-emerald-300 transition"
                >
                  <FileSpreadsheet className="w-3 h-3 text-emerald-600" />
                  <span className="hidden sm:inline">Sheets Live</span>
                  <ExternalLink className="w-2.5 h-2.5 opacity-70" />
                </a>
              ) : isConnected ? (
                <button
                  type="button"
                  onClick={onOpenGasGuide}
                  title="Klik untuk melihat Panduan Apps Script & Unduh Code.gs"
                  className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-bold hover:text-emerald-800 hover:underline cursor-pointer transition"
                >
                  <Wifi className="w-3 h-3 text-emerald-600" />
                  <span className="hidden sm:inline">Google Sheets Connected</span>
                  <span className="sm:hidden">Sheets OK</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onOpenSettings}
                  title="Klik untuk menghubungkan ke Google Sheets"
                  className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-bold hover:text-emerald-800 hover:underline cursor-pointer bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 transition"
                >
                  <FileSpreadsheet className="w-3 h-3 text-emerald-600" />
                  <span>Google Sheets</span>
                </button>
              )}

              {lastSyncTime && (
                <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-stone-400">
                  <Clock className="w-3 h-3" />
                  <span>Sync {lastSyncTime}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={onSync}
            disabled={isSyncing}
            className="px-2.5 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50 cursor-pointer"
            title="Sinkronisasi data real-time dari Google Sheets"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-red-600' : 'text-stone-600'}`} />
            <span className="hidden sm:inline">{isSyncing ? 'Sinkron...' : 'Sinkron'}</span>
          </button>

          {onOpenCariRekap ? (
            <button
              onClick={onOpenCariRekap}
              className="hidden sm:flex px-2.5 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-semibold items-center gap-1.5 transition active:scale-95 cursor-pointer"
              title="Pencarian Rekapan Piutang & Pelunasan Karyawan"
            >
              <Search className="w-3.5 h-3.5 text-stone-600" />
              <span>Cari Rekapan</span>
            </button>
          ) : onOpenReprint ? (
            <button
              onClick={onOpenReprint}
              className="hidden sm:flex px-2.5 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-semibold items-center gap-1.5 transition active:scale-95 cursor-pointer"
              title="Cari & Cetak Ulang Invoice"
            >
              <Search className="w-3.5 h-3.5 text-stone-600" />
              <span>Cetak Ulang</span>
            </button>
          ) : null}

          <button
            onClick={onOpenSettings}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            title="Pengaturan Toko & Kasir"
          >
            <Settings className="w-4 h-4 text-stone-600" />
            <span className="hidden sm:inline">Pengaturan</span>
          </button>

          {currentUser && onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="px-2.5 py-1.5 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 cursor-pointer"
              title={`Keluar (${currentUser})`}
            >
              <LogOut className="w-3.5 h-3.5 text-red-600" />
              <span>Keluar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
