import React, { useState } from 'react';
import { X, FileUp, Upload, Check, AlertCircle, FileText } from 'lucide-react';
import { Product } from '../types';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmImport: (products: Product[]) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ImportModal: React.FC<ImportModalProps> = ({
  isOpen,
  onClose,
  onConfirmImport,
  onShowToast,
}) => {
  const [pasteData, setPasteData] = useState('');
  const [parsedHeaders, setParsedHeaders] = useState<string[]>([]);
  const [parsedRows, setParsedRows] = useState<Record<string, string>[]>([]);
  const [columnMap, setColumnMap] = useState<Record<number, string>>({});

  if (!isOpen) return null;

  const detectSeparator = (text: string) => {
    const firstLine = text.split('\n')[0];
    if (firstLine.includes('\t')) return '\t';
    return (firstLine.match(/;/g) || []).length > (firstLine.match(/,/g) || []).length ? ';' : ',';
  };

  const parseCSVText = (text: string) => {
    const sep = detectSeparator(text);
    const lines = text
      .trim()
      .split(/\r?\n/)
      .filter((l) => l.trim());
    if (lines.length < 2) return null;

    const headers = lines[0].split(sep).map((h) => h.trim().replace(/^["']|["']$/g, ''));
    const rows: Record<string, string>[] = [];

    for (let i = 1; i < lines.length; i++) {
      const cells = lines[i].split(sep).map((c) => c.trim().replace(/^["']|["']$/g, ''));
      if (cells.length >= headers.length) {
        const row: Record<string, string> = {};
        headers.forEach((h, idx) => (row[h] = cells[idx] || ''));
        rows.push(row);
      }
    }
    return { headers, rows };
  };

  const autoMapColumns = (headers: string[]) => {
    const map: Record<number, string> = {};
    const keywords: Record<string, string[]> = {
      kode: ['kode', 'id', 'sku', 'code', 'kd'],
      nama: ['nama', 'name', 'barang', 'item', 'produk', 'jasa'],
      harga: ['harga', 'price', 'biaya', 'cost', 'rate'],
      kategori: ['kategori', 'category', 'grup', 'jenis', 'type'],
      stok: ['stok', 'stock'],
      satuan: ['satuan', 'unit', 'uom'],
      tipeHarga: ['tipe', 'tipeharga', 'type_harga', 'pricetype'],
    };

    const used = new Set<number>();
    for (const [field, ks] of Object.entries(keywords)) {
      for (let i = 0; i < headers.length; i++) {
        if (used.has(i)) continue;
        if (ks.some((k) => headers[i].toLowerCase().includes(k))) {
          map[i] = field;
          used.add(i);
          break;
        }
      }
    }

    if (!Object.values(map).includes('kode') && headers.length > 0 && !used.has(0)) map[0] = 'kode';
    if (!Object.values(map).includes('nama') && headers.length > 1 && !used.has(1)) map[1] = 'nama';
    if (!Object.values(map).includes('harga') && headers.length > 2 && !used.has(2)) map[2] = 'harga';

    return map;
  };

  const handleProcessText = (text: string) => {
    const parsed = parseCSVText(text);
    if (!parsed || parsed.rows.length === 0) {
      onShowToast('Format data CSV/TSV tidak valid', 'error');
      return;
    }

    setParsedHeaders(parsed.headers);
    setParsedRows(parsed.rows);
    setColumnMap(autoMapColumns(parsed.headers));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target?.result as string;
      setPasteData(content);
      handleProcessText(content);
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = () => {
    const importedProducts: Product[] = [];
    let skipped = 0;

    parsedRows.forEach((row) => {
      const getValue = (field: string) => {
        const idx = Object.keys(columnMap).find((k) => columnMap[Number(k)] === field);
        return idx !== undefined ? (row[parsedHeaders[Number(idx)]] || '').trim() : '';
      };

      const nama = getValue('nama');
      const hargaRaw = getValue('harga').replace(/[^0-9]/g, '');
      const harga = parseInt(hargaRaw, 10);

      if (!nama || isNaN(harga) || harga <= 0) {
        skipped++;
        return;
      }

      importedProducts.push({
        kode: getValue('kode') || `AUTO-${String(importedProducts.length + 1).padStart(3, '0')}`,
        nama,
        harga,
        kategori: getValue('kategori') || 'Lainnya',
        stok: getValue('stok'),
        satuan: getValue('satuan') || 'pcs',
        tipeHarga: getValue('tipeHarga') || 'fix',
      });
    });

    if (importedProducts.length === 0) {
      onShowToast('Tidak ada data produk yang valid untuk diimport', 'error');
      return;
    }

    onConfirmImport(importedProducts);
    onShowToast(`Berhasil mengimport ${importedProducts.length} item produk`, 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-700 text-white flex items-center justify-center font-bold">
              <FileUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base">Import Data Produk</h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Upload atau Paste dari Excel / Spreadsheet (.csv, .tsv)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 space-y-4">
          {/* File Upload Dropzone */}
          <div>
            <label className="border-2 border-dashed border-stone-300 hover:border-red-500 rounded-xl p-5 flex flex-col items-center justify-center cursor-pointer transition bg-stone-50/50 hover:bg-red-50/30">
              <Upload className="w-8 h-8 text-red-600 mb-1" />
              <span className="text-xs font-bold text-stone-800">
                Klik untuk upload file CSV / TSV
              </span>
              <span className="text-[10px] text-stone-400 mt-0.5">
                Format: Kode, Nama, Harga, Kategori, Stok, Satuan, TipeHarga
              </span>
              <input
                type="file"
                accept=".csv,.tsv,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          <div className="relative text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-stone-200" />
            </div>
            <span className="relative bg-white px-3 text-[10px] font-bold text-stone-400 uppercase">
              atau paste teks dari excel
            </span>
          </div>

          {/* Paste Text Area */}
          <textarea
            rows={4}
            value={pasteData}
            onChange={(e) => {
              setPasteData(e.target.value);
              if (e.target.value.trim()) handleProcessText(e.target.value);
            }}
            placeholder="Paste teks tabel di sini... (Kode	Nama	Harga	Kategori	Satuan)"
            className="w-full p-3 border border-stone-200 rounded-xl font-mono text-xs focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100 bg-stone-50/50"
          />

          {/* Column Mapping Preview */}
          {parsedHeaders.length > 0 && (
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <h4 className="font-bold text-xs text-stone-800">Pemetaan Kolom Import</h4>
              <div className="space-y-2">
                {parsedHeaders.map((header, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <span className="w-32 font-mono font-bold text-stone-700 truncate">
                      {header}
                    </span>
                    <span className="text-stone-300">→</span>
                    <select
                      value={columnMap[i] || ''}
                      onChange={(e) => setColumnMap({ ...columnMap, [i]: e.target.value })}
                      className="flex-1 py-1 px-2 border border-stone-200 rounded-lg text-xs font-semibold bg-white"
                    >
                      <option value="">-- Abaikan Kolom Ini --</option>
                      <option value="kode">Kode Produk</option>
                      <option value="nama">Nama Produk / Jasa</option>
                      <option value="harga">Harga Rp</option>
                      <option value="kategori">Kategori</option>
                      <option value="stok">Stok</option>
                      <option value="satuan">Satuan (pcs/m²/lembar)</option>
                      <option value="tipeHarga">Tipe Harga (ukuran/fix)</option>
                    </select>
                  </div>
                ))}
              </div>

              {/* Preview Table */}
              <div className="pt-2">
                <p className="text-[11px] font-bold text-stone-600 mb-1">
                  Preview 3 Baris Pertama ({parsedRows.length} total):
                </p>
                <div className="overflow-x-auto rounded-lg border border-stone-200">
                  <table className="w-full text-[11px] border-collapse">
                    <thead className="bg-stone-100 text-stone-700 font-bold">
                      <tr>
                        {parsedHeaders.map((h, i) => (
                          <th key={i} className="p-1.5 text-left border-b border-stone-200">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono">
                      {parsedRows.slice(0, 3).map((r, ri) => (
                        <tr key={ri}>
                          {parsedHeaders.map((h, hi) => (
                            <td key={hi} className="p-1.5 truncate max-w-[120px]">
                              {r[h]}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Confirm Button */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-200">
            <button
              onClick={onClose}
              className="px-4 py-2 text-stone-600 hover:bg-stone-100 text-xs font-semibold rounded-lg transition"
            >
              Batal
            </button>
            <button
              onClick={handleExecuteImport}
              disabled={parsedRows.length === 0}
              className="px-5 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-bold rounded-lg shadow-xs transition active:scale-95 disabled:opacity-50 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Import {parsedRows.length} Item</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
