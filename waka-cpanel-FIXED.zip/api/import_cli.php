<?php
// ============================================================================
// WAKA import CLI — jalankan di cPanel Terminal:
//   cd ~/public_html/api && php import_cli.php ../Backup_WARUNG_KAKA_20261026_112227.json
// Membaca config.php (tanpa perlu token), lalu meng-import seluruh data lama.
// ============================================================================
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("Hanya boleh dijalankan dari terminal (CLI).\n"); }
define('WAKA_CLI', 1);

$file = $argv[1] ?? null;
if (!$file || !is_readable($file)) {
  fwrite(STDERR, "Penggunaan: php import_cli.php <file-backup.json>\n");
  exit(1);
}
if (!file_exists(__DIR__ . '/config.php')) {
  fwrite(STDERR, "config.php tidak ditemukan di folder ini. Buat dulu dari config.sample.php.\n");
  exit(1);
}

echo "Membaca backup: $file ... ";
$raw = file_get_contents($file);
$data = json_decode($raw, true);
if (!is_array($data)) { fwrite(STDERR, "JSON tidak valid.\n"); exit(1); }
echo "OK (" . number_format(strlen($raw) / 1024) . " KB)\n";

require __DIR__ . '/index.php'; // memuat fungsi doImport() dsb. (router web dilewati via WAKA_CLI)

echo "Meng-import ke MySQL (" . WAKA_DB_NAME . ") ...\n";
try {
  $counts = doImport($data);
  foreach ($counts as $k => $v) printf("  %-14s: %d record\n", $k, $v);
  echo "SELESAI. Data lama berhasil dimigrasikan.\n";
} catch (Throwable $e) {
  fwrite(STDERR, "GAGAL: " . $e->getMessage() . "\n");
  exit(1);
}
