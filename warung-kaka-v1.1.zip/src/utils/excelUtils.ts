import * as XLSX from 'xlsx';
import { Customer, Invoice } from '../types';
import { getLocalCustomers } from '../services/gasService';
import { isInvoiceLocked } from './slipUtils';

export interface EmployeeExportRow {
  no: number;
  rowId: string;
  noNota: string;
  name: string;
  phone: string;
  date: string;
  itemName: string;
  qty: number;
  price: number;
  total: number;
  division?: string;
  nominal: number; // Compatibility with prior code
  slip?: string;
  keterangan?: string;
}

// Known master employees list from template / WAKA ecosystem
export const KNOWN_EMPLOYEE_DIRECTORY: Array<{ name: string; division: string; phone: string }> = [
  { name: 'DAHLAN', division: 'ERVO PRINT', phone: '082219249173' },
  { name: 'ARDI', division: 'ERVO SUBLIME', phone: '083896361444' },
  { name: 'IMAN', division: 'ERVO SUBLIME', phone: '085607487367' },
  { name: 'HOLIS', division: 'ERVO SUBLIME', phone: '085703272429' },
  { name: 'NOVI', division: 'GUDANG POLOSAN', phone: '081324086871' },
  { name: 'MUIZ', division: 'ERVO STORE', phone: '082316894235' },
  { name: 'CLARA', division: 'ERVO STORE', phone: '085722706105' },
  { name: 'GUGUM', division: 'ERVO PRINT', phone: '081312161206' },
  { name: 'MAMAN', division: 'ERVO STORE', phone: '0882001361944' },
  { name: 'AGUS', division: 'ERVO PRINT', phone: '083143135894' },
  { name: 'IZHAR', division: 'ERVO STORE', phone: '081324830983' },
  { name: 'FAUZY', division: 'ERVO PRINT', phone: '088218197329' },
];

/**
 * Helper to parse employee name and division
 * Example: "Holis (Ervo Sublime)" -> name: "HOLIS", division: "ERVO SUBLIME"
 */
export function parseEmployeeNameAndDivision(
  rawName: string, 
  customerObj?: Customer
): { name: string; division: string; phone?: string } {
  let name = (rawName || '').trim();
  let division = (customerObj?.divisi || customerObj?.division || '').trim();
  let phone = customerObj?.telepon || '';

  // Fallback to local customer database if customerObj is undefined
  if (!customerObj && typeof window !== 'undefined') {
    try {
      const cleanUpper = name.toUpperCase().replace(/\(.*?\)/g, '').trim();
      const localList = getLocalCustomers();
      const matched = localList.find((c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === cleanUpper);
      if (matched) {
        customerObj = matched;
        if (!division) division = (matched.divisi || matched.division || '').trim();
        if (!phone) phone = matched.telepon || '';
      }
    } catch {}
  }

  // 1. Check for parenthesis: e.g. "Holis (Ervo Sublime)" or "Novi (Gudang Polosan)"
  const parenMatch = name.match(/^(.*?)\s*\((.*?)\)$/);
  if (parenMatch) {
    name = parenMatch[1].trim();
    if (!division) division = parenMatch[2].trim();
  }

  // 2. Check for delimiter dash or slash in name: e.g. "AGUS - ERVO STORE" or "IZHAR / ERVO STORE"
  if (!division) {
    const dashMatch = name.match(/^(.*?)\s*[-–\/:]\s*(.+)$/);
    if (dashMatch) {
      name = dashMatch[1].trim();
      division = dashMatch[2].trim();
    }
  }

  // 3. Check customer object fields (catatan, kelas, alamat)
  if (!division && customerObj) {
    if (customerObj.catatan && customerObj.catatan.trim()) {
      division = customerObj.catatan.trim();
    } else if (customerObj.kelas && customerObj.kelas.toLowerCase().includes('karyawan')) {
      const classMatch = customerObj.kelas.match(/karyawan\s*[-–:]\s*(.+)/i);
      if (classMatch) {
        division = classMatch[1].trim();
      }
    } else if (customerObj.alamat && customerObj.alamat.trim() && !customerObj.alamat.toLowerCase().includes('jl')) {
      division = customerObj.alamat.trim();
    }
  }

  // 4. Check known employee directory for master team members
  const cleanUpper = name.toUpperCase().replace(/\(.*?\)/g, '').trim();
  const known = KNOWN_EMPLOYEE_DIRECTORY.find((k) => k.name === cleanUpper);
  if (known) {
    if (!division) division = known.division;
    if (!phone) phone = known.phone;
  }

  return {
    name: name.toUpperCase(),
    division: division ? division.toUpperCase() : '',
    phone: cleanPhoneNumber(phone || known?.phone),
  };
}

/**
 * Helper to resolve customer/employee division accurately.
 * References:
 * 1. Explicit customer object field (divisi / division)
 * 2. Mapped customer directory from database / list
 * 3. Known directory (KNOWN_EMPLOYEE_DIRECTORY)
 * 4. Extracted from name patterns (e.g., "Holis (Ervo Sublime)") or remarks / address
 */
export function getCustomerDivision(
  name?: string,
  customerList?: Customer[],
  directCustObj?: Customer
): string {
  if (!name && !directCustObj) return '';
  const targetName = (name || directCustObj?.nama || '').trim();
  const cleanName = targetName.toUpperCase().replace(/\(.*?\)/g, '').trim();

  let cust = directCustObj;
  if (!cust && customerList && customerList.length > 0) {
    cust = customerList.find(
      (c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === cleanName
    );
  }

  const parsed = parseEmployeeNameAndDivision(targetName, cust);
  return (cust?.divisi || cust?.division || parsed.division || '').trim().toUpperCase();
}

/**
 * Normalizes any date string (DD/MM/YYYY, YYYY-MM-DD, ISO string) to standard YYYY-MM-DD format
 */
export function normalizeToYMD(dateStr?: string): string {
  if (!dateStr) return '';
  const s = String(dateStr).trim();

  // Format DD/MM/YYYY or DD-MM-YYYY (e.g. 24/08/2026 or 24-08-2026)
  const dmyMatch = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
  if (dmyMatch) {
    const [, d, m, y] = dmyMatch;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }

  // Format YYYY-MM-DD or YYYY/MM/DD or ISO string 2026-08-24T...
  const ymdMatch = s.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
  if (ymdMatch) {
    const [, y, m, d] = ymdMatch;
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }

  return s;
}

/**
 * Checks if an employee's division matches the selected filter (string or array of strings)
 */
export function matchesDivisionFilter(empDivision: string, filterDivision?: string | string[]): boolean {
  if (!filterDivision) return true;
  if (Array.isArray(filterDivision)) {
    if (filterDivision.length === 0 || filterDivision.includes('ALL')) return true;
    return filterDivision.some((f) => matchesSingleDivision(empDivision, f));
  }
  return matchesSingleDivision(empDivision, filterDivision);
}

function matchesSingleDivision(empDivision: string, singleFilter: string): boolean {
  if (!singleFilter || singleFilter === 'ALL' || singleFilter.trim() === '') return true;
  const d1 = (empDivision || '').trim().toUpperCase();
  const d2 = singleFilter.trim().toUpperCase();
  if (d1 === d2) return true;
  if (d1.includes(d2) || d2.includes(d1)) return true;
  const d1Clean = d1.replace(/^ERVO\s+/, '').trim();
  const d2Clean = d2.replace(/^ERVO\s+/, '').trim();
  return d1Clean === d2Clean;
}

/**
 * Clean phone number to standard text format (e.g., 082219249173)
 */
export function cleanPhoneNumber(rawPhone?: string): string {
  if (!rawPhone) return '';
  let cleaned = rawPhone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('62')) {
    cleaned = '0' + cleaned.slice(2);
  }
  return cleaned;
}

/**
 * Helper to extract items safely from an invoice (handling arrays, stringified JSON, and alternative property names)
 */
export function extractInvoiceItems(inv: any): any[] {
  if (!inv) return [];
  if (Array.isArray(inv.items) && inv.items.length > 0) return inv.items;
  if (typeof inv.items === 'string' && inv.items.trim()) {
    try {
      const parsed = JSON.parse(inv.items);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    } catch {}
  }
  if (Array.isArray(inv.barang) && inv.barang.length > 0) return inv.barang;
  if (typeof inv.barang === 'string' && inv.barang.trim()) {
    try {
      const parsed = JSON.parse(inv.barang);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    } catch {}
  }
  return [];
}

/**
 * Build export rows for all employees or active debtors synchronized with Piutang View
 */
export function buildEmployeeExportRows(params: {
  groupedCustomers: Array<{
    customer: string;
    invoices: Invoice[];
    totalUnpaid: number;
    phone?: string;
    potongGajiUnpaid: number;
  }>;
  customers: Customer[];
  startDate?: string;
  endDate?: string;
  divisionFilter?: string | string[];
  exportDate?: string;
  keterangan?: string;
  exportScope?: 'all_karyawan' | 'only_unpaid';
  onlyLockedTransactions?: boolean;
  specificSlipNo?: number | 'all_locked' | 'all';
  includeInvoiceNumbers?: boolean;
}): EmployeeExportRow[] {
  const {
    groupedCustomers,
    customers,
    startDate,
    endDate,
    divisionFilter = 'ALL',
  } = params;

  const startYMD = startDate ? normalizeToYMD(startDate) : '';
  const endYMD = endDate ? normalizeToYMD(endDate) : '';

  const rows: EmployeeExportRow[] = [];
  const processedCustomerKeys = new Set<string>();

  // Helper to filter invoice by locked status and date range
  const isInvoiceEligible = (inv: Invoice): boolean => {
    const isLocked = isInvoiceLocked(inv);
    if (params.onlyLockedTransactions === true && !isLocked) {
      return false;
    }

    if (startYMD && endYMD && inv.date) {
      const invYMD = normalizeToYMD(inv.date);
      if (invYMD && (invYMD < startYMD || invYMD > endYMD)) {
        return false;
      }
    }
    return true;
  };

  // Helper to render an invoice into export row(s)
  const renderInvoiceRows = (
    inv: Invoice,
    customerDisplayName: string,
    customerDivision: string,
    customerPhone: string,
    invIdx: number
  ) => {
    const invNo = (inv.invoiceNo || (inv as any).noInvoice || `INV-${invIdx + 1}`).trim();
    const invDate = normalizeToYMD(inv.date || (inv as any).tanggal || (inv as any).createdAt || '');
    const slipText = inv.slipNo ? `Slip #${inv.slipNo}` : (inv.time ? `${inv.time}` : 'Slip #1');
    const items = extractInvoiceItems(inv);

    const invSisa = (inv as any).calculatedSisa !== undefined
      ? Number((inv as any).calculatedSisa)
      : Number(inv.sisa !== undefined ? inv.sisa : inv.total || 0);

    if (items.length > 0) {
      items.forEach((item: any, itemIdx: number) => {
        const itemQty = Number(item.qty || item.jumlah || 1);
        const itemPrice = Number(item.harga || item.price || item.hargaSatuan || 0);
        const itemTotal = Number(
          item.totalItem !== undefined && item.totalItem !== null
            ? item.totalItem
            : (itemQty * itemPrice - (Number(item.diskonItem) || 0))
        );
        const itemName = item.nama || item.name || item.namaBarang || item.menuName || item.keterangan || 'Item Belanja';

        rows.push({
          no: rows.length + 1,
          rowId: `${customerDisplayName}_${invNo}_item_${itemIdx}_${item.kode || item.nama || itemIdx}`,
          noNota: invNo,
          name: customerDisplayName,
          phone: cleanPhoneNumber(customerPhone),
          date: invDate || normalizeToYMD(new Date().toISOString().split('T')[0]),
          itemName,
          qty: itemQty,
          price: itemPrice,
          total: itemTotal > 0 ? itemTotal : (itemQty * itemPrice),
          division: customerDivision,
          nominal: itemTotal > 0 ? itemTotal : (itemQty * itemPrice),
          slip: slipText,
          keterangan: item.catatan || '',
        });
      });
    } else {
      // Fallback row if no items array
      rows.push({
        no: rows.length + 1,
        rowId: `${customerDisplayName}_${invNo}_${invIdx}`,
        noNota: invNo,
        name: customerDisplayName,
        phone: cleanPhoneNumber(customerPhone),
        date: invDate || normalizeToYMD(new Date().toISOString().split('T')[0]),
        itemName: (inv as any).keterangan || 'Pembelian/Belanja',
        qty: 1,
        price: invSisa > 0 ? invSisa : Number(inv.total || 0),
        total: invSisa > 0 ? invSisa : Number(inv.total || 0),
        division: customerDivision,
        nominal: invSisa > 0 ? invSisa : Number(inv.total || 0),
        slip: slipText,
        keterangan: (inv as any).keterangan || (invSisa <= 0 ? 'Lunas' : 'Belum Lunas'),
      });
    }
  };

  // 1. Process active debtors from groupedCustomers (guaranteed to match Piutang View)
  groupedCustomers.forEach((g) => {
    const rawName = (g.customer || 'Umum').trim();
    const cleanKey = rawName.toUpperCase().replace(/\(.*?\)/g, '').trim();
    if (!cleanKey || cleanKey === 'UMUM' || processedCustomerKeys.has(cleanKey)) return;

    const custObj = customers.find(
      (c) => c.nama.toUpperCase().replace(/\(.*?\)/g, '').trim() === cleanKey
    );
    const parsed = parseEmployeeNameAndDivision(rawName, custObj);
    const finalDivision = (custObj?.divisi || custObj?.division || parsed.division || '').trim().toUpperCase();

    // Check division filter
    if (!matchesDivisionFilter(finalDivision, divisionFilter)) {
      return;
    }

    processedCustomerKeys.add(cleanKey);

    const eligibleInvoices = (g.invoices || []).filter((inv) => {
      if (!isInvoiceEligible(inv)) return false;
      const sisa = (inv as any).calculatedSisa !== undefined
        ? Number((inv as any).calculatedSisa)
        : Number(inv.sisa !== undefined ? inv.sisa : inv.total || 0);
      return sisa > 0;
    });

    const finalPhone = custObj?.telepon || g.phone || parsed.phone || '';
    const displayName = parsed.name || cleanKey;

    if (eligibleInvoices.length > 0) {
      eligibleInvoices.forEach((inv, invIdx) => {
        renderInvoiceRows(inv, displayName, finalDivision, finalPhone, invIdx);
      });
    } else if (params.exportScope === 'all_karyawan') {
      rows.push({
        no: rows.length + 1,
        rowId: `${displayName}_none`,
        noNota: '-',
        name: displayName,
        phone: cleanPhoneNumber(finalPhone),
        date: startDate || normalizeToYMD(new Date().toISOString().split('T')[0]),
        itemName: '-',
        qty: 0,
        price: 0,
        total: 0,
        division: finalDivision,
        nominal: 0,
        slip: '-',
        keterangan: 'Tidak ada piutang',
      });
    }
  });

  // 2. If exportScope is 'all_karyawan', include registered customers who don't have active debt
  if (params.exportScope === 'all_karyawan') {
    customers.forEach((cust) => {
      const rawName = (cust.nama || '').trim();
      const cleanKey = rawName.toUpperCase().replace(/\(.*?\)/g, '').trim();
      if (!cleanKey || cleanKey === 'UMUM' || processedCustomerKeys.has(cleanKey)) return;

      const parsed = parseEmployeeNameAndDivision(rawName, cust);
      const finalDivision = (cust.divisi || cust.division || parsed.division || '').trim().toUpperCase();

      if (!matchesDivisionFilter(finalDivision, divisionFilter)) return;
      processedCustomerKeys.add(cleanKey);

      const displayName = parsed.name || cleanKey;
      rows.push({
        no: rows.length + 1,
        rowId: `${displayName}_none`,
        noNota: '-',
        name: displayName,
        phone: cleanPhoneNumber(cust.telepon || parsed.phone),
        date: startDate || normalizeToYMD(new Date().toISOString().split('T')[0]),
        itemName: '-',
        qty: 0,
        price: 0,
        total: 0,
        division: finalDivision,
        nominal: 0,
        slip: '-',
        keterangan: 'Tidak ada piutang',
      });
    });
  }

  // Re-number sequentially
  rows.forEach((r, idx) => {
    r.no = idx + 1;
  });

  return rows;
}

/**
 * Generate and download Excel with per-item breakdown formatted as requested:
 * Headers:
 * A: No Nota
 * B: Nama Karyawan
 * C: No. WA
 * D: Tanggal
 * E: Item Barang
 * F: Qty
 * G: Harga Satuan
 * H: Total
 */
export function exportEmployeePiutangToExcel(
  rows: EmployeeExportRow[],
  filenameDate: string = new Date().toISOString().split('T')[0]
) {
  // Construct AOA (Array of Arrays) matching exact picture format + No. WA
  const headers = [
    'No Nota',
    'Nama Karyawan',
    'No. WA',
    'Tanggal',
    'Item Barang',
    'Qty',
    'Harga Satuan',
    'Total',
  ];

  const dataRows = rows.map((r) => [
    r.noNota || '',
    r.name || '',
    r.phone || '',
    r.date || '',
    r.itemName || '',
    Number(r.qty || 0),
    Number(r.price || 0),
    Number(r.total || 0),
  ]);

  const aoa = [headers, ...dataRows];

  // Create worksheet
  const ws = XLSX.utils.aoa_to_sheet(aoa);

  // Set explicit cell types for phone numbers so Excel treats them as string (preserving leading zero e.g. 0812...)
  dataRows.forEach((row, rowIdx) => {
    const phoneCellRef = XLSX.utils.encode_cell({ r: rowIdx + 1, c: 2 }); // Column C (0-indexed 2)
    if (ws[phoneCellRef]) {
      ws[phoneCellRef].t = 's'; // string type
      ws[phoneCellRef].v = String(row[2] || '');
    }

    // Explicit format for Harga Satuan and Total as numbers
    const priceCellRef = XLSX.utils.encode_cell({ r: rowIdx + 1, c: 6 });
    if (ws[priceCellRef]) {
      ws[priceCellRef].z = '#,##0';
    }
    const totalCellRef = XLSX.utils.encode_cell({ r: rowIdx + 1, c: 7 });
    if (ws[totalCellRef]) {
      ws[totalCellRef].z = '#,##0';
    }
  });

  // Set column widths for optimal reading matching image layout
  ws['!cols'] = [
    { wch: 18 }, // No Nota
    { wch: 22 }, // Nama Karyawan
    { wch: 18 }, // No. WA
    { wch: 14 }, // Tanggal
    { wch: 26 }, // Item Barang
    { wch: 8 },  // Qty
    { wch: 16 }, // Harga Satuan
    { wch: 16 }, // Total
  ];

  // Create workbook
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Rekap Piutang');

  // File name: Rekap_WAKA_{rentang_tanggal}.xlsx
  const filename = filenameDate.startsWith('Rekap_WAKA_')
    ? (filenameDate.endsWith('.xlsx') ? filenameDate : `${filenameDate}.xlsx`)
    : `Rekap_WAKA_${filenameDate}.xlsx`;
  XLSX.writeFile(wb, filename);
}

