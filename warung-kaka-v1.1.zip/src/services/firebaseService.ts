import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit, 
  writeBatch,
  serverTimestamp 
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { getDeletedCustomers, recalculateInvoiceSisaAndStatus, getLocalProducts, mergePelunasanHistories } from './gasService';
import { 
  Product, 
  Customer, 
  StoreSettings, 
  Invoice, 
  InvoiceItem,
  KasirUser, 
  StockInRecord, 
  ExpenseRecord,
  PelunasanRecord,
  StockOpnameRecord
} from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Real-time Listeners with Caching Strategy
export function subscribeProducts(callback: (products: Product[]) => void) {
  const colRef = collection(db, 'products');
  return onSnapshot(colRef, (snapshot) => {
    const list: Product[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      list.push({
        kode: data.kode || docSnap.id,
        nama: data.nama || '',
        harga: Number(data.harga || 0),
        hargaBeli: data.hargaBeli !== undefined && data.hargaBeli !== null ? Number(data.hargaBeli) : (data.hpp !== undefined && data.hpp !== null ? Number(data.hpp) : undefined),
        hpp: data.hargaBeli !== undefined && data.hargaBeli !== null ? Number(data.hargaBeli) : (data.hpp !== undefined && data.hpp !== null ? Number(data.hpp) : undefined),
        kategori: data.kategori || 'Lainnya',
        stok: data.stok !== undefined && data.stok !== null ? String(data.stok) : '',
        satuan: data.satuan || 'pcs',
        tipeHarga: data.tipeHarga || 'fix',
      });
    });
    // Deduplicate products by kode and nama
    const seen = new Set<string>();
    const uniqueList: Product[] = [];
    for (const p of list) {
      if (!p || !p.nama) continue;
      const kKey = p.kode ? p.kode.trim().toLowerCase() : '';
      const nKey = p.nama.trim().toLowerCase();
      const primaryKey = kKey || nKey;
      if (!seen.has(primaryKey) && !seen.has(nKey)) {
        if (kKey) seen.add(kKey);
        seen.add(nKey);
        uniqueList.push(p);
      }
    }

    // Update local cache for instant zero-latency loading on boot
    localStorage.setItem('strukku_products', JSON.stringify(uniqueList));
    callback(uniqueList);
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'products');
  });
}

export function subscribeCustomers(callback: (customers: Customer[]) => void) {
  const colRef = collection(db, 'customers');
  return onSnapshot(colRef, (snapshot) => {
    const custMap = new Map<string, Customer>();
    const deletedNames = getDeletedCustomers();
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      const name = (data.nama || docSnap.id || '').trim();
      if (name && !deletedNames.has(name.toLowerCase())) {
        const divClean = (data.divisi || data.division || '').trim();
        const custObj: Customer = {
          nama: name,
          kelas: data.kelas || 'Reguler',
          divisi: divClean,
          division: divClean,
          diskon: Number(data.diskon || 0),
          telepon: data.telepon || '',
          catatan: data.catatan || '',
          alamat: data.alamat || '',
        };
        // Deduplicate by case-insensitive name
        const key = name.toLowerCase();
        // If docId matches exactly, prioritize this doc
        if (!custMap.has(key) || docSnap.id === name) {
          custMap.set(key, custObj);
        }
      }
    });

    const list: Customer[] = Array.from(custMap.values());
    localStorage.setItem('strukku_customers', JSON.stringify(list));
    localStorage.setItem('warung_kaka_customers', JSON.stringify(list));
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'customers');
  });
}

export function subscribeKasirUsers(callback: (users: KasirUser[]) => void) {
  const colRef = collection(db, 'kasirUsers');
  return onSnapshot(colRef, (snapshot) => {
    const list: KasirUser[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      const name = (data.nama || docSnap.id).trim();
      const lower = name.toLowerCase();
      let role = data.role ? String(data.role).trim().toLowerCase() : '';
      if (!role) {
        if (lower === 'admin' || lower.includes('owner')) role = 'owner';
        else if (lower.includes('spv') || lower.includes('supervisor')) role = 'spv';
        else role = 'kasir';
      }
      list.push({
        nama: name,
        password: data.password || 'ervo123',
        role: role,
      });
    });
    const finalList = list.length > 0 ? list : [{ nama: 'Admin', password: 'admin', role: 'owner' }];
    localStorage.setItem('strukku_kasir_users', JSON.stringify(finalList));
    localStorage.setItem('strukku_kasir_list', JSON.stringify(finalList.map((u) => u.nama)));
    callback(finalList);
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'kasirUsers');
  });
}

export function subscribeSettings(callback: (settings: Partial<StoreSettings>) => void) {
  const docRef = doc(db, 'settings', 'store');
  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      const data = docSnap.data();
      const cfg: Partial<StoreSettings> = {
        name: data.name,
        tagline: data.tagline,
        address: data.address,
        phone: data.phone,
        footer: data.footer,
        prefixInvoice: data.prefixInvoice,
        rekening: data.rekening,
        autoLogoutMinutes: data.autoLogoutMinutes,
        minStockThreshold: data.minStockThreshold,
      };
      localStorage.setItem('strukku_sheet_settings', JSON.stringify(cfg));
      callback(cfg);
    }
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'settings/store');
  });
}

export async function saveStoreSettingsFirebase(settings: Partial<StoreSettings>): Promise<void> {
  const docRef = doc(db, 'settings', 'store');
  await setDoc(docRef, {
    ...settings,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export function subscribeInvoices(callback: (invoices: Invoice[]) => void) {
  const colRef = collection(db, 'invoices');
  return onSnapshot(colRef, (snapshot) => {
    const list: Invoice[] = [];
    snapshot.forEach((docSnap) => {
      const d = docSnap.data();
      const invNo = d.invoiceNo || d.noInvoice || docSnap.id;
      const rawInv: Invoice = {
        invoiceNo: invNo,
        noInvoice: invNo,
        date: d.date || d.tanggal || '',
        time: d.time || d.jam || '',
        cashier: d.cashier || d.kasir || 'Admin',
        customer: d.customer || d.pelanggan || 'Umum',
        payMethod: d.payMethod || d.metodePembayaran || 'Tunai',
        subtotal: Number(d.subtotal || 0),
        discPct: Number(d.discPct || d.diskonPct || 0),
        discAmt: Number(d.discAmt || d.diskonNominal || 0),
        taxPct: Number(d.taxPct || d.pajakPct || 0),
        taxAmt: Number(d.taxAmt || d.pajakNominal || 0),
        negoAmt: Number(d.negoAmt || d.negoNominal || 0),
        total: Number(d.total || 0),
        dp: Number(d.dp || d.bayarDp || 0),
        sisa: Number(d.sisa || d.sisaPiutang || 0),
        kembalian: Number(d.kembalian || 0),
        deadline: d.deadline || '',
        status: d.status || 'LUNAS',
        items: (() => {
          if (Array.isArray(d.items)) return d.items;
          if (typeof d.items === 'string' && d.items.trim()) {
            try {
              const parsed = JSON.parse(d.items);
              if (Array.isArray(parsed)) return parsed;
            } catch {}
          }
          if (Array.isArray(d.barang)) return d.barang;
          if (typeof d.barang === 'string' && d.barang.trim()) {
            try {
              const parsed = JSON.parse(d.barang);
              if (Array.isArray(parsed)) return parsed;
            } catch {}
          }
          return [];
        })(),
        pelunasanHistory: Array.isArray(d.pelunasanHistory) ? d.pelunasanHistory : (Array.isArray(d.historiPelunasan) ? d.historiPelunasan : []),
        historiPelunasan: Array.isArray(d.historiPelunasan) ? d.historiPelunasan : (Array.isArray(d.pelunasanHistory) ? d.pelunasanHistory : []),
        lastEditedBy: d.lastEditedBy,
        lastEditedAt: d.lastEditedAt,
        editReason: d.editReason,
        auditLogs: Array.isArray(d.auditLogs) ? d.auditLogs : [],
        slipNo: d.slipNo !== undefined && d.slipNo !== null && d.slipNo !== '' ? Number(d.slipNo) : undefined,
        slipPrinted: Boolean(d.slipPrinted),
        slipPrintedAt: d.slipPrintedAt || '',
      };
      const processed = recalculateInvoiceSisaAndStatus(rawInv);
      list.push(processed);
    });
    // Sort descending by invoiceNo
    list.sort((a, b) => (b.invoiceNo || '').localeCompare(a.invoiceNo || ''));

    // Update local cache so all modals (Reprint, Pelunasan, Laporan) get instant multi-device real-time sync
    if (list.length > 0) {
      const recentFormat = list.map((inv) => {
        const method = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
        return {
          invoiceNo: inv.invoiceNo,
          date: inv.date,
          time: inv.time,
          customer: inv.customer,
          cashier: inv.cashier,
          payMethod: method,
          metodePembayaran: method,
          total: inv.total,
          dp: inv.dp,
          sisa: inv.sisa,
          status: inv.status,
          items: inv.items,
          historiPelunasan: inv.pelunasanHistory || [],
          slipNo: inv.slipNo,
          slipPrinted: inv.slipPrinted,
          slipPrintedAt: inv.slipPrintedAt,
        };
      });
      localStorage.setItem('strukku_recent_invoices', JSON.stringify(recentFormat));

      const allPelunasan: PelunasanRecord[] = [];
      list.forEach((inv) => {
        if (Array.isArray(inv.pelunasanHistory)) {
          allPelunasan.push(...inv.pelunasanHistory);
        }
      });
      const dedupedPelunasan = mergePelunasanHistories(allPelunasan, []);
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(dedupedPelunasan));
    }

    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'invoices');
  });
}

export function subscribeExpenses(callback: (expenses: ExpenseRecord[]) => void) {
  const colRef = collection(db, 'expenses');
  return onSnapshot(colRef, (snapshot) => {
    const list: ExpenseRecord[] = [];
    snapshot.forEach((docSnap) => {
      const d = docSnap.data();
      list.push({
        id: d.id || docSnap.id,
        tanggal: d.tanggal || '',
        kategori: d.kategori || 'Operasional',
        keterangan: d.keterangan || '',
        nominal: Number(d.nominal || 0),
        pj: d.pj || 'Admin',
      });
    });
    // Deduplicate by ID
    const seen = new Set<string>();
    const unique: ExpenseRecord[] = [];
    for (const item of list) {
      if (!item) continue;
      const key = item.id ? item.id.trim() : `${item.tanggal}-${item.keterangan}-${item.nominal}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(item);
      }
    }
    unique.sort((a, b) => b.tanggal.localeCompare(a.tanggal));
    localStorage.setItem('strukku_company_expenses', JSON.stringify(unique));
    callback(unique);
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'expenses');
  });
}

export function subscribeStockOpname(callback: (records: StockOpnameRecord[]) => void) {
  const colRef = collection(db, 'stockOpname');
  return onSnapshot(colRef, (snapshot) => {
    const list: StockOpnameRecord[] = [];
    snapshot.forEach((docSnap) => {
      const d = docSnap.data();
      list.push({
        id: docSnap.id,
        tanggal: d.tanggal || '',
        jam: d.jam || '',
        bulanPeriode: d.bulanPeriode || '',
        petugas: d.petugas || 'Admin',
        penanggungJawab: d.penanggungJawab || '',
        totalItemDihitung: Number(d.totalItemDihitung || (Array.isArray(d.items) ? d.items.length : 0)),
        totalItemSesuai: Number(d.totalItemSesuai || 0),
        totalItemSelisihKurang: Number(d.totalItemSelisihKurang || 0),
        totalItemSelisihLebih: Number(d.totalItemSelisihLebih || 0),
        totalNilaiSelisih: Number(d.totalNilaiSelisih || 0),
        catatanUmum: d.catatanUmum || '',
        items: Array.isArray(d.items) ? d.items : [],
      });
    });
    list.sort((a, b) => {
      const cmpDate = (b.tanggal || '').localeCompare(a.tanggal || '');
      if (cmpDate !== 0) return cmpDate;
      return (b.jam || '').localeCompare(a.jam || '');
    });
    localStorage.setItem('strukku_stock_opname_history', JSON.stringify(list));
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'stockOpname');
  });
}

// Single Action Helper Functions

export function sanitizeForFirestore(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item));
  }
  // If it's a Date or special Firestore FieldValue, preserve it
  if (obj instanceof Date || (typeof obj === 'object' && obj && (obj._methodName || (obj as any).isEqual))) {
    return obj;
  }
  const clean: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined && typeof value !== 'function') {
      clean[key] = typeof value === 'object' && value !== null ? sanitizeForFirestore(value) : value;
    }
  }
  return clean;
}

export async function saveProductFirebase(product: Product): Promise<void> {
  const docId = product.kode.trim() || `PROD-${Date.now()}`;
  const cleanData = sanitizeForFirestore(product);
  await setDoc(doc(db, 'products', docId), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function deleteProductFirebase(kode: string): Promise<void> {
  await deleteDoc(doc(db, 'products', kode.trim()));
}

export async function saveCustomerFirebase(customer: Customer, oldName?: string): Promise<void> {
  const cleanName = customer.nama.trim();
  const docId = cleanName || `CUST-${Date.now()}`;
  const cleanData = sanitizeForFirestore(customer);

  if (oldName && oldName.trim() && oldName.trim() !== cleanName) {
    await deleteCustomerFirebase(oldName.trim()).catch(() => {});
  }

  await setDoc(doc(db, 'customers', docId), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function deleteCustomerFirebase(nama: string): Promise<void> {
  const cleanName = nama.trim();
  if (!cleanName) return;

  try {
    // Delete by exact name doc id
    await deleteDoc(doc(db, 'customers', cleanName));
  } catch {}

  try {
    // Also clean up any doc where id matches lowercase or uppercase
    if (cleanName !== cleanName.toLowerCase()) {
      await deleteDoc(doc(db, 'customers', cleanName.toLowerCase())).catch(() => {});
    }
    if (cleanName !== cleanName.toUpperCase()) {
      await deleteDoc(doc(db, 'customers', cleanName.toUpperCase())).catch(() => {});
    }
  } catch {}
}

export async function saveKasirUserFirebase(user: KasirUser): Promise<void> {
  const docId = user.nama.trim();
  const cleanData = sanitizeForFirestore(user);
  await setDoc(doc(db, 'kasirUsers', docId), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function deleteKasirUserFirebase(nama: string): Promise<void> {
  const docId = nama.trim();
  if (!docId) return;
  await deleteDoc(doc(db, 'kasirUsers', docId));
}

export async function saveSettingsFirebase(settings: Partial<StoreSettings>): Promise<void> {
  const cleanData = sanitizeForFirestore(settings);
  await setDoc(doc(db, 'settings', 'store'), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function saveInvoiceFirebase(
  invoice: Invoice,
  options?: { deductStock?: boolean }
): Promise<void> {
  const invNo = (invoice.invoiceNo || invoice.noInvoice || '').trim();
  if (!invNo) return;
  const processed = recalculateInvoiceSisaAndStatus(invoice);
  const cleanData = sanitizeForFirestore(processed);
  const invRef = doc(db, 'invoices', invNo);

  // Check if invoice already exists in Firestore BEFORE deciding to deduct stock
  let isExisting = false;
  try {
    const existingSnap = await getDoc(invRef);
    if (existingSnap.exists()) {
      isExisting = true;
    }
  } catch {}

  await setDoc(invRef, {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });

  // Update stock for products ONLY if this is a BRAND NEW invoice and deductStock is not false
  // Existing invoices (e.g. pelunasan payments, status updates) must NEVER deduct stock again!
  const shouldDeductStock = !isExisting && options?.deductStock !== false;

  if (shouldDeductStock && invoice.items && invoice.items.length > 0) {
    const batch = writeBatch(db);
    for (const item of invoice.items) {
      if (item.kode) {
        const prodRef = doc(db, 'products', item.kode.trim());
        const prodSnap = await getDoc(prodRef);
        if (prodSnap.exists()) {
          const currentStokStr = prodSnap.data().stok;
          if (currentStokStr !== '' && currentStokStr !== null && currentStokStr !== undefined) {
            const currentVal = parseFloat(currentStokStr);
            if (!isNaN(currentVal)) {
              const qty = Number(item.qty || 1);
              const newVal = Math.max(0, currentVal - qty);
              batch.update(prodRef, { stok: String(newVal) });
            }
          }
        }
      }
    }
    await batch.commit().catch((err) => console.warn('Stock update batch failed:', err));
  }
}

export async function updateInvoiceFirebase(
  invoice: Invoice,
  options?: {
    editedBy?: string;
    editReason?: string;
  }
): Promise<void> {
  const invNo = (invoice.invoiceNo || invoice.noInvoice || '').trim();
  if (!invNo) return;

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const dateStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
  const formattedTimestamp = `${dateStr} ${timeStr}`;

  const editLog = options?.editReason || options?.editedBy ? {
    editedBy: options.editedBy || 'SPV/Owner',
    editedAt: formattedTimestamp,
    reason: options.editReason || 'Koreksi Data Transaksi Penjualan',
    previousTotal: invoice.total ?? 0,
    previousPayMethod: invoice.payMethod ?? '',
    previousDp: invoice.dp ?? 0,
    previousSisa: invoice.sisa ?? 0,
    previousCustomer: invoice.customer ?? '',
  } : null;

  const existingLogs = Array.isArray(invoice.auditLogs) ? invoice.auditLogs : [];
  const updatedLogs = editLog ? [editLog, ...existingLogs] : existingLogs;

  const updatedInvoice: Invoice = {
    ...invoice,
    lastEditedBy: options?.editedBy || invoice.lastEditedBy || 'SPV/Owner',
    lastEditedAt: formattedTimestamp,
    editReason: options?.editReason || invoice.editReason || 'Koreksi Data Transaksi',
    auditLogs: updatedLogs,
  };

  const processed = recalculateInvoiceSisaAndStatus(updatedInvoice);
  const cleanData = sanitizeForFirestore(processed);

  await setDoc(doc(db, 'invoices', invNo), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function batchUpdateInvoicesFirebase(invoices: Invoice[]): Promise<void> {
  if (!invoices || invoices.length === 0) return;
  const batch = writeBatch(db);
  for (const inv of invoices) {
    const invNo = (inv.invoiceNo || inv.noInvoice || '').trim();
    if (!invNo) continue;
    const invRef = doc(db, 'invoices', invNo);
    const cleanData = sanitizeForFirestore(inv);
    batch.set(invRef, {
      ...cleanData,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  }
  await batch.commit();
}

export async function recordPelunasanFirebase(payload: PelunasanRecord): Promise<void> {
  const invNo = (payload.invoiceNo || '').trim();
  if (!invNo) return;
  const docRef = doc(db, 'invoices', invNo);
  const docSnap = await getDoc(docRef);
  if (!docSnap.exists()) return;
  const data = docSnap.data();
  const existingHistory: PelunasanRecord[] = Array.isArray(data.pelunasanHistory)
    ? data.pelunasanHistory
    : Array.isArray(data.historiPelunasan)
    ? data.historiPelunasan
    : [];

  const newRecord: PelunasanRecord = {
    ...payload,
    id: payload.id || `PEL-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
  };

  const updatedHistory = mergePelunasanHistories(existingHistory, [newRecord]);
  const currentInvoice: Invoice = {
    invoiceNo: invNo,
    ...data,
    pelunasanHistory: updatedHistory,
    historiPelunasan: updatedHistory,
  } as Invoice;

  const processed = recalculateInvoiceSisaAndStatus(currentInvoice);
  const cleanData = sanitizeForFirestore(processed);

  await setDoc(docRef, {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function batchRecordPelunasanFirebase(payloads: PelunasanRecord[]): Promise<void> {
  if (!payloads || payloads.length === 0) return;
  const batch = writeBatch(db);

  // Fetch unique invoice documents in parallel
  const uniqueInvNos = Array.from(
    new Set(payloads.map((p) => (p.invoiceNo || '').trim()).filter(Boolean))
  );
  
  const docSnaps = await Promise.all(
    uniqueInvNos.map((invNo) => getDoc(doc(db, 'invoices', invNo)))
  );

  const docMap = new Map<string, any>();
  docSnaps.forEach((snap, idx) => {
    if (snap.exists()) {
      docMap.set(uniqueInvNos[idx], snap.data());
    }
  });

  // Group payloads by invoiceNo
  const payloadsByInv = new Map<string, PelunasanRecord[]>();
  payloads.forEach((p) => {
    const invNo = (p.invoiceNo || '').trim();
    if (!invNo) return;
    if (!payloadsByInv.has(invNo)) payloadsByInv.set(invNo, []);
    payloadsByInv.get(invNo)!.push({
      ...p,
      id: p.id || `PEL-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    });
  });

  for (const [invNo, records] of payloadsByInv.entries()) {
    const data = docMap.get(invNo);
    if (!data) continue;
    const existingHistory: PelunasanRecord[] = Array.isArray(data.pelunasanHistory)
      ? data.pelunasanHistory
      : Array.isArray(data.historiPelunasan)
      ? data.historiPelunasan
      : [];

    const updatedHistory = mergePelunasanHistories(existingHistory, records);
    const currentInvoice: Invoice = {
      invoiceNo: invNo,
      ...data,
      pelunasanHistory: updatedHistory,
      historiPelunasan: updatedHistory,
    } as Invoice;

    const processed = recalculateInvoiceSisaAndStatus(currentInvoice);
    const cleanData = sanitizeForFirestore(processed);
    const docRef = doc(db, 'invoices', invNo);
    batch.set(docRef, {
      ...cleanData,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  }

  await batch.commit();
}

export async function deleteInvoiceFirebase(
  invoiceNo: string,
  targetInvoiceItems?: InvoiceItem[]
): Promise<{ restoredItemsCount: number; restoredDetails: { kode: string; nama: string; qty: number }[] }> {
  const invNo = (invoiceNo || '').trim();
  if (!invNo) return { restoredItemsCount: 0, restoredDetails: [] };

  const restoredDetails: { kode: string; nama: string; qty: number }[] = [];
  let itemsToRestore: InvoiceItem[] = Array.isArray(targetInvoiceItems) && targetInvoiceItems.length > 0 
    ? [...targetInvoiceItems] 
    : [];

  const invRef = doc(db, 'invoices', invNo);

  // If no items were passed or array is empty, read the invoice document from Firestore first
  if (itemsToRestore.length === 0) {
    try {
      const invSnap = await getDoc(invRef);
      if (invSnap.exists()) {
        const invData = invSnap.data();
        let extracted: any[] = [];
        if (Array.isArray(invData.items)) {
          extracted = invData.items;
        } else if (typeof invData.items === 'string' && invData.items.trim()) {
          try {
            const parsed = JSON.parse(invData.items);
            if (Array.isArray(parsed)) extracted = parsed;
          } catch {}
        } else if (Array.isArray(invData.barang)) {
          extracted = invData.barang;
        } else if (typeof invData.barang === 'string' && invData.barang.trim()) {
          try {
            const parsed = JSON.parse(invData.barang);
            if (Array.isArray(parsed)) extracted = parsed;
          } catch {}
        }
        if (extracted.length > 0) {
          itemsToRestore = extracted;
        }
      }
    } catch (err) {
      console.warn('Failed reading invoice before deletion:', err);
    }
  }

  // Fallback: check recent invoice cache from localStorage if itemsToRestore is still empty
  if (itemsToRestore.length === 0) {
    try {
      const cached = localStorage.getItem('strukku_recent_invoices');
      if (cached) {
        const parsedList = JSON.parse(cached);
        const match = parsedList.find((i: any) => (i.invoiceNo || i.noInvoice)?.trim().toLowerCase() === invNo.toLowerCase());
        if (match && Array.isArray(match.items) && match.items.length > 0) {
          itemsToRestore = match.items;
        }
      }
    } catch {}
  }

  // If items exist, batch update the product stock in Firestore to return the quantities
  if (itemsToRestore.length > 0) {
    try {
      const prodSnapshot = await getDocs(collection(db, 'products'));
      const localProducts = getLocalProducts();
      const batch = writeBatch(db);

      // Track updated doc IDs to accumulate quantities if multiple items point to the same product
      const updatedDocMap = new Map<string, { ref: any; currentVal: number; addedQty: number; kode: string; nama: string; extraFields?: any }>();

      for (const item of itemsToRestore) {
        const qty = Number(item.qty || 1);
        if (qty <= 0) continue;

        const itKode = (item.kode || '').trim().toLowerCase();
        const itNama = (item.nama || '').trim().toLowerCase();

        // 1. Find matching document in Firestore products collection
        const matchedDocSnap = prodSnapshot.docs.find((dSnap) => {
          const dData = dSnap.data();
          const docId = dSnap.id.trim().toLowerCase();
          const dKode = String(dData.kode || '').trim().toLowerCase();
          const dNama = String(dData.nama || '').trim().toLowerCase();

          // Direct docId match
          if (itKode && (docId === itKode || docId === toSafeDocId(itKode).toLowerCase())) return true;
          // Kode field match
          if (itKode && dKode === itKode) return true;
          // Nama field match (exact or whitespace stripped)
          if (itNama && (dNama === itNama || dNama.replace(/\s+/g, '') === itNama.replace(/\s+/g, ''))) return true;
          return false;
        });

        // 2. Also check local product directory for fallback data
        const localMatched = localProducts.find((p) => {
          const pKode = (p.kode || '').trim().toLowerCase();
          const pNama = (p.nama || '').trim().toLowerCase();
          return (itKode && pKode === itKode) || (itNama && (pNama === itNama || pNama.replace(/\s+/g, '') === itNama.replace(/\s+/g, '')));
        });

        if (matchedDocSnap) {
          const dId = matchedDocSnap.id;
          const dData = matchedDocSnap.data();
          if (updatedDocMap.has(dId)) {
            const entry = updatedDocMap.get(dId)!;
            entry.addedQty += qty;
          } else {
            const rawStok = dData.stok !== undefined && dData.stok !== null && dData.stok !== ''
              ? dData.stok
              : localMatched?.stok;
            const curVal = parseFloat(String(rawStok ?? '0'));
            updatedDocMap.set(dId, {
              ref: matchedDocSnap.ref,
              currentVal: isNaN(curVal) ? 0 : curVal,
              addedQty: qty,
              kode: dData.kode || item.kode || dId,
              nama: dData.nama || item.nama || localMatched?.nama || '',
            });
          }
        } else {
          // If product doesn't exist in Firestore, create it using local product data so original stock is preserved
          const fallbackDocId = toSafeDocId(item.kode || localMatched?.kode || item.nama) || `PROD-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
          const newRef = doc(db, 'products', fallbackDocId);
          if (updatedDocMap.has(fallbackDocId)) {
            const entry = updatedDocMap.get(fallbackDocId)!;
            entry.addedQty += qty;
          } else {
            const curVal = parseFloat(String(localMatched?.stok ?? '0'));
            updatedDocMap.set(fallbackDocId, {
              ref: newRef,
              currentVal: isNaN(curVal) ? 0 : curVal,
              addedQty: qty,
              kode: item.kode || localMatched?.kode || fallbackDocId,
              nama: item.nama || localMatched?.nama || 'Produk',
              extraFields: {
                harga: Number(localMatched?.harga || item.harga || 0),
                satuan: localMatched?.satuan || item.satuan || 'pcs',
                tipeHarga: localMatched?.tipeHarga || item.tipeHarga || 'fix',
              }
            });
          }
        }
      }

      // Apply batch updates for all matched products
      updatedDocMap.forEach((entry) => {
        const newVal = entry.currentVal + entry.addedQty;
        batch.set(entry.ref, {
          kode: entry.kode,
          nama: entry.nama,
          stok: String(newVal),
          ...(entry.extraFields || {}),
          updatedAt: serverTimestamp(),
        }, { merge: true });

        restoredDetails.push({
          kode: entry.kode,
          nama: entry.nama,
          qty: entry.addedQty,
        });
      });

      // Delete invoice document in the same batch
      batch.delete(invRef);
      await batch.commit();
    } catch (batchErr) {
      console.warn('Batch stock restore & invoice delete failed, falling back to direct deleteDoc:', batchErr);
      await deleteDoc(invRef);
    }
  } else {
    await deleteDoc(invRef);
  }

  return { restoredItemsCount: restoredDetails.length, restoredDetails };
}

export async function saveExpenseFirebase(expense: ExpenseRecord): Promise<void> {
  const docId = expense.id.trim();
  const cleanData = sanitizeForFirestore(expense);
  await setDoc(doc(db, 'expenses', docId), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

export async function deleteExpenseFirebase(id: string): Promise<void> {
  await deleteDoc(doc(db, 'expenses', id.trim()));
}

export async function saveStockInFirebase(record: StockInRecord, updateProductStock: boolean = false): Promise<void> {
  const docId = record.id || `STOCKIN-${Date.now()}`;
  const cleanData = sanitizeForFirestore(record);
  await setDoc(doc(db, 'stockIn', docId), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });

  // Update product stock in product doc ONLY if explicitly requested (caller already manages product state)
  if (updateProductStock) {
    const prodCode = (record.kodeProduct || record.kode || '').trim();
    if (prodCode) {
      const prodRef = doc(db, 'products', prodCode);
      const prodSnap = await getDoc(prodRef);
      if (prodSnap.exists()) {
        const currentStokStr = prodSnap.data().stok;
        let currentVal = parseFloat(currentStokStr || '0');
        if (isNaN(currentVal)) currentVal = 0;
        const addedQty = Number(record.jumlahMasuk || record.qty || 0);
        const updatePayload: any = { stok: String(currentVal + addedQty) };
        if (record.hargaBeli !== undefined && record.hargaBeli !== null && Number(record.hargaBeli) > 0) {
          updatePayload.hargaBeli = Number(record.hargaBeli);
          updatePayload.hpp = Number(record.hargaBeli);
        }
        await updateDoc(prodRef, updatePayload);
      }
    }
  }
}

export async function deleteStockInFirebase(id: string): Promise<void> {
  const docId = (id || '').trim();
  if (!docId) return;
  await deleteDoc(doc(db, 'stockIn', docId));
}

export async function clearStockInHistoryFirebase(): Promise<{ success: boolean; count: number }> {
  try {
    const snap = await getDocs(collection(db, 'stockIn'));
    let count = 0;
    if (!snap.empty) {
      const batch = writeBatch(db);
      snap.forEach((d) => {
        batch.delete(d.ref);
        count++;
      });
      await batch.commit();
    }
    return { success: true, count };
  } catch (err) {
    console.error('Error clearing stockIn history in Firebase:', err);
    return { success: false, count: 0 };
  }
}

export async function fetchStockInFirebase(): Promise<StockInRecord[]> {
  try {
    const snap = await getDocs(collection(db, 'stockIn'));
    const list: StockInRecord[] = [];
    snap.forEach((d) => {
      const data = d.data();
      list.push({
        id: d.id,
        kode: data.kode || data.kodeProduct || '',
        kodeProduct: data.kodeProduct || data.kode || '',
        nama: data.nama || data.namaProduct || '',
        namaProduct: data.namaProduct || data.nama || '',
        qty: Number(data.qty || data.jumlahMasuk || 0),
        jumlahMasuk: Number(data.jumlahMasuk || data.qty || 0),
        hargaBeli: data.hargaBeli !== undefined && data.hargaBeli !== null ? Number(data.hargaBeli) : undefined,
        satuan: data.satuan || 'pcs',
        supplier: data.supplier || 'Vendor Umum',
        cashier: data.cashier || data.penanggungJawab || 'Admin',
        penanggungJawab: data.penanggungJawab || data.cashier || 'Admin',
        date: data.date || data.tanggal || '',
        tanggal: data.tanggal || data.date || '',
        time: data.time || data.jam || '',
        jam: data.jam || data.time || '',
        catatan: data.catatan || '',
      });
    });
    return list;
  } catch (err) {
    console.warn('fetchStockInFirebase error:', err);
    return [];
  }
}

export function subscribeStockIn(callback: (stockIn: StockInRecord[]) => void) {
  const colRef = collection(db, 'stockIn');
  return onSnapshot(colRef, (snapshot) => {
    const list: StockInRecord[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      list.push({
        id: docSnap.id,
        kode: data.kode || data.kodeProduct || '',
        kodeProduct: data.kodeProduct || data.kode || '',
        nama: data.nama || data.namaProduct || '',
        namaProduct: data.namaProduct || data.nama || '',
        qty: Number(data.qty || data.jumlahMasuk || 0),
        jumlahMasuk: Number(data.jumlahMasuk || data.qty || 0),
        hargaBeli: data.hargaBeli !== undefined && data.hargaBeli !== null ? Number(data.hargaBeli) : undefined,
        satuan: data.satuan || 'pcs',
        supplier: data.supplier || 'Vendor Umum',
        cashier: data.cashier || data.penanggungJawab || 'Admin',
        penanggungJawab: data.penanggungJawab || data.cashier || 'Admin',
        date: data.date || data.tanggal || '',
        tanggal: data.tanggal || data.date || '',
        time: data.time || data.jam || '',
        jam: data.jam || data.time || '',
        catatan: data.catatan || '',
      });
    });
    // Sort descending by date/time or id
    list.sort((a, b) => {
      const timeA = `${a.date || ''} ${a.time || ''}`;
      const timeB = `${b.date || ''} ${b.time || ''}`;
      return timeB.localeCompare(timeA);
    });

    // Deduplicate by id or unique signature
    const seen = new Set<string>();
    const uniqueStockIn: StockInRecord[] = [];
    for (const item of list) {
      if (!item) continue;
      const key = item.id ? item.id.trim() : `${item.date}_${item.time}_${item.kode}_${item.qty}_${item.nama}`;
      if (!seen.has(key)) {
        seen.add(key);
        uniqueStockIn.push(item);
      }
    }

    localStorage.setItem('strukku_stock_in_history', JSON.stringify(uniqueStockIn));
    callback(uniqueStockIn);
  }, (err) => {
    console.warn('StockIn subscription error:', err);
  });
}

export async function saveStockOpnameFirebase(
  record: StockOpnameRecord, 
  updateProductStocks: boolean = true
): Promise<void> {
  const docId = record.id || `OPN-${Date.now()}`;
  const cleanData = sanitizeForFirestore(record);
  await setDoc(doc(db, 'stockOpname', docId), {
    ...cleanData,
    updatedAt: serverTimestamp(),
  }, { merge: true });

  // If updateProductStocks is enabled, batch update product stock to the real physical stock
  if (updateProductStocks && Array.isArray(record.items) && record.items.length > 0) {
    const batch = writeBatch(db);
    for (const item of record.items) {
      if (item.kode) {
        const prodRef = doc(db, 'products', item.kode.trim());
        const updateData: any = {
          stok: String(item.stokFisik),
          updatedAt: serverTimestamp(),
        };
        if (item.hargaBeli !== undefined && item.hargaBeli !== null && Number(item.hargaBeli) > 0) {
          updateData.hargaBeli = Number(item.hargaBeli);
          updateData.hpp = Number(item.hargaBeli);
        }
        batch.set(prodRef, updateData, { merge: true });
      }
    }
    await batch.commit().catch((err) => {
      console.warn('Batch product stock update failed from Stock Opname:', err);
    });
  }
}

export async function deleteStockOpnameFirebase(id: string): Promise<void> {
  await deleteDoc(doc(db, 'stockOpname', id.trim()));
}

// Generate Next Invoice Number from Firestore (Monthly sequence: PREFIX-YYYYMM-001)
export async function getNextInvoiceNumberFirebase(prefix: string = 'INV'): Promise<string> {
  try {
    const d = new Date();
    const yearMonth = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0'); // e.g. 202608
    const colRef = collection(db, 'invoices');
    const snapshot = await getDocs(colRef);
    let maxSeq = 0;

    snapshot.forEach((doc) => {
      const id = doc.id;
      const data = doc.data();
      const invNo = String(data.invoiceNo || data.noInvoice || id || '').trim();

      // Match invoices from the same year & month (contains yearMonth, e.g. "202608")
      if (invNo.includes(yearMonth) || id.includes(yearMonth)) {
        const parts = invNo.split('-');
        if (parts.length >= 2) {
          const last = parts[parts.length - 1];
          const seq = parseInt(last, 10);
          if (!isNaN(seq) && seq > maxSeq) {
            maxSeq = seq;
          }
        }
      }
    });

    const nextSeq = String(maxSeq + 1).padStart(3, '0');
    return `${prefix}-${yearMonth}-${nextSeq}`;
  } catch (err) {
    const d = new Date();
    const yearMonth = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0');
    return `${prefix}-${yearMonth}-001`;
  }
}

function toSafeDocId(str: string): string {
  if (!str) return '';
  return str.trim().replace(/[\/\\]/g, '_');
}

// Full One-Click Resilient Migration Utility to Firebase Firestore
export async function migrateAllDataToFirebase(data: {
  products?: Product[];
  customers?: Customer[];
  kasirUsers?: KasirUser[];
  settings?: Partial<StoreSettings>;
  expenses?: ExpenseRecord[];
  stockIn?: StockInRecord[];
  invoices?: Invoice[];
}): Promise<{ success: boolean; migratedCounts: Record<string, number>; message: string }> {
  try {
    const counts: Record<string, number> = {
      products: 0,
      customers: 0,
      kasirUsers: 0,
      settings: 0,
      expenses: 0,
      stockIn: 0,
      invoices: 0,
    };

    const operations: { ref: any; data: any; type: string }[] = [];

    if (data.products && data.products.length > 0) {
      for (const p of data.products) {
        const safeId = toSafeDocId(p.kode) || `PROD-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
        if (safeId) {
          const ref = doc(db, 'products', safeId);
          const cleanProd = sanitizeForFirestore({
            kode: p.kode ? p.kode.trim() : safeId,
            nama: p.nama || '',
            harga: Number(p.harga || 0),
            hargaBeli: p.hargaBeli !== undefined && p.hargaBeli !== null ? Number(p.hargaBeli) : (p.hpp !== undefined && p.hpp !== null ? Number(p.hpp) : 0),
            hpp: p.hargaBeli !== undefined && p.hargaBeli !== null ? Number(p.hargaBeli) : (p.hpp !== undefined && p.hpp !== null ? Number(p.hpp) : 0),
            kategori: p.kategori || 'Umum',
            stok: p.stok !== undefined && p.stok !== null ? String(p.stok) : '0',
            satuan: p.satuan || 'pcs',
            tipeHarga: p.tipeHarga || 'fix',
            updatedAt: serverTimestamp(),
          });
          operations.push({ ref, data: cleanProd, type: 'products' });
        }
      }
    }

    if (data.customers && data.customers.length > 0) {
      for (const c of data.customers) {
        const safeName = toSafeDocId(c.nama);
        if (safeName) {
          const ref = doc(db, 'customers', safeName);
          const divClean = (c.divisi || c.division || '').trim();
          const cleanCust = sanitizeForFirestore({
            nama: c.nama.trim(),
            kelas: c.kelas || 'Umum',
            divisi: divClean,
            division: divClean,
            diskon: Number(c.diskon || 0),
            telepon: c.telepon || '',
            alamat: c.alamat || '',
            catatan: c.catatan || '',
            updatedAt: serverTimestamp(),
          });
          operations.push({ ref, data: cleanCust, type: 'customers' });
        }
      }
    }

    if (data.kasirUsers && data.kasirUsers.length > 0) {
      for (const u of data.kasirUsers) {
        const safeName = toSafeDocId(u.nama);
        if (safeName) {
          const ref = doc(db, 'kasirUsers', safeName);
          const cleanUser = sanitizeForFirestore({
            nama: u.nama.trim(),
            password: u.password || '123456',
            role: u.role || 'kasir',
            updatedAt: serverTimestamp(),
          });
          operations.push({ ref, data: cleanUser, type: 'kasirUsers' });
        }
      }
    }

    if (data.settings && Object.keys(data.settings).length > 0) {
      const ref = doc(db, 'settings', 'store');
      const cleanSettings = sanitizeForFirestore({
        ...data.settings,
        updatedAt: serverTimestamp(),
      });
      operations.push({ ref, data: cleanSettings, type: 'settings' });
    }

    if (data.expenses && data.expenses.length > 0) {
      for (const e of data.expenses) {
        const safeId = toSafeDocId(e.id) || `EXP-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
        const ref = doc(db, 'expenses', safeId);
        const cleanExp = sanitizeForFirestore({
          ...e,
          updatedAt: serverTimestamp(),
        });
        operations.push({ ref, data: cleanExp, type: 'expenses' });
      }
    }

    if (data.stockIn && data.stockIn.length > 0) {
      for (const s of data.stockIn) {
        const safeId = toSafeDocId(s.id) || `STOCKIN-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
        const ref = doc(db, 'stockIn', safeId);
        const cleanStockIn = sanitizeForFirestore({
          ...s,
          updatedAt: serverTimestamp(),
        });
        operations.push({ ref, data: cleanStockIn, type: 'stockIn' });
      }
    }

    if (data.invoices && data.invoices.length > 0) {
      for (const inv of data.invoices) {
        const invNo = toSafeDocId(inv.invoiceNo || inv.noInvoice || '');
        if (invNo) {
          const ref = doc(db, 'invoices', invNo);
          const cleanInv = sanitizeForFirestore({
            ...inv,
            updatedAt: serverTimestamp(),
          });
          operations.push({ ref, data: cleanInv, type: 'invoices' });
        }
      }
    }

    if (operations.length === 0) {
      return {
        success: true,
        migratedCounts: counts,
        message: 'Tidak ada data baru untuk dimigrasikan.',
      };
    }

    // Process in smaller batches of 50 for max reliability across networks
    const BATCH_SIZE = 50;
    for (let i = 0; i < operations.length; i += BATCH_SIZE) {
      const chunk = operations.slice(i, i + BATCH_SIZE);
      try {
        const batch = writeBatch(db);
        for (const op of chunk) {
          batch.set(op.ref, op.data, { merge: true });
        }
        await batch.commit();
        for (const op of chunk) {
          counts[op.type] = (counts[op.type] || 0) + 1;
        }
      } catch (batchErr) {
        console.warn('Batch commit warning, falling back to sequential setDoc:', batchErr);
        // Fallback: write items in parallel individual setDoc
        await Promise.allSettled(
          chunk.map(async (op) => {
            try {
              await setDoc(op.ref, op.data, { merge: true });
              counts[op.type] = (counts[op.type] || 0) + 1;
            } catch (singleErr) {
              console.warn('Individual setDoc warning:', singleErr);
            }
          })
        );
      }
    }

    // Store flag in localStorage that Firebase migration is active
    localStorage.setItem('strukku_firebase_active', 'true');

    return {
      success: true,
      migratedCounts: counts,
      message: 'Migrasi data ke Firebase Firestore berhasil dilakukan!',
    };
  } catch (err: any) {
    console.error('Firebase migration error:', err);
    return {
      success: false,
      migratedCounts: {},
      message: 'Gagal migrasi ke Firebase: ' + (err?.message || 'Error tidak diketahui'),
    };
  }
}

/**
 * Delete all dummy products, sample customers, dummy cashiers, and clear all local cache.
 */
export async function deleteAllDummyDataFirebase(): Promise<{ success: boolean; message: string; deletedCounts: Record<string, number> }> {
  try {
    const deletedCounts: Record<string, number> = {
      products: 0,
      customers: 0,
      kasirUsers: 0,
      invoices: 0,
      expenses: 0,
      stockIn: 0,
      stockOpname: 0
    };

    // 1. Delete all Products in Firestore
    const prodSnap = await getDocs(collection(db, 'products'));
    if (!prodSnap.empty) {
      const batch = writeBatch(db);
      prodSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
        deletedCounts.products++;
      });
      await batch.commit();
    }

    // 2. Delete dummy customers in Firestore (Keep 'Umum')
    const custSnap = await getDocs(collection(db, 'customers'));
    if (!custSnap.empty) {
      const batch = writeBatch(db);
      custSnap.forEach((docSnap) => {
        const d = docSnap.data();
        const nama = (d.nama || docSnap.id || '').trim();
        if (nama.toLowerCase() !== 'umum') {
          batch.delete(docSnap.ref);
          deletedCounts.customers++;
        }
      });
      await batch.commit();
    }

    // 3. Delete dummy cashiers in Firestore (Keep only Admin)
    const kasirSnap = await getDocs(collection(db, 'kasirUsers'));
    if (!kasirSnap.empty) {
      const batch = writeBatch(db);
      kasirSnap.forEach((docSnap) => {
        const d = docSnap.data();
        const nama = (d.nama || docSnap.id || '').trim();
        if (nama.toLowerCase() !== 'admin') {
          batch.delete(docSnap.ref);
          deletedCounts.kasirUsers++;
        }
      });
      await batch.commit();
    }

    // 4. Delete dummy Invoices in Firestore
    const invSnap = await getDocs(collection(db, 'invoices'));
    if (!invSnap.empty) {
      const batch = writeBatch(db);
      invSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
        deletedCounts.invoices++;
      });
      await batch.commit();
    }

    // 5. Delete Expenses in Firestore
    const expSnap = await getDocs(collection(db, 'expenses'));
    if (!expSnap.empty) {
      const batch = writeBatch(db);
      expSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
        deletedCounts.expenses++;
      });
      await batch.commit();
    }

    // 6. Delete StockIn in Firestore
    const stockInSnap = await getDocs(collection(db, 'stockIn'));
    if (!stockInSnap.empty) {
      const batch = writeBatch(db);
      stockInSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
        deletedCounts.stockIn++;
      });
      await batch.commit();
    }

    // 7. Delete StockOpname in Firestore
    const opnameSnap = await getDocs(collection(db, 'stockOpname'));
    if (!opnameSnap.empty) {
      const batch = writeBatch(db);
      opnameSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
        deletedCounts.stockOpname++;
      });
      await batch.commit();
    }

    // 8. Reset Local Storage Caches
    localStorage.setItem('strukku_products', JSON.stringify([]));
    localStorage.setItem('strukku_customers', JSON.stringify([{ nama: 'Umum', kelas: 'Umum', diskon: 0, telepon: '', catatan: 'Pembeli umum', alamat: '' }]));
    localStorage.setItem('strukku_kasir_users', JSON.stringify([{ nama: 'Admin', password: 'admin', role: 'owner' }]));
    localStorage.setItem('strukku_kasir_list', JSON.stringify(['Admin']));
    localStorage.setItem('strukku_recent_invoices', JSON.stringify([]));
    localStorage.setItem('strukku_expenses', JSON.stringify([]));
    localStorage.setItem('strukku_stock_in_history', JSON.stringify([]));
    localStorage.setItem('strukku_stock_opname_history', JSON.stringify([]));
    localStorage.removeItem('strukku_deleted_products');
    localStorage.removeItem('strukku_deleted_customers');

    return {
      success: true,
      message: 'Semua data dummy berhasil dihapus dari sistem & database!',
      deletedCounts
    };
  } catch (err: any) {
    console.error('Error clearing dummy data:', err);
    return {
      success: false,
      message: 'Gagal menghapus data dummy: ' + (err?.message || 'Error tidak diketahui'),
      deletedCounts: {}
    };
  }
}

