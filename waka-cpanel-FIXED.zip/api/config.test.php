<?php
const WAKA_DB_HOST='localhost'; const WAKA_DB_NAME='test_waka';
const WAKA_DB_USER='u'; const WAKA_DB_PASS='p';
const WAKA_IMPORT_TOKEN='waka-import-2026';
