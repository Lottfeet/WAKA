import React from 'react';
import { 
  Grid, 
  ShoppingCart, 
  BadgeDollarSign,
  Search
} from 'lucide-react';
import { ViewTab } from '../types';
import { fRp } from '../utils/formatters';

interface MobileBottomNavProps {
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  cartCount: number;
  cartTotal: number;
  onOpenReprint?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  cartTotal,
  onOpenReprint,
}) => {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-stone-200 px-1 py-1 shadow-lg">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Katalog */}
        <button
          onClick={() => setActiveTab('catalog')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
            activeTab === 'catalog' ? 'text-red-700 bg-red-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Grid className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">Katalog</span>
        </button>

        {/* Order / Keranjang with counter badge */}
        <button
          onClick={() => setActiveTab('cart')}
          className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
            activeTab === 'cart' ? 'text-red-700 bg-red-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <div className="relative">
            <ShoppingCart className="w-5 h-5 mb-0.5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-red-700 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] leading-tight">Order</span>
        </button>

        {/* Quick Cart Pill if items exist */}
        {cartCount > 0 && activeTab === 'catalog' && (
          <button
            onClick={() => setActiveTab('cart')}
            className="absolute -top-12 left-1/2 -translate-x-1/2 bg-red-700 hover:bg-red-800 text-white font-bold text-xs py-2 px-4 rounded-full shadow-xl flex items-center gap-2 border border-red-600 transition active:scale-95 cursor-pointer"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{cartCount} Item ({fRp(cartTotal)})</span>
          </button>
        )}

        {/* Pelunasan */}
        <button
          onClick={() => setActiveTab('pelunasan')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
            activeTab === 'pelunasan' ? 'text-red-700 bg-red-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <BadgeDollarSign className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">Pelunasan</span>
        </button>

        {/* Cari Rekap */}
        <button
          onClick={onOpenReprint}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold text-stone-500 hover:text-stone-900 transition active:scale-95 cursor-pointer"
          title="Pencarian Rekapan Piutang & Pelunasan Karyawan"
        >
          <Search className="w-5 h-5 mb-0.5 text-stone-600" />
          <span className="text-[10px] leading-tight whitespace-nowrap">Cari Rekap</span>
        </button>
      </div>
    </div>
  );
};
