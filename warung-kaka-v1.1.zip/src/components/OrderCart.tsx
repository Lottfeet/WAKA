import React, { useEffect } from 'react';
import { 
  FileText, 
  User, 
  UserPlus,
  Trash2, 
  Plus, 
  Receipt,
  BadgeDollarSign, 
  CheckCircle2, 
  AlertCircle,
  RotateCw,
  Ticket,
  Banknote,
  Users,
  Layers
} from 'lucide-react';
import { Customer, InvoiceItem, Invoice } from '../types';
import { fRp, fDec, computeItemTotal } from '../utils/formatters';
import { getNextSlipNumberForCustomer } from '../utils/slipUtils';

interface OrderCartProps {
  invoiceNo: string;
  invoiceDate: string;
  items: InvoiceItem[];
  customers: Customer[];
  selectedCustomer: string;
  setSelectedCustomer: (name: string) => void;
  orderDate: string;
  setOrderDate: (date: string) => void;
  deadlineDate?: string;
  setDeadlineDate?: (date: string) => void;
  discountPct: number;
  setDiscountPct: (pct: number) => void;
  taxPct: number;
  setTaxPct: (pct: number) => void;
  negoAmt: number;
  setNegoAmt: (amt: number) => void;
  payMethod: string;
  setPayMethod: (method: string) => void;
  dpAmount: number | string;
  setDpAmount: (val: number | string) => void;
  onUpdateQty: (index: number, delta: number) => void;
  onRemoveItem: (index: number) => void;
  onNewInvoice: () => void;
  onSaveOrder: () => void;
  onOpenPelunasan?: () => void;
  onOpenAddCustomer?: () => void;
  isSaving?: boolean;
  invoices?: Invoice[];
}

export const OrderCart: React.FC<OrderCartProps> = ({
  invoiceNo,
  invoiceDate,
  items,
  customers,
  selectedCustomer,
  setSelectedCustomer,
  orderDate,
  setOrderDate,
  deadlineDate,
  setDeadlineDate,
  discountPct,
  setDiscountPct,
  taxPct,
  setTaxPct,
  negoAmt,
  setNegoAmt,
  payMethod,
  setPayMethod,
  dpAmount,
  setDpAmount,
  onUpdateQty,
  onRemoveItem,
  onNewInvoice,
  onSaveOrder,
  onOpenAddCustomer,
  isSaving = false,
  invoices = [],
}) => {
  // Find customer match
  const matchedCustomer = customers.find(
    (c) => c.nama.toLowerCase() === selectedCustomer.trim().toLowerCase()
  );

  const isKaryawan = matchedCustomer 
    ? (matchedCustomer.kelas || '').toLowerCase().includes('karyawan')
    : selectedCustomer.toLowerCase().includes('karyawan');

  const activeSlipNo = selectedCustomer.trim() && invoices.length > 0 
    ? getNextSlipNumberForCustomer(selectedCustomer.trim(), invoices) 
    : 1;

  // Enforce payment method rules:
  // - Umum (non-karyawan): Tunai (cash)
  // - Karyawan: Default is Potong Gaji (Payroll), or Voucher WAKA
  useEffect(() => {
    if (isKaryawan) {
      if (payMethod === 'Tunai') {
        setPayMethod('Potong Gaji');
      }
    } else {
      if (payMethod === 'Voucher WAKA' || payMethod === 'Potong Gaji') {
        setPayMethod('Tunai');
      }
    }
  }, [isKaryawan, payMethod, setPayMethod]);

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + computeItemTotal(item), 0);
  const discAmt = (subtotal * discountPct) / 100;
  const afterDisc = Math.max(0, subtotal - discAmt - negoAmt);
  const taxAmt = (afterDisc * taxPct) / 100;
  const total = Math.max(0, afterDisc) + taxAmt;

  const isPotongGaji = payMethod === 'Potong Gaji';
  const isVoucherWaka = payMethod === 'Voucher WAKA';

  // DP and Sisa Calculation based on payment method
  let dp = 0;
  let sisa = 0;
  let kembalian = 0;

  if (isPotongGaji) {
    dp = 0;
    sisa = total;
    kembalian = 0;
  } else if (isVoucherWaka) {
    dp = total;
    sisa = 0;
    kembalian = 0;
  } else {
    // Tunai
    if (dpAmount === '' || dpAmount === undefined || dpAmount === null) {
      dp = total;
      sisa = 0;
      kembalian = 0;
    } else {
      const parsed = typeof dpAmount === 'number' ? dpAmount : parseFloat(dpAmount) || 0;
      if (parsed >= total) {
        dp = total;
        kembalian = parsed - total;
        sisa = 0;
      } else {
        dp = parsed;
        sisa = Math.max(0, total - parsed);
        kembalian = 0;
      }
    }
  }

  const isCustomerEmpty = !selectedCustomer || !selectedCustomer.trim();
  const isTransactionDisabled = items.length === 0 || isSaving || isCustomerEmpty;

  const handleCustomerChange = (val: string) => {
    setSelectedCustomer(val);
    const match = customers.find((c) => c.nama.toLowerCase() === val.trim().toLowerCase());
    const matchIsKaryawan = match
      ? (match.kelas || '').toLowerCase().includes('karyawan')
      : val.toLowerCase().includes('karyawan');

    if (matchIsKaryawan) {
      if (payMethod === 'Tunai') {
        setPayMethod('Potong Gaji');
      }
    } else {
      if (payMethod === 'Voucher WAKA' || payMethod === 'Potong Gaji') {
        setPayMethod('Tunai');
      }
    }
  };

  return (
    <div className="bg-white border border-stone-200 rounded-xl flex flex-col min-h-full lg:h-full overflow-y-auto lg:overflow-hidden shadow-xs">
      {/* Header */}
      <div className="px-3.5 py-2.5 sm:px-4 sm:py-3 border-b border-stone-200 flex items-center justify-between bg-stone-50 shrink-0">
        <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-stone-900">
          <FileText className="w-4 h-4 text-orange-700" />
          <span>Pesanan / Order Active</span>
        </div>
        <div className="text-right text-[11px] sm:text-xs font-semibold text-stone-600 font-mono">
          <span className="text-orange-700 font-extrabold">{invoiceNo}</span>
          <span className="mx-1 text-stone-300">•</span>
          <span>{invoiceDate}</span>
        </div>
      </div>

      {/* Customer & Dates Section */}
      <div className="p-2.5 sm:p-3 bg-stone-50/50 border-b border-stone-200 space-y-2 shrink-0">
        {/* Customer Input */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-bold text-stone-600 flex items-center gap-1.5 flex-wrap">
              <span>Nama Pelanggan / Pemesan <span className="text-red-500 font-extrabold">*</span></span>
              {matchedCustomer ? (
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md inline-flex items-center gap-1 ${
                  isKaryawan ? 'bg-amber-100 text-amber-900 border border-amber-200' : 'bg-stone-100 text-stone-800 border border-stone-200'
                }`}>
                  {isKaryawan ? <Users className="w-3 h-3 text-amber-700" /> : <CheckCircle2 className="w-3 h-3 text-stone-600" />}
                  <span>{matchedCustomer.kelas || 'Umum'}</span>
                </span>
              ) : selectedCustomer.trim() ? (
                <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-stone-100 text-stone-700">
                  Pelanggan Baru (Umum)
                </span>
              ) : (
                <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-red-100 text-red-700 inline-flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 text-red-600" /> Wajib Diisi
                </span>
              )}
              {selectedCustomer.trim() && (isKaryawan || isPotongGaji) && (
                <span className="bg-amber-500/10 text-amber-900 border border-amber-300/80 text-[10px] font-extrabold px-2 py-0.5 rounded-md inline-flex items-center gap-1">
                  <Layers className="w-3 h-3 text-amber-700" />
                  <span>Slip #{activeSlipNo}</span>
                </span>
              )}
            </label>
            {onOpenAddCustomer && (
              <button
                type="button"
                onClick={onOpenAddCustomer}
                className="text-[10px] font-bold px-2 py-0.5 bg-orange-100 hover:bg-orange-200 text-orange-800 rounded-md transition flex items-center gap-1 active:scale-95 shadow-2xs cursor-pointer"
                title="Tambah Pelanggan Baru ke Database"
              >
                <UserPlus className="w-3 h-3 text-orange-700" />
                <span>+ Pelanggan</span>
              </button>
            )}
          </div>
          <div className="relative">
            <User className={`w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 transition-colors ${
              isCustomerEmpty ? 'text-red-400' : 'text-stone-400'
            }`} />
            <input
              type="text"
              list="customerListOptions"
              value={selectedCustomer}
              onChange={(e) => handleCustomerChange(e.target.value)}
              placeholder="Ketik Nama Pelanggan (Umum / Karyawan)..."
              required
              className={`w-full pl-9 pr-3 py-1.5 border rounded-lg text-xs font-semibold bg-white focus:outline-none transition ${
                isCustomerEmpty
                  ? 'border-red-300 focus:border-red-500 focus:ring-2 focus:ring-red-100 text-red-900 placeholder-red-300'
                  : 'border-stone-200 focus:border-orange-600 focus:ring-2 focus:ring-orange-100'
              }`}
            />
            <datalist id="customerListOptions">
              {customers.map((c, idx) => (
                <option key={`${c.nama}-${idx}`} value={c.nama}>
                  {c.kelas ? `Kategori: ${c.kelas}` : ''}
                </option>
              ))}
            </datalist>
          </div>
          {isCustomerEmpty && (
            <p className="text-[10px] font-bold text-red-600 mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3 shrink-0 text-red-500" />
              <span>Nama pelanggan/pemesan tidak boleh kosong untuk transaksi</span>
            </p>
          )}
        </div>

        {/* Order Date */}
        <div>
          <label className="text-[11px] font-bold text-stone-600 mb-1 block">Tgl Order</label>
          <input
            type="date"
            value={orderDate}
            onChange={(e) => setOrderDate(e.target.value)}
            className="w-full py-1.5 px-2.5 border border-stone-200 rounded-lg text-xs font-semibold bg-white focus:outline-none focus:border-orange-600"
          />
        </div>
      </div>

      {/* Item List */}
      <div className="flex-1 min-h-[160px] overflow-y-auto p-2.5 sm:p-3 space-y-2 bg-stone-50/20">
        {items.length === 0 ? (
          <div className="text-center py-6 sm:py-10 px-4 text-stone-400">
            <Receipt className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-1.5 opacity-30" />
            <p className="font-semibold text-xs text-stone-600">Keranjang Masih Kosong</p>
            <p className="text-[11px] text-stone-400 mt-0.5">
              Klik produk / sembako dari katalog untuk menambah pesanan.
            </p>
          </div>
        ) : (
          items.map((item, idx) => {
            const itemTotal = computeItemTotal(item);
            const isUkuran = item.tipeHarga === 'ukuran';
            const dimStr = isUkuran ? `${fDec(item.panjang, 2)}m × ${fDec(item.lebar, 2)}m` : '';

            return (
              <div
                key={idx}
                className="p-2.5 rounded-xl border border-stone-200 bg-white hover:border-stone-300 transition shadow-2xs"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs sm:text-sm font-bold text-stone-900 truncate">
                      {item.nama}
                    </div>
                    <div className="flex flex-wrap items-center gap-1 mt-1">
                      {isUkuran && (
                        <span className="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700">
                          {dimStr}
                        </span>
                      )}
                      {item.bahan && (
                        <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800">
                          {item.bahan}
                        </span>
                      )}
                      {item.catatan && (
                        <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-stone-100 text-stone-600">
                          {item.catatan}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-stone-500 mt-1">
                      {fRp(item.harga)} / {item.satuan}
                    </div>
                  </div>

                  {/* Stepper + Total */}
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="flex items-center border border-stone-200 rounded-lg overflow-hidden bg-stone-50">
                      <button
                        onClick={() => onUpdateQty(idx, -1)}
                        className="w-6 h-6 flex items-center justify-center font-bold text-xs text-stone-600 hover:bg-stone-200 cursor-pointer"
                      >
                        -
                      </button>
                      <span className="w-8 text-center text-xs font-extrabold">
                        {fDec(item.qty, 2).replace(/\.?0+$/, '')}
                      </span>
                      <button
                        onClick={() => onUpdateQty(idx, 1)}
                        className="w-6 h-6 flex items-center justify-center font-bold text-xs text-stone-600 hover:bg-stone-200 cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right">
                      <div className="text-xs sm:text-sm font-black text-red-700">
                        {fRp(itemTotal)}
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveItem(idx)}
                      className="p-1 rounded text-stone-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                      title="Hapus Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer Calculation & Actions */}
      <div className="border-t border-stone-200 p-2.5 sm:p-3 bg-stone-50/80 space-y-2 shrink-0">
        {/* Breakdown Calculation */}
        <div className="space-y-1 text-xs border-stone-200 pt-1">
          <div className="flex justify-between text-stone-600">
            <span>Subtotal</span>
            <span className="font-semibold">{fRp(subtotal)}</span>
          </div>
          {negoAmt > 0 && (
            <div className="flex justify-between text-red-600">
              <span>Potongan Nego</span>
              <span className="font-semibold">- {fRp(negoAmt)}</span>
            </div>
          )}
          {taxAmt > 0 && (
            <div className="flex justify-between text-stone-600">
              <span>PPN ({taxPct}%)</span>
              <span className="font-semibold">{fRp(taxAmt)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm font-black text-stone-900 border-t border-stone-200 pt-1">
            <span>TOTAL</span>
            <span className="text-red-700 text-base">{fRp(total)}</span>
          </div>
        </div>

        {/* Payment Method & DP input */}
        <div className="flex gap-2">
          <div className="w-44 shrink-0">
            <label className="text-[10px] font-bold text-stone-500 mb-0.5 block flex items-center justify-between">
              <span>Metode Bayar</span>
              <span className={`text-[9px] font-extrabold px-1 rounded ${
                isKaryawan ? 'bg-red-100 text-red-900' : 'bg-stone-200 text-stone-700'
              }`}>
                {isKaryawan ? 'Karyawan' : 'Umum'}
              </span>
            </label>
            <select
              value={payMethod}
              onChange={(e) => {
                const val = e.target.value;
                setPayMethod(val);
                if (val === 'Potong Gaji') {
                  setDpAmount('0');
                } else if (val === 'Voucher WAKA') {
                  setDpAmount('');
                }
              }}
              className="w-full py-1.5 px-2 border border-stone-200 rounded-lg text-xs font-extrabold bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500/20"
            >
              {isKaryawan ? (
                <>
                  <option value="Potong Gaji">📋 Potong Gaji (Piutang)</option>
                  <option value="Voucher WAKA">🎟️ Voucher WAKA</option>
                </>
              ) : (
                <option value="Tunai">💵 Tunai (Cash)</option>
              )}
            </select>
          </div>

          <div className="flex-1">
            <label className="text-[10px] font-bold text-stone-500 mb-0.5 block">
              {isPotongGaji 
                ? 'Status Pembayaran' 
                : isVoucherWaka 
                ? 'Status Voucher' 
                : 'Nominal Uang Tunai / DP (Rp)'}
            </label>
            {isPotongGaji ? (
              <div className="py-1.5 px-2.5 bg-red-50 border border-red-200 rounded-lg text-[11px] font-bold text-red-900 flex items-center justify-between">
                <span>Otomatis Masuk Piutang</span>
                <span className="font-extrabold text-red-700">Rp 0 (DP)</span>
              </div>
            ) : isVoucherWaka ? (
              <div className="py-1.5 px-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] font-bold text-emerald-900 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Ticket className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Voucher WAKA</span>
                </span>
                <span className="font-extrabold text-emerald-700">Lunas ({fRp(total)})</span>
              </div>
            ) : (
              <input
                type="number"
                min="0"
                value={dpAmount}
                onChange={(e) => setDpAmount(e.target.value)}
                placeholder={`Kosong = Lunas (${fRp(total)})`}
                className="w-full py-1.5 px-2.5 border border-stone-200 rounded-lg text-xs font-bold text-stone-800 bg-white placeholder:text-stone-400 placeholder:font-normal focus:outline-none focus:ring-2 focus:ring-red-500/20"
              />
            )}
          </div>
        </div>

        {/* DP & Sisa Status */}
        <div className={`space-y-1 text-xs p-2.5 rounded-xl font-semibold border ${
          isPotongGaji 
            ? 'bg-red-50/80 border-red-200 text-red-950'
            : isVoucherWaka
            ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
            : sisa > 0 
            ? 'bg-rose-50/70 border-rose-200 text-rose-950'
            : 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
        }`}>
          {isPotongGaji ? (
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[11px] text-red-800 font-bold">Status Tagihan:</span>
                <span className="text-red-800 font-black uppercase text-[11px] bg-red-200/80 px-2 py-0.5 rounded">
                  📋 PIUTANG POTONG GAJI
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-stone-600">Tagihan Saat Gajian:</span>
                <span className="text-red-700 font-black text-sm">{fRp(total)}</span>
              </div>
              <p className="text-[10px] text-red-800 leading-tight">
                *Tagihan ini otomatis tercatat pada <strong>Rekapitulasi Piutang Karyawan</strong> untuk dipotong saat gajian.
              </p>
            </div>
          ) : isVoucherWaka ? (
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[11px] text-emerald-800 font-bold">Metode Pembayaran:</span>
                <span className="text-emerald-800 font-black uppercase text-[11px] bg-emerald-200 px-2 py-0.5 rounded">
                  🎟️ VOUCHER WAKA
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-stone-600">Status Pembayaran:</span>
                <span className="text-emerald-700 font-black text-sm">✓ LUNAS</span>
              </div>
            </div>
          ) : (
            <>
              <div className="flex justify-between">
                <span className="text-stone-500">Uang Diterima / DP (Tunai)</span>
                <span className="text-emerald-700 font-bold">{fRp(dp)}</span>
              </div>
              <div className="flex justify-between font-bold items-center">
                <span className={sisa > 0 ? 'text-rose-700' : 'text-emerald-700'}>
                  {sisa > 0 ? 'Sisa Piutang (Belum Lunas)' : 'Status Transaksi'}
                </span>
                <span className={sisa > 0 ? 'text-rose-700 font-black' : 'text-emerald-700 font-extrabold bg-emerald-100 px-2 py-0.5 rounded text-[11px]'}>
                  {sisa > 0 ? fRp(sisa) : '✓ LUNAS (TUNAI)'}
                </span>
              </div>
              {kembalian > 0 && (
                <div className="flex justify-between text-emerald-800 font-bold border-t border-emerald-200/60 pt-1 mt-1">
                  <span>Kembalian Pembeli</span>
                  <span className="font-black">{fRp(kembalian)}</span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Warning Banner when Cart has items but customer name is empty */}
        {isCustomerEmpty && items.length > 0 && (
          <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-800 text-[11px] font-extrabold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>Wajib isi Nama Pelanggan / Pemesan di atas untuk memproses transaksi!</span>
          </div>
        )}

        {/* Order Action Buttons: Baru & Simpan */}
        <div className="grid grid-cols-3 gap-1.5 pt-1">
          <button
            type="button"
            onClick={onNewInvoice}
            className="py-2.5 px-2 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-100 text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 shadow-2xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Baru</span>
          </button>

          <button
            type="button"
            onClick={onSaveOrder}
            disabled={isTransactionDisabled}
            title={isCustomerEmpty ? 'Nama pelanggan / pemesan wajib diisi!' : 'Simpan Transaksi ke Sistem'}
            className="col-span-2 py-2.5 px-3 rounded-xl bg-red-700 hover:bg-red-800 text-white text-xs font-black flex items-center justify-center gap-1.5 transition active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shadow-xs cursor-pointer"
          >
            {isSaving ? (
              <>
                <RotateCw className="w-4 h-4 animate-spin" />
                <span>Menyimpan...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Simpan Transaksi</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
