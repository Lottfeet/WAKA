import React, { useState, useEffect } from 'react';
import { X, Search, Printer, Receipt, FileSpreadsheet, Loader2, RefreshCw, Pencil } from 'lucide-react';
import { Invoice, StoreSettings, KasirUser, Customer, Product } from '../types';
import { getInvoiceByNo, fetchRecentInvoices, RecentInvoiceItem } from '../services/gasService';
import { fRp, fDec } from '../utils/formatters';
import { generateThermalHTML, generateA5HTML, openPrintWindow, calculateCurrentSisa } from '../utils/printUtils';
import { EditTransactionModal } from './EditTransactionModal';

interface ReprintModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StoreSettings;
  kasirUsers?: KasirUser[];
  customers?: Customer[];
  products?: Product[];
  currentUser?: string | null;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ReprintModal: React.FC<ReprintModalProps> = ({
  isOpen,
  onClose,
  settings,
  kasirUsers = [],
  customers = [],
  products = [],
  currentUser,
  onShowToast,
}) => {
  const [searchInv, setSearchInv] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingList, setLoadingList] = useState(false);
  const [scriptOutdated, setScriptOutdated] = useState(false);
  const [recentInvoices, setRecentInvoices] = useState<RecentInvoiceItem[]>([]);
  const [invData, setInvData] = useState<Invoice | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const formatInvoiceDate = (dateStr?: string) => {
    if (!dateStr) return '';
    if (dateStr.includes('T') || dateStr.includes('-')) {
      try {
        const d = new Date(dateStr);
        if (!isNaN(d.getTime())) {
          const day = String(d.getDate()).padStart(2, '0');
          const month = String(d.getMonth() + 1).padStart(2, '0');
          const year = d.getFullYear();
          return `${day}/${month}/${year}`;
        }
      } catch {}
    }
    return dateStr;
  };

  const loadRecentList = async (autoSelectFirst = false, forceRefresh = false) => {
    setLoadingList(true);
    const { list, needsScriptUpdate } = await fetchRecentInvoices(forceRefresh);
    setRecentInvoices(list);
    setScriptOutdated(needsScriptUpdate);
    setLoadingList(false);

    if (autoSelectFirst && list.length > 0 && !searchInv) {
      const firstNo = list[0].invoiceNo;
      setSearchInv(firstNo);
      fetchInvoiceDetail(firstNo);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setInvData(null);
      loadRecentList(true);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const fetchInvoiceDetail = async (noToFetch: string) => {
    if (!noToFetch.trim()) return;

    setLoading(true);
    setInvData(null);

    const res = await getInvoiceByNo(noToFetch.trim());
    setLoading(false);

    if (res.success && res.data) {
      const inv = res.data;
      const currentSisa = calculateCurrentSisa(inv);
      setInvData({ ...inv, sisa: currentSisa });
    } else {
      onShowToast(res.message || 'Invoice tidak ditemukan di Google Sheets', 'error');
    }
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchInv.trim()) {
      onShowToast('Masukkan nomor invoice', 'error');
      return;
    }
    fetchInvoiceDetail(searchInv.trim());
  };

  const handleSelectDropdown = (no: string) => {
    if (!no) return;
    setSearchInv(no);
    fetchInvoiceDetail(no);
  };

  const handlePrintThermal = () => {
    if (!invData) return;
    const html = generateThermalHTML(invData, settings);
    openPrintWindow(html, 'Struk Ulang ' + invData.invoiceNo);
  };

  const handlePrintA5 = () => {
    if (!invData) return;
    const html = generateA5HTML(invData, settings);
    openPrintWindow(html, 'Invoice A5 Ulang ' + invData.invoiceNo);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-stone-800 text-white flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base">Cari & Cetak Ulang</h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Pilih atau cari nomor invoice dari Google Sheets
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 space-y-4">
          {/* Dropdown Auto-Select Invoice dari Spreadsheet */}
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-stone-700">
              <span>Semua Invoice dari Spreadsheet ({recentInvoices.length}):</span>
              <button
                onClick={() => loadRecentList(false, true)}
                disabled={loadingList}
                className="text-[10px] text-red-700 hover:text-red-800 flex items-center gap-1 font-extrabold cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${loadingList ? 'animate-spin' : ''}`} />
                <span>Muat Ulang</span>
              </button>
            </div>

            {scriptOutdated && (
              <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-[11px] text-red-800 space-y-1">
                <p className="font-bold">⚠️ Perhatian: Kode Google Apps Script perlu diperbarui</p>
                <p className="text-[10.5px]">
                  Saat ini Google Apps Script di spreadsheet Anda masih versi lama sehingga hanya menampilkan invoice piutang/lokal. Silakan <strong>Deploy Ulang (Versi Baru)</strong> kode dari menu "Pengaturan" &gt; "Panduan Apps Script" agar seluruh invoice otomatis ditarik.
                </p>
              </div>
            )}

            {loadingList ? (
              <div className="flex items-center gap-2 py-2 text-xs text-stone-500 italic">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-red-600" />
                <span>Memuat data transaksi dari Google Sheets...</span>
              </div>
            ) : recentInvoices.length > 0 ? (
              <select
                value={searchInv}
                onChange={(e) => handleSelectDropdown(e.target.value)}
                className="w-full py-2 px-2.5 border border-stone-300 rounded-lg text-xs font-mono font-bold bg-white text-stone-900 shadow-xs focus:ring-2 focus:ring-red-200 focus:border-red-600 transition truncate"
              >
                <option value="">-- Pilih No. Invoice --</option>
                {recentInvoices.map((item, idx) => (
                  <option key={`${item.invoiceNo}-${idx}`} value={item.invoiceNo}>
                    {item.invoiceNo} • {item.customer || 'Umum'} {formatInvoiceDate(item.date) ? `(${formatInvoiceDate(item.date)})` : ''} {item.total ? `• Rp ${item.total.toLocaleString('id-ID')}` : ''}
                  </option>
                ))}
              </select>
            ) : (
              <p className="text-[11px] text-stone-500 italic">
                Belum ada daftar invoice otomatis. Gunakan kolom pencarian di bawah.
              </p>
            )}
          </div>

          {/* Manual Search Input */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={searchInv}
                onChange={(e) => setSearchInv(e.target.value)}
                placeholder="Atau ketik No. Invoice (misal: INV-20260729-001)..."
                className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-lg text-xs font-mono font-bold focus:outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold rounded-lg transition active:scale-95 disabled:opacity-50 shrink-0 flex items-center gap-1.5 cursor-pointer"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Cari'}
            </button>
          </form>

          {/* Result Card */}
          {loading && !invData && (
            <div className="p-8 text-center text-xs text-stone-500 space-y-2">
              <Loader2 className="w-6 h-6 animate-spin text-red-600 mx-auto" />
              <p className="font-semibold">Mengambil rincian invoice dari Spreadsheet...</p>
            </div>
          )}

          {invData && !loading && (
            <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50 space-y-3 animate-fade-in">
              <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                <div>
                  <div className="font-mono font-extrabold text-sm text-stone-900">
                    {invData.invoiceNo}
                  </div>
                  <div className="text-xs text-stone-500">
                    {invData.date} {invData.time} • Kasir: {invData.cashier || 'Admin'}
                  </div>
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    invData.sisa <= 0
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {invData.sisa <= 0 ? '✓ LUNAS' : 'DP / UNPAID'}
                </span>
              </div>

              <div className="text-xs text-stone-700 flex items-center justify-between">
                <span>Pelanggan: <strong>{invData.customer || 'Umum'}</strong></span>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-stone-200 text-stone-800 uppercase">
                  Metode: {invData.payMethod || (invData as any).metodePembayaran || 'Tunai'}
                </span>
              </div>

              {/* Items Summary */}
              <div className="max-h-36 overflow-y-auto space-y-1 text-xs border-y border-stone-200 py-2">
                {invData.items && invData.items.length > 0 ? (
                  invData.items.map((it, i) => (
                    <div key={i} className="flex justify-between text-stone-700">
                      <span className="truncate pr-2">
                        {it.nama} ({fDec(it.qty, 2).replace(/\.?0+$/, '')} {it.satuan || 'pcs'})
                      </span>
                      <span className="font-semibold shrink-0">
                        {fRp(it.totalItem || it.harga * it.qty)}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="text-stone-400 italic">Rincian item tidak tersedia</p>
                )}
              </div>

              <div className="space-y-1 text-xs pt-1">
                <div className="flex justify-between font-bold text-stone-900">
                  <span>TOTAL</span>
                  <span className="text-red-700">{fRp(invData.total)}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Sisa Bayar</span>
                  <span className={invData.sisa > 0 ? 'text-red-700 font-bold' : 'text-emerald-700'}>
                    {fRp(invData.sisa || 0)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={handlePrintThermal}
                  className="py-2 px-3 rounded-lg border border-stone-300 bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Struk Thermal</span>
                </button>

                <button
                  onClick={handlePrintA5}
                  className="py-2 px-3 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Invoice A5</span>
                </button>
              </div>

              {/* Edit / Koreksi Transaction Button for SPV / Owner */}
              <div className="pt-1">
                <button
                  onClick={() => setIsEditModalOpen(true)}
                  className="w-full py-2 px-3 rounded-lg border border-red-300 bg-red-50 hover:bg-red-100 text-red-900 text-xs font-extrabold flex items-center justify-center gap-1.5 transition cursor-pointer"
                  title="Koreksi kesalahan input kasir atau metode pembayaran (Otorisasi SPV/Owner)"
                >
                  <Pencil className="w-3.5 h-3.5 text-red-700" />
                  <span>Koreksi & Edit Transaksi Ini (SPV/Owner)</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Edit Transaction Modal */}
        {isEditModalOpen && invData && (
          <EditTransactionModal
            isOpen={isEditModalOpen}
            onClose={() => setIsEditModalOpen(false)}
            invoice={invData}
            settings={settings}
            kasirUsers={kasirUsers}
            customers={customers}
            products={products}
            currentUser={currentUser}
            onSaveSuccess={(updated) => {
              setInvData(updated);
              loadRecentList(false, true);
              onShowToast(`✓ Nota #${updated.invoiceNo} berhasil diperbarui!`, 'success');
            }}
            onShowToast={onShowToast}
          />
        )}
      </div>
    </div>
  );
};
