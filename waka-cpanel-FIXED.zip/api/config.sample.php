<?php
// ============================================================================
// Konfigurasi database WAKA — EDIT SESUAI DATA cPanel/phpMyAdmin Anda
// Letakkan file ini di folder /api di hosting cPanel.
// ============================================================================

const WAKA_DB_HOST = 'localhost';        // biasanya 'localhost' di cPanel
const WAKA_DB_NAME = 'yourcpanel_waka';  // nama database yang dibuat di phpMyAdmin
const WAKA_DB_USER = 'yourcpanel_waka';  // username MySQL
const WAKA_DB_PASS = 'GANTI_PASSWORD';   // password MySQL

// Token rahasia untuk endpoint import backup (samakan dengan nilai di app)
const WAKA_IMPORT_TOKEN = 'waka-import-2026';
