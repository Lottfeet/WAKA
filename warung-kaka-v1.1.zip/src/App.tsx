import React, { useState, useEffect, useCallback } from 'react';
import { 
  Product, 
  Customer, 
  InvoiceItem, 
  StoreSettings, 
  Invoice, 
  ViewTab,
  MainViewTab,
  KasirUser,
  PelunasanRecord,
  StockInRecord
} from './types';
import { 
  fetchProducts, 
  fetchCustomers, 
  fetchKasirList, 
  fetchKasirUsers,
  fetchSheetSettings, 
  fetchStockInHistory,
  getNextInvoiceNumber, 
  saveTransaction,
  addRecentInvoiceToLocal,
  deleteCustomer,
  fetchAllDataBatch,
  getLocalProducts,
  getLocalCustomers,
  getLocalKasirUsers,
  getLocalSettings,
  submitPelunasan,
  addStockIn,
  deleteInvoiceRemote,
  updateProductDetails,
  savePelunasanHistoryToLocal,
  mergePelunasanHistories,
  recalculateInvoiceSisaAndStatus
} from './services/gasService';
import {
  subscribeProducts,
  subscribeCustomers,
  subscribeKasirUsers,
  subscribeSettings,
  subscribeInvoices,
  saveInvoiceFirebase,
  getNextInvoiceNumberFirebase,
  deleteCustomerFirebase,
  deleteInvoiceFirebase,
  recordPelunasanFirebase,
  batchRecordPelunasanFirebase,
  batchUpdateInvoicesFirebase,
  saveStockInFirebase
} from './services/firebaseService';
import { logActivity } from './services/activityService';
import { fRp, fDate, fTime, fDateInput, formatDateFromInput, computeItemTotal, INITIAL_PRODUCTS, INITIAL_CUSTOMERS } from './utils/formatters';
import { generateThermalHTML, generateA5HTML, openPrintWindow } from './utils/printUtils';
import { getNextSlipNumberForCustomer } from './utils/slipUtils';
import { appendInvoiceToGoogleSheets, getStoredSpreadsheetId } from './services/googleSheetsService';
import { enqueueOfflineOperation, flushOfflineQueue, setupAutoSyncListener } from './services/offlineSyncService';

import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { SidebarNav } from './components/SidebarNav';
import { ProductCatalog } from './components/ProductCatalog';
import { SpecModal } from './components/SpecModal';
import { OrderCart } from './components/OrderCart';
import { PelunasanModal } from './components/PelunasanModal';
import { ReprintModal } from './components/ReprintModal';
import { SettingsModal } from './components/SettingsModal';
import { ImportModal } from './components/ImportModal';
import { AddCustomerModal } from './components/AddCustomerModal';
import { GasSetupGuideModal } from './components/GasSetupGuideModal';
import { LoginScreen } from './components/LoginScreen';
import { BarangMasukView } from './components/BarangMasukView';
import { StokOpnameView } from './components/StokOpnameView';
import { PelangganView } from './components/PelangganView';
import { LaporanPenjualanView } from './components/LaporanPenjualanView';
import { PiutangView } from './components/PiutangView';
import { PencarianRekapView } from './components/PencarianRekapView';

export default function App() {
  // Navigation State
  const [mainViewTab, setMainViewTab] = useState<MainViewTab>('transaksi');
  const [activeTab, setActiveTab] = useState<ViewTab>('catalog');

  // Master Data & User Authentication State
  const [products, setProducts] = useState<Product[]>(() => getLocalProducts());
  const [customers, setCustomers] = useState<Customer[]>(() => getLocalCustomers());
  const [kasirUsers, setKasirUsers] = useState<KasirUser[]>(() => getLocalKasirUsers());
  const [kasirList, setKasirList] = useState<string[]>(() => getLocalKasirUsers().map((u) => u.nama));
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    return localStorage.getItem('strukku_logged_kasir') || null;
  });
  const [authView, setAuthView] = useState<'rekap' | 'login'>('rekap');

  // Central Invoices State (Real-time Firestore + Local Storage)
  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const raw = localStorage.getItem('strukku_recent_invoices');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [settings, setSettings] = useState<StoreSettings>(() => {
    let base: StoreSettings = {
      name: 'WARUNGKU',
      storeName: 'WARUNGKU',
      tagline: 'Cepat / Tepat / Berkualitas',
      address: 'Jl. HOS Cokroaminoto No.17, Ciamis',
      phone: '0812-2247-2007',
      footer: 'Terima Kasih Atas Kunjungan Anda',
      rekening: '',
      autoLogoutMinutes: 15,
      cashier: localStorage.getItem('strukku_logged_kasir') || 'Admin',
    };

    try {
      const sheetCfg = localStorage.getItem('strukku_sheet_settings');
      if (sheetCfg) {
        const p = JSON.parse(sheetCfg);
        if (p.name || p.storeName) base.name = p.name || p.storeName;
        if (p.tagline) base.tagline = p.tagline;
        if (p.address) base.address = p.address;
        if (p.phone) base.phone = p.phone;
        if (p.footer) base.footer = p.footer;
        if (p.rekening) base.rekening = p.rekening;
        if (p.prefixInvoice) base.prefixInvoice = p.prefixInvoice;
      }
      const localCfg = localStorage.getItem('strukku_settings');
      if (localCfg) {
        const p = JSON.parse(localCfg);
        if (p.name || p.storeName) base.name = p.name || p.storeName;
        if (p.tagline) base.tagline = p.tagline;
        if (p.address) base.address = p.address;
        if (p.phone) base.phone = p.phone;
        if (p.footer) base.footer = p.footer;
        if (p.rekening) base.rekening = p.rekening;
        if (p.prefixInvoice) base.prefixInvoice = p.prefixInvoice;
        if (p.autoLogoutMinutes) base.autoLogoutMinutes = p.autoLogoutMinutes;
      }
    } catch {}

    return base;
  });

  // Sync State
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);

  // Active Transaction State
  const [invoiceNo, setInvoiceNo] = useState<string>('Memuat...');
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [orderDate, setOrderDate] = useState<string>(fDateInput(new Date()));
  const [deadlineDate, setDeadlineDate] = useState<string>('');
  const [discountPct, setDiscountPct] = useState<number>(0);
  const [taxPct, setTaxPct] = useState<number>(0);
  const [negoAmt, setNegoAmt] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<string>('Tunai');
  const [dpAmount, setDpAmount] = useState<number | string>('');
  const [isTransactionSaved, setIsTransactionSaved] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Modal Dialog Controls
  const [specProduct, setSpecProduct] = useState<Product | null>(null);
  const [isSpecModalOpen, setIsSpecModalOpen] = useState<boolean>(false);
  const [selectedRestockProduct, setSelectedRestockProduct] = useState<Product | null>(null);
  const [isPelunasanOpen, setIsPelunasanOpen] = useState<boolean>(false);
  const [isReprintOpen, setIsReprintOpen] = useState<boolean>(false);
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isGasGuideOpen, setIsGasGuideOpen] = useState<boolean>(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState<boolean>(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
  const [initialCustomerName, setInitialCustomerName] = useState<string>('');

  // Handle when new customer is added or updated
  const handleCustomerAdded = async (newCust: Customer, oldCustomer?: Customer | null) => {
    const prevCust = oldCustomer || customerToEdit;
    const oldName = prevCust ? prevCust.nama.trim() : '';
    const newName = newCust.nama.trim();
    const oldDivisi = prevCust ? (prevCust.divisi || prevCust.division || '').trim() : '';
    const newDivisi = (newCust.divisi || newCust.division || '').trim();

    // Track historical alias names
    const existingOldNames = Array.isArray(prevCust?.oldNames) ? prevCust.oldNames : [];
    const updatedOldNames = Array.from(new Set([
      ...existingOldNames,
      ...(oldName && oldName.toLowerCase() !== newName.toLowerCase() ? [oldName] : []),
      ...(oldName && oldDivisi ? [`${oldName} (${oldDivisi})`] : []),
    ]));

    const enrichedCust: Customer = {
      ...newCust,
      oldNames: updatedOldNames,
    };

    // 1. Update master customers state
    setCustomers((prev) => {
      let filtered = prev;
      if (prevCust) {
        filtered = filtered.filter((c) => c.nama.trim().toLowerCase() !== prevCust.nama.trim().toLowerCase());
      }
      filtered = filtered.filter((c) => c.nama.trim().toLowerCase() !== newName.toLowerCase());
      const updated = [...filtered, enrichedCust];
      localStorage.setItem('warung_kaka_customers', JSON.stringify(updated));
      localStorage.setItem('strukku_customers', JSON.stringify(updated));
      return updated;
    });

    // 2. Cascade customer edits to all existing matching invoices while preserving original historical audit trail
    if (prevCust && (oldName.toLowerCase() !== newName.toLowerCase() || oldDivisi.toLowerCase() !== newDivisi.toLowerCase() || prevCust.telepon !== newCust.telepon || prevCust.alamat !== newCust.alamat)) {
      const oldBaseLower = oldName.replace(/\(.*?\)/g, '').replace(/[-–\/].*$/, '').trim().toLowerCase();

      const modifiedInvs: Invoice[] = [];
      const updatedInvoicesList = invoices.map((inv) => {
        const invCust = (inv.customer || (inv as any).pelanggan || '').trim();
        const invCustLower = invCust.toLowerCase();
        const invBaseLower = invCust.replace(/\(.*?\)/g, '').replace(/[-–\/].*$/, '').trim().toLowerCase();

        const isMatch = invCustLower === oldName.toLowerCase() || 
          (oldBaseLower.length > 2 && invBaseLower === oldBaseLower) ||
          (Array.isArray(prevCust?.oldNames) && prevCust.oldNames.some((o) => o.toLowerCase() === invCustLower));

        if (isMatch) {
          const modInv: Invoice = {
            ...inv,
            originalCustomer: inv.originalCustomer || inv.customer || oldName,
            originalDivisi: inv.originalDivisi || inv.divisi || oldDivisi,
            customer: newName,
            pelanggan: newName,
            customerPhone: newCust.telepon || inv.customerPhone,
            customerAddress: newCust.alamat || inv.customerAddress,
            divisi: newDivisi,
            division: newDivisi,
          };
          modifiedInvs.push(modInv);
          return modInv;
        }
        return inv;
      });

      if (modifiedInvs.length > 0) {
        setInvoices(updatedInvoicesList);
        localStorage.setItem('strukku_recent_invoices', JSON.stringify(updatedInvoicesList));

        // Batch update to Firestore
        batchUpdateInvoicesFirebase(modifiedInvs).catch((err) => {
          console.warn('Batch update invoices on customer edit error:', err);
        });

        // Log audit event
        logActivity({
          type: 'edit_pelanggan',
          actor: currentUser || settings.cashier || 'Admin',
          title: `Update Pelanggan: "${oldName}" ➔ "${newName}"`,
          description: `Data pelanggan diperbarui. ${modifiedInvs.length} nota transaksi otomatis disinkronkan ke profil "${newName}" (Divisi: ${newDivisi || 'Umum'}).`,
          date: fDateInput(new Date()),
          time: fTime(new Date()),
          metadata: {
            oldValue: oldName,
            newValue: newName,
            changes: [
              `Nama: ${oldName} ➔ ${newName}`,
              `Divisi: ${oldDivisi} ➔ ${newDivisi}`,
              `${modifiedInvs.length} transaksi diselaraskan`
            ]
          }
        }).catch(() => {});
      }
    }

    setCustomerToEdit(null);
    setInitialCustomerName('');
    setSelectedCustomer(newCust.nama);
    const isKaryawan = (newCust.kelas || '').toLowerCase().includes('karyawan');
    if (isKaryawan) {
      setPayMethod('Potong Gaji');
    } else {
      setPayMethod('Tunai');
    }
  };

  // Toast Banner State
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = useCallback((msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ msg, type });
    setTimeout(() => {
      setToast((prev) => (prev?.msg === msg ? null : prev));
    }, 3500);
  }, []);

  // Fetch Central Invoice Number
  const prefixInvoice = settings.prefixInvoice || 'INV';
  const loadNewInvoiceNumber = useCallback(async () => {
    setInvoiceNo('Memuat...');
    try {
      const num = await getNextInvoiceNumberFirebase(prefixInvoice);
      setInvoiceNo(num);
    } catch {
      const num = await getNextInvoiceNumber();
      setInvoiceNo(num);
    }
    setIsTransactionSaved(false);
  }, [prefixInvoice]);

  // Real-Time Data Synchronization with Google Sheets & Firebase
  const handleSyncData = useCallback(async () => {
    setIsSyncing(true);
    let ok = false;

    try {
      const batch = await fetchAllDataBatch();

      if (batch.products && batch.products.length > 0) setProducts(batch.products);
      if (batch.customers) setCustomers(batch.customers);
      if (batch.kasirUsers && batch.kasirUsers.length > 0) {
        setKasirUsers(batch.kasirUsers);
        setKasirList(batch.kasirUsers.map((u) => u.nama));
      }
      if (batch.settings) {
        setSettings((prev) => ({
          ...prev,
          ...batch.settings,
          rekening: (batch.settings?.rekening && batch.settings.rekening.trim()) ? batch.settings.rekening : (prev.rekening || ''),
        }));
      }
      if (batch.nextInvoiceNo) {
        setInvoiceNo(batch.nextInvoiceNo);
      }

      const syncTimeString = fTime(new Date());
      setLastSyncTime(syncTimeString);
      setIsConnected(true);
      ok = true;

      // Automatically flush any pending offline transactions
      flushOfflineQueue().then((res) => {
        if (res.syncedCount > 0) {
          showToast(`Otomatis mengunggah ${res.syncedCount} transaksi dari penyimpanan lokal ke server!`, 'success');
        }
      }).catch(() => {});
    } catch (err) {
      console.warn('Sync failed:', err);
      setIsConnected(false);
    } finally {
      setIsSyncing(false);
    }

    return ok;
  }, []);

  // Realtime Firebase Listeners Setup
  useEffect(() => {
    const unsubProducts = subscribeProducts((list) => {
      setProducts(list);
    });

    const unsubCustomers = subscribeCustomers((list) => {
      setCustomers(list);
    });

    const unsubKasir = subscribeKasirUsers((list) => {
      setKasirUsers(list);
      setKasirList(list.map((u) => u.nama));
    });

    const unsubSettings = subscribeSettings((cfg) => {
      setSettings((prev) => ({ ...prev, ...cfg }));
    });

    const unsubInvoices = subscribeInvoices((invs) => {
      setInvoices(invs || []);
    });

    return () => {
      unsubProducts();
      unsubCustomers();
      unsubKasir();
      unsubSettings();
      unsubInvoices();
    };
  }, []);

  // Ref for tracking last user activity / interaction timestamp
  const lastActivityRef = React.useRef<number>(Date.now());

  const touchActivity = useCallback(() => {
    lastActivityRef.current = Date.now();
  }, []);

  // User Auth Handlers
  const handleLogout = useCallback((reason?: string | React.MouseEvent) => {
    localStorage.removeItem('strukku_logged_kasir');
    setCurrentUser(null);
    setAuthView('rekap');
    showToast(typeof reason === 'string' ? reason : 'Anda telah keluar dari akun kasir', 'info');
  }, [showToast]);

  const handleLoginSuccess = (kasirName: string) => {
    localStorage.setItem('strukku_logged_kasir', kasirName);
    setCurrentUser(kasirName);
    setSettings((prev) => ({ ...prev, cashier: kasirName }));
    lastActivityRef.current = Date.now();
  };

  // On App Mount & 10-Minute Periodic Background Sync
  useEffect(() => {
    handleSyncData();
    loadNewInvoiceNumber();

    // Load local device settings if present
    const localSetting = localStorage.getItem('strukku_settings');
    if (localSetting) {
      try {
        const parsed = JSON.parse(localSetting);
        setSettings((prev) => ({
          ...prev,
          ...(parsed.cashier ? { cashier: parsed.cashier } : {}),
          ...(typeof parsed.autoLogoutMinutes === 'number' ? { autoLogoutMinutes: parsed.autoLogoutMinutes } : {}),
          ...(parsed.rekening ? { rekening: parsed.rekening } : {}),
        }));
      } catch {}
    }

    // Auto Background Sync Every 10 Minutes (10 * 60 * 1000 = 600,000 ms)
    const intervalId = setInterval(() => {
      handleSyncData();
    }, 10 * 60 * 1000);

    // Setup resilient online auto-sync listener
    const unsubAutoSync = setupAutoSyncListener((syncedCount) => {
      showToast(`Otomatis mengunggah ${syncedCount} transaksi dari penyimpanan lokal ke server!`, 'success');
      handleSyncData();
    });

    return () => {
      clearInterval(intervalId);
      unsubAutoSync();
    };
  }, [handleSyncData, loadNewInvoiceNumber, showToast]);

  // Inactivity & Auto Logout Watcher
  useEffect(() => {
    if (!currentUser) return;

    // Reset timestamp on user activity events
    const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'];
    const handleUserActivity = () => {
      lastActivityRef.current = Date.now();
    };

    events.forEach((evt) => window.addEventListener(evt, handleUserActivity, { passive: true }));

    const logoutMinutes = settings.autoLogoutMinutes ?? 15;

    const checkInterval = setInterval(() => {
      if (logoutMinutes <= 0) return; // 0 = disabled

      const inactiveMs = Date.now() - lastActivityRef.current;
      const limitMs = logoutMinutes * 60 * 1000;

      if (inactiveMs >= limitMs) {
        handleLogout(`Sesi kasir berakhir otomatis karena tidak ada aktivitas selama ${logoutMinutes} menit`);
      }
    }, 10000); // Check every 10 seconds

    return () => {
      events.forEach((evt) => window.removeEventListener(evt, handleUserActivity));
      clearInterval(checkInterval);
    };
  }, [currentUser, settings.autoLogoutMinutes, handleLogout]);

  // Handle Item Spec Modal Confirmation
  const handleConfirmSpecItem = (newItem: InvoiceItem) => {
    setInvoiceItems((prev) => [...prev, newItem]);
    setIsSpecModalOpen(false);
    showToast(`"${newItem.nama}" ditambahkan ke order`, 'success');
  };

  // Stepper Qty Update
  const handleUpdateQty = (index: number, delta: number) => {
    setInvoiceItems((prev) => {
      const updated = [...prev];
      const cur = updated[index];
      const newQty = Math.max(0.01, parseFloat((cur.qty + delta).toFixed(2)));
      updated[index] = {
        ...cur,
        qty: newQty,
        totalItem: computeItemTotal({ ...cur, qty: newQty }),
      };
      return updated;
    });
  };

  // Remove Item
  const handleRemoveItem = (index: number) => {
    setInvoiceItems((prev) => prev.filter((_, i) => i !== index));
    showToast('Item dihapus dari order', 'info');
  };

  // Delete Customer
  const handleDeleteCustomer = async (cName: string) => {
    deleteCustomerFirebase(cName).catch(() => {});
    const res = await deleteCustomer(cName);
    setCustomers((prev) => {
      const updated = prev.filter((c) => c.nama.trim().toLowerCase() !== cName.trim().toLowerCase());
      localStorage.setItem('warung_kaka_customers', JSON.stringify(updated));
      return updated;
    });
    showToast(res.message, 'success');
  };

  // Delete Invoice with Automatic Stock Restoration
  const handleDeleteInvoice = async (invoiceNo: string, passedItems?: InvoiceItem[]) => {
    const cleanNo = invoiceNo.trim();
    if (!cleanNo) return;

    // 1. Find the target invoice in current React state to know its items
    const targetInvoice = invoices.find(
      (i) => (i.invoiceNo || (i as any).noInvoice)?.trim().toLowerCase() === cleanNo.toLowerCase()
    );
    let invoiceItems: InvoiceItem[] = Array.isArray(passedItems) && passedItems.length > 0
      ? passedItems
      : Array.isArray(targetInvoice?.items) && targetInvoice!.items.length > 0
      ? targetInvoice!.items
      : [];

    // Fallback: check recent invoice cache from localStorage if items are not in state
    if (invoiceItems.length === 0) {
      try {
        const cachedRaw = localStorage.getItem('strukku_recent_invoices');
        if (cachedRaw) {
          const cachedList = JSON.parse(cachedRaw);
          const found = cachedList.find((i: any) => (i.invoiceNo || i.noInvoice)?.trim().toLowerCase() === cleanNo.toLowerCase());
          if (found && Array.isArray(found.items) && found.items.length > 0) {
            invoiceItems = found.items;
          }
        }
      } catch {}
    }

    try {
      // 2. Delete from Firebase and restore stock in Firestore
      const deleteResult = await deleteInvoiceFirebase(cleanNo, invoiceItems);

      // Determine final restored items list from Firestore return or invoiceItems
      const itemsRestoredList = deleteResult.restoredDetails && deleteResult.restoredDetails.length > 0
        ? deleteResult.restoredDetails
        : invoiceItems;

      // 3. Update React invoices state
      setInvoices((prev) => prev.filter((i) => (i.invoiceNo || (i as any).noInvoice)?.trim().toLowerCase() !== cleanNo.toLowerCase()));

      // 4. Update React products state and localStorage immediately
      let restoredSummary = '';
      if (itemsRestoredList.length > 0) {
        setProducts((prevProducts) => {
          const modifiedProds: Product[] = [];
          const updated = prevProducts.map((prod) => {
            const prodCode = (prod.kode || '').trim().toLowerCase();
            const prodName = (prod.nama || '').trim().toLowerCase();

            // Find all matching items (by code or name)
            const matchedItems = itemsRestoredList.filter((it: any) => {
              const itCode = (it.kode || '').trim().toLowerCase();
              const itName = (it.nama || '').trim().toLowerCase();
              const isCodeMatch = Boolean(itCode && prodCode && itCode === prodCode);
              const isNameMatch = Boolean(itName && prodName && (itName === prodName || itName.replace(/\s+/g, '') === prodName.replace(/\s+/g, '')));
              return isCodeMatch || isNameMatch;
            });

            if (matchedItems.length > 0) {
              const curStok = parseFloat(String(prod.stok ?? '0'));
              const addQty = matchedItems.reduce((acc, it: any) => acc + (Number(it.qty) || 0), 0);
              const newStok = isNaN(curStok) ? addQty : curStok + addQty;
              const mod: Product = {
                ...prod,
                stok: String(newStok),
              };
              modifiedProds.push(mod);
              return mod;
            }
            return prod;
          });

          try {
            localStorage.setItem('strukku_products', JSON.stringify(updated));
            localStorage.setItem('warung_kaka_products', JSON.stringify(updated));
          } catch {}

          // Also sync each restored product's updated stock to Google Sheets in background
          modifiedProds.forEach((p) => {
            updateProductDetails(p).catch(() => {});
          });

          return updated;
        });

        restoredSummary = itemsRestoredList
          .map((i: any) => `${i.nama} (+${i.qty} ${i.satuan || 'pcs'})`)
          .join(', ');
      }

      // 5. Clean recent cached invoices
      const recentCached = localStorage.getItem('strukku_recent_invoices');
      if (recentCached) {
        try {
          const parsed: any[] = JSON.parse(recentCached);
          const filtered = parsed.filter((i) => (i.invoiceNo || i.noInvoice)?.trim().toLowerCase() !== cleanNo.toLowerCase());
          localStorage.setItem('strukku_recent_invoices', JSON.stringify(filtered));
        } catch {}
      }

      // Also sync delete with Google Sheets in background
      deleteInvoiceRemote(cleanNo).catch(() => {});

      // 6. User Toast Feedback
      if (restoredSummary) {
        showToast(`Nota "${cleanNo}" dihapus & stok barang berhasil dikembalikan: ${restoredSummary}`, 'success');
      } else {
        showToast(`Nota "${cleanNo}" berhasil dihapus`, 'success');
      }

      // 7. Log Activity
      logActivity({
        type: 'void_invoice',
        actor: currentUser || settings.cashier || 'Admin',
        title: `Hapus Nota Transaksi: ${cleanNo}`,
        description: `Nota transaksi ${cleanNo} telah dihapus dari sistem oleh ${currentUser || settings.cashier || 'Admin'}.${restoredSummary ? ` Stok barang dikembalikan: ${restoredSummary}.` : ''}`,
        date: fDateInput(new Date()),
        time: fTime(new Date()),
        metadata: {
          invoiceNo: cleanNo,
          customerName: targetInvoice?.customer || (targetInvoice as any)?.pelanggan,
          amount: targetInvoice?.total,
          restoredItems: restoredSummary,
        }
      }).catch(() => {});

      // 8. Record reverse stock-in in history for complete audit
      if (itemsRestoredList.length > 0) {
        const stockInVoidPayload: StockInRecord = {
          id: `VOID-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          kode: cleanNo,
          nama: `Pengembalian Stok (Hapus Nota: ${cleanNo})`,
          qty: itemsRestoredList.reduce((acc, it: any) => acc + (Number(it.qty) || 0), 0),
          satuan: 'item',
          supplier: `Sistem Pembatalan Nota (${targetInvoice?.customer || 'Pelanggan'})`,
          cashier: currentUser || settings.cashier || 'Admin',
          date: fDateInput(new Date()),
          time: fTime(new Date()),
          catatan: `[Hapus Nota] Stok dikembalikan ke sistem: ${restoredSummary}`,
        };
        saveStockInFirebase(stockInVoidPayload).catch(() => {});
        addStockIn(stockInVoidPayload).catch(() => {});
      }
    } catch {
      showToast(`Gagal menghapus nota "${cleanNo}"`, 'error');
    }
  };

  // Reset to New Order
  const handleNewOrder = async () => {
    setInvoiceItems([]);
    setSelectedCustomer('');
    setDiscountPct(0);
    setNegoAmt(0);
    setTaxPct(0);
    setDpAmount('');
    setPayMethod('Tunai');
    setOrderDate(fDateInput(new Date()));
    setDeadlineDate('');
    await loadNewInvoiceNumber();
    showToast('Order baru dibuat', 'info');
  };

  // Compute Current Invoice Calculations
  const subtotal = invoiceItems.reduce((s, i) => s + computeItemTotal(i), 0);
  const discAmt = (subtotal * discountPct) / 100;
  const afterDisc = Math.max(0, subtotal - discAmt - negoAmt);
  const taxAmt = (afterDisc * taxPct) / 100;
  const total = Math.max(0, afterDisc) + taxAmt;

  const isPotongGaji = payMethod === 'Potong Gaji';
  const isVoucherWaka = payMethod === 'Voucher WAKA';
  let dp = 0;
  let sisa = 0;
  let kembalian = 0;
  let invoiceStatus: 'LUNAS' | 'DP' | 'BELUM LUNAS' = 'LUNAS';

  if (isPotongGaji) {
    dp = 0;
    sisa = total;
    kembalian = 0;
    invoiceStatus = 'BELUM LUNAS';
  } else if (isVoucherWaka) {
    dp = total;
    sisa = 0;
    kembalian = 0;
    invoiceStatus = 'LUNAS';
  } else {
    // Tunai
    if (dpAmount === '' || dpAmount === undefined || dpAmount === null) {
      dp = total;
      sisa = 0;
      kembalian = 0;
      invoiceStatus = 'LUNAS';
    } else {
      const parsedDp = typeof dpAmount === 'number' ? dpAmount : parseFloat(dpAmount) || 0;
      if (parsedDp >= total) {
        dp = total;
        kembalian = parsedDp - total;
        sisa = 0;
        invoiceStatus = 'LUNAS';
      } else {
        dp = parsedDp;
        sisa = Math.max(0, total - parsedDp);
        kembalian = 0;
        invoiceStatus = dp > 0 ? 'DP' : 'BELUM LUNAS';
      }
    }
  }

  const selectedCustObj = customers.find(
    (c) => c.nama.trim().toLowerCase() === selectedCustomer.trim().toLowerCase()
  );

  const currentInvoiceData: Partial<Invoice> = {
    invoiceNo,
    date: fDate(new Date()),
    time: fTime(new Date()),
    customer: selectedCustomer.trim(),
    customerPhone: selectedCustObj ? selectedCustObj.telepon : '',
    customerAddress: selectedCustObj ? selectedCustObj.alamat : '',
    cashier: settings.cashier || 'Admin',
    subtotal,
    discPct: discountPct,
    discAmt,
    taxPct,
    taxAmt,
    negoAmt,
    total,
    payMethod,
    dp,
    sisa,
    kembalian,
    deadline: deadlineDate ? formatDateFromInput(deadlineDate) : '',
    status: invoiceStatus,
    items: invoiceItems,
  };

  // Save Transaction to Google Sheets & Firebase
  const saveTransactionToSheets = async () => {
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return false;
    }
    if (isTransactionSaved) return true;

    setIsSaving(true);
    const nextSlipNo = getNextSlipNumberForCustomer(selectedCustomer.trim(), invoices, customers);
    const customerDivisi = (selectedCustObj?.divisi || selectedCustObj?.division || '').trim();
    const payload: any = {
      ...currentInvoiceData,
      divisi: customerDivisi,
      division: customerDivisi,
      noInvoice: currentInvoiceData.invoiceNo || invoiceNo,
      tanggal: currentInvoiceData.date || fDate(new Date()),
      jam: currentInvoiceData.time || fTime(new Date()),
      pelanggan: selectedCustomer.trim(),
      metodePembayaran: payMethod,
      deadline: deadlineDate ? formatDateFromInput(deadlineDate) : '',
      slipNo: nextSlipNo,
      slipPrinted: false,
      items: invoiceItems.map((i) => ({
        ...i,
        totalItem: computeItemTotal(i),
      })),
    };

    // Immediately update local React state so any consecutive transactions or calculations have up-to-date state
    setInvoices((prev) => {
      const filtered = prev.filter((i) => (i.invoiceNo || (i as any).noInvoice) !== payload.noInvoice);
      return [payload as Invoice, ...filtered];
    });

    // Immediately decrease local products stock in React state & localStorage
    setProducts((prevProducts) => {
      const updated = prevProducts.map((prod) => {
        const itemSold = invoiceItems.find(
          (it) => (it.kode && it.kode.trim().toLowerCase() === prod.kode.trim().toLowerCase()) ||
                  (!it.kode && it.nama && it.nama.trim().toLowerCase() === prod.nama.trim().toLowerCase())
        );
        if (itemSold) {
          const curStok = parseFloat(String(prod.stok ?? '0'));
          const subQty = Number(itemSold.qty) || 0;
          const newStok = isNaN(curStok) ? 0 : Math.max(0, curStok - subQty);
          return {
            ...prod,
            stok: String(newStok),
          };
        }
        return prod;
      });
      try {
        localStorage.setItem('strukku_products', JSON.stringify(updated));
        localStorage.setItem('warung_kaka_products', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // Update local cache instantly
    addRecentInvoiceToLocal(payload);

    // Save to Firebase Firestore instantly with offline fallback backup
    saveInvoiceFirebase(payload as Invoice).catch((err) => {
      console.warn('Firebase saveInvoice notice (queued to local offline storage):', err);
      enqueueOfflineOperation('invoice', payload.noInvoice, payload);
    });

    // Record sales to Stock In history & System Activity Log
    const itemsSummary = invoiceItems.map((i) => `${i.nama} (${i.qty} ${i.satuan || 'pcs'})`).join(', ');
    const stockInPayload: StockInRecord = {
      id: `SALE-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      kode: payload.noInvoice,
      nama: `Penjualan: ${selectedCustomer.trim()}`,
      qty: 0,
      satuan: 'transaksi',
      supplier: `Kasir POS (${payMethod})`,
      cashier: settings.cashier || currentUser || 'Admin',
      date: fDateInput(new Date()),
      time: fTime(new Date()),
      catatan: `[Penjualan Kasir] No: ${payload.noInvoice} | Pelanggan: ${selectedCustomer.trim()} | Total: ${fRp(total)} | Bayar: ${payMethod} | Items: ${itemsSummary}`,
    };
    saveStockInFirebase(stockInPayload).catch(() => {});
    addStockIn(stockInPayload).catch(() => {});

    logActivity({
      type: 'penjualan',
      actor: settings.cashier || currentUser || 'Admin',
      title: `Penjualan Kasir: ${payload.noInvoice} (${selectedCustomer.trim()})`,
      description: `Transaksi senilai ${fRp(total)} (${payMethod}) untuk ${selectedCustomer.trim()}${customerDivisi ? ' [Divisi: ' + customerDivisi + ']' : ''}. Items: ${itemsSummary}`,
      date: fDateInput(new Date()),
      time: fTime(new Date()),
      metadata: {
        invoiceNo: payload.noInvoice,
        customerName: selectedCustomer.trim(),
        amount: total,
        payMethod: payMethod,
        qty: invoiceItems.reduce((acc, i) => acc + (Number(i.qty) || 1), 0),
      },
    }).catch(() => {});

    // Save to Connected Google Spreadsheet (via Google Workspace API) if configured
    const connectedSpreadsheetId = getStoredSpreadsheetId();
    if (connectedSpreadsheetId) {
      appendInvoiceToGoogleSheets(connectedSpreadsheetId, payload as Invoice).catch((err) => {
        console.warn('Google Workspace Sheets append error:', err);
      });
    }

    // Save to Google Apps Script asynchronously in background (non-blocking) with offline fallback
    saveTransaction(payload).then((res) => {
      if (!res.success) {
        console.warn('Google Sheets async save notice:', res.message);
        enqueueOfflineOperation('invoice', payload.noInvoice, payload);
      }
    }).catch((err) => {
      console.warn('Google Sheets async save error (queued locally):', err);
      enqueueOfflineOperation('invoice', payload.noInvoice, payload);
    });

    setIsSaving(false);
    setIsTransactionSaved(true);
    return true;
  };

  // Reset order state cleanly without showToast noise
  const resetOrderState = async () => {
    setInvoiceItems([]);
    setSelectedCustomer('');
    setDiscountPct(0);
    setNegoAmt(0);
    setTaxPct(0);
    setDpAmount('');
    setPayMethod('Tunai');
    setOrderDate(fDateInput(new Date()));
    setDeadlineDate('');
    await loadNewInvoiceNumber();
  };

  // Save Order Handler (Direct Save to Firebase and Sheets)
  const handleSaveOrder = async () => {
    if (invoiceItems.length === 0) return;
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return;
    }
    const currentNo = invoiceNo;
    const saved = await saveTransactionToSheets();
    if (saved) {
      await resetOrderState();
      showToast(`Transaksi ${currentNo} berhasil disimpan!`, 'success');
    }
  };

  // Print Thermal Handler (For Reprint modal & direct print)
  const handlePrintThermal = async () => {
    if (invoiceItems.length === 0) return;
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return;
    }
    const saved = await saveTransactionToSheets();
    if (saved) {
      const html = generateThermalHTML(currentInvoiceData, settings);
      openPrintWindow(html, 'Struk ' + invoiceNo);
      await resetOrderState();
      showToast('Transaksi selesai! Order baru otomatis disiapkan.', 'success');
    }
  };

  // Print A5 Invoice Handler (For Reprint modal & direct print)
  const handlePrintA5 = async () => {
    if (invoiceItems.length === 0) return;
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return;
    }
    const saved = await saveTransactionToSheets();
    if (saved) {
      const html = generateA5HTML(currentInvoiceData, settings);
      openPrintWindow(html, 'Invoice A5 ' + invoiceNo);
      await resetOrderState();
      showToast('Transaksi selesai! Order baru otomatis disiapkan.', 'success');
    }
  };

  // Sample Data Loading
  const handleLoadSampleData = () => {
    setProducts(INITIAL_PRODUCTS);
    localStorage.setItem('strukku_products', JSON.stringify(INITIAL_PRODUCTS));
    showToast(`Data contoh dimuat (${INITIAL_PRODUCTS.length} produk)`, 'success');
  };

  // CSV Import Confirmation
  const handleConfirmImportProducts = (imported: Product[]) => {
    setProducts(imported);
    localStorage.setItem('strukku_products', JSON.stringify(imported));
  };

  // Record Pelunasan Piutang Handler (Firebase + Google Sheets + Offline Queue Fallback)
  const handleRecordPelunasan = async (payload: PelunasanRecord) => {
    // 1. Immediately record in local storage so UI and offline mode work instantly
    savePelunasanHistoryToLocal(payload);

    // 2. Optimistically update local React invoices state so UI updates instantaneously
    setInvoices((prev) => {
      const targetNo = (payload.invoiceNo || '').trim().toLowerCase();
      return prev.map((inv) => {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
        if (invNo === targetNo) {
          const currentHist = inv.pelunasanHistory || inv.historiPelunasan || [];
          const merged = mergePelunasanHistories(currentHist, [payload]);
          return recalculateInvoiceSisaAndStatus({
            ...inv,
            pelunasanHistory: merged,
            historiPelunasan: merged,
          });
        }
        return inv;
      });
    });

    try {
      await recordPelunasanFirebase(payload).catch((fbErr) => {
        console.warn('Firebase pelunasan notice (enqueued locally):', fbErr);
        enqueueOfflineOperation('pelunasan', payload.invoiceNo, payload);
      });

      submitPelunasan(payload).catch((gasErr) => {
        console.warn('GAS pelunasan notice (enqueued locally):', gasErr);
        enqueueOfflineOperation('pelunasan', payload.invoiceNo, payload);
      });

      showToast(`Pelunasan nota ${payload.invoiceNo} berhasil dicatat!`, 'success');

      logActivity({
        type: 'pelunasan',
        actor: payload.cashier || currentUser || settings.cashier || 'Admin',
        title: `Pelunasan Bon: ${payload.invoiceNo} (${fRp(payload.jumlahBayar)})`,
        description: `Pelunasan piutang nota ${payload.invoiceNo} sejumlah ${fRp(payload.jumlahBayar)} dengan metode ${payload.payMethod}. Kasir: ${payload.cashier || 'Admin'}${payload.catatan ? ' | ' + payload.catatan : ''}`,
        date: payload.date,
        time: payload.time,
        metadata: {
          invoiceNo: payload.invoiceNo,
          amount: payload.jumlahBayar,
          payMethod: payload.payMethod,
        }
      }).catch(() => {});
    } catch (err: any) {
      enqueueOfflineOperation('pelunasan', payload.invoiceNo, payload);
      showToast(`Pelunasan nota ${payload.invoiceNo} tersimpan secara lokal (offline)!`, 'info');
    }
  };

  const handleBatchRecordPelunasan = async (payloads: PelunasanRecord[]) => {
    const dedupedPayloads = mergePelunasanHistories(payloads, []);
    dedupedPayloads.forEach((p) => savePelunasanHistoryToLocal(p));

    // Optimistically update React invoices state for all settled invoices
    setInvoices((prev) => {
      const payloadMap = new Map<string, PelunasanRecord[]>();
      dedupedPayloads.forEach((p) => {
        const k = (p.invoiceNo || '').trim().toLowerCase();
        if (!payloadMap.has(k)) payloadMap.set(k, []);
        payloadMap.get(k)!.push(p);
      });

      return prev.map((inv) => {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim().toLowerCase();
        if (payloadMap.has(invNo)) {
          const newRecords = payloadMap.get(invNo)!;
          const currentHist = inv.pelunasanHistory || inv.historiPelunasan || [];
          const merged = mergePelunasanHistories(currentHist, newRecords);
          return recalculateInvoiceSisaAndStatus({
            ...inv,
            pelunasanHistory: merged,
            historiPelunasan: merged,
          });
        }
        return inv;
      });
    });

    try {
      await batchRecordPelunasanFirebase(dedupedPayloads).catch((fbErr) => {
        console.warn('Batch pelunasan Firebase notice (enqueued locally):', fbErr);
        dedupedPayloads.forEach((p) => enqueueOfflineOperation('pelunasan', p.invoiceNo, p));
      });

      Promise.allSettled(dedupedPayloads.map((p) => submitPelunasan(p))).catch(() => {});
      showToast(`Pelunasan (${dedupedPayloads.length} nota) berhasil diproses!`, 'success');

      const totalBayar = dedupedPayloads.reduce((acc, p) => acc + (Number(p.jumlahBayar) || 0), 0);
      logActivity({
        type: 'pelunasan',
        actor: currentUser || settings.cashier || 'Admin',
        title: `Pelunasan Massal: ${dedupedPayloads.length} Nota (${fRp(totalBayar)})`,
        description: `Pelunasan serentak ${dedupedPayloads.length} nota dengan total nilai ${fRp(totalBayar)}. Rincian nota: ${dedupedPayloads.map((p) => p.invoiceNo).join(', ')}`,
        date: fDateInput(new Date()),
        time: fTime(new Date()),
        metadata: {
          amount: totalBayar,
          count: dedupedPayloads.length,
        }
      }).catch(() => {});
    } catch (err: any) {
      dedupedPayloads.forEach((p) => enqueueOfflineOperation('pelunasan', p.invoiceNo, p));
      showToast(`Pelunasan (${dedupedPayloads.length} nota) disimpan secara lokal (offline)!`, 'info');
    }
  };

  const handleBatchUpdateInvoices = async (updatedInvoices: Invoice[]) => {
    try {
      await batchUpdateInvoicesFirebase(updatedInvoices);
      setInvoices((prev) => {
        const map = new Map<string, Invoice>();
        prev.forEach((i) => map.set((i.invoiceNo || (i as any).noInvoice || '').trim(), i));
        updatedInvoices.forEach((i) => map.set((i.invoiceNo || (i as any).noInvoice || '').trim(), i));
        const nextList = Array.from(map.values());
        localStorage.setItem('strukku_recent_invoices', JSON.stringify(nextList));
        return nextList;
      });
    } catch (err: any) {
      console.error('Error batch updating invoices:', err);
      showToast('Gagal memperbarui data slip: ' + (err?.message || 'Error'), 'error');
      throw err;
    }
  };

  // Calculate unpaid invoices count
  const unpaidPiutangCount = invoices.filter((inv) => {
    const sisa = inv.sisa !== undefined ? inv.sisa : Math.max(0, (inv.total || 0) - (inv.dp || 0));
    return sisa > 0;
  }).length;

  if (!currentUser) {
    if (authView === 'login') {
      return (
        <>
          {toast && (
            <div className="fixed top-4 right-4 z-50 max-w-sm animate-fade-in">
              <div
                className={`px-4 py-3 rounded-xl shadow-xl font-bold text-xs text-white flex items-center gap-2 ${
                  toast.type === 'success'
                    ? 'bg-emerald-700'
                    : toast.type === 'error'
                    ? 'bg-red-700'
                    : 'bg-stone-800'
                }`}
              >
                <span>{toast.msg}</span>
              </div>
            </div>
          )}
          <LoginScreen
            kasirUsers={kasirUsers}
            settings={settings}
            onLoginSuccess={handleLoginSuccess}
            onRefreshKasir={async () => {
              await handleSyncData();
            }}
            onUpdateKasirUsers={(newUsers) => setKasirUsers(newUsers)}
            onOpenPublicRekap={() => setAuthView('rekap')}
            onShowToast={showToast}
          />
        </>
      );
    }

    return (
      <div className="min-h-screen bg-stone-100 flex flex-col font-sans text-stone-900">
        {toast && (
          <div className="fixed top-4 right-4 z-50 max-w-sm animate-fade-in">
            <div
              className={`px-4 py-3 rounded-xl shadow-xl font-bold text-xs text-white flex items-center gap-2 ${
                toast.type === 'success'
                  ? 'bg-emerald-700'
                  : toast.type === 'error'
                  ? 'bg-red-700'
                  : 'bg-stone-800'
              }`}
            >
              <span>{toast.msg}</span>
            </div>
          </div>
        )}
        <div className="flex-1 max-w-[1600px] w-full mx-auto p-2 sm:p-4 h-screen flex flex-col">
          <PencarianRekapView
            invoices={invoices}
            customers={customers}
            settings={settings}
            cashierName="Umum"
            isLoggedIn={false}
            onLoginClick={() => setAuthView('login')}
            onReprintInvoice={(inv) => {
              const html = generateThermalHTML(inv, settings);
              openPrintWindow(html, 'Nota ' + (inv.invoiceNo || (inv as any).noInvoice));
            }}
            onShowToast={showToast}
          />
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-stone-100 flex flex-col font-sans text-stone-900 ${mainViewTab === 'transaksi' ? 'pb-16 lg:pb-0' : 'pb-2 lg:pb-0'}`}>
      {/* Toast Banner */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 max-w-sm animate-fade-in">
          <div
            className={`px-4 py-3 rounded-xl shadow-xl font-bold text-xs text-white flex items-center gap-2 ${
              toast.type === 'success'
                ? 'bg-emerald-700'
                : toast.type === 'error'
                ? 'bg-red-700'
                : 'bg-stone-800'
            }`}
          >
            <span>{toast.msg}</span>
          </div>
        </div>
      )}

      {/* Main Header */}
      <Header
        settings={settings}
        currentUser={currentUser}
        isConnected={isConnected}
        isSyncing={isSyncing}
        lastSyncTime={lastSyncTime}
        onSync={async () => {
          const ok = await handleSyncData();
          if (ok) showToast('Sinkronisasi data Google Sheets berhasil!', 'success');
          else showToast('Gagal terhubung ke Google Sheets', 'error');
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenCariRekap={() => setMainViewTab('pencarian_rekap')}
        onOpenGasGuide={() => setIsGasGuideOpen(true)}
        onLogout={handleLogout}
      />

      {/* Responsive Work Area */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-2 sm:p-4 overflow-hidden">
        {/* DESKTOP VIEW WITH LEFT SIDEBAR NAVIGATION */}
        <div className="hidden lg:flex gap-4 h-[calc(100vh-80px)] overflow-hidden">
          {/* Left Submenu Navigation Sidebar */}
          <SidebarNav
            activeTab={mainViewTab}
            onChangeTab={(tab) => setMainViewTab(tab)}
            cartCount={invoiceItems.length}
            piutangCount={unpaidPiutangCount}
            currentUser={currentUser}
            onLogout={handleLogout}
          />

          {/* Main Content Pane */}
          <div className="flex-1 min-w-0 h-full overflow-hidden">
            {mainViewTab === 'transaksi' && (
              <div className="grid grid-cols-12 gap-4 h-full">
                {/* Column 1: Catalog */}
                <div className="col-span-7 h-full overflow-hidden">
                  <ProductCatalog
                    products={products}
                    onSelectProduct={(p) => {
                      setSpecProduct(p);
                      setIsSpecModalOpen(true);
                    }}
                    onLoadSample={handleLoadSampleData}
                  />
                </div>

                {/* Column 2: Order Cart */}
                <div className="col-span-5 h-full overflow-hidden">
                  <OrderCart
                    invoiceNo={invoiceNo}
                    invoiceDate={fDate(new Date())}
                    items={invoiceItems}
                    customers={customers}
                    selectedCustomer={selectedCustomer}
                    setSelectedCustomer={setSelectedCustomer}
                    orderDate={orderDate}
                    setOrderDate={setOrderDate}
                    deadlineDate={deadlineDate}
                    setDeadlineDate={setDeadlineDate}
                    discountPct={discountPct}
                    setDiscountPct={setDiscountPct}
                    taxPct={taxPct}
                    setTaxPct={setTaxPct}
                    negoAmt={negoAmt}
                    setNegoAmt={setNegoAmt}
                    payMethod={payMethod}
                    setPayMethod={setPayMethod}
                    dpAmount={dpAmount}
                    setDpAmount={setDpAmount}
                    onUpdateQty={handleUpdateQty}
                    onRemoveItem={handleRemoveItem}
                    onNewInvoice={handleNewOrder}
                    onSaveOrder={handleSaveOrder}
                    onOpenPelunasan={() => setIsPelunasanOpen(true)}
                    onOpenAddCustomer={() => {
                      const isExisting = customers.some(
                        (c) => c.nama.toLowerCase() === selectedCustomer.trim().toLowerCase()
                      );
                      setInitialCustomerName(isExisting ? '' : selectedCustomer.trim());
                      setCustomerToEdit(null);
                      setIsAddCustomerOpen(true);
                    }}
                    isSaving={isSaving}
                    invoices={invoices}
                  />
                </div>
              </div>
            )}

            {mainViewTab === 'piutang' && (
              <PiutangView
                invoices={invoices}
                customers={customers}
                settings={settings}
                cashierName={currentUser || settings.cashier || 'Admin'}
                onRefresh={handleSyncData}
                onRecordPelunasan={handleRecordPelunasan}
                onBatchRecordPelunasan={handleBatchRecordPelunasan}
                onBatchUpdateInvoices={handleBatchUpdateInvoices}
                onReprintInvoice={(inv) => {
                  const html = generateThermalHTML(inv, settings);
                  openPrintWindow(html, 'Nota ' + (inv.invoiceNo || (inv as any).noInvoice));
                }}
                onDeleteInvoice={handleDeleteInvoice}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'pencarian_rekap' && (
              <PencarianRekapView
                invoices={invoices}
                customers={customers}
                settings={settings}
                cashierName={currentUser || settings.cashier || 'Admin'}
                isLoggedIn={true}
                onRecordPelunasan={handleRecordPelunasan}
                onBatchRecordPelunasan={handleBatchRecordPelunasan}
                onBatchUpdateInvoices={handleBatchUpdateInvoices}
                onDeleteInvoice={handleDeleteInvoice}
                onReprintInvoice={(inv) => {
                  const html = generateThermalHTML(inv, settings);
                  openPrintWindow(html, 'Nota ' + (inv.invoiceNo || (inv as any).noInvoice));
                }}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'barang_masuk' && (
              <BarangMasukView
                products={products}
                currentCashier={currentUser || 'Admin'}
                kasirUsers={kasirUsers}
                onRefreshProducts={handleSyncData}
                onProductsUpdated={setProducts}
                onShowToast={showToast}
                initialSelectedProduct={selectedRestockProduct}
              />
            )}

            {mainViewTab === 'stok_opname' && (
              <StokOpnameView
                products={products}
                currentCashier={currentUser || 'Admin'}
                settings={settings}
                onRefreshProducts={handleSyncData}
                onProductsUpdated={setProducts}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'pelanggan' && (
              <PelangganView
                customers={customers}
                onOpenAddCustomer={() => {
                  setInitialCustomerName('');
                  setCustomerToEdit(null);
                  setIsAddCustomerOpen(true);
                }}
                onEditCustomer={(cust) => {
                  setInitialCustomerName('');
                  setCustomerToEdit(cust);
                  setIsAddCustomerOpen(true);
                }}
                onSelectCustomerToOrder={(cName) => {
                  setSelectedCustomer(cName);
                  const matched = customers.find((c) => c.nama.toLowerCase() === cName.trim().toLowerCase());
                  const isKaryawan = matched
                    ? (matched.kelas || '').toLowerCase().includes('karyawan')
                    : cName.toLowerCase().includes('karyawan');
                  if (isKaryawan) {
                    setPayMethod('Potong Gaji');
                  } else {
                    setPayMethod('Tunai');
                  }
                  setMainViewTab('transaksi');
                  showToast(`Pelanggan "${cName}" dipilih untuk order`, 'success');
                }}
                onDeleteCustomer={handleDeleteCustomer}
              />
            )}

            {mainViewTab === 'laporan_penjualan' && (
              <LaporanPenjualanView
                invoices={invoices}
                products={products}
                settings={settings}
                kasirUsers={kasirUsers}
                customers={customers}
                onShowToast={showToast}
                onNavigateToTransaksi={() => setMainViewTab('transaksi')}
              />
            )}
          </div>
        </div>

        {/* MOBILE VIEW: Submenu Bar + Single Tabbed Screen */}
        <div className={`lg:hidden flex flex-col gap-2 ${mainViewTab === 'transaksi' ? 'h-[calc(100vh-130px)]' : 'h-[calc(100vh-80px)]'}`}>
          <div className="shrink-0">
            <SidebarNav
              activeTab={mainViewTab}
              onChangeTab={(tab) => setMainViewTab(tab)}
              cartCount={invoiceItems.length}
              piutangCount={unpaidPiutangCount}
              currentUser={currentUser}
              onLogout={handleLogout}
            />
          </div>

          <div className="flex-1 min-h-0 overflow-y-auto pb-20">
            {mainViewTab === 'piutang' && (
              <PiutangView
                invoices={invoices}
                customers={customers}
                settings={settings}
                cashierName={currentUser || settings.cashier || 'Admin'}
                onRefresh={handleSyncData}
                onRecordPelunasan={handleRecordPelunasan}
                onBatchRecordPelunasan={handleBatchRecordPelunasan}
                onBatchUpdateInvoices={handleBatchUpdateInvoices}
                onReprintInvoice={(inv) => {
                  const html = generateThermalHTML(inv, settings);
                  openPrintWindow(html, 'Nota ' + (inv.invoiceNo || (inv as any).noInvoice));
                }}
                onDeleteInvoice={handleDeleteInvoice}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'pencarian_rekap' && (
              <PencarianRekapView
                invoices={invoices}
                customers={customers}
                settings={settings}
                cashierName={currentUser || settings.cashier || 'Admin'}
                isLoggedIn={true}
                onRecordPelunasan={handleRecordPelunasan}
                onBatchRecordPelunasan={handleBatchRecordPelunasan}
                onBatchUpdateInvoices={handleBatchUpdateInvoices}
                onDeleteInvoice={handleDeleteInvoice}
                onReprintInvoice={(inv) => {
                  const html = generateThermalHTML(inv, settings);
                  openPrintWindow(html, 'Nota ' + (inv.invoiceNo || (inv as any).noInvoice));
                }}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'barang_masuk' && (
              <BarangMasukView
                products={products}
                currentCashier={currentUser || 'Admin'}
                kasirUsers={kasirUsers}
                onRefreshProducts={handleSyncData}
                onProductsUpdated={setProducts}
                onShowToast={showToast}
                initialSelectedProduct={selectedRestockProduct}
              />
            )}

            {mainViewTab === 'stok_opname' && (
              <StokOpnameView
                products={products}
                currentCashier={currentUser || 'Admin'}
                settings={settings}
                onRefreshProducts={handleSyncData}
                onProductsUpdated={setProducts}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'pelanggan' && (
              <PelangganView
                customers={customers}
                onOpenAddCustomer={() => {
                  setInitialCustomerName('');
                  setCustomerToEdit(null);
                  setIsAddCustomerOpen(true);
                }}
                onEditCustomer={(cust) => {
                  setInitialCustomerName('');
                  setCustomerToEdit(cust);
                  setIsAddCustomerOpen(true);
                }}
                onSelectCustomerToOrder={(cName) => {
                  setSelectedCustomer(cName);
                  const matched = customers.find((c) => c.nama.toLowerCase() === cName.trim().toLowerCase());
                  const isKaryawan = matched
                    ? (matched.kelas || '').toLowerCase().includes('karyawan')
                    : cName.toLowerCase().includes('karyawan');
                  if (isKaryawan) {
                    setPayMethod('Potong Gaji');
                  } else {
                    setPayMethod('Tunai');
                  }
                  setMainViewTab('transaksi');
                  showToast(`Pelanggan "${cName}" dipilih untuk order`, 'success');
                }}
                onDeleteCustomer={handleDeleteCustomer}
              />
            )}

            {mainViewTab === 'laporan_penjualan' && (
              <LaporanPenjualanView
                invoices={invoices}
                products={products}
                settings={settings}
                kasirUsers={kasirUsers}
                customers={customers}
                onShowToast={showToast}
                onNavigateToTransaksi={() => setMainViewTab('transaksi')}
              />
            )}

            {mainViewTab === 'transaksi' && (
              <>
                {activeTab === 'catalog' && (
                  <ProductCatalog
                    products={products}
                    onSelectProduct={(p) => {
                      setSpecProduct(p);
                      setIsSpecModalOpen(true);
                    }}
                    onLoadSample={handleLoadSampleData}
                  />
                )}

                {activeTab === 'cart' && (
                  <OrderCart
                    invoiceNo={invoiceNo}
                    invoiceDate={fDate(new Date())}
                    items={invoiceItems}
                    customers={customers}
                    selectedCustomer={selectedCustomer}
                    setSelectedCustomer={setSelectedCustomer}
                    orderDate={orderDate}
                    setOrderDate={setOrderDate}
                    deadlineDate={deadlineDate}
                    setDeadlineDate={setDeadlineDate}
                    discountPct={discountPct}
                    setDiscountPct={setDiscountPct}
                    taxPct={taxPct}
                    setTaxPct={setTaxPct}
                    negoAmt={negoAmt}
                    setNegoAmt={setNegoAmt}
                    payMethod={payMethod}
                    setPayMethod={setPayMethod}
                    dpAmount={dpAmount}
                    setDpAmount={setDpAmount}
                    onUpdateQty={handleUpdateQty}
                    onRemoveItem={handleRemoveItem}
                    onNewInvoice={handleNewOrder}
                    onSaveOrder={handleSaveOrder}
                    onOpenPelunasan={() => setIsPelunasanOpen(true)}
                    onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
                    isSaving={isSaving}
                    invoices={invoices}
                  />
                )}

                {activeTab === 'pelunasan' && (
                  <div className="bg-white border border-stone-200 rounded-xl p-4 h-full overflow-y-auto">
                    <h3 className="font-extrabold text-stone-900 text-base mb-2">
                      Pelunasan & Piutang Pelanggan
                    </h3>
                    <p className="text-xs text-stone-600 mb-4">
                      Cari invoice dengan sisa pembayaran (DP) dari Google Sheets untuk memproses pelunasan.
                    </p>
                    <button
                      onClick={() => setIsPelunasanOpen(true)}
                      className="w-full py-3 bg-red-700 hover:bg-red-800 text-white font-bold text-xs rounded-xl shadow-xs transition"
                    >
                      Buka Modal Pelunasan Piutang
                    </button>
                  </div>
                )}

                {activeTab === 'settings' && (
                  <div className="bg-white border border-stone-200 rounded-xl p-4 h-full overflow-y-auto space-y-3">
                    <h3 className="font-extrabold text-stone-900 text-base">Menu & Pengaturan</h3>
                    <button
                      onClick={() => setIsSettingsOpen(true)}
                      className="w-full py-2.5 px-4 bg-red-700 text-white text-xs font-bold rounded-xl text-left flex items-center justify-between shadow-xs"
                    >
                      <span>Pengaturan Kasir & Connect Google Sheets</span>
                      <span>→</span>
                    </button>
                    <button
                      onClick={() => setMainViewTab('pencarian_rekap')}
                      className="w-full py-2.5 px-4 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl text-left flex items-center justify-between transition"
                    >
                      <span>Pencarian Rekapan Piutang & Pelunasan</span>
                      <span>→</span>
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </main>

      {/* Mobile Bottom Navigation - Tampil khusus saat di menu Kasir POS */}
      {mainViewTab === 'transaksi' && (
        <MobileBottomNav
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          cartCount={invoiceItems.length}
          cartTotal={total}
          onOpenReprint={() => setMainViewTab('pencarian_rekap')}
        />
      )}

      {/* Item Specs Dialog Modal */}
      <SpecModal
        product={specProduct}
        isOpen={isSpecModalOpen}
        onClose={() => setIsSpecModalOpen(false)}
        onConfirm={handleConfirmSpecItem}
      />

      {/* Pelunasan Modal */}
      <PelunasanModal
        isOpen={isPelunasanOpen}
        onClose={() => setIsPelunasanOpen(false)}
        settings={settings}
        onShowToast={showToast}
      />

      {/* Reprint Modal */}
      <ReprintModal
        isOpen={isReprintOpen}
        onClose={() => setIsReprintOpen(false)}
        settings={settings}
        kasirUsers={kasirUsers}
        customers={customers}
        products={products}
        currentUser={currentUser}
        onShowToast={showToast}
      />

      {/* CSV Import Modal */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onConfirmImport={handleConfirmImportProducts}
        onShowToast={showToast}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        kasirList={kasirList}
        kasirUsers={kasirUsers}
        customers={customers}
        products={products}
        invoices={invoices}
        onUpdateProducts={(updated) => {
          setProducts(updated);
          localStorage.setItem('strukku_products', JSON.stringify(updated));
        }}
        onUpdateCustomers={(updated) => {
          setCustomers(updated);
          localStorage.setItem('strukku_customers', JSON.stringify(updated));
        }}
        onUpdateInvoices={(updated) => {
          setInvoices(updated);
          localStorage.setItem('strukku_recent_invoices', JSON.stringify(updated));
        }}
        onUpdateKasirUsers={(updated) => {
          setKasirUsers(updated);
          setKasirList(updated.map((u) => u.nama));
          localStorage.setItem('strukku_kasir_users', JSON.stringify(updated));
          localStorage.setItem('strukku_kasir_list', JSON.stringify(updated.map((u) => u.nama)));
        }}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          localStorage.setItem('strukku_settings', JSON.stringify(newSettings));
          localStorage.setItem('strukku_sheet_settings', JSON.stringify(newSettings));
        }}
        onSync={handleSyncData}
        onShowToast={showToast}
        onOpenAddCustomer={() => {
          setInitialCustomerName('');
          setCustomerToEdit(null);
          setIsAddCustomerOpen(true);
        }}
        onOpenGasGuide={() => setIsGasGuideOpen(true)}
      />

      {/* Add / Edit Customer Modal */}
      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => {
          setIsAddCustomerOpen(false);
          setCustomerToEdit(null);
          setInitialCustomerName('');
        }}
        onCustomerAdded={handleCustomerAdded}
        onShowToast={showToast}
        initialName={initialCustomerName}
        customerToEdit={customerToEdit}
        onOpenGasGuide={() => setIsGasGuideOpen(true)}
      />

      {/* Google Apps Script Setup Guide Modal */}
      <GasSetupGuideModal
        isOpen={isGasGuideOpen}
        onClose={() => setIsGasGuideOpen(false)}
        onShowToast={showToast}
      />
    </div>
  );
}
