import React from 'react';
import { 
  ShoppingBag, 
  PackagePlus, 
  Users, 
  Search,
  Sparkles,
  UserCheck,
  LogOut,
  BadgeDollarSign,
  ClipboardCheck,
  TrendingUp
} from 'lucide-react';
import { MainViewTab } from '../types';

interface SidebarNavProps {
  activeTab: MainViewTab;
  onChangeTab: (tab: MainViewTab) => void;
  cartCount?: number;
  piutangCount?: number;
  currentUser?: string | null;
  onLogout?: () => void;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onChangeTab,
  cartCount = 0,
  piutangCount = 0,
  currentUser,
  onLogout,
}) => {
  const menuItems = [
    {
      id: 'transaksi' as MainViewTab,
      label: 'Kasir WAKA',
      sublabel: 'Katalog & Order',
      icon: ShoppingBag,
      badge: cartCount > 0 ? cartCount : null,
      badgeColor: 'bg-red-700 text-white',
    },
    {
      id: 'piutang' as MainViewTab,
      label: 'Bon/Tagihan',
      sublabel: 'Rekap Tagihan WAKA',
      icon: BadgeDollarSign,
      badge: piutangCount > 0 ? `${piutangCount}` : null,
      badgeColor: 'bg-red-600 text-white',
    },
    {
      id: 'pencarian_rekap' as MainViewTab,
      label: 'Cari Bon Waka',
      sublabel: 'Piutang & Pelunasan',
      icon: Search,
      badge: null,
    },
    {
      id: 'barang_masuk' as MainViewTab,
      label: 'Inventory',
      sublabel: 'Restock & Stok',
      icon: PackagePlus,
      badge: null,
    },
    {
      id: 'stok_opname' as MainViewTab,
      label: 'Stok Opname',
      sublabel: 'Audit & Selisih Fisik',
      icon: ClipboardCheck,
      badge: null,
    },
    {
      id: 'pelanggan' as MainViewTab,
      label: 'Pelanggan',
      sublabel: 'Data Karyawan & Member',
      icon: Users,
      badge: null,
    },
    {
      id: 'laporan_penjualan' as MainViewTab,
      label: 'Laporan',
      sublabel: 'Omset & Barang Laris',
      icon: TrendingUp,
      badge: null,
    },
  ];

  return (
    <aside className="w-full lg:w-60 xl:w-64 shrink-0 bg-white border border-stone-200/80 rounded-2xl p-2.5 shadow-xs flex flex-col justify-between select-none">
      <div>
        {/* Navigation Header */}
        <div className="px-3 py-2 mb-2 border-b border-stone-100 hidden lg:block">
          <div className="flex items-center gap-2 text-stone-400 font-bold text-[10px] tracking-wider uppercase">
            <Sparkles className="w-3 h-3 text-red-600" />
            <span>Menu Utama</span>
          </div>
        </div>

        {/* Desktop Sidebar List / Mobile Scrollable Bar */}
        <nav className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible pb-1 lg:pb-0 scrollbar-none">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onChangeTab(item.id)}
                className={`flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl font-medium text-xs transition-all whitespace-nowrap shrink-0 lg:w-full cursor-pointer ${
                  isActive
                    ? 'bg-red-700 text-white font-bold shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100 hover:text-stone-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`p-1.5 rounded-lg shrink-0 ${
                      isActive ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="text-left leading-tight hidden lg:block">
                    <div className="font-bold">{item.label}</div>
                    <div
                      className={`text-[10px] ${
                        isActive ? 'text-red-100' : 'text-stone-400 font-normal'
                      }`}
                    >
                      {item.sublabel}
                    </div>
                  </div>
                  <span className="lg:hidden font-bold">{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded-full ${
                      item.badgeColor || 'bg-red-100 text-red-800'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="lg:hidden flex items-center gap-1.5 px-3 py-2.5 rounded-xl font-bold text-xs bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 transition whitespace-nowrap shrink-0 active:scale-95 cursor-pointer"
              title={`Keluar (${currentUser || 'Kasir'})`}
            >
              <LogOut className="w-4 h-4 text-red-600" />
              <span>Keluar</span>
            </button>
          )}
        </nav>
      </div>

      {/* Footer User Info & Logout Box */}
      {currentUser && (
        <div className="mt-3 p-2.5 rounded-xl bg-red-50/80 border border-red-200/80 hidden lg:block">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-700 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-2xs">
              <UserCheck className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[9px] uppercase font-black text-red-900 tracking-wider">
                User Log In
              </div>
              <div className="font-black text-xs text-stone-900 truncate">
                {currentUser}
              </div>
            </div>
          </div>

          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="w-full mt-2.5 py-1.5 px-2 bg-red-700 hover:bg-red-800 active:scale-95 text-white font-extrabold text-xs rounded-lg flex items-center justify-center gap-1.5 shadow-2xs transition cursor-pointer"
              title="Keluar / Ganti Kasir"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Keluar</span>
            </button>
          )}
        </div>
      )}
    </aside>
  );
};
