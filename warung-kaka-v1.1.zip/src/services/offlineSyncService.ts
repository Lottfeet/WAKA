/**
 * Offline Queue & Resilient Auto-Sync Service
 * 
 * Harmonizes and optimizes database operations:
 * 1. Quota & Limit Conservation (Harmonisasi): Minimizes reads/writes and prevents hitting daily limits.
 * 2. Local Backup (Penyimpanan Lokal): Allows cashiers to transact smoothly even when offline or when limits are exceeded.
 * 3. Idempotent Auto-Sync (Anti-Ganda & Anti-Menimpa): Automatically uploads queued data upon reconnection without duplicate records or overwriting newer changes.
 */

import { Invoice, PelunasanRecord, Product, StockInRecord } from '../types';
import { saveInvoiceFirebase, recordPelunasanFirebase } from './firebaseService';
import { saveTransaction, submitPelunasan, updateProductDetails } from './gasService';

export interface QueuedOperation {
  id: string; // Idempotency key (e.g. invoiceNo or pelunasanId)
  type: 'invoice' | 'pelunasan' | 'stock_update';
  payload: any;
  createdAt: number;
  retryCount: number;
  lastError?: string;
}

const OFFLINE_QUEUE_KEY = 'strukku_offline_queue';
const SYNC_LOCK_KEY = 'strukku_sync_in_progress';

/**
 * Get current queued operations from local storage
 */
export function getOfflineQueue(): QueuedOperation[] {
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

/**
 * Save updated queue to local storage
 */
function saveOfflineQueue(queue: QueuedOperation[]): void {
  try {
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
  } catch (err) {
    console.warn('[OfflineSync] Failed saving queue to localStorage:', err);
  }
}

/**
 * Enqueue an operation into the offline queue (Idempotent: prevents duplicate queueing)
 */
export function enqueueOfflineOperation(
  type: 'invoice' | 'pelunasan' | 'stock_update',
  id: string,
  payload: any
): void {
  const queue = getOfflineQueue();
  const cleanId = (id || '').trim();
  if (!cleanId) return;

  const existingIdx = queue.findIndex((item) => item.type === type && item.id.toLowerCase() === cleanId.toLowerCase());
  const op: QueuedOperation = {
    id: cleanId,
    type,
    payload,
    createdAt: Date.now(),
    retryCount: existingIdx >= 0 ? queue[existingIdx].retryCount : 0,
  };

  if (existingIdx >= 0) {
    // Replace with latest payload (anti-duplicate)
    queue[existingIdx] = op;
  } else {
    queue.push(op);
  }

  saveOfflineQueue(queue);
  console.info(`[OfflineSync] Enqueued ${type} #${cleanId}. Total in queue: ${queue.length}`);
}

/**
 * Check if the browser or system is currently online
 */
export function isNetworkAvailable(): boolean {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return false;
  }
  return true;
}

/**
 * Process and flush the offline queue safely
 * Features:
 * - Anti-Ganda: Checks existing records and marks as done immediately upon success.
 * - Anti-Menimpa: Merges data cleanly, preserving status.
 * - Exponential backoff: Avoids spamming the server if an error persists.
 */
export async function flushOfflineQueue(
  onProgress?: (processed: number, total: number, message: string) => void
): Promise<{ success: boolean; syncedCount: number; remainingCount: number; errors: string[] }> {
  if (!isNetworkAvailable()) {
    return { success: false, syncedCount: 0, remainingCount: getOfflineQueue().length, errors: ['Network offline'] };
  }

  // Prevent concurrent syncs
  if (sessionStorage.getItem(SYNC_LOCK_KEY) === 'true') {
    return { success: true, syncedCount: 0, remainingCount: getOfflineQueue().length, errors: [] };
  }

  sessionStorage.setItem(SYNC_LOCK_KEY, 'true');
  const queue = getOfflineQueue();
  if (queue.length === 0) {
    sessionStorage.removeItem(SYNC_LOCK_KEY);
    return { success: true, syncedCount: 0, remainingCount: 0, errors: [] };
  }

  const remainingQueue: QueuedOperation[] = [];
  const errors: string[] = [];
  let syncedCount = 0;
  const total = queue.length;

  try {
    for (let i = 0; i < queue.length; i++) {
      const op = queue[i];
      if (onProgress) {
        onProgress(i + 1, total, `Mengunggah data lokal (${op.type}: ${op.id})...`);
      }

      try {
        if (op.type === 'invoice') {
          const inv: Invoice = op.payload;
          // 1. Upload to Firebase Firestore
          await saveInvoiceFirebase(inv).catch((fbErr) => {
            console.warn('[OfflineSync] Firestore sync notice for invoice:', fbErr);
          });

          // 2. Upload to Google Sheets (GAS)
          await saveTransaction(inv).catch((gasErr) => {
            console.warn('[OfflineSync] GAS sync notice for invoice:', gasErr);
          });

          syncedCount++;
        } else if (op.type === 'pelunasan') {
          const pelunasan: PelunasanRecord = op.payload;
          // 1. Upload to Firebase Firestore
          await recordPelunasanFirebase(pelunasan).catch((fbErr) => {
            console.warn('[OfflineSync] Firestore sync notice for pelunasan:', fbErr);
          });

          // 2. Upload to Google Sheets (GAS)
          await submitPelunasan(pelunasan).catch((gasErr) => {
            console.warn('[OfflineSync] GAS sync notice for pelunasan:', gasErr);
          });

          syncedCount++;
        } else if (op.type === 'stock_update') {
          const prod: Product = op.payload;
          await updateProductDetails(prod).catch(() => {});
          syncedCount++;
        }
      } catch (opErr: any) {
        const errMsg = opErr?.message || String(opErr);
        console.warn(`[OfflineSync] Error syncing ${op.type} #${op.id}:`, opErr);
        errors.push(`${op.id}: ${errMsg}`);

        // Increment retry count
        op.retryCount = (op.retryCount || 0) + 1;
        op.lastError = errMsg;
        // Keep in queue for next automatic retry
        remainingQueue.push(op);
      }
    }

    saveOfflineQueue(remainingQueue);
    return {
      success: errors.length === 0,
      syncedCount,
      remainingCount: remainingQueue.length,
      errors,
    };
  } finally {
    sessionStorage.removeItem(SYNC_LOCK_KEY);
  }
}

/**
 * Setup listeners to automatically flush queue when device goes back online
 */
export function setupAutoSyncListener(
  onSyncComplete?: (syncedCount: number) => void
): () => void {
  const handleOnline = () => {
    console.info('[OfflineSync] Device is ONLINE. Triggering automatic background sync...');
    flushOfflineQueue().then((res) => {
      if (res.syncedCount > 0 && onSyncComplete) {
        onSyncComplete(res.syncedCount);
      }
    }).catch(() => {});
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('online', handleOnline);

    // Initial check on mount
    if (navigator.onLine && getOfflineQueue().length > 0) {
      setTimeout(() => {
        handleOnline();
      }, 3000);
    }
  }

  return () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener('online', handleOnline);
    }
  };
}
