import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  Calendar, 
  DollarSign, 
  ShoppingBag, 
  Package, 
  CreditCard, 
  Users, 
  Search, 
  Printer, 
  Download, 
  RotateCw, 
  Award, 
  Clock, 
  ChevronRight,
  Receipt,
  FileSpreadsheet,
  Layers,
  ArrowUpRight,
  Filter,
  CheckCircle2,
  AlertCircle,
  Eye,
  Building2,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip as RechartsTooltip, 
  CartesianGrid,
  Cell
} from 'recharts';
import { Invoice, Product, StoreSettings, KasirUser, Customer } from '../types';
import { fRp, fNum, fDate, fDateInput, escHtml } from '../utils/formatters';
import { generateThermalHTML, openPrintWindow } from '../utils/printUtils';
import { getCustomerDivision } from '../utils/excelUtils';
import { getLocalCustomers } from '../services/gasService';

interface LaporanPenjualanViewProps {
  invoices: Invoice[];
  products: Product[];
  settings: StoreSettings;
  kasirUsers?: KasirUser[];
  customers?: Customer[];
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
  onNavigateToTransaksi?: () => void;
}

type PeriodFilter = 'hari_ini' | 'kemarin' | '7_hari' | 'bulan_ini' | '30_hari' | 'semua' | 'custom';
type TopSortBy = 'qty' | 'omset';

export const LaporanPenjualanView: React.FC<LaporanPenjualanViewProps> = ({
  invoices,
  products,
  settings,
  kasirUsers = [],
  customers,
  onShowToast,
  onNavigateToTransaksi,
}) => {
  const allCustomers = useMemo(() => {
    return customers && customers.length > 0 ? customers : getLocalCustomers();
  }, [customers]);

  // Table search & filter for daftar_transaksi
  const [tableSearch, setTableSearch] = useState<string>('');
  const [tableQuickStatus, setTableQuickStatus] = useState<'all' | 'LUNAS' | 'PIUTANG' | 'POTONG_GAJI'>('all');
  const [showFullMetricsInTableTab, setShowFullMetricsInTableTab] = useState<boolean>(false);
  const [isTableMaximized, setIsTableMaximized] = useState<boolean>(false);
  const [tableMobileView, setTableMobileView] = useState<'card' | 'table'>('card');
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);
  const [copiedInvoiceNo, setCopiedInvoiceNo] = useState<string | null>(null);

  const handleCopyNoNota = (noNota: string) => {
    navigator.clipboard?.writeText(noNota);
    setCopiedInvoiceNo(noNota);
    onShowToast(`No. Nota ${noNota} berhasil disalin!`, 'info');
    setTimeout(() => setCopiedInvoiceNo(null), 2000);
  };

  const handlePrintNotaThermal = (inv: Invoice) => {
    const html = generateThermalHTML(inv, settings);
    openPrintWindow(html, 'Nota ' + (inv.invoiceNo || (inv as any).noInvoice));
  };

  // Period & Date Filters
  const [period, setPeriod] = useState<PeriodFilter>('hari_ini');
  const [customStartDate, setCustomStartDate] = useState<string>(() => fDateInput(new Date()));
  const [customEndDate, setCustomEndDate] = useState<string>(() => fDateInput(new Date()));
  
  // Secondary Filters
  const [selectedKasir, setSelectedKasir] = useState<string>('all');
  const [selectedPayMethod, setSelectedPayMethod] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  
  // Best Seller View Controls
  const [topSortBy, setTopSortBy] = useState<TopSortBy>('qty');
  const [topCategory, setTopCategory] = useState<string>('Semua');
  const [productSearch, setProductSearch] = useState<string>('');

  // Active Tab for Analytics Sub-view
  const [analyticsSubTab, setAnalyticsSubTab] = useState<'produk_laris' | 'tren_waktu' | 'kinerja_kasir' | 'daftar_transaksi'>('produk_laris');

  // Selected Invoice Detail Modal
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Helper date parsing (Supports YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, ISO strings, etc.)
  const parseInvDate = (dStr: string): Date | null => {
    if (!dStr) return null;
    const clean = String(dStr).trim();
    if (!clean) return null;

    // 1. If ISO format or timestamp
    if (clean.includes('T')) {
      const d = new Date(clean);
      return isNaN(d.getTime()) ? null : d;
    }

    // 2. If contains slash or dash or space
    if (clean.includes('/') || clean.includes('-') || clean.includes('.')) {
      const sep = clean.includes('/') ? '/' : clean.includes('-') ? '-' : '.';
      const parts = clean.split(sep);
      if (parts.length === 3) {
        const p0 = parseInt(parts[0], 10);
        const p1 = parseInt(parts[1], 10);
        const p2 = parseInt(parts[2], 10);

        if (!isNaN(p0) && !isNaN(p1) && !isNaN(p2)) {
          // If first part is 4-digit year (YYYY-MM-DD or YYYY/MM/DD)
          if (parts[0].length === 4 || p0 > 1000) {
            return new Date(p0, p1 - 1, p2, 12, 0, 0);
          }
          // If last part is 4-digit year (DD-MM-YYYY or DD/MM/YYYY)
          if (parts[2].length === 4 || p2 > 1000) {
            return new Date(p2, p1 - 1, p0, 12, 0, 0);
          }
          // Fallback assume DD-MM-YY (e.g. 20-08-26 -> 2026)
          const year = p2 < 100 ? (2000 + p2) : p2;
          return new Date(year, p1 - 1, p0, 12, 0, 0);
        }
      }
    }

    const d = new Date(clean);
    return isNaN(d.getTime()) ? null : d;
  };

  // Date bounds based on period filter
  const { startDateObj, endDateObj, periodLabel } = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

    if (period === 'hari_ini') {
      return {
        startDateObj: todayStart,
        endDateObj: todayEnd,
        periodLabel: `Hari Ini (${fDate(now)})`,
      };
    }
    if (period === 'kemarin') {
      const yStart = new Date(todayStart);
      yStart.setDate(yStart.getDate() - 1);
      const yEnd = new Date(todayEnd);
      yEnd.setDate(yEnd.getDate() - 1);
      return {
        startDateObj: yStart,
        endDateObj: yEnd,
        periodLabel: `Kemarin (${fDate(yStart)})`,
      };
    }
    if (period === '7_hari') {
      const sevenDaysAgo = new Date(todayStart);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
      return {
        startDateObj: sevenDaysAgo,
        endDateObj: todayEnd,
        periodLabel: `7 Hari Terakhir (${fDate(sevenDaysAgo)} - ${fDate(now)})`,
      };
    }
    if (period === 'bulan_ini') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      return {
        startDateObj: monthStart,
        endDateObj: todayEnd,
        periodLabel: `Bulan Ini (${monthStart.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })})`,
      };
    }
    if (period === '30_hari') {
      const thirtyDaysAgo = new Date(todayStart);
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29);
      return {
        startDateObj: thirtyDaysAgo,
        endDateObj: todayEnd,
        periodLabel: `30 Hari Terakhir (${fDate(thirtyDaysAgo)} - ${fDate(now)})`,
      };
    }
    if (period === 'custom') {
      const s = customStartDate ? new Date(`${customStartDate}T00:00:00`) : new Date(2000, 0, 1);
      const e = customEndDate ? new Date(`${customEndDate}T23:59:59`) : new Date(2099, 11, 31);
      return {
        startDateObj: s,
        endDateObj: e,
        periodLabel: `Rentang: ${customStartDate} s/d ${customEndDate}`,
      };
    }
    // Semua
    return {
      startDateObj: new Date(2000, 0, 1),
      endDateObj: new Date(2099, 11, 31),
      periodLabel: 'Semua Periode Transaksi',
    };
  }, [period, customStartDate, customEndDate]);

  // Filtered Invoices
  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const invDate = parseInvDate(inv.date);
      if (!invDate) return false;

      // Check date bounds
      if (invDate < startDateObj || invDate > endDateObj) {
        return false;
      }

      // Check cashier
      if (selectedKasir !== 'all') {
        if ((inv.cashier || '').toLowerCase().trim() !== selectedKasir.toLowerCase().trim()) {
          return false;
        }
      }

      // Check pay method
      if (selectedPayMethod !== 'all') {
        const m = (inv.payMethod || (inv as any).metodePembayaran || '').toLowerCase();
        if (selectedPayMethod === 'Tunai' && !m.includes('tunai')) return false;
        if (selectedPayMethod === 'Transfer' && !m.includes('transfer') && !m.includes('qris') && !m.includes('bank')) return false;
        if (selectedPayMethod === 'Potong Gaji' && !m.includes('gaji')) return false;
      }

      // Check status
      if (selectedStatus !== 'all') {
        const s = (inv.status || '').toUpperCase();
        if (selectedStatus === 'LUNAS' && (s !== 'LUNAS' || (inv.sisa || 0) > 0)) return false;
        if (selectedStatus === 'PIUTANG' && (inv.sisa || 0) <= 0) return false;
      }

      return true;
    });
  }, [invoices, startDateObj, endDateObj, selectedKasir, selectedPayMethod, selectedStatus]);

  // Overall Financial & Sales Summary Metrics
  const summaryMetrics = useMemo(() => {
    let totalOmset = 0;
    let totalDiterima = 0;
    let totalPiutang = 0;
    let totalQty = 0;
    let totalDiskon = 0;

    const payMethodsMap: Record<string, { count: number; total: number }> = {
      Tunai: { count: 0, total: 0 },
      'Transfer / QRIS': { count: 0, total: 0 },
      'Potong Gaji': { count: 0, total: 0 },
      Lainnya: { count: 0, total: 0 },
    };

    filteredInvoices.forEach((inv) => {
      const tot = Number(inv.total || 0);
      const sisa = Number(inv.sisa || 0);
      const paid = Math.max(0, tot - sisa);

      totalOmset += tot;
      totalDiterima += paid;
      totalPiutang += sisa;
      totalDiskon += Number(inv.discAmt || 0) + Number(inv.negoAmt || 0);

      // Payment Breakdown
      const m = (inv.payMethod || (inv as any).metodePembayaran || 'Tunai').toLowerCase();
      if (m.includes('tunai') || m.includes('cash')) {
        payMethodsMap.Tunai.count += 1;
        payMethodsMap.Tunai.total += tot;
      } else if (m.includes('transfer') || m.includes('qris') || m.includes('bca') || m.includes('bri') || m.includes('mandiri')) {
        payMethodsMap['Transfer / QRIS'].count += 1;
        payMethodsMap['Transfer / QRIS'].total += tot;
      } else if (m.includes('gaji')) {
        payMethodsMap['Potong Gaji'].count += 1;
        payMethodsMap['Potong Gaji'].total += tot;
      } else {
        payMethodsMap.Lainnya.count += 1;
        payMethodsMap.Lainnya.total += tot;
      }

      // Items qty
      if (Array.isArray(inv.items)) {
        inv.items.forEach((it) => {
          totalQty += Number(it.qty || 0);
        });
      }
    });

    const totalTransaksi = filteredInvoices.length;
    const aov = totalTransaksi > 0 ? Math.round(totalOmset / totalTransaksi) : 0;

    return {
      totalOmset,
      totalDiterima,
      totalPiutang,
      totalTransaksi,
      totalQty,
      totalDiskon,
      aov,
      payMethodsMap,
    };
  }, [filteredInvoices]);

  // Filtered invoices for the detailed table with in-table search & quick filters
  const { displayedTableInvoices, tableCounts } = useMemo(() => {
    let lunasCount = 0;
    let piutangCount = 0;
    let potongGajiCount = 0;

    filteredInvoices.forEach((i) => {
      const s = String(i.status).toUpperCase();
      const sisa = Number(i.sisa) || 0;
      const m = (i.payMethod || (i as any).metodePembayaran || '').toLowerCase();

      if (s === 'LUNAS' && sisa <= 0) {
        lunasCount++;
      } else {
        piutangCount++;
      }

      if (m.includes('gaji')) {
        potongGajiCount++;
      }
    });

    let list = filteredInvoices;

    // Quick status filter
    if (tableQuickStatus === 'LUNAS') {
      list = list.filter((i) => String(i.status).toUpperCase() === 'LUNAS' && (Number(i.sisa) || 0) <= 0);
    } else if (tableQuickStatus === 'PIUTANG') {
      list = list.filter((i) => (Number(i.sisa) || 0) > 0 || String(i.status).toUpperCase() !== 'LUNAS');
    } else if (tableQuickStatus === 'POTONG_GAJI') {
      list = list.filter((i) => {
        const m = (i.payMethod || (i as any).metodePembayaran || '').toLowerCase();
        return m.includes('gaji');
      });
    }

    // Search query (No Nota, Customer, Cashier, Item Name)
    const q = tableSearch.trim().toLowerCase();
    if (q) {
      list = list.filter((i) => {
        const invNo = (i.invoiceNo || (i as any).noInvoice || '').toLowerCase();
        const cust = (i.customer || (i as any).pelanggan || '').toLowerCase();
        const kasir = (i.cashier || '').toLowerCase();
        const itemsMatch = Array.isArray(i.items) && i.items.some((it) => (it.nama || '').toLowerCase().includes(q));
        return invNo.includes(q) || cust.includes(q) || kasir.includes(q) || itemsMatch;
      });
    }

    return {
      displayedTableInvoices: list,
      tableCounts: {
        total: filteredInvoices.length,
        lunas: lunasCount,
        piutang: piutangCount,
        potongGaji: potongGajiCount,
      },
    };
  }, [filteredInvoices, tableQuickStatus, tableSearch]);

  // Aggregated Best Seller Products Data
  const { topProducts, categoriesList, topProductChamp } = useMemo(() => {
    const productStatsMap: Record<
      string,
      {
        kode: string;
        nama: string;
        kategori: string;
        qtyTerjual: number;
        satuan: string;
        totalOmset: number;
        notaCount: number;
        avgPrice: number;
      }
    > = {};

    const catSet = new Set<string>();

    filteredInvoices.forEach((inv) => {
      if (!Array.isArray(inv.items)) return;
      inv.items.forEach((it) => {
        const rawCode = (it.kode || '').trim().toUpperCase();
        const rawName = (it.nama || '').trim();
        const key = rawCode || rawName.toLowerCase();
        if (!key) return;

        // Match master product to get exact category & stock
        const master = products.find(
          (p) =>
            (p.kode && p.kode.trim().toUpperCase() === rawCode) ||
            (p.nama && p.nama.trim().toLowerCase() === rawName.toLowerCase())
        );

        const category = master?.kategori || 'Lainnya';
        catSet.add(category);

        const qty = Number(it.qty || 0);
        const hargaSatuan = Number(it.harga || 0);
        const itemOmset = it.totalItem !== undefined ? Number(it.totalItem) : qty * hargaSatuan;

        if (!productStatsMap[key]) {
          productStatsMap[key] = {
            kode: rawCode || master?.kode || '-',
            nama: rawName || master?.nama || 'Produk Tanpa Nama',
            kategori: category,
            qtyTerjual: 0,
            satuan: it.satuan || master?.satuan || 'pcs',
            totalOmset: 0,
            notaCount: 0,
            avgPrice: hargaSatuan,
          };
        }

        productStatsMap[key].qtyTerjual += qty;
        productStatsMap[key].totalOmset += itemOmset;
        productStatsMap[key].notaCount += 1;
      });
    });

    // Convert to array
    let list = Object.values(productStatsMap).map((stat) => {
      const master = products.find(
        (p) =>
          (p.kode && p.kode.trim().toUpperCase() === stat.kode.trim().toUpperCase()) ||
          p.nama.toLowerCase().trim() === stat.nama.toLowerCase().trim()
      );

      const currentStock = master ? Number(master.stok || 0) : 0;
      const contributionPct = summaryMetrics.totalOmset > 0 
        ? (stat.totalOmset / summaryMetrics.totalOmset) * 100 
        : 0;

      return {
        ...stat,
        currentStock,
        contributionPct,
      };
    });

    // Champion top product before category filter
    const champ = [...list].sort((a, b) => b.qtyTerjual - a.qtyTerjual)[0] || null;

    // Filter by category
    if (topCategory !== 'Semua') {
      list = list.filter((p) => p.kategori.toLowerCase() === topCategory.toLowerCase());
    }

    // Filter by product search
    if (productSearch.trim()) {
      const q = productSearch.toLowerCase().trim();
      list = list.filter((p) => p.nama.toLowerCase().includes(q) || p.kode.toLowerCase().includes(q));
    }

    // Sort
    if (topSortBy === 'qty') {
      list.sort((a, b) => b.qtyTerjual - a.qtyTerjual);
    } else {
      list.sort((a, b) => b.totalOmset - a.totalOmset);
    }

    return {
      topProducts: list,
      categoriesList: ['Semua', ...Array.from(catSet)],
      topProductChamp: champ,
    };
  }, [filteredInvoices, products, topCategory, productSearch, topSortBy, summaryMetrics.totalOmset]);

  // Chart Data: Daily Sales Trend
  const dailyTrendData = useMemo(() => {
    const dayMap: Record<string, { sortKey: string; dateStr: string; omset: number; transaksi: number }> = {};

    filteredInvoices.forEach((inv) => {
      const d = parseInvDate(inv.date);
      if (!d) return;
      const sortKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const dateStr = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (!dayMap[sortKey]) {
        dayMap[sortKey] = { sortKey, dateStr, omset: 0, transaksi: 0 };
      }
      dayMap[sortKey].omset += Number(inv.total || 0);
      dayMap[sortKey].transaksi += 1;
    });

    return Object.values(dayMap).sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  }, [filteredInvoices]);

  // Chart Data: Peak Hours Distribution (07:00 - 22:00)
  const hourlyPeakData = useMemo(() => {
    const hoursCount: Record<string, number> = {};
    for (let h = 7; h <= 21; h++) {
      hoursCount[`${String(h).padStart(2, '0')}:00`] = 0;
    }

    filteredInvoices.forEach((inv) => {
      const t = inv.time || '';
      if (t) {
        const hour = parseInt(t.split(':')[0], 10);
        if (!isNaN(hour) && hour >= 0 && hour <= 23) {
          const key = `${String(hour).padStart(2, '0')}:00`;
          hoursCount[key] = (hoursCount[key] || 0) + 1;
        }
      }
    });

    return Object.entries(hoursCount).map(([hour, count]) => ({
      hour,
      count,
    }));
  }, [filteredInvoices]);

  // Cashier Performance Data
  const cashierStats = useMemo(() => {
    const map: Record<string, { cashier: string; transaksi: number; totalOmset: number }> = {};

    filteredInvoices.forEach((inv) => {
      const c = (inv.cashier || 'Kasir Default').trim();
      if (!map[c]) {
        map[c] = { cashier: c, transaksi: 0, totalOmset: 0 };
      }
      map[c].transaksi += 1;
      map[c].totalOmset += Number(inv.total || 0);
    });

    return Object.values(map).sort((a, b) => b.totalOmset - a.totalOmset);
  }, [filteredInvoices]);

  // Top Customers Data
  const topCustomerStats = useMemo(() => {
    const map: Record<string, { name: string; transaksi: number; totalBelanja: number }> = {};

    filteredInvoices.forEach((inv) => {
      const c = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
      if (!map[c]) {
        map[c] = { name: c, transaksi: 0, totalBelanja: 0 };
      }
      map[c].transaksi += 1;
      map[c].totalBelanja += Number(inv.total || 0);
    });

    return Object.values(map).sort((a, b) => b.totalBelanja - a.totalBelanja).slice(0, 15);
  }, [filteredInvoices]);

  // Print Sales & Top Products Report
  const handlePrintReport = () => {
    const win = window.open('', '_blank');
    if (!win) {
      onShowToast('Popup browser terblokir. Izinkan popup untuk mencetak laporan.', 'error');
      return;
    }

    const top10Html = topProducts.slice(0, 15).map((p, idx) => `
      <tr>
        <td style="text-align: center; font-weight: bold;">${idx + 1}</td>
        <td>
          <div style="font-weight: bold;">${escHtml(p.nama)}</div>
          <div style="font-size: 9px; color: #666;">Kode: ${escHtml(p.kode)} | Kat: ${escHtml(p.kategori)}</div>
        </td>
        <td style="text-align: right; font-weight: bold;">${fNum(p.qtyTerjual)} ${escHtml(p.satuan)}</td>
        <td style="text-align: right;">${fRp(p.totalOmset)}</td>
        <td style="text-align: center;">${p.contributionPct.toFixed(1)}%</td>
        <td style="text-align: right;">${fNum(p.currentStock)}</td>
      </tr>
    `).join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Laporan Penjualan & Produk Terlaris - ${settings.name || 'ERVO PRINT'}</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; color: #222; margin: 20px; }
          .header { text-align: center; border-bottom: 2px solid #b91c1c; padding-bottom: 10px; margin-bottom: 15px; }
          .title { font-size: 16px; font-weight: 900; color: #b91c1c; margin: 0; text-transform: uppercase; }
          .subtitle { font-size: 11px; color: #555; margin: 2px 0; }
          .meta-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; }
          .meta-card { border: 1px solid #ddd; border-radius: 8px; padding: 8px; background: #fafafa; }
          .meta-label { font-size: 9px; color: #666; font-weight: bold; text-transform: uppercase; }
          .meta-val { font-size: 13px; font-weight: 900; color: #111; margin-top: 2px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th { background: #b91c1c; color: #fff; padding: 6px 8px; font-size: 10px; text-transform: uppercase; border: 1px solid #991b1b; }
          td { border: 1px solid #ddd; padding: 6px 8px; }
          tr:nth-child(even) { background: #fdf2f2; }
          .footer { margin-top: 25px; display: flex; justify-content: space-between; font-size: 10px; color: #666; }
          @media print {
            body { margin: 0; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1 class="title">${escHtml(settings.name || 'ERVO PRINT')}</h1>
          <p class="subtitle">${escHtml(settings.address || '')} | Telp: ${escHtml(settings.phone || '')}</p>
          <h2 style="font-size: 13px; margin: 6px 0 0 0; color: #333;">LAPORAN OMSET & BARANG PALING LARIS</h2>
          <p style="font-size: 10px; color: #777; margin: 2px 0;">Periode: ${escHtml(periodLabel)} | Dicetak: ${fDate(new Date())} ${new Date().toLocaleTimeString('id-ID')}</p>
        </div>

        <div class="meta-grid">
          <div class="meta-card">
            <div class="meta-label">Total Omset Penjualan</div>
            <div class="meta-val" style="color: #b91c1c;">${fRp(summaryMetrics.totalOmset)}</div>
          </div>
          <div class="meta-card">
            <div class="meta-label">Total Transaksi</div>
            <div class="meta-val">${fNum(summaryMetrics.totalTransaksi)} Nota</div>
          </div>
          <div class="meta-card">
            <div class="meta-label">Total Item Terjual</div>
            <div class="meta-val">${fNum(summaryMetrics.totalQty)} Pcs/Satuan</div>
          </div>
          <div class="meta-card">
            <div class="meta-label">Rata-Rata per Nota (AOV)</div>
            <div class="meta-val">${fRp(summaryMetrics.aov)}</div>
          </div>
        </div>

        <h3 style="font-size: 12px; font-weight: 800; color: #b91c1c; margin: 15px 0 5px 0;">DAFTAR PRODUK PALING LARIS TERJUAL</h3>
        <table>
          <thead>
            <tr>
              <th style="width: 30px;">No</th>
              <th>Nama Produk & Kategori</th>
              <th style="text-align: right;">Qty Terjual</th>
              <th style="text-align: right;">Total Omset</th>
              <th style="text-align: center;">Kontribusi</th>
              <th style="text-align: right;">Sisa Stok</th>
            </tr>
          </thead>
          <tbody>
            ${top10Html || '<tr><td colspan="6" style="text-align: center;">Tidak ada data penjualan pada periode ini</td></tr>'}
          </tbody>
        </table>

        <div class="footer">
          <div>Dicetak oleh sistem kasir: <strong>${escHtml(settings.cashier || 'Operator')}</strong></div>
          <div>Halaman 1 dari 1</div>
        </div>

        <script>
          window.onload = function() {
            window.print();
          }
        </script>
      </body>
      </html>
    `;

    win.document.write(htmlContent);
    win.document.close();
  };

  // Export CSV Data
  const handleExportCSV = () => {
    if (topProducts.length === 0) {
      onShowToast('Tidak ada data produk terjual untuk diekspor', 'info');
      return;
    }

    const headers = ['Peringkat', 'Kode Produk', 'Nama Produk', 'Kategori', 'Qty Terjual', 'Satuan', 'Total Omset (Rp)', 'Kontribusi (%)', 'Sisa Stok Saat Ini'];
    const rows = topProducts.map((p, idx) => [
      idx + 1,
      `"${p.kode}"`,
      `"${p.nama.replace(/"/g, '""')}"`,
      `"${p.kategori}"`,
      p.qtyTerjual,
      `"${p.satuan}"`,
      p.totalOmset,
      `${p.contributionPct.toFixed(2)}%`,
      p.currentStock,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Laporan_Produk_Laris_${fDateInput(new Date())}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onShowToast('File CSV Laporan Produk Laris berhasil diunduh', 'success');
  };

  return (
    <div className="w-full flex flex-col gap-3 sm:gap-4 select-none lg:h-full lg:overflow-y-auto pr-0 lg:pr-1 pb-16 lg:pb-4">
      {/* ================= TOP HEADER BANNER ================= */}
      <div className={`bg-stone-900 text-white rounded-2xl p-3.5 sm:p-4 shadow-sm items-start md:items-center justify-between gap-3 sm:gap-4 ${
        analyticsSubTab === 'daftar_transaksi' ? 'hidden sm:flex' : 'flex flex-col md:flex-row'
      }`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 sm:p-3 bg-red-700 rounded-xl text-white shrink-0 shadow-md">
            <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black tracking-tight">Laporan Omset & Barang Terlaris</h2>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-red-500/30 text-red-200 border border-red-500/40 uppercase">
                {periodLabel}
              </span>
            </div>
            <p className="text-xs text-stone-300 mt-0.5 hidden sm:block">
              Analisis performa pendapatan toko, produk terlaris, jam ramai transaksi, dan rincian metode pembayaran.
            </p>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2 self-stretch md:self-auto justify-end flex-wrap">
          <button
            onClick={handlePrintReport}
            className="px-3 py-1.5 sm:px-3.5 sm:py-2 bg-stone-800 hover:bg-stone-700 text-white font-bold text-xs rounded-xl border border-stone-700 flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs"
            title="Cetak Rekap Laporan Penjualan"
          >
            <Printer className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-400" />
            <span>Cetak Rekap</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 sm:px-3.5 sm:py-2 bg-stone-800 hover:bg-stone-700 text-white font-bold text-xs rounded-xl border border-stone-700 flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs"
            title="Download Data CSV / Excel"
          >
            <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
            <span>Ekspor CSV</span>
          </button>
        </div>
      </div>

      {/* ================= COMPACT MOBILE FILTER STRIP (For Daftar Transaksi) ================= */}
      {analyticsSubTab === 'daftar_transaksi' && !mobileFilterOpen && (
        <div className="sm:hidden bg-white border border-stone-200 rounded-2xl p-2.5 shadow-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-xl bg-red-100 text-red-700 shrink-0">
              <Calendar className="w-3.5 h-3.5" />
            </div>
            <div className="min-w-0">
              <div className="font-extrabold text-xs text-stone-900 truncate">Filter: {periodLabel}</div>
              <div className="text-[10px] text-stone-500 truncate">
                {selectedKasir === 'all' ? 'Semua Kasir' : selectedKasir} • {selectedPayMethod === 'all' ? 'Semua Bayar' : selectedPayMethod}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setMobileFilterOpen(true)}
            className="px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1 cursor-pointer"
          >
            <Filter className="w-3 h-3 text-red-700" />
            <span>Ubah</span>
          </button>
        </div>
      )}

      {/* ================= FILTER & PERIODE SELECTOR ================= */}
      <div className={`bg-white border border-stone-200 rounded-2xl p-3.5 sm:p-4 shadow-xs space-y-3 ${
        analyticsSubTab === 'daftar_transaksi' && !mobileFilterOpen ? 'hidden sm:block' : 'block'
      }`}>
        <div className="flex items-center justify-between gap-2 flex-wrap pb-2 border-b border-stone-100">
          <div className="flex items-center gap-2 text-xs font-black text-stone-800 uppercase tracking-wide">
            <Calendar className="w-4 h-4 text-red-700" />
            <span>Pilih Periode Laporan:</span>
          </div>

          {/* Quick Collapse Button on Mobile */}
          {analyticsSubTab === 'daftar_transaksi' && mobileFilterOpen && (
            <button
              type="button"
              onClick={() => setMobileFilterOpen(false)}
              className="sm:hidden text-[11px] font-extrabold text-red-700 bg-red-50 px-2 py-0.5 rounded-lg border border-red-200 cursor-pointer"
            >
              ✕ Tutup Filter
            </button>
          )}

          {/* Quick Period Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 sm:pb-0 flex-nowrap sm:flex-wrap">
            {[
              { id: 'hari_ini', label: 'Hari Ini' },
              { id: 'kemarin', label: 'Kemarin' },
              { id: '7_hari', label: '7 Hari Terakhir' },
              { id: 'bulan_ini', label: 'Bulan Ini' },
              { id: '30_hari', label: '30 Hari' },
              { id: 'semua', label: 'Semua Data' },
              { id: 'custom', label: 'Kustom Tanggal' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id as PeriodFilter)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
                  period === p.id
                    ? 'bg-red-700 text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Date Pickers & Additional Filter Dropdowns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
          {period === 'custom' && (
            <>
              <div>
                <label className="block text-[11px] font-bold text-stone-500 mb-1">Mulai Tanggal</label>
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-semibold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-stone-500 mb-1">Sampai Tanggal</label>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-semibold"
                />
              </div>
            </>
          )}

          {/* Filter Kasir */}
          <div>
            <label className="block text-[11px] font-bold text-stone-500 mb-1">Operator / Kasir</label>
            <select
              value={selectedKasir}
              onChange={(e) => setSelectedKasir(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-semibold"
            >
              <option value="all">Semua Operator / Kasir</option>
              {kasirUsers.map((u, i) => (
                <option key={i} value={u.nama}>{u.nama}</option>
              ))}
            </select>
          </div>

          {/* Filter Metode Pembayaran */}
          <div>
            <label className="block text-[11px] font-bold text-stone-500 mb-1">Metode Bayar</label>
            <select
              value={selectedPayMethod}
              onChange={(e) => setSelectedPayMethod(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-semibold"
            >
              <option value="all">Semua Metode Pembayaran</option>
              <option value="Tunai">Tunai / Cash</option>
              <option value="Transfer">Transfer Bank / QRIS</option>
              <option value="Potong Gaji">Potong Gaji</option>
            </select>
          </div>

          {/* Filter Status */}
          <div>
            <label className="block text-[11px] font-bold text-stone-500 mb-1">Status Pembayaran</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-semibold"
            >
              <option value="all">Semua Status Nota</option>
              <option value="LUNAS">Lunas Sepenuhnya</option>
              <option value="PIUTANG">Ada Sisa Piutang / DP</option>
            </select>
          </div>
        </div>
      </div>

      {/* ================= RINGKASAN OMSET & STAT CARDS ================= */}
      {/* Tampilkan 8 kartu metrik lengkap jika bukan di tab daftar_transaksi */}
      {analyticsSubTab !== 'daftar_transaksi' && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Total Omset */}
            <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-red-700" />
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Total Omset Kotor</span>
                <div className="p-2 rounded-xl bg-red-50 text-red-700">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <div className="text-xl font-black text-stone-900 tracking-tight">{fRp(summaryMetrics.totalOmset)}</div>
                <div className="flex items-center justify-between text-[10px] text-stone-500 mt-1 pt-1 border-t border-stone-100">
                  <span>Diterima: <strong className="text-emerald-700">{fRp(summaryMetrics.totalDiterima)}</strong></span>
                  {summaryMetrics.totalPiutang > 0 && (
                    <span>Piutang: <strong className="text-rose-600">{fRp(summaryMetrics.totalPiutang)}</strong></span>
                  )}
                </div>
              </div>
            </div>

            {/* Total Transaksi */}
            <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-stone-800" />
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Total Transaksi (Nota)</span>
                <div className="p-2 rounded-xl bg-stone-100 text-stone-700">
                  <Receipt className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <div className="text-xl font-black text-stone-900 tracking-tight">{fNum(summaryMetrics.totalTransaksi)} <span className="text-xs font-bold text-stone-400">Nota</span></div>
                <div className="text-[10px] text-stone-500 mt-1 pt-1 border-t border-stone-100 flex items-center justify-between">
                  <span>Rata-Rata (AOV):</span>
                  <strong className="text-stone-800">{fRp(summaryMetrics.aov)} / nota</strong>
                </div>
              </div>
            </div>

            {/* Total Item Terjual */}
            <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-amber-600" />
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Total Item Terjual</span>
                <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
                  <ShoppingBag className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <div className="text-xl font-black text-stone-900 tracking-tight">{fNum(summaryMetrics.totalQty)} <span className="text-xs font-bold text-stone-400">Satuan</span></div>
                <div className="text-[10px] text-stone-500 mt-1 pt-1 border-t border-stone-100 flex items-center justify-between">
                  <span>Produk Unik Terjual:</span>
                  <strong className="text-stone-800">{topProducts.length} Jenis</strong>
                </div>
              </div>
            </div>

            {/* Juara Produk Terlaris */}
            <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-600" />
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">Produk Terlaris #1</span>
                <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  <Award className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                {topProductChamp ? (
                  <>
                    <div className="text-sm font-black text-stone-900 truncate" title={topProductChamp.nama}>
                      🥇 {topProductChamp.nama}
                    </div>
                    <div className="text-[10px] text-stone-500 mt-1 pt-1 border-t border-stone-100 flex items-center justify-between">
                      <span>Terjual: <strong className="text-emerald-700">{fNum(topProductChamp.qtyTerjual)} {topProductChamp.satuan}</strong></span>
                      <span>{fRp(topProductChamp.totalOmset)}</span>
                    </div>
                  </>
                ) : (
                  <div className="text-xs text-stone-400 italic">Belum ada data penjualan</div>
                )}
              </div>
            </div>
          </div>

          {/* Rincian Arus Kas & Metode Pembayaran */}
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-stone-900 text-xs flex items-center gap-2 uppercase tracking-wide">
                <CreditCard className="w-4 h-4 text-red-700" />
                <span>Rincian Arus Kas & Metode Pembayaran</span>
              </h3>
              <span className="text-[11px] text-stone-400 font-semibold">
                {summaryMetrics.totalTransaksi} Transaksi
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(Object.entries(summaryMetrics.payMethodsMap) as [string, { count: number; total: number }][]).map(([method, data]) => {
                const pct = summaryMetrics.totalOmset > 0 ? (data.total / summaryMetrics.totalOmset) * 100 : 0;
                return (
                  <div key={method} className="bg-stone-50 border border-stone-200/80 rounded-xl p-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-stone-800">{method}</span>
                      <span className="font-extrabold text-[10px] px-1.5 py-0.5 rounded bg-white text-stone-600 border border-stone-200">
                        {data.count} Nota
                      </span>
                    </div>
                    <div className="text-base font-black text-stone-900 mt-1.5">{fRp(data.total)}</div>
                    {/* Mini Progress Bar */}
                    <div className="w-full bg-stone-200 h-1.5 rounded-full mt-2 overflow-hidden">
                      <div 
                        className="bg-red-700 h-full rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                      />
                    </div>
                    <div className="text-[10px] text-stone-500 font-semibold mt-1 text-right">
                      {pct.toFixed(1)}% dari total omset
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* ================= SUB-NAVIGATION TABS FOR DEEP ANALYTICS ================= */}
      <div className="bg-white border border-stone-200 rounded-2xl p-1.5 sm:p-2 shadow-xs shrink-0">
        <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-0.5 scrollbar-none">
          <button
            onClick={() => setAnalyticsSubTab('produk_laris')}
            className={`px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 sm:gap-2 whitespace-nowrap cursor-pointer shrink-0 ${
              analyticsSubTab === 'produk_laris'
                ? 'bg-red-700 text-white shadow-xs'
                : 'bg-stone-50 text-stone-600 hover:bg-stone-100 border border-stone-200/70'
            }`}
          >
            <Award className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${analyticsSubTab === 'produk_laris' ? 'text-amber-300' : 'text-amber-600'}`} />
            <span>Barang Paling Laris ({topProducts.length})</span>
          </button>

          <button
            onClick={() => setAnalyticsSubTab('tren_waktu')}
            className={`px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 sm:gap-2 whitespace-nowrap cursor-pointer shrink-0 ${
              analyticsSubTab === 'tren_waktu'
                ? 'bg-red-700 text-white shadow-xs'
                : 'bg-stone-50 text-stone-600 hover:bg-stone-100 border border-stone-200/70'
            }`}
          >
            <TrendingUp className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${analyticsSubTab === 'tren_waktu' ? 'text-white' : 'text-emerald-600'}`} />
            <span>Grafik Tren & Jam Ramai</span>
          </button>

          <button
            onClick={() => setAnalyticsSubTab('kinerja_kasir')}
            className={`px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 sm:gap-2 whitespace-nowrap cursor-pointer shrink-0 ${
              analyticsSubTab === 'kinerja_kasir'
                ? 'bg-red-700 text-white shadow-xs'
                : 'bg-stone-50 text-stone-600 hover:bg-stone-100 border border-stone-200/70'
            }`}
          >
            <Users className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${analyticsSubTab === 'kinerja_kasir' ? 'text-white' : 'text-sky-600'}`} />
            <span>Kinerja Operator & Pelanggan</span>
          </button>

          <button
            onClick={() => setAnalyticsSubTab('daftar_transaksi')}
            className={`px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 sm:gap-2 whitespace-nowrap cursor-pointer shrink-0 ${
              analyticsSubTab === 'daftar_transaksi'
                ? 'bg-red-700 text-white shadow-xs'
                : 'bg-stone-50 text-stone-600 hover:bg-stone-100 border border-stone-200/70'
            }`}
          >
            <Receipt className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${analyticsSubTab === 'daftar_transaksi' ? 'text-white' : 'text-rose-600'}`} />
            <span>Daftar Transaksi ({filteredInvoices.length})</span>
          </button>
        </div>
      </div>

      {/* ================= TAB 1: PRODUK PALING LARIS ================= */}
      {analyticsSubTab === 'produk_laris' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama produk atau kode..."
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-medium"
              />
            </div>

            {/* Category Filter & Sort Toggles */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Category Dropdown */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-bold text-stone-500">Kategori:</span>
                <select
                  value={topCategory}
                  onChange={(e) => setTopCategory(e.target.value)}
                  className="px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:border-red-600"
                >
                  {categoriesList.map((c, i) => (
                    <option key={i} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              {/* Sort By Toggle */}
              <div className="flex items-center bg-stone-100 p-0.5 rounded-xl border border-stone-200">
                <button
                  onClick={() => setTopSortBy('qty')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                    topSortBy === 'qty'
                      ? 'bg-red-700 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Qty Terbanyak
                </button>
                <button
                  onClick={() => setTopSortBy('omset')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                    topSortBy === 'omset'
                      ? 'bg-red-700 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Omset Terbesar
                </button>
              </div>
            </div>
          </div>

          {/* Top 3 Visual Highlights */}
          {topProducts.length >= 3 && !productSearch && topCategory === 'Semua' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {/* Rank 1 */}
              <div className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-2 border-amber-400 rounded-2xl p-4 relative overflow-hidden shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500 text-white uppercase tracking-wider">
                    🏆 Peringkat 1
                  </span>
                  <Award className="w-5 h-5 text-amber-600" />
                </div>
                <h4 className="font-extrabold text-stone-900 text-sm mt-2 line-clamp-1" title={topProducts[0].nama}>
                  {topProducts[0].nama}
                </h4>
                <div className="text-[10px] text-stone-500 mt-0.5">Kode: {topProducts[0].kode} • {topProducts[0].kategori}</div>
                <div className="flex items-baseline justify-between mt-3 pt-2 border-t border-amber-200/60">
                  <div>
                    <div className="text-lg font-black text-amber-900">{fNum(topProducts[0].qtyTerjual)} <span className="text-xs font-bold text-stone-600">{topProducts[0].satuan}</span></div>
                    <div className="text-[10px] font-bold text-amber-700">{fRp(topProducts[0].totalOmset)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-amber-900">{topProducts[0].contributionPct.toFixed(1)}%</div>
                    <div className="text-[9px] text-stone-500">Kontribusi Omset</div>
                  </div>
                </div>
              </div>

              {/* Rank 2 */}
              <div className="bg-gradient-to-br from-stone-400/15 to-stone-400/5 border border-stone-300 rounded-2xl p-4 relative overflow-hidden shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-stone-500 text-white uppercase tracking-wider">
                    🥈 Peringkat 2
                  </span>
                  <Award className="w-5 h-5 text-stone-500" />
                </div>
                <h4 className="font-extrabold text-stone-900 text-sm mt-2 line-clamp-1" title={topProducts[1].nama}>
                  {topProducts[1].nama}
                </h4>
                <div className="text-[10px] text-stone-500 mt-0.5">Kode: {topProducts[1].kode} • {topProducts[1].kategori}</div>
                <div className="flex items-baseline justify-between mt-3 pt-2 border-t border-stone-200">
                  <div>
                    <div className="text-lg font-black text-stone-900">{fNum(topProducts[1].qtyTerjual)} <span className="text-xs font-bold text-stone-600">{topProducts[1].satuan}</span></div>
                    <div className="text-[10px] font-bold text-stone-700">{fRp(topProducts[1].totalOmset)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-stone-800">{topProducts[1].contributionPct.toFixed(1)}%</div>
                    <div className="text-[9px] text-stone-500">Kontribusi Omset</div>
                  </div>
                </div>
              </div>

              {/* Rank 3 */}
              <div className="bg-gradient-to-br from-amber-700/10 to-amber-700/5 border border-amber-600/30 rounded-2xl p-4 relative overflow-hidden shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-700 text-white uppercase tracking-wider">
                    🥉 Peringkat 3
                  </span>
                  <Award className="w-5 h-5 text-amber-700" />
                </div>
                <h4 className="font-extrabold text-stone-900 text-sm mt-2 line-clamp-1" title={topProducts[2].nama}>
                  {topProducts[2].nama}
                </h4>
                <div className="text-[10px] text-stone-500 mt-0.5">Kode: {topProducts[2].kode} • {topProducts[2].kategori}</div>
                <div className="flex items-baseline justify-between mt-3 pt-2 border-t border-amber-200/60">
                  <div>
                    <div className="text-lg font-black text-amber-950">{fNum(topProducts[2].qtyTerjual)} <span className="text-xs font-bold text-stone-600">{topProducts[2].satuan}</span></div>
                    <div className="text-[10px] font-bold text-amber-800">{fRp(topProducts[2].totalOmset)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-amber-900">{topProducts[2].contributionPct.toFixed(1)}%</div>
                    <div className="text-[9px] text-stone-500">Kontribusi Omset</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Complete Top Products Table */}
          <div className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="p-3.5 border-b border-stone-100 flex items-center justify-between">
              <h3 className="font-extrabold text-stone-900 text-xs uppercase tracking-wide flex items-center gap-2">
                <Layers className="w-4 h-4 text-red-700" />
                <span>Peringkat Lengkap Penjualan Produk ({topProducts.length} Produk)</span>
              </h3>
              <span className="text-[11px] text-stone-400 font-semibold">
                Urut berdasarkan: {topSortBy === 'qty' ? 'Qty Terbanyak' : 'Omset Terbesar'}
              </span>
            </div>

            <div className="overflow-x-auto overflow-y-auto max-h-[480px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 z-10 shadow-xs bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3 w-12 text-center bg-stone-50">Rank</th>
                    <th className="py-2.5 px-3 bg-stone-50">Kode & Produk</th>
                    <th className="py-2.5 px-3 bg-stone-50">Kategori</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Terjual (Qty)</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Total Omset</th>
                    <th className="py-2.5 px-3 text-center bg-stone-50">Kontribusi</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Sisa Stok</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {topProducts.length > 0 ? (
                    topProducts.map((p, idx) => {
                      const isLowStock = p.currentStock <= (settings.minStockThreshold || 5);
                      return (
                        <tr key={idx} className="hover:bg-stone-50/80 transition">
                          <td className="py-2.5 px-3 text-center font-black">
                            {idx === 0 ? (
                              <span className="text-amber-600 font-black text-sm">🥇 1</span>
                            ) : idx === 1 ? (
                              <span className="text-stone-500 font-black text-sm">🥈 2</span>
                            ) : idx === 2 ? (
                              <span className="text-amber-700 font-black text-sm">🥉 3</span>
                            ) : (
                              <span className="text-stone-400 font-semibold">{idx + 1}</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="font-extrabold text-stone-900">{p.nama}</div>
                            <div className="text-[10px] text-stone-400 font-mono">{p.kode}</div>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-stone-100 text-stone-700 border border-stone-200">
                              {p.kategori}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-black text-stone-900">
                            {fNum(p.qtyTerjual)} <span className="text-[10px] font-bold text-stone-500">{p.satuan}</span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-black text-red-700">
                            {fRp(p.totalOmset)}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className="font-bold text-[11px] text-stone-700">
                              {p.contributionPct.toFixed(1)}%
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <span
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-black inline-flex items-center gap-1 ${
                                isLowStock
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                  : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              }`}
                            >
                              {fNum(p.currentStock)} {p.satuan}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-stone-400">
                        <Package className="w-8 h-8 mx-auto mb-2 text-stone-300 opacity-60" />
                        <p className="text-xs font-semibold">Tidak ada data transaksi penjualan yang cocok dengan filter ini</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: GRAFIK TREN & JAM RAMAI ================= */}
      {analyticsSubTab === 'tren_waktu' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Daily Trend Chart */}
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-stone-900 text-xs uppercase tracking-wide flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-red-700" />
                  <span>Tren Omset Penjualan</span>
                </h3>
                <p className="text-[11px] text-stone-500">Perkembangan total omset harian pada periode terpilih</p>
              </div>
            </div>

            <div className="h-64 w-full pt-2">
              {dailyTrendData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyTrendData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="dateStr" 
                      tick={{ fontSize: 10, fill: '#78716c' }} 
                      axisLine={{ stroke: '#e7e5e4' }} 
                    />
                    <YAxis 
                      tick={{ fontSize: 10, fill: '#78716c' }} 
                      axisLine={{ stroke: '#e7e5e4' }}
                      tickFormatter={(val) => `Rp ${(val / 1000).toFixed(0)}k`}
                    />
                    <RechartsTooltip 
                      formatter={(val: any) => [fRp(Number(val)), 'Omset']}
                      labelFormatter={(label) => `Tanggal: ${label}`}
                      contentStyle={{ backgroundColor: '#1c1917', borderRadius: '12px', color: '#fff', fontSize: '11px', border: 'none' }}
                    />
                    <Bar dataKey="omset" fill="#b91c1c" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-stone-400">
                  Belum ada data untuk grafik tren
                </div>
              )}
            </div>
          </div>

          {/* Peak Hours Chart */}
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-stone-900 text-xs uppercase tracking-wide flex items-center gap-2">
                  <Clock className="w-4 h-4 text-red-700" />
                  <span>Distribusi Jam Ramai Transaksi (Peak Hours)</span>
                </h3>
                <p className="text-[11px] text-stone-500">Melihat jam sibuk kasir untuk optimasi staf & pelayanan</p>
              </div>
            </div>

            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={hourlyPeakData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="hour" 
                    tick={{ fontSize: 9, fill: '#78716c' }} 
                    axisLine={{ stroke: '#e7e5e4' }} 
                  />
                  <YAxis 
                    tick={{ fontSize: 10, fill: '#78716c' }} 
                    axisLine={{ stroke: '#e7e5e4' }}
                    allowDecimals={false}
                  />
                  <RechartsTooltip 
                    formatter={(val: any) => [`${val} Transaksi`, 'Jumlah Nota']}
                    labelFormatter={(label) => `Pukul: ${label}`}
                    contentStyle={{ backgroundColor: '#1c1917', borderRadius: '12px', color: '#fff', fontSize: '11px', border: 'none' }}
                  />
                  <Bar dataKey="count" fill="#ea580c" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: KINERJA OPERATOR & PELANGGAN ================= */}
      {analyticsSubTab === 'kinerja_kasir' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Operator Performance Table */}
          <div className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="p-3.5 border-b border-stone-100">
              <h3 className="font-extrabold text-stone-900 text-xs uppercase tracking-wide flex items-center gap-2">
                <Users className="w-4 h-4 text-red-700" />
                <span>Kinerja & Perolehan Kasir / Operator</span>
              </h3>
            </div>
            <div className="overflow-x-auto overflow-y-auto max-h-[420px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 z-10 shadow-xs bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3 bg-stone-50">Nama Operator</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Jumlah Nota</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Total Omset</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Rata-Rata</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {cashierStats.length > 0 ? (
                    cashierStats.map((c, i) => {
                      const aovKasir = c.transaksi > 0 ? Math.round(c.totalOmset / c.transaksi) : 0;
                      return (
                        <tr key={i} className="hover:bg-stone-50">
                          <td className="py-2.5 px-3 font-extrabold text-stone-900 flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-red-100 text-red-800 text-[10px] font-black flex items-center justify-center">
                              {i + 1}
                            </span>
                            <span>{c.cashier}</span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-black text-stone-800">
                            {fNum(c.transaksi)} Nota
                          </td>
                          <td className="py-2.5 px-3 text-right font-black text-red-700">
                            {fRp(c.totalOmset)}
                          </td>
                          <td className="py-2.5 px-3 text-right text-stone-500 font-semibold">
                            {fRp(aovKasir)}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-stone-400">Belum ada data kasir</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Customers Table */}
          <div className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="p-3.5 border-b border-stone-100">
              <h3 className="font-extrabold text-stone-900 text-xs uppercase tracking-wide flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600" />
                <span>Pelanggan Paling Aktif (Top 15 Pembeli)</span>
              </h3>
            </div>
            <div className="overflow-x-auto overflow-y-auto max-h-[420px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 z-10 shadow-xs bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3 bg-stone-50">Nama Pelanggan</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Frekuensi Belanja</th>
                    <th className="py-2.5 px-3 text-right bg-stone-50">Total Transaksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {topCustomerStats.length > 0 ? (
                    topCustomerStats.map((c, i) => (
                      <tr key={i} className="hover:bg-stone-50">
                        <td className="py-2.5 px-3 font-extrabold text-stone-900 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-stone-100 text-stone-700 text-[10px] font-black flex items-center justify-center">
                            {i + 1}
                          </span>
                          <span>{c.name}</span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-black text-stone-800">
                          {fNum(c.transaksi)} Kali
                        </td>
                        <td className="py-2.5 px-3 text-right font-black text-red-700">
                          {fRp(c.totalBelanja)}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="py-8 text-center text-stone-400">Belum ada data transaksi pelanggan</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: DAFTAR TRANSAKSI LENGKAP ================= */}
      {analyticsSubTab === 'daftar_transaksi' && (
        <div className={`bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden flex flex-col transition-all duration-200 ${
          isTableMaximized 
            ? 'fixed inset-0 sm:inset-2 md:inset-4 z-50 shadow-2xl border-stone-300 rounded-none sm:rounded-2xl' 
            : ''
        }`}>
          {/* Card Top Title & Quick Action Bar */}
          <div className="p-3.5 sm:p-4 border-b border-stone-200 flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0 bg-stone-50/70">
            <div className="flex items-center gap-2.5">
              <div className="p-2 sm:p-2.5 bg-red-700 text-white rounded-xl shadow-xs shrink-0">
                <Receipt className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div>
                <h3 className="font-black text-stone-900 text-sm tracking-tight flex items-center gap-2">
                  <span>Daftar Transaksi Sesuai Filter</span>
                  <span className="text-xs font-extrabold px-2 py-0.5 rounded-full bg-red-100 text-red-800">
                    {displayedTableInvoices.length} Nota
                  </span>
                </h3>
                <p className="text-[11px] text-stone-500">
                  Rincian lengkap nota, pelanggan, divisi, item barang belanja, kasir, dan status tagihan.
                </p>
              </div>
            </div>

            {/* Quick Metrics Badges, Mobile View Toggle & Maximize in Header */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Mobile View Switcher (Kartu vs Tabel) */}
              <div className="sm:hidden flex items-center bg-stone-200/80 p-0.5 rounded-xl border border-stone-300/70">
                <button
                  type="button"
                  onClick={() => setTableMobileView('card')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    tableMobileView === 'card'
                      ? 'bg-red-700 text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>📱 Kartu</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTableMobileView('table')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    tableMobileView === 'table'
                      ? 'bg-red-700 text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span>📊 Tabel</span>
                </button>
              </div>

              <div className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white border border-stone-200 text-right shadow-2xs">
                <span className="text-[9px] sm:text-[10px] text-stone-400 font-semibold block leading-none">Total Omset Filter</span>
                <span className="text-xs font-black text-stone-900 font-mono leading-tight">
                  {fRp(summaryMetrics.totalOmset)}
                </span>
              </div>
              {summaryMetrics.totalPiutang > 0 && (
                <div className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-200 text-right shadow-2xs">
                  <span className="text-[9px] sm:text-[10px] text-rose-600 font-semibold block leading-none">Total Sisa Piutang</span>
                  <span className="text-xs font-black text-rose-700 font-mono leading-tight">
                    {fRp(summaryMetrics.totalPiutang)}
                  </span>
                </div>
              )}
              <button
                type="button"
                onClick={() => setIsTableMaximized(!isTableMaximized)}
                className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 text-stone-700 text-xs font-bold border border-stone-200 transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title={isTableMaximized ? 'Kembalikan Ukuran Normal' : 'Maksimalkan Tabel Layar Penuh'}
              >
                {isTableMaximized ? (
                  <>
                    <Minimize2 className="w-3.5 h-3.5 text-stone-600" />
                    <span className="hidden sm:inline">Perkecil</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-3.5 h-3.5 text-stone-600" />
                    <span className="hidden sm:inline">Layar Penuh</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Filter & In-Table Search Strip */}
          <div className="p-3 border-b border-stone-100 bg-white flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 shrink-0">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari no. nota, pelanggan, nama barang, kasir..."
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
                className="w-full pl-9 pr-8 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-600 font-medium"
              />
              {tableSearch && (
                <button
                  type="button"
                  onClick={() => setTableSearch('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Quick Status Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => setTableQuickStatus('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                  tableQuickStatus === 'all'
                    ? 'bg-stone-900 text-white shadow-2xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Semua ({tableCounts.total})
              </button>
              <button
                type="button"
                onClick={() => setTableQuickStatus('LUNAS')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                  tableQuickStatus === 'LUNAS'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                ✓ Lunas ({tableCounts.lunas})
              </button>
              <button
                type="button"
                onClick={() => setTableQuickStatus('PIUTANG')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                  tableQuickStatus === 'PIUTANG'
                    ? 'bg-rose-600 text-white shadow-2xs'
                    : 'bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200'
                }`}
              >
                ⏳ Ada Piutang / DP ({tableCounts.piutang})
              </button>
              <button
                type="button"
                onClick={() => setTableQuickStatus('POTONG_GAJI')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                  tableQuickStatus === 'POTONG_GAJI'
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
                }`}
              >
                📋 Potong Gaji ({tableCounts.potongGaji})
              </button>
            </div>
          </div>

          {/* Swipe / Mode Hint for Mobile */}
          <div className="sm:hidden flex items-center justify-between text-[10px] text-stone-500 bg-stone-50 px-3 py-1.5 border-b border-stone-200/70 shrink-0">
            {tableMobileView === 'card' ? (
              <span className="font-medium text-stone-600">📱 Mode Kartu: Mudah dibaca & sentuh di layar ponsel</span>
            ) : (
              <span className="font-medium text-stone-600">👉 Mode Tabel: Geser horizontal untuk melihat kolom kasir & aksi</span>
            )}
            <span className="font-bold text-stone-700">{displayedTableInvoices.length} Nota</span>
          </div>

          {/* Table Container: 2x Height on Desktop & Responsive on Mobile */}
          <div className={`overflow-x-auto overflow-y-auto ${
            isTableMaximized 
              ? 'flex-1 min-h-0' 
              : 'h-[500px] sm:h-[640px] lg:h-[760px] min-h-[420px] sm:min-h-[500px] max-h-[85vh]'
          }`}>
            {/* Mobile Card List (Active on mobile screen when tableMobileView === 'card') */}
            {tableMobileView === 'card' && (
              <div className="sm:hidden divide-y divide-stone-100 bg-white">
                {displayedTableInvoices.length > 0 ? (
                  displayedTableInvoices.map((inv, idx) => {
                    const custName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
                    const custDivision = getCustomerDivision(custName, allCustomers);
                    const isCopied = copiedInvoiceNo === inv.invoiceNo;
                    const isLunas = String(inv.status).toUpperCase() === 'LUNAS' && (Number(inv.sisa) || 0) <= 0;
                    const isPotongGaji = (inv.payMethod || (inv as any).metodePembayaran || '').toLowerCase().includes('gaji');
                    const items = Array.isArray(inv.items) ? inv.items : [];
                    const totalItemQty = items.reduce((sum, it) => sum + (Number(it.qty) || 0), 0);
                    const sisa = Number(inv.sisa || 0);

                    return (
                      <div key={idx} className="p-3 hover:bg-stone-50/80 transition flex flex-col gap-2">
                        {/* Header: No Nota, Waktu, Status */}
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-mono font-black text-red-700 text-xs bg-red-50 px-2 py-0.5 rounded border border-red-200">
                              {inv.invoiceNo}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCopyNoNota(inv.invoiceNo)}
                              className="p-1 text-stone-400 hover:text-stone-700 rounded transition cursor-pointer"
                              title="Salin No. Nota"
                            >
                              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                            <span className="text-[10px] text-stone-400 font-medium">
                              {inv.date} {inv.time}
                            </span>
                          </div>

                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase shrink-0 ${
                              isLunas
                                ? 'bg-emerald-100 text-emerald-800'
                                : isPotongGaji
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {isLunas ? 'LUNAS' : isPotongGaji ? 'POTONG GAJI' : 'BELUM LUNAS'}
                          </span>
                        </div>

                        {/* Customer & Items */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-stone-900 text-xs">{custName}</span>
                              {custDivision && (
                                <span className="inline-flex items-center gap-1 text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200/60">
                                  <Building2 className="w-2.5 h-2.5" />
                                  <span>{custDivision}</span>
                                </span>
                              )}
                              {inv.originalCustomer && inv.originalCustomer.toLowerCase() !== custName.toLowerCase() && (
                                <span className="text-[9px] text-amber-700 font-medium">
                                  (Semula: "{inv.originalCustomer}")
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-stone-600 mt-1 line-clamp-1">
                              <span className="font-extrabold text-stone-800">{items.length} Barang</span>{' '}
                              <span className="text-stone-400">({totalItemQty} pcs): </span>
                              <span className="text-stone-500">
                                {items.map((it) => `${it.nama} (${it.qty})`).join(', ') || '-'}
                              </span>
                            </div>
                          </div>

                          {/* Nominal & Sisa */}
                          <div className="text-right shrink-0">
                            <div className="font-black text-stone-900 text-xs font-mono">
                              {fRp(inv.total)}
                            </div>
                            {sisa > 0 ? (
                              <div className="text-[10px] font-black text-rose-600 font-mono">
                                Sisa: {fRp(sisa)}
                              </div>
                            ) : (
                              <div className="text-[10px] font-semibold text-emerald-600">
                                Lunas
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Footer: Kasir, Metode & Aksi */}
                        <div className="flex items-center justify-between gap-2 pt-1.5 border-t border-stone-100 text-[10px]">
                          <div className="flex items-center gap-1.5 flex-wrap text-stone-500">
                            <span className="px-1.5 py-0.5 rounded bg-stone-100 font-semibold text-stone-700">
                              Kasir: {inv.cashier || 'Admin'}
                            </span>
                            <span className={`px-1.5 py-0.5 rounded font-bold uppercase border ${
                              isPotongGaji
                                ? 'bg-amber-50 text-amber-900 border-amber-200'
                                : (inv.payMethod || '').toLowerCase().includes('transfer')
                                ? 'bg-blue-50 text-blue-900 border-blue-200'
                                : 'bg-stone-100 text-stone-800 border-stone-200'
                            }`}>
                              {inv.payMethod || (inv as any).metodePembayaran || 'Tunai'}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => handlePrintNotaThermal(inv)}
                              className="p-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg transition cursor-pointer"
                              title="Cetak Struk Thermal"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setSelectedInvoice(inv)}
                              className="px-2.5 py-1 bg-red-700 hover:bg-red-800 text-white font-bold text-[10px] rounded-lg transition cursor-pointer flex items-center gap-1 shadow-2xs"
                            >
                              <Eye className="w-3 h-3 text-white" />
                              <span>Lihat Item</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="py-12 text-center text-stone-400">
                    <Receipt className="w-10 h-10 mx-auto text-stone-300 mb-2" />
                    <p className="font-bold text-xs">Tidak ada transaksi yang cocok dengan kriteria pencarian.</p>
                    <p className="text-[11px] text-stone-400 mt-0.5">Ubah kata kunci pencarian atau sesuaikan filter di atas.</p>
                  </div>
                )}
              </div>
            )}

            {/* Desktop Table OR Mobile Wide Table (when tableMobileView === 'table') */}
            <table className={`${tableMobileView === 'card' ? 'hidden sm:table' : 'table'} min-w-[850px] w-full text-left text-xs border-collapse`}>
              <thead className="sticky top-0 z-10 shadow-xs">
                <tr className="bg-stone-100 border-b border-stone-200 text-stone-700 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-2.5 px-3.5 bg-stone-100 whitespace-nowrap">No. Nota</th>
                  <th className="py-2.5 px-3 bg-stone-100 whitespace-nowrap">Waktu</th>
                  <th className="py-2.5 px-3.5 bg-stone-100 min-w-[140px]">Pelanggan & Divisi</th>
                  <th className="py-2.5 px-3 bg-stone-100 min-w-[180px]">Item Belanja (Preview)</th>
                  <th className="py-2.5 px-3 bg-stone-100 whitespace-nowrap">Kasir</th>
                  <th className="py-2.5 px-3 bg-stone-100 whitespace-nowrap">Metode</th>
                  <th className="py-2.5 px-3 text-right bg-stone-100 whitespace-nowrap">Total & Sisa</th>
                  <th className="py-2.5 px-3 text-center bg-stone-100 whitespace-nowrap">Status</th>
                  <th className="py-2.5 px-3.5 text-center bg-stone-100 whitespace-nowrap">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {displayedTableInvoices.length > 0 ? (
                  displayedTableInvoices.map((inv, idx) => {
                    const custName = (inv.customer || (inv as any).pelanggan || 'Umum').trim();
                    const custDivision = getCustomerDivision(custName, allCustomers);
                    const isCopied = copiedInvoiceNo === inv.invoiceNo;
                    const isLunas = String(inv.status).toUpperCase() === 'LUNAS' && (Number(inv.sisa) || 0) <= 0;
                    const isPotongGaji = (inv.payMethod || (inv as any).metodePembayaran || '').toLowerCase().includes('gaji');
                    const items = Array.isArray(inv.items) ? inv.items : [];
                    const totalItemQty = items.reduce((sum, it) => sum + (Number(it.qty) || 0), 0);
                    const sisa = Number(inv.sisa || 0);

                    return (
                      <tr key={idx} className="hover:bg-stone-50/80 transition group">
                        {/* 1. No. Nota */}
                        <td className="py-2 px-3.5 font-mono">
                          <div className="flex items-center gap-1.5">
                            <span className="font-black text-red-700">{inv.invoiceNo}</span>
                            <button
                              type="button"
                              onClick={() => handleCopyNoNota(inv.invoiceNo)}
                              className="p-1 text-stone-400 hover:text-stone-700 rounded transition opacity-0 group-hover:opacity-100 cursor-pointer"
                              title="Salin No. Nota"
                            >
                              {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                        </td>

                        {/* 2. Waktu */}
                        <td className="py-2 px-3 text-stone-600 whitespace-nowrap">
                          <div className="font-semibold text-stone-800">{inv.date}</div>
                          <div className="text-[10px] text-stone-400">{inv.time}</div>
                        </td>

                        {/* 3. Pelanggan & Divisi */}
                        <td className="py-2 px-3.5">
                          <div className="flex flex-col gap-0.5">
                            <span className="font-bold text-stone-900">{custName}</span>
                            {custDivision && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200/60 w-max">
                                <Building2 className="w-2.5 h-2.5" />
                                <span>{custDivision}</span>
                              </span>
                            )}
                            {inv.originalCustomer && inv.originalCustomer.toLowerCase() !== custName.toLowerCase() && (
                              <span className="text-[10px] text-amber-700 font-medium">
                                (Semula: "{inv.originalCustomer}")
                              </span>
                            )}
                          </div>
                        </td>

                        {/* 4. Item Belanja Preview */}
                        <td className="py-2 px-3 max-w-[280px]">
                          <div className="text-stone-700">
                            <div className="font-extrabold text-[11px] text-stone-800 mb-0.5">
                              {items.length} Barang <span className="font-normal text-stone-400">({totalItemQty} pcs)</span>
                            </div>
                            <div className="text-[10px] text-stone-500 truncate" title={items.map((it) => `${it.nama} (${it.qty})`).join(', ')}>
                              {items.map((it) => `${it.nama} (${it.qty})`).join(', ') || '-'}
                            </div>
                          </div>
                        </td>

                        {/* 5. Kasir */}
                        <td className="py-2 px-3 text-stone-700 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 font-semibold text-[11px]">
                            {inv.cashier || 'Admin'}
                          </span>
                        </td>

                        {/* 6. Metode */}
                        <td className="py-2 px-3 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${
                            isPotongGaji
                              ? 'bg-amber-50 text-amber-900 border-amber-200'
                              : (inv.payMethod || '').toLowerCase().includes('transfer')
                              ? 'bg-blue-50 text-blue-900 border-blue-200'
                              : 'bg-stone-100 text-stone-800 border-stone-200'
                          }`}>
                            {inv.payMethod || (inv as any).metodePembayaran || 'Tunai'}
                          </span>
                        </td>

                        {/* 7. Total & Sisa */}
                        <td className="py-2 px-3 text-right whitespace-nowrap font-mono">
                          <div className="font-black text-stone-900 text-xs">
                            {fRp(inv.total)}
                          </div>
                          {sisa > 0 ? (
                            <div className="text-[10px] font-black text-rose-600">
                              Sisa: {fRp(sisa)}
                            </div>
                          ) : (
                            <div className="text-[10px] font-semibold text-emerald-600">
                              Lunas
                            </div>
                          )}
                        </td>

                        {/* 8. Status */}
                        <td className="py-2 px-3 text-center whitespace-nowrap">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                              isLunas
                                ? 'bg-emerald-100 text-emerald-800'
                                : isPotongGaji
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {isLunas ? 'LUNAS' : isPotongGaji ? 'POTONG GAJI' : 'BELUM LUNAS'}
                          </span>
                        </td>

                        {/* 9. Aksi */}
                        <td className="py-2 px-3.5 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => setSelectedInvoice(inv)}
                              className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 font-extrabold text-[11px] rounded-lg transition cursor-pointer flex items-center gap-1 shadow-2xs"
                              title="Lihat Rincian Nota Lengkap"
                            >
                              <Eye className="w-3 h-3 text-stone-600" />
                              <span>Lihat Item</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handlePrintNotaThermal(inv)}
                              className="p-1 hover:bg-stone-200 text-stone-600 rounded-lg transition cursor-pointer"
                              title="Cetak Ulang Nota Kasir"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-stone-400">
                      <Receipt className="w-10 h-10 mx-auto text-stone-300 mb-2" />
                      <p className="font-bold text-xs">Tidak ada transaksi yang cocok dengan kriteria pencarian.</p>
                      <p className="text-[11px] text-stone-400 mt-0.5">Ubah kata kunci pencarian atau sesuaikan filter di atas.</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Table Footer Summary */}
          {displayedTableInvoices.length > 0 && (
            <div className="px-4 py-2.5 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between text-xs text-stone-600 font-medium shrink-0">
              <span className="text-[11px] text-stone-500">
                Menampilkan <strong>{displayedTableInvoices.length}</strong> dari <strong>{filteredInvoices.length}</strong> transaksi nota
              </span>
              <div className="flex items-center gap-4 text-[11px]">
                <span>
                  Total Omset: <strong className="font-mono text-red-700 font-black">{fRp(displayedTableInvoices.reduce((a, b) => a + Number(b.total || 0), 0))}</strong>
                </span>
                <span>
                  Total Sisa: <strong className="font-mono text-rose-600 font-bold">{fRp(displayedTableInvoices.reduce((a, b) => a + Number(b.sisa || 0), 0))}</strong>
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= MODAL DETAIL INVOICE ================= */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-red-700" />
                  <span>Detail Nota: {selectedInvoice.invoiceNo}</span>
                </h3>
                <p className="text-[11px] text-stone-500">{selectedInvoice.date} • {selectedInvoice.time} • Kasir: {selectedInvoice.cashier}</p>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-xs space-y-3">
              <div className="flex justify-between bg-stone-50 p-2.5 rounded-xl border border-stone-100">
                <div>Pelanggan: <strong className="text-stone-900">{selectedInvoice.customer}</strong></div>
                <div>Metode: <strong className="text-stone-900">{selectedInvoice.payMethod}</strong></div>
              </div>

              <div className="max-h-56 overflow-y-auto space-y-1.5 border border-stone-100 rounded-xl p-2">
                {selectedInvoice.items && selectedInvoice.items.map((it, i) => (
                  <div key={i} className="flex justify-between items-center py-1 border-b border-stone-50 last:border-none">
                    <div>
                      <div className="font-bold text-stone-800">{it.nama}</div>
                      <div className="text-[10px] text-stone-400">{it.qty} {it.satuan} × {fRp(it.harga)}</div>
                    </div>
                    <div className="font-black text-stone-900">
                      {fRp(it.totalItem !== undefined ? it.totalItem : it.qty * it.harga)}
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-1 pt-1 text-right text-xs">
                <div className="flex justify-between text-stone-500">
                  <span>Subtotal:</span>
                  <span>{fRp(selectedInvoice.subtotal || selectedInvoice.total)}</span>
                </div>
                {selectedInvoice.discAmt > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Diskon:</span>
                    <span>- {fRp(selectedInvoice.discAmt)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-black text-stone-900 pt-1 border-t border-stone-100">
                  <span>Total Nota:</span>
                  <span className="text-red-700">{fRp(selectedInvoice.total)}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedInvoice(null)}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
