export interface Product {
  kode: string;
  nama: string;
  harga: number; // Harga Jual di Kasir POS
  hargaBeli?: number; // Harga Beli / Modal / HPP
  hpp?: number; // Alias HPP
  kategori: string;
  stok: string | number;
  satuan: string;
  tipeHarga: 'ukuran' | 'fix' | string;
}

export interface KasirUser {
  nama: string;
  password?: string;
  role?: 'owner' | 'spv' | 'kasir' | string;
}

export interface Customer {
  nama: string;
  kelas: 'Umum' | 'Karyawan' | string;
  divisi?: string;
  division?: string;
  diskon?: number;
  telepon: string;
  catatan: string;
  alamat: string;
  oldNames?: string[];
}

export interface ActivityLog {
  id: string;
  timestamp: number;
  date: string; // YYYY-MM-DD or DD/MM/YYYY
  time: string; // HH:mm
  type: 'penjualan' | 'barang_masuk' | 'tambah_produk' | 'edit_harga' | 'hapus_produk' | 'pelunasan' | 'void_invoice' | 'stok_opname' | 'edit_pelanggan';
  actor: string; // Cashier / Admin name
  title: string;
  description: string;
  metadata?: {
    invoiceNo?: string;
    customerName?: string;
    productCode?: string;
    productName?: string;
    oldValue?: any;
    newValue?: any;
    amount?: number;
    qty?: number;
    count?: number;
    payMethod?: string;
    changes?: string[];
    restoredItems?: string;
  };
}

export interface InvoiceItem {
  kode: string;
  nama: string;
  harga: number;
  qty: number;
  satuan: string;
  tipeHarga: 'ukuran' | 'fix' | string;
  panjang: number;
  lebar: number;
  bahan: string;
  catatan: string;
  diskonItem: number;
  totalItem?: number;
}

export interface InvoiceAuditLog {
  editedBy: string;
  editedAt: string;
  reason: string;
  previousTotal?: number;
  previousPayMethod?: string;
  previousDp?: number;
  previousSisa?: number;
  previousCustomer?: string;
}

export interface Invoice {
  invoiceNo: string;
  noInvoice?: string;
  date: string;
  time: string;
  customer: string;
  pelanggan?: string;
  cashier: string;
  subtotal: number;
  discPct: number;
  discAmt: number;
  taxPct: number;
  taxAmt: number;
  negoAmt: number;
  total: number;
  payMethod: string;
  metodePembayaran?: string;
  dp: number;
  sisa: number;
  kembalian: number;
  deadline: string;
  status: 'LUNAS' | 'DP' | string;
  customerPhone?: string;
  customerAddress?: string;
  originalCustomer?: string;
  originalDivisi?: string;
  divisi?: string;
  division?: string;
  items: InvoiceItem[];
  pelunasanHistory?: PelunasanRecord[];
  historiPelunasan?: PelunasanRecord[];
  lastEditedBy?: string;
  lastEditedAt?: string;
  editReason?: string;
  auditLogs?: InvoiceAuditLog[];
  slipNo?: number;
  slipPrinted?: boolean;
  slipPrintedAt?: string;
}

export interface StoreSettings {
  name: string;
  tagline?: string;
  address: string;
  phone: string;
  footer: string;
  cashier: string;
  prefixInvoice?: string;
  autoLogoutMinutes?: number;
  rekening?: string;
  minStockThreshold?: number;
  storeName?: string;
}

export interface PiutangItem {
  invoiceNo: string;
  date: string;
  customer: string;
  total: number;
  dp: number;
  sisa: number;
  deadline: string;
  historiPelunasan?: PelunasanRecord[];
}

export interface PelunasanRecord {
  id?: string;
  invoiceNo: string;
  date: string;
  time: string;
  customer?: string;
  cashier: string;
  kasir?: string;
  payMethod: string;
  jumlahBayar: number;
  sisaAwal?: number;
  newSisa?: number;
  kembalian?: number;
  status?: string;
  catatan?: string;
}

export interface StockInRecord {
  id: string;
  kode: string;
  kodeProduct?: string;
  nama: string;
  namaProduct?: string;
  qty: number;
  jumlahMasuk?: number;
  hargaBeli?: number; // Harga Beli / Modal saat barang masuk
  satuan: string;
  supplier: string;
  cashier: string;
  penanggungJawab?: string;
  date: string;
  tanggal?: string;
  time: string;
  jam?: string;
  catatan?: string;
}

export interface ExpenseRecord {
  id: string;
  tanggal: string; // YYYY-MM-DD
  kategori: string; // e.g. 'Bahan Baku', 'Gaji / Honorer', 'Sewa & Utilitas', 'Operasional & Makanan', 'Maintenance & Service', 'Lain-lain'
  keterangan: string;
  nominal: number;
  pj: string; // Cashier / Admin name
  buktiRef?: string;
}

export interface StockOpnameItem {
  kode: string;
  nama: string;
  satuan: string;
  kategori: string;
  stokSistem: number; // Stok buku tercatat di aplikasi
  stokFisik: number; // Stok real hasil hitungan fisik di toko/gudang
  selisih: number; // stokFisik - stokSistem
  hargaBeli: number; // HPP / Harga beli per unit
  hargaJual?: number; // Harga jual
  nilaiSelisih: number; // selisih * hargaBeli (atau hargaJual)
  status: 'sesuai' | 'kurang' | 'lebih';
  catatan?: string; // Alasan selisih (rusak, hilang, kadaluarsa, dsb.)
}

export interface StockOpnameRecord {
  id: string; // e.g. "OPN-202608-001"
  tanggal: string; // YYYY-MM-DD
  jam: string; // HH:mm
  bulanPeriode: string; // e.g. "Agustus 2026"
  petugas: string; // Kasir / Staf yang menghitung
  penanggungJawab?: string; // SPV / Saksi / Owner
  totalItemDihitung: number;
  totalItemSesuai: number;
  totalItemSelisihKurang: number;
  totalItemSelisihLebih: number;
  totalNilaiSelisihKurang?: number;
  totalNilaiSelisihLebih?: number;
  totalNilaiSelisih: number; // Total rupiah nilai selisih
  catatanUmum?: string;
  items: StockOpnameItem[];
  createdAt?: any;
  updatedAt?: any;
}

export type MainViewTab = 'transaksi' | 'barang_masuk' | 'stok_opname' | 'piutang' | 'pelanggan' | 'laporan_penjualan' | 'pencarian_rekap';

export interface GasResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  invoiceNo?: string;
  alreadyLunas?: boolean;
  newSisa?: number;
  kembalian?: number;
  status?: string;
  total?: number;
  pelanggan?: string;
}

export type ViewTab = 'catalog' | 'cart' | 'preview' | 'pelunasan' | 'settings' | 'guide';
